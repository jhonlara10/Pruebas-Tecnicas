import 'dart:async';
import 'package:neivor_flutter_app/domain/models/settings/setting.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../../domain/models/settings/copy.dart';

class DatabaseHelper {
  static Database? _database;

  static final DatabaseHelper db = DatabaseHelper._();

  DatabaseHelper._();

  Future<Database?> get database async {
    // If database exists, return database.
    if (_database != null) return _database;
    // If database don't exists, create one.
    _database = await initDb();
    return _database;
  }

  initDb() async {
    String dbPath = await getDatabasesPath();
    String path = join(dbPath, "neivor.db");
    return await openDatabase(
      path,
      version: 1,
      // ignore: no-empty-block
      onOpen: (db) {},
      onCreate: (Database db, int version) async {
        await db.execute(
          "CREATE TABLE Setting(id INTEGER PRIMARY KEY, state INTEGER, key TEXT, value TEXT)",
        );
        await db.execute(
          "CREATE TABLE Copy(id INTEGER PRIMARY KEY, key TEXT, value TEXT)",
        );
      },
    );
  }

  // Insert setting on database.
  createSettings(List<Setting> settingsObject) async {
    await deleteAllSettings();
    final db = await database;
    for (var element in settingsObject) {
      await db?.insert('Setting', element.toJson());
    }
  }

  // Insert copy on database.
  createCopies(List<Copy> copiesObjects) async {
    await deleteAllCopies();
    final db = await database;
    for (var element in copiesObjects) {
      await db?.insert('Copy', element.toJson());
    }
  }

  // Delete all copies.
  Future<int?> deleteAllCopies() async {
    final db = await database;
    return await db?.rawDelete('DELETE FROM Copy');
  }

  // Delete all settings.
  Future<int?> deleteAllSettings() async {
    final db = await database;
    return await db?.rawDelete('DELETE FROM Setting');
  }

  Future<String> getCopy(String key) async {
    final db = await database;
    List<Map<String, dynamic>>? result =
        await db?.rawQuery('SELECT * FROM Copy WHERE key=?', [key]);
    return result?.first['value'];
  }

  Future<String> getProperty(String key) async {
    final db = await database;
    List<Map<String, dynamic>>? result =
        await db?.rawQuery('SELECT * FROM Setting WHERE key=?', [key]);
    return result?.first['value'];
  }
}
