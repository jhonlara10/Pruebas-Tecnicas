import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a json list of tickets, converts them to a list of TicketsRequestResponse objects,
/// reverses the list, and returns the reversed list
///
/// Args:
///   parsed (List<dynamic>): List of dynamic objects
///
/// Returns:
///   A list of TicketsRequestResponse objects.
List<TicketsRequestResponse> parseTickets(List<dynamic> parsed) {
  List<TicketsRequestResponse> converted = [];
  for (var element in parsed) {
    converted.add(TicketsRequestResponse.fromJson(element));
  }

  return converted.reversed.toList();
}

/// It takes an API response, converts them to a list of TicketGetMessagesResponse objects,
/// and returns the list
///
/// Args:
///   parsed (List<dynamic>): The list of dynamic objects that you get from the JSON.
///
/// Returns:
///   A list of TicketGetMessagesResponse objects.
List<TicketGetMsgResponse> parseMessages(List<dynamic> parsed) {
  List<TicketGetMsgResponse> converted = [];
  for (var element in parsed) {
    converted.add(TicketGetMsgResponse.fromJson(element));
  }

  return converted;
}

/// It takes a list Returned from API, and parse a list of integers
///
/// Args:
///   toParse (List<dynamic>): The list of dynamic objects to parse.
///
/// Returns:
///   A list of integers.
List<int> parseIds(List<dynamic> toParse) {
  List<int> converted = [];
  for (var element in toParse) {
    converted.add(element as int);
  }

  return converted;
}

/// It gets a list of tickets from an API
///
/// Returns:
///   A Future<List<TicketsRequestResponse>>
Future<List<TicketsRequestResponse>> getTickets() async {
  String url = await AppUrls().getUrl(AppApiConstants.pqrUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  //User? currentUser = UserUtils.currentUser;
  final Response response;
  response = await dioClient.get(
    '${Constants.complaintDemandPath}${UserUtils.currentServicePoint?.id}${Constants.zyosUserPath}${UserUtils.currentUser?.id}${Constants.enterprise}${UserUtils.currentEnterprise?.id}',
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseTickets(response.data);
  } else {
    throw Exception("Can't load ticket list");
  }
}

/// It gets the current user, then it gets the current enterprise, then it gets the list of admins for
/// that enterprise, then it parses the ids from the response
///
/// Returns:
///   A list of integers.
Future<List<int>> getAdminsIds() async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.get(
    '${Constants.adminsByEnterprisePath}${UserUtils.currentEnterprise?.id.toString()}',
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseIds(response.data);
  } else {
    throw Exception("Can't load admin id list");
  }
}

/// It takes a map to create a ticket, sends it to the server, and returns a response
///
/// Args:
///   data (Map<String, dynamic>): {
///
/// Returns:
///   A Future<TicketsAddResponse>
Future<TicketsAddResponse> createTicket(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.pqrUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(
    Constants.complaintDemand,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return TicketsAddResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create ticket data");
  }
}

/// Updates ticket
///
/// Args:
///   data (Map<String, dynamic>): is the data that is sent to the server.
///
/// Returns:
///   A Future<TicketsAddResponse>
Future<TicketsAddResponse> updateTicket(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.pqrUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(
    Constants.complaintDemand,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return TicketsAddResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create ticket data");
  }
}

/// Send a message to the ticket conversation
/// object
///
/// Args:
///   data (Map<String, dynamic>): This is the data that you want to send to the server.
///
/// Returns:
///   A Future<SendTicketMessageResponse>
Future<SendTicketMessageResponse> sendTicketMessage(
  Map<String, dynamic> data,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(
    Constants.sendMessagePath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return SendTicketMessageResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create ticket data");
  }
}

/// get the tconversation from selected ticket
///
///
/// Args:
///   idConversation: The id of the conversation
///   idEnterprise: The id of the enterprise
///   idUser: The user's ID
///
/// Returns:
///   A Future<List<TicketGetMessagesResponse>>
Future<List<TicketGetMsgResponse>> getTicketMessage(
  idConversation,
  idEnterprise,
  idUser,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.get(
    "${Constants.conversationPath}$idConversation/enterprise/$idEnterprise/user/$idUser",
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseMessages(response.data);
  } else {
    throw Exception("Can't Create ticket data");
  }
}

/// send notification email in conversation
///
/// Args:
///   data (Map<String, dynamic>): The data to be sent as the request body.
///
/// Returns:
///   A Future<TicketsAddResponse>
Future<TicketsAddResponse> sendEmail(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(
    Constants.emailPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return TicketsAddResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create ticket data");
  }
}
