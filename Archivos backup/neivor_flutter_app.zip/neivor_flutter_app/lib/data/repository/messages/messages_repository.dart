import 'package:neivor_flutter_app/domain/models/settings/messages_request.dart';
import 'package:neivor_flutter_app/domain/models/settings/copy.dart';

/// Interface to create methods of messages features.
abstract class IMessagesRepository {
  Future<List<Copy>> getMessages(MessagesRequest messagesRequest);
}
