import 'dart:convert';

import 'package:neivor_flutter_app/data/repository/messages/messages_repository.dart';
import 'package:neivor_flutter_app/domain/models/settings/copy.dart';
import 'package:neivor_flutter_app/domain/models/settings/country.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/settings/messages_request.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Repository implementation for Messages copies API.
class MessagesRepository implements IMessagesRepository {
  /// Getting generic httpClient using master API base url.
  Dio dioClient = HttpClientFactory.getHttpClient(Constants.masterBaseUrl);

  /// Obtaining messages list from API by country and language
  ///
  /// Returns [Country] list if API response is 200.
  /// [Exception] if any error is on the way
  @override
  // ignore: long-method
  Future<List<Copy>> getMessages(MessagesRequest messagesRequest) async {
    try {
      final response = await dioClient.post(
        Constants.messagesPath,
        data: messagesRequest.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        var copiesList = parseCopies(response.data);
        var sharedPreferences = await SharedPreferences.getInstance();
        sharedPreferences.setInt(
          "language",
          int.parse(messagesRequest.idLanguage ?? "0"),
        );
        sharedPreferences.setString("copies", jsonEncode(copiesList));
        return copiesList;
      } else {
        throw Exception("Can't load messages");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  /// Parsing API response body of messages list to map list.
  ///
  /// Returns [Copy] list.
  List<Copy> parseCopies(dynamic parsed) {
    return parsed.map<Copy>((json) => Copy.fromJson(json)).toList();
  }
}
