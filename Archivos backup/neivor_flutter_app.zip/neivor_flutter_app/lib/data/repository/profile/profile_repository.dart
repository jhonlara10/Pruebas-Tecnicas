import 'package:neivor_flutter_app/domain/models/profile/profile.dart';

/// Interface to create methods of documents features.
abstract class IProfileRepository {
  Future<ProfileData> getProfile();
}
