import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import '../../../domain/models/profile/profile.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a JSON object and returns a ProfileData object
///
/// Args:
///   parsed (dynamic): The JSON data that was returned from the server.
///
/// Returns:
///   A Future&lt;ProfileData&gt;
ProfileData parseProfile(dynamic parsed) {
  return ProfileData.fromJson(parsed);
}

/// Gets the profile data from API
/// object
///
/// Args:
///   userId (int): The user's ID.
///   enterpriseId (int): The id of the enterprise
///   servicePointId (int): The id of the service point
///
/// Returns:
///   A Future<ProfileData>
Future<ProfileData> getProfile(
  int userId,
  int enterpriseId,
  int servicePointId,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);

  final Response response;
  response = await dioClient.get(
    '${Constants.profilePath}/$userId${Constants.servicePoint}$servicePointId${Constants.enterprise}$enterpriseId',
  );

  if (response.statusCode == Constants.httpSuccessCode) {
    return parseProfile(response.data);
  } else {
    throw Exception("Can't load Profile data");
  }
}

/// Updates Profile photo
/// object
///
/// Args:
///   data (UpdatePhotoRequest): UpdatePhotoRequest
///
/// Returns:
///   A Future<UpdatePhotoResponse>
Future<UpdatePhotoResponse> uploadPhoto(UpdatePhotoRequest data) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(
    Constants.updatePhotoPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return UpdatePhotoResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load Profile data");
  }
}

/// Updates profile data
///
/// Args:
///   data (Map<String, dynamic>): {
///
/// Returns:
///   A Future<UpdateProfileResponse>
Future<UpdateProfileResponse> uploadProfile(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(
    Constants.profilePath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return UpdateProfileResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load Profile data");
  }
}

/// Updates visibility for neighbors
///
/// Args:
///   data (Map<String, dynamic>):
///
/// Returns:
///   A Future<UpdateVisibilityResponse>
Future<UpdateVisibilityResponse> updateVisibility(
  Map<String, dynamic> data,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(
    Constants.profilePath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return UpdateVisibilityResponse.fromJson(response.data);
  } else {
    throw Exception("Can't update visibility user");
  }
}

/// Delete Account User
///
/// Args:
///   data (Map<String, dynamic>):
///
/// Returns:
///   A Future<DeleteAccounResponse>
Future<DeleteAccounResponse> deleteUserAccount(
  int idUser,
  Map<String, dynamic> data,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.patch(
    '${Constants.deleteAccountPath}/$idUser',
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return DeleteAccounResponse.fromJson(response.data);
  } else {
    throw Exception("Can't delete user account");
  }
}
