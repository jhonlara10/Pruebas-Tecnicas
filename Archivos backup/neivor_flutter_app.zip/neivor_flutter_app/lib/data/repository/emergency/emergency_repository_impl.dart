// ignore_for_file: use_build_context_synchronously

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/emergency/emergency_bloc.dart';
import 'package:neivor_flutter_app/bloc/emergency/relationship_bloc.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a list of dynamic objects, converts each one to an EmergencyData object, and returns a list
/// of EmergencyData objects
///
/// Args:
///   parsed (List<dynamic>): The list of JSON objects that you want to convert to a list of
/// EmergencyData objects.
///
/// Returns:
///   A list of EmergencyData objects.
List<EmergencyData> parseEmergency(List<dynamic> parsed) {
  List<EmergencyData> converted = [];
  for (var element in parsed) {
    converted.add(EmergencyData.fromJson(element));
  }

  return converted;
}

/// It takes a list of dynamic objects, converts them to a list of Relationship objects, and returns the
/// list of Relationship objects
///
/// Args:
///   parsed (List<dynamic>): The list of JSON objects that you want to convert to a list of
/// Relationship objects.
///
/// Returns:
///   A list of Relationship objects.
List<Relationship> parseRelationship(List<dynamic> parsed) {
  List<Relationship> converted = [];
  for (var element in parsed) {
    converted.add(Relationship.fromJson(element));
  }
  return converted;
}

Dio dioClient = HttpClientFactory.getHttpClient(Constants.masterBaseUrl);

/// I'm using the dio package to make a get request to an API, and if the response is successful, I'm
/// adding the parsed data to a bloc
///
/// Args:
///   idServicePoint (int): the id of the service point
///   context (BuildContext): The context of the widget that calls the function.
///
/// Returns:
///   A list of EmergencyData objects.
Future<List<EmergencyData>> getEmergency(
  int idServicePoint,
  BuildContext context,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient
      .get('${Constants.contactsServicePointPath}$idServicePoint');

  if (response.statusCode == Constants.httpSuccessCode) {
    BlocProvider.of<EmergencyBloc>(context)
        .add(SetNewEmergencyData(parseEmergency(response.data)));
    return parseEmergency(response.data);
  } else {
    throw Exception("Can't emergency list");
  }
}

/// It makes a network call to an API, and if the response is successful, it adds a new event to the
/// bloc
///
/// Args:
///   context (BuildContext): BuildContext
///
/// Returns:
///   A Future<List<Relationship>>
Future<List<Relationship>> getRelationship(BuildContext context) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.get(Constants.relationshipsPath);

  if (response.statusCode == Constants.httpSuccessCode) {
    BlocProvider.of<RelationshipBloc>(context)
        .add(SetNewRelations(parseRelationship(response.data)));

    return parseRelationship(response.data);
  } else {
    throw Exception("Can't load relationship list");
  }
}

/// Creates a new emergency contact
///
/// Args:
///   data (Map<String, dynamic>): The data to be sent as the request body.
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> createEmergencyContact(
  Map<String, dynamic> data,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(
    Constants.contactPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create emergency data");
  }
}

/// Creates a new emergency contact
///
/// Args:
///   data (Map<String, dynamic>): The data to be sent as the request body.
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> editEmergencyContact(
  Map<String, dynamic> data,
) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(
    Constants.contactPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create emergency data");
  }
}

/// It takes a map of data, deletes an emergency contact, and returns a Future of
/// EmergencyResponse
///
/// Args:
///   data (Map<String, dynamic>): {
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> deleteEmergency(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.delete(
    Constants.contactPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't delete emergency contact");
  }
}
