// ignore_for_file: prefer-correct-identifier-length
/// This class only will have variables of network layer.
class Constants {
  static const masterBaseUrl = "http://api.master.neivor.com:8099";
  static const countriesPath = "/private/countries?environment=";
  static const messagesPath = "/private/settings/messages";
  static const settingsPath = "/private/settings/";
  static const filesPath = "/private/v1/files/enterprises/";
  static const documentsPath = "/documents?path=";
  static const contactsServicePointPath = "/private/contacts/service-point/";
  static const relationshipsPath = "/private/relationships";
  static const contactPath = "/private/contact";
  static const servicePointPath = "/private/service-point";
  static const profilePath = "/private/zyos-profile";
  static const updatePhotoPath = "/private/zyos-profile/update-photo";
  static const servicePoint = "/service-point/";
  static const enterprise = "/enterprise/";
  static const enterpriseUsnlashed = "enterprise";
  static const adminsByEnterprisePath = "/private/admins/enterprise/";
  static const complaintDemandPath = "/private/complaint-demand/service-point/";
  static const complaintDemand = "/private/complaint-demand";
  static const zyosUserPath = "/zyosUser/";
  static const countryPath = "/country/";
  static const loginPath = "/public/login";
  static const firstMailPath = "/public/zyos-user/first-mail";
  static const deleteAccountPath = "/private/v1/auths/zyos-user/";
  static const feedbackPath = "/private/feedback";
  static const enviromentPath = "/enviroment";
  static const emailPath = "/private/email";
  static const vehiclePath = "/private/vehicle";
  static const vehiclesPath = "/private/vehicles";
  static const neighborsPath = "/private/neighbors/";
  static const sendMessagePath = "/private/chat/send-message";
  static const conversationPath = "/private/chat/conversation-messages/";
  static const insertVisitPath = "/private/insert-visit";
  static const insertPlatePhoto = "/private/v1/visits/visits";
  static const markEntryVisitPath = "/private/v1/visitors/visitors";
  static const insertDocumentPhoto = "/private/update-photo-visitor";
  static const listVisits = "/private/v1/visits/visits";
  static const deleteVisits = "/private/v1/visitors/zyos-users";
  static const validateQr = "/private/validate-qr";
  static const petsPath = "/private/pets";
  static const petPath = "/private/pet";
  static const parkingsPath = "/private/parkings";
  static const inboxPath = "/private/chat/inbox/";
  static const paymentServicePointPath = "/private/v1/payments/service-points/";
  static const invoicePending = 1;
  static const invoicePayed = 2;
  static const invoiceOverdue = 3;
  static const invoicePartialPayment = 4;
  static const invoiceProcess = 5;
  static const conciliationPath = "/private/conciliation";
  static const downloadBalancePath = "/private/v1/payments/downloads/balances";
  static const invoicesPath = "/private/invoices";
  static const zyosUserClabesPath = "/zyos-user-clabes";
  static const daviviendaOfficePaymentPath =
      "/davivienda-office-payments?state=4&stateNotification=0";
  static const daviviendaOfficePaymentDeletePath =
      '/private/v1/payments/davivienda-office-payments/';
  static const debtsPath = "/debts";
  static const daviviendaOfficepayments =
      "/private/v1/payments/davivienda-office-payments";
  static const activePaymentMethodsPath = "/payment-method-types?active=true";
  static const paymentsPath = "/private/v1/payments/enterprises/";
  static const transactionsPath = "/transactions";
  static const deliverPackagesPath = "/private/v1/packs/list/packs";
  static const structureEnterprisePath = "/private/v1/structures/enterprises/";
  static const operationZonesQueryPath = "/operation-zones?page-size=9999";
  static const userPaymentMethodPath = '/private/payments/users/';
  static const paginationServicePointPath =
      "/service-points?page=2&page-size=6&dynamic-name=";
  static const packTypesPath = "/private/v1/packs/pack-types/";
  static const servicePointsDynamicName = "/service-points?dynamic-name=";
  static const servicePointOperationZoneQueryParamPath =
      "/service-points?operation-zone=";
  static const pageSizeQueryParam = "&page-size=9999";
  static const packStateQueryParam = "&pack-state=1&page=0&page-size=10";
  static const packsServicePointParam =
      "/private/v1/packs/packs?service-point=";
  static const distributorsPath = "/distributors";
  static const methods = "/methods";
  static const paymentMethodsPath = "/private/payments/method";
  static const httpSuccessCode = 200;
  static const httpCreatedCode = 201;
  static const json = "application/json";
  static const amenities = "/private/v1/social-areas/enterprises/";
  static const kushkiSuscriptionUrl =
      "https://api.kushkipagos.com/v1/subscription-tokens";
  static const kushkiSettingsUrl =
      'https://api.kushkipagos.com/merchant/v1/merchant/settings';
  static const kushkiSubscriptionsUrl =
      'https://api.kushkipagos.com/v1/subscriptions/';
  static const kushkiCardSuscriptionUrl =
      'https://api.kushkipagos.com/subscriptions/v1/card/';
  static const kushskiPaymentTokenPath =
      "https://api.kushkipagos.com/card/v1/tokens";
  static const kushkiSuscriptionTestUrl =
      "https://api-uat.kushkipagos.com/v1/subscription-tokens";
  static const kushkiSettingsTestUrl =
      'https://api-uat.kushkipagos.com/merchant/v1/merchant/settings';
  static const kushkiSubscriptionsTestUrl =
      'https://api-uat.kushkipagos.com/v1/subscriptions/';
  static const kushkiCardSuscriptionTestUrl =
      'https://api-uat.kushkipagos.com/subscriptions/v1/card/';
  static const kushskiPaymentTokenTestPath =
      "https://api-uat.kushkipagos.com/card/v1/tokens";
  static const payPath = '/private/pay';
  static const user = "/user";
  static const tokens = "/tokens";
  static const sendMailTransaction = "/private/send-mail-transaction";
  static const collectonsFirstPath = "/private/payments/enterprises/";
  static const collectionThirdPath = "/collections";
  static const historicTransaction = "/transactions?state=0";
  static const payResponsePath = '/private/pay-response/';
  static const documentTypesPath = "/private/document-types";
  static const balancesPath = "/private/v1/payments/balances/";
  static const joinGroupPath = "/private/v1/chats/message-recipients";
  static const getFavoritesPath = "/private/visitors-favorite/";
  static const getGroupsPath =
      "/private/v1/chats/conversations/users-not-in?zyos-user=";
  static const andEnterprise = "&enterprise=";
  static const andZyosGroup = "&zyos-group=";
  static const leaveGroupPath =
      "/private/v1/chats/message-recipients/zyos-users/";
  static const conversations = "/conversations/";
  static const queryUserChange = "?userChange=";
  static const schedulePaymentPath = "/private/v1/payments/payment-schedules";
  static const getSchedulePayPath = "/private/v1/payments/enterprises/";
  static const getSchedulePayFinalPath = "/payment-schedules";
  static const deletePaymentMethodPath = "/private/payment-method";
  static const deleteSchedulePay = "/private/v1/payments/payment-schedules/";
  static const publicMerchantIdProd = "b8c9b3bd12f940418fb825644f66a763";
  static const publicMerchantIdTest = "833d039e085242aa8d84497993226b90";
  static const discountDataLogs = "/discount-data-logs";
}
