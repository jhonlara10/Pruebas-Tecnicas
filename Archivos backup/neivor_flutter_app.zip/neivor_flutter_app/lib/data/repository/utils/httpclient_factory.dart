import 'package:chucker_flutter/chucker_flutter.dart';
import 'package:dio/dio.dart';
import 'dart:io';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';

class HttpClientFactory {
  /// Returns specific http client object using [baseUrl] of parameter,
  /// Also putting optional parameters of [connectTimeOut] and [recieveTimeout].
  ///
  /// Return [Dio] http client with custom properties.
  static Dio getHttpClient(
    String baseUrl, {
    int connectTimeOut = 10000,
    int recieveTimeout = 10000,
  }) {
    var dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: connectTimeOut,
      receiveTimeout: recieveTimeout,
      headers: {HttpHeaders.contentTypeHeader: Constants.json},
    ));
    dio.interceptors.add(ChuckerDioInterceptor());
    return dio;
  }
}
