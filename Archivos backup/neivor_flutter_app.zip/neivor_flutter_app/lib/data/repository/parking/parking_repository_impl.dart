import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/parking/parking_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a API response, converts each one to a ParkingResponse object, and returns a
/// list of ParkingResponse objects
///
/// Args:
///   parsed (List<dynamic>): The list of JSON objects that you want to convert to a list of
/// ParkingResponse objects.
///
/// Returns:
///   A list of ParkingResponse objects.
List<ParkingResponse> parseParking(dynamic parsed) {
  return parsed
      .map<ParkingResponse>(
        (json) => ParkingResponse.fromJson(json),
      )
      .toList();
}

/// It makes a GET request to the server, to get parking list, it returns a list of
/// ParkingResponse  objects
///
/// Args:
///   idServicePoint (int): The id of the service point
///
/// Returns:
///   A Future<List<ParkingResponse>
Future<List<ParkingResponse>> getParkings(int idServicePoint) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient
      .get('${Constants.parkingsPath}${Constants.servicePoint}$idServicePoint');

  if (response.statusCode == Constants.httpSuccessCode) {
    return parseParking(response.data);
  } else {
    throw Exception("Can't load parkings list");
  }
}
