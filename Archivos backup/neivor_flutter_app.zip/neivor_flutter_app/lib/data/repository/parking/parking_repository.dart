import 'package:neivor_flutter_app/domain/models/parking/parking_response.dart';

/// Interface to create methods of pets feature.
abstract class IParkingsRepository {
  Future<ParkingResponse> getParkings();
}
