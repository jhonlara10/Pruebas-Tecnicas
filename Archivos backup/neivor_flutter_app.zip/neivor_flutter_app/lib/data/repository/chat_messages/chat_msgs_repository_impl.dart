import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/domain/groups/groups_response.dart';
import 'package:neivor_flutter_app/domain/groups/join_group_response.dart';
import 'package:neivor_flutter_app/domain/models/chat_messages/get_chat_msgs_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

List<GetChatMsgsResponse> parseMessages(List<dynamic> parsed) {
  List<GetChatMsgsResponse> converted = [];
  for (var element in parsed) {
    converted.add(GetChatMsgsResponse.fromJson(element));
  }
  return converted;
}

Dio dioClient = HttpClientFactory.getHttpClient(Constants.masterBaseUrl);

/// I'm using the dio package to make a get request to an API, and if the response is successful, I'm
/// adding the parsed data to a bloc
///
/// Args:
///   idServicePoint (int): the id of the service point
///   context (BuildContext): The context of the widget that calls the function.
///
/// Returns:
///   A list of EmergencyData objects.
Future<List<GetChatMsgsResponse>> getInboxMsgs(BuildContext context) async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.get(
    "${Constants.inboxPath}${UserUtils.currentUser?.id.toString() ?? ''}/${UserUtils.currentEnterprise?.id ?? ''}",
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    // ignore: use_build_context_synchronously
    BlocProvider.of<MessagesBloc>(context)
        .add(NewMessagesEvent(messagesList: parseMessages(response.data)));
    return parseMessages(response.data);
  } else {
    throw Exception("Can't get Chats list");
  }
}

Future<GroupsResponse> getGroups() async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.get(
    "${Constants.getGroupsPath}${UserUtils.currentUser?.id}${Constants.andEnterprise}${UserUtils.currentEnterprise?.id}${Constants.andZyosGroup}${UserUtils.currentZyosGroup?.id}",
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return GroupsResponse.fromJson(response.data);
  } else {
    throw Exception("Can't get Chats list");
  }
}

Future<JoinGroupResponse> joinGroup(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(
    Constants.joinGroupPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return JoinGroupResponse.fromJson(response.data);
  } else {
    throw Exception("Can't get Chats list");
  }
}

Future<JoinGroupResponse> leaveGroup(int idZyosUser, int idGroup) async {
  String url = await AppUrls().getUrl(AppApiConstants.messageUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.delete(
    "${Constants.leaveGroupPath}$idZyosUser${Constants.conversations}$idGroup${Constants.queryUserChange}$idZyosUser",
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return JoinGroupResponse.fromJson(response.data);
  } else {
    throw Exception("Can't get Chats list");
  }
}
