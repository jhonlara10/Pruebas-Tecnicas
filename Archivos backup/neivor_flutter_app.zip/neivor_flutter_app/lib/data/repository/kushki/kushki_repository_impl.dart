// ignore_for_file: long-method
import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:neivor_flutter_app/domain/models/kushki/kushki_settings_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/kushki_suscriptions_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/pay_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/payment_token_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/suscription_token_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

isTest() async {
  var sharedPreferences = await SharedPreferences.getInstance();
  bool? isTest = sharedPreferences.getBool("isTest");
  return isTest ?? false;
}

Future<String> get publicMerchantId async {
  return await isTest()
      ? Constants.publicMerchantIdTest
      : Constants.publicMerchantIdProd;
}

Future<SuscriptionTokenResponse> getSuscriptionToken(
  Map<String, dynamic> data,
) async {
  final Response response;

  Dio dio = Dio();
  dio.options.headers['content-Type'] = Constants.json;
  dio.options.headers["public-merchant-id"] = await publicMerchantId;
  response = await dio.post(
    (await isTest()
        ? Constants.kushkiSuscriptionTestUrl
        : Constants.kushkiSuscriptionUrl),
    data: data,
  );
  if (response.statusCode == Constants.httpCreatedCode) {
    return SuscriptionTokenResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

Future<PaymentTokenResponse?>? getPaymentToken(
  Map<String, dynamic> data,
) async {
  final Response response;

  Dio dio = Dio();
  dio.options.headers['content-Type'] = Constants.json;
  dio.options.headers["public-merchant-id"] = await publicMerchantId;
  try {
    response = await dio.post(
      (await isTest()
          ? Constants.kushskiPaymentTokenTestPath
          : Constants.kushskiPaymentTokenPath),
      data: data,
    );
    if (response.statusCode == Constants.httpCreatedCode) {
      return PaymentTokenResponse.fromJson(response.data);
    }
    return null;
  } on DioError catch (_) {
    return null;
  }
}

Future<KushkiSuscriptionsResponse> getKushkiSuscriptions(
  String suscriptionId,
) async {
  final Response response;

  Dio dio = Dio();
  dio.options.headers['content-Type'] = Constants.json;
  dio.options.headers["public-merchant-id"] = await publicMerchantId;
  response = await dio.post(
    (await isTest()
            ? Constants.kushkiSubscriptionsTestUrl
            : Constants.kushkiSubscriptionsUrl) +
        suscriptionId +
        Constants.user,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return KushkiSuscriptionsResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

Future<SuscriptionTokenResponse> getKushkiCardSuscription(
  String userId,
  Map<String, dynamic> data,
) async {
  final Response response;
  Dio dio = Dio();
  dio.options.headers['content-Type'] = Constants.json;
  dio.options.headers["public-merchant-id"] = await publicMerchantId;
  response = await dio.post(
    (await isTest()
            ? Constants.kushkiCardSuscriptionTestUrl
            : Constants.kushkiCardSuscriptionUrl) +
        userId +
        Constants.tokens,
    data: data,
  );
  if (response.statusCode == Constants.httpCreatedCode) {
    return SuscriptionTokenResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

Future<KushkiSettingsResponse> getKushkiSettings() async {
  final Response response;

  Dio dio = Dio();
  dio.options.headers['content-Type'] = Constants.json;
  dio.options.headers["public-merchant-id"] = await publicMerchantId;
  response = await dio.get(
    await isTest()
        ? Constants.kushkiSettingsTestUrl
        : Constants.kushkiSettingsUrl,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return KushkiSettingsResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

Future<PaymentMethodResponse> getPostPaymentMethod(
  Map<String, dynamic> data,
) async {
  final Response response;

  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    url + Constants.paymentMethodsPath,
    data: data,
    options: Options(
      receiveTimeout: 18000,
    ),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return PaymentMethodResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load pending transaction");
  }
}

// ignore: long-method
Future<PayResponse?>? pay(
  Map<String, dynamic> data,
) async {
  try {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.post(
      url + Constants.payPath,
      data: data,
      options: Options(
        receiveTimeout: 15000,
      ),
    );

    if (response.statusCode == Constants.httpSuccessCode) {
      return PayResponse.fromJson(response.data);
    } else {
      return null;
    }
  } on DioError catch (_) {
    return null;
  }
}
