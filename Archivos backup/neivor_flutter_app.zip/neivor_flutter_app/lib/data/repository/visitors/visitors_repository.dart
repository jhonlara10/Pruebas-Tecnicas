import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/favorite.dart';

abstract class IVisitorsRepository {
  Future<CreateVisitResponse> createVisit(
    CreateVisitRequest createVisitRequest,
  );
  Future<List<Favorite>> obtainFavorites();
}
