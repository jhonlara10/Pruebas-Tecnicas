import 'package:dio/dio.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/delete_visit_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/entry_visit_action_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/entry_visit_action_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/favorite.dart';
import 'package:neivor_flutter_app/domain/models/visitors/insert_document_photo_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/insert_plate_photo_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/insert_plate_photo_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/list_visits_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/scan_qr_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/validate_qr_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class VisitorsRepository implements IVisitorsRepository {
  /// It makes a POST request to the server, and if the response is successful, it returns a [CreateVisitResponse] object
  ///
  /// Params:
  /// [CreateVisitResponse] with visit parameters.
  /// idServicePoint
  /// nameEnterprise
  /// userName
  /// email
  /// idZyosUser
  /// userCreation
  /// visitor object with, name, mobilePhone and favorite
  /// eventName
  /// idVisitPeriod
  /// idVisitCategory
  /// visitDateAsString
  /// initDateAsString
  /// lastDateAsString
  /// idVisitType
  ///
  /// Returns:
  /// A [Future<CreateVisitResponse>] object to the UI
  @override
  // ignore: long-method
  Future<CreateVisitResponse> createVisit(
    CreateVisitRequest? createVisitRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    try {
      final response = await dioClient.post(
        Constants.insertVisitPath,
        data: createVisitRequest?.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return CreateVisitResponse.fromJson(response.data);
      } else {
        throw Exception("Can't insert visit");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<List<Favorite>> obtainFavorites() async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    var currentUser = UserUtils.currentUser;
    try {
      final response = await dioClient.get(
        Constants.getFavoritesPath + (currentUser?.id.toString() ?? ""),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return parseFavorites(response.data);
      } else {
        throw Exception("Can't get favorites");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<InsertPlatePhotoResponse> insertPlatePhoto(
    InsertPlatePhotoRequest? insertPlatePhotoRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    try {
      final response = await dioClient.put(
        Constants.insertPlatePhoto,
        data: insertPlatePhotoRequest?.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return InsertPlatePhotoResponse.fromJson(response.data);
      } else {
        throw Exception("Can't insert plate photo");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<ScanQrResponse> validateQrCode(
    ValidateQrRequest? validateQrRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    try {
      final response = await dioClient.post(
        Constants.validateQr,
        data: validateQrRequest?.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        print(response.data.toString());
        return ScanQrResponse.fromJson(response.data);
      } else {
        throw Exception("Can't insert plate photo");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<InsertPlatePhotoResponse> insertDocumentPhoto(
    InsertDocumentPhotoRequest? insertDocumentPhotoRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    try {
      final response = await dioClient.put(
        Constants.insertDocumentPhoto,
        data: insertDocumentPhotoRequest?.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return InsertPlatePhotoResponse.fromJson(response.data);
      } else {
        throw Exception("Can't insert plate photo");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  /// Parsing API response body of favorites list to map list.
  ///
  /// Returns [Favorites] list.
  List<Favorite> parseFavorites(dynamic parsed) {
    return parsed.map<Favorite>((json) => Favorite.fromJson(json)).toList();
  }

  @override
  // ignore: long-method
  Future<ListVisitsResponse> listVisits() async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final now = DateTime.now();
    var currentUser = UserUtils.currentUser;
    try {
      final response = await dioClient.get(
        '${Constants.listVisits}?enterprise=${currentUser?.currentEnterprise?.id.toString() ?? ''}&servicePoint=${currentUser?.currentServicePoint?.id.toString() ?? ""}&firstDate=${Jiffy(now, 'yyyy-MM-dd').format('yyyy-MM-dd')}',
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return ListVisitsResponse.fromJson(response.data);
      } else {
        throw Exception("Can't list visits");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<DeleteVisitResponse> deleteVisit(int? visitId) async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);

    var currentZyosUser = UserUtils.currentZyosGroup?.id;
    try {
      final response = await dioClient.delete(
        '${Constants.deleteVisits}/$currentZyosUser/visitors/$visitId',
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return DeleteVisitResponse.fromJson(response.data);
      } else {
        throw Exception("Can't delete visit");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<EntryVisitActionResponse> markVisitAsEntry(
    EntryVisitActionRequest? entryVisitActionRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.visitUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    try {
      final response = await dioClient.put(
        Constants.markEntryVisitPath,
        data: entryVisitActionRequest?.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return EntryVisitActionResponse.fromJson(response.data);
      } else {
        throw Exception("Can't mark visit as entry");
      }
    } catch (e) {
      throw Exception(e);
    }
  }
}
