import 'package:neivor_flutter_app/domain/models/packages/create_pack_response.dart';
import 'package:neivor_flutter_app/domain/models/packages/delivered_packages_response.dart';

import '../../../domain/models/packages/package_data_response.dart';
import '../../../domain/models/packages/service_point_list_response.dart';

abstract class IPackagesRepository {
  Future<List<ServicePointObject>?> getServicePointListByName(String name);
  Future<PackageDataResponse?>? getPackageListByServicePoint(String sp);
  Future<DeliveredPackagesResponse> deliverPackages(
    List<PackageDataObject> packages,
  );
  Future<CreatePackResponse> createPackage(Map<String, dynamic> data);
}
