import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/domain/models/packages/create_pack_response.dart';
import 'package:neivor_flutter_app/domain/models/packages/delivered_packages_response.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_data_response.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_types_response.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

import '../../../domain/models/packages/list_buildings_response.dart';
import '../../../domain/models/packages/operation_zones_response.dart';
import '../../../domain/models/packages/package_distributors_response.dart';
import '../../../domain/models/packages/service_points_operation_zone.dart';
import '../../../presentation/util/app_api_constants.dart';
import '../../../presentation/util/app_urls.dart';
import '../utils/httpclient_factory.dart';

/// Repository implementation for Packages API.
class PackageRepository implements IPackagesRepository {
  /// Bring the list of Service point by name passed
  /// Params name is the string for do the search
  ///
  /// Returns [List<ServicPointObject>]
  @override
  // ignore: long-method
  Future<List<ServicePointObject>?> getServicePointListByName(
    String name,
  ) async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.get(
      Constants.structureEnterprisePath +
          (UserUtils.currentEnterprise?.id.toString() ?? "") +
          Constants.servicePointsDynamicName +
          name,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      var servicePointResponse =
          ServicePointListResponse.fromJson(response.data);
      return servicePointResponse.data?.list;
    } else {
      throw Exception("Can't get Packages List By Service Point");
    }
  }

  /// Bring the list of Packages by service point
  /// Params sp is the id service point
  ///
  /// Returns [PackageDataResponse] Object.
  @override
  Future<PackageDataResponse?>? getPackageListByServicePoint(String sp) async {
    try {
      final Response response;
      String url = await AppUrls().getUrl(AppApiConstants.packageUrl);
      Dio dioClient = HttpClientFactory.getHttpClient(url);
      Constants.packStateQueryParam;
      response = await dioClient.get(
        Constants.packsServicePointParam + sp + Constants.packStateQueryParam,
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return PackageDataResponse.fromJson(response.data);
      } else {
        print(response.statusCode);
      }
    } on DioError catch (e) {
      print(e);
    }
  }

  /// It takes a JSON object and returns a PackagesTypesResponse object
  ///
  /// Args:
  ///   parsed (dynamic): The JSON data that was returned from the server.
  ///
  /// Returns:
  ///   A Future<PackagesTypesResponse>
  Future<PackagesTypesResponse> getPackageTypes() async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.packageUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.get(
      Constants.packTypesPath,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return PackagesTypesResponse.fromJson(response.data);
    } else {
      throw Exception("Can't get Packages Types");
    }
  }

  /// It takes a JSON object and returns a PackagesDistributorsResponse object
  ///
  /// Args:
  ///   idPackType (int): The id of package type, it can be 1, 2 or 3.
  ///
  /// Returns:
  ///   A Future<PackagesDistributorsResponse>
  Future<PackagesDistributorsResponse> getPackagesDistributors(
    int idPackType,
  ) async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.packageUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);

    response = await dioClient.get(
      Constants.packTypesPath +
          idPackType.toString() +
          Constants.distributorsPath,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return PackagesDistributorsResponse.fromJson(response.data);
    } else {
      throw Exception("Can't get Packages Types");
    }
  }

  /// /// It takes a JSON object and returns a ServicePointsOperationZone object
  ///
  /// Args:
  ///   parsed (dynamic): The JSON data that was returned from the server.
  ///
  /// Returns:
  ///   A Future<ServicePointsOperationZone>
  // ignore: long-method
  Future<ServicePointsOperationZoneResponse>
      getServicePointsOperationZone() async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    var currentUser = UserUtils.currentUser;
    response = await dioClient.get(
      Constants.structureEnterprisePath +
          (UserUtils.currentEnterprise?.id.toString() ?? "") +
          Constants.servicePointOperationZoneQueryParamPath +
          (currentUser?.currentServicePoint?.operationZone?.id.toString() ??
              "") +
          Constants.pageSizeQueryParam,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return ServicePointsOperationZoneResponse.fromJson(response.data);
    } else {
      throw Exception("Can't get List Servie Points");
    }
  }

  /// It takes a JSON object and returns a ServicePointsOperationZone object
  ///
  /// Args:
  ///   parsed (dynamic): The JSON data that was returned from the server.
  ///
  /// Returns:
  ///   A Future<ServicePointsOperationZone>
  Future<OperationZonesResponse> getOperationZonesResponse() async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.get(
      Constants.structureEnterprisePath +
          (UserUtils.currentEnterprise?.id.toString() ?? "") +
          Constants.operationZonesQueryPath,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return OperationZonesResponse.fromJson(response.data);
    } else {
      throw Exception("Can't get List Servie Points");
    }
  }

  /// It takes a JSON object and returns a ListBuildingsResponse object
  ///
  /// Args:
  ///   parsed (dynamic): The JSON data that was returned from the server.
  ///
  /// Returns:
  ///   A Future<ListBuildingsResponse>
  Future<ListBuildingsResponse> getListBuildingsResponse(String? name) async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.get(
      Constants.structureEnterprisePath +
          (UserUtils.currentEnterprise?.id.toString() ?? "") +
          Constants.paginationServicePointPath +
          (name ?? ""),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return ListBuildingsResponse.fromJson(response.data);
    } else {
      throw Exception("Can't get List Buildings");
    }
  }

  @override
  Future<DeliveredPackagesResponse> deliverPackages(
    List<PackageDataObject> packages,
  ) async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.packageUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.patch(
      Constants.deliverPackagesPath,
      data: jsonEncode(packages),
      options: Options(),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return DeliveredPackagesResponse.fromJson(response.data);
    } else {
      throw Exception("Can't deliver packages");
    }
  }

  /// It takes a JSON object and returns a ListBuildingsResponse object
  ///
  /// Args:
  ///   parsed (dynamic): The JSON data that was returned from the server.
  ///
  /// Returns:
  ///   A Future<CreatePackResponse>
  @override
  Future<CreatePackResponse> createPackage(Map<String, dynamic> data) async {
    final Response response;
    String url = await AppUrls().getUrl(AppApiConstants.packageUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    response = await dioClient.post(
      '/private/v1/packs/packs',
      data: data,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return CreatePackResponse.fromJson(response.data);
    } else {
      throw Exception("Can't create package");
    }
  }
}
