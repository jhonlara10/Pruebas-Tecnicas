import 'package:neivor_flutter_app/domain/models/pets/pets_response.dart';

/// Interface to create methods of pets feature.
abstract class IPetsRepository {
  Future<PetsResponse> getPets();
}
