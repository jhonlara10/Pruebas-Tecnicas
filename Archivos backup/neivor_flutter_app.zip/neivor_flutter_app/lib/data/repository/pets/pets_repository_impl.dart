import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';
import 'package:neivor_flutter_app/domain/models/pets/pets.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a API response, converts each one to a PetsResponse object, and returns a
/// list of PetsResponse objects
///
/// Args:
///   parsed (List<dynamic>): The list of JSON objects that you want to convert to a list of
/// PetsResponse objects.
///
/// Returns:
///   A list of PetsResponse objects.
List<PetsResponse> parsePets(List<dynamic> parsed) {
  List<PetsResponse> converted = [];
  for (var element in parsed) {
    converted.add(PetsResponse.fromJson(element));
  }
  return converted;
}

/// It makes a GET request to the server, to get pets list, it returns a list of
/// PetsResponse  objects
///
/// Args:
///   idServicePoint (int): The id of the service point
///
/// Returns:
///   A Future<List<PetsResponse>
Future<List<PetsResponse>?>? getPets(int idServicePoint) async {
  try {
    String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final Response response;
    response = await dioClient
        .get('${Constants.petsPath}${Constants.servicePoint}$idServicePoint');

    if (response.statusCode == Constants.httpSuccessCode) {
      return parsePets(response.data);
    } else {
      throw Exception("Can't load pets list");
    }
  } catch (e) {
    return null;
  }
}

/// It takes a map of data, sends it to the server to create a new pet, and returns a response
///
/// Args:
///   data (Map<String, dynamic>): data of new pet to insert
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> addPet(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(Constants.petPath, data: data);
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't add Pet");
  }
}

/// It Makes Delete request, delete a register of pet
///
/// Args:
///   data (Map<String, dynamic>): dat of pet
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> deletePet(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.delete(
    Constants.petPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't deteled Pet");
  }
}

/// It Makes Update request, update a register of pet
///
/// Args:
///   data (Map<String, dynamic>): dat of pet
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> updatePet(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(Constants.petPath, data: data);
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't update Pet");
  }
}
