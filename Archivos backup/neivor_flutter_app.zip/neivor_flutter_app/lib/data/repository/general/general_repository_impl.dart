// ignore_for_file: use_build_context_synchronously

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/domain/models/general/change_language_response.dart';
import 'package:neivor_flutter_app/domain/models/general/document_types_response.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/domain/models/general/permissions_request.dart';
import 'package:neivor_flutter_app/domain/models/general/Permission.dart';
import 'package:neivor_flutter_app/domain/models/login/service_point_body.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

//! this file is called general because it will be used to bring data used throughout the app
//! for example the list of service points of all enterprise
/// It takes a API response, converts them to a list of ServicepointRequest objects, and
/// returns the list of ServicepointRequest objects
///
/// Args:
///   toParse (List<dynamic>): List<dynamic>
///
/// Returns:
///   A list of ServicepointRequest objects.
List<ServicepointRequest> parseServicepoints(List<dynamic> toParse) {
  List<ServicepointRequest> converted = [];
  for (var element in toParse) {
    converted.add(ServicepointRequest.fromJson(element));
  }

  return converted;
}

List<DocumentTypesResponse> parseDocumentTypes(List<dynamic> toParse) {
  List<DocumentTypesResponse> converted = [];
  for (var element in toParse) {
    converted.add(DocumentTypesResponse.fromJson(element));
  }

  return converted;
}

/// It takes response JSON, converts each one to a NeighborsResponse object, and returns a
/// list of NeighborsResponse objects
///
/// Args:
///   toParse (List<dynamic>): The list of dynamic objects to parse.
///
/// Returns:
///   A list of NeighborsResponse objects.
List<NeighborsResponse> parseNeighbors(List<dynamic> toParse) {
  List<NeighborsResponse> converted = [];
  for (var element in toParse) {
    converted.add(NeighborsResponse.fromJson(element));
  }

  return converted;
}

/// It makes a GET request to the server, and if the response is successful, it parses the response and
/// returns a list of ServicepointRequest objects
///
/// Returns:
///   A Future<List<ServicepointRequest>>
Future<List<ServicepointRequest>> getServicepoints() async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  //User? currentUser = await User().getCurrentUser();
  var currentEnterprise = UserUtils.currentEnterprise?.id ?? '';
  final Response response;
  response = await dioClient.get(
    '${Constants.servicePointPath}/$currentEnterprise/${Constants.enterpriseUsnlashed}',
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseServicepoints(response.data);
  } else {
    throw Exception("Can't load service point list");
  }
}

/// Get the neighbors list from the server and return it as a list of NeighborsResponse objects
///
/// Returns:
///   A Future<List<NeighborsResponse>>
Future<List<NeighborsResponse>> getNeighbors(BuildContext context) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient
      .get('${Constants.neighborsPath}${UserUtils.currentEnterprise?.id}');

  if (response.statusCode == Constants.httpSuccessCode) {
    BlocProvider.of<MessagesBloc>(context)
        .add(NewNeighborsList(neighborsList: parseNeighbors(response.data)));
    return parseNeighbors(response.data);
  } else {
    throw Exception("Can't load Neighbors list");
  }
}

Future<List<DocumentTypesResponse>> getDocumentTypes() async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.get(
    Constants.documentTypesPath,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseDocumentTypes(response.data);
  } else {
    throw Exception("Can't load service point list");
  }
}

// ignore: long-method
Future<ServicePointListResponse> getServicePointList(
  ServicePointBody body,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(
    '/private/v1/structures/enterprises/${body.enterprise}/service-points',
    queryParameters: body.toJson(),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return ServicePointListResponse.fromJson(response.data);
  } else {
    throw Exception("Can't get Packages List By Service Point");
  }
}

// ignore: long-method
Future<ChangeLanguageResponse> changeLenguage(
  Map<String, dynamic> data,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.patch(
    '/private/v1/auths/zyos-user/${UserUtils.currentEnterprise?.id}',
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return ChangeLanguageResponse.fromJson(response.data);
  } else {
    throw Exception("Can't get Change Language");
  }
}

// ignore: long-method
Future<ChangeLanguageResponse> deleteTokens() async {
  final Response response;
  User? currentUser = await User().getCurrentUser();

  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.delete(
    '/private/v1/auths/zyos-users/${currentUser.id}/zyos-user-devices',
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return ChangeLanguageResponse.fromJson(response.data);
  } else {
    throw Exception("Can't delte Tokens");
  }
}

// ignore: long-method
Future<List<Permission>> getPermissions(PermissionsRequest params) async {
  String url = await AppUrls().getUrl(AppApiConstants.authUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  Response response =
      await dioClient.post('/private/funcionalities', data: params.toJson());
  if (response.statusCode == Constants.httpSuccessCode) {
    return response.data
        .map<Permission>((permission) => Permission.fromJson(permission))
        .toList();
  } else {
    throw Exception("Can't delte Tokens");
  }
}
