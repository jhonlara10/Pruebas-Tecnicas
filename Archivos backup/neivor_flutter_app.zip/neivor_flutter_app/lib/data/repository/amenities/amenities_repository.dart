//ignore: prefer-match-file-name
import 'package:neivor_flutter_app/domain/models/amenities/added_booking_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/approve_booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_blocks_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_days_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_days_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/cancel_booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/service_point_info_model.dart';

// ignore: prefer-match-file-name
abstract class IAmenitiesRepository {
  Future<AmenitiesModel> getAmenities(String? enviroment);
  Future<BookingsModel> getBookings(BookingsBody params);
  Future<AvailableBlocksModel> getAvailableBlocks(String? enviroment);
  Future<ServicePointInfoModel> getServicePointInfo(
    int servicePointId,
    int amenityId,
  );
  Future<AddedBookingModel> bookAmenity(BookingBody body);
  Future<AvailableDaysModel> getAvailableDates(AvailableDaysBody body);
  Future<dynamic> cancelBooking(CancelBookingBody body);
  Future<dynamic> approveBooking(ApproveBookingBody body);
  Future<dynamic> rejectBooking(ApproveBookingBody body);
}
