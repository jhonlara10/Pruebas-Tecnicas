import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository.dart';
import 'package:neivor_flutter_app/domain/models/amenities/added_booking_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/amenities/approve_booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_blocks_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_days_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_days_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/cancel_booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/service_point_info_model.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

/// Repository implementation for Countries settings API.
// ignore: prefer-match-file-name
class AmenitiesRepository implements IAmenitiesRepository {
  @override
  Future<AmenitiesModel> getAmenities(String? params) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.get(
      '/private/v1/social-areas/enterprises/${UserUtils.currentEnterprise?.id}/social-areas?operation-zone=${UserUtils.currentEnterprise?.servicePointList?.first.operationZone?.id}&$params',
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return AmenitiesModel.fromJson(response.data);
    } else {
      throw Exception("Failed to load amenities");
    }
  }

  @override
  Future<AvailableBlocksModel> getAvailableBlocks(String? params) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.get(
      '/private/v1/social-areas/blocks?$params',
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return AvailableBlocksModel.fromJson(response.data);
    } else {
      throw Exception("Failed to load blocks");
    }
  }

  @override
  // ignore: long-method
  Future<BookingsModel> getBookings(BookingsBody params) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    String path = '/private/v2/social-areas/events?';
    Response response;
    RegExp exp = RegExp(r'(?<=[a-z])[A-Z]');

    for (var key in params.toJson().keys) {
      var param = params.toJson()[key];
      if (param.runtimeType.toString().contains('List')) {
        path += '&$key=';
        path += (param as List).join('&$key=');
      } else if (param != null) {
        if (path.split('').last != '?') path += '&';
        path += '$key=$param';
      }
    }

    path = path
        .replaceAllMapped(exp, (Match m) => ('-${m.group(0)}'))
        .toLowerCase();

    response = await dioClient.get(path);
    if (response.statusCode == Constants.httpSuccessCode) {
      return BookingsModel.fromJson(response.data);
    } else {
      throw Exception("Failed to load bookings");
    }
  }

  @override
  Future<ServicePointInfoModel> getServicePointInfo(
    int? servicePointId,
    int amenityId,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.get(
      '/private/service-point/validate/enterprise/${UserUtils.currentEnterprise?.id}/social-area/$amenityId/service-point/${servicePointId ?? UserUtils.currentServicePoint?.id}',
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return ServicePointInfoModel.fromJson(response.data);
    } else {
      throw Exception("Failed to load info");
    }
  }

  @override
  Future<AddedBookingModel> bookAmenity(BookingBody params) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.post(
      '/private/v1/social-area/event/add',
      data: params.toJson(),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return AddedBookingModel.fromJson(response.data);
    } else {
      throw Exception("Failed to book amenity");
    }
  }

  @override
  Future<AvailableDaysModel> getAvailableDates(AvailableDaysBody body) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    int? socialArea = body.toJson().remove('social-area');
    final response = await dioClient.get(
      '/private/v1/social-areas/social-areas/$socialArea/days-availabilities',
      queryParameters: body.toJson(),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return AvailableDaysModel.fromJson(response.data);
    } else {
      throw Exception("Failed to get available days");
    }
  }

  @override
  Future cancelBooking(CancelBookingBody params) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.post(
      '/private/v1/social-area/event/delete',
      data: params,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return response.data;
    } else {
      throw Exception("Failed to get available days");
    }
  }

  @override
  Future approveBooking(ApproveBookingBody body) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.post(
      '/private/v1/social-area/event/approve',
      data: body.toJson(),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return response.data;
    } else {
      throw Exception("Failed to approve booking");
    }
  }

  /// Service to reject an amenity booking
  ///
  /// Args:
  ///  [boddy] the object with data needed for the request
  ///
//TODO: se utiliza el mismo body que para aprobar una reserva,
// este endpoint acepta un campo opcional que de momento no se esta utilizando: "denyReason"
  @override
  Future rejectBooking(ApproveBookingBody body) async {
    String url = await AppUrls().getUrl(AppApiConstants.amenitiesUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    final response = await dioClient.post(
      '/private/v1/social-area/event/deny',
      data: body.toJson(),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return response.data;
    } else {
      throw Exception("Failed to reject booking");
    }
  }
}
