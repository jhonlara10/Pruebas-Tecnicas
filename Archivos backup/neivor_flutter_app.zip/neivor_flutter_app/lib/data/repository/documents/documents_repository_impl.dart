import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import '../../../domain/models/documents/document_list.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A DocumentList object.
DocumentList parseDocuments(dynamic parsed) {
  return DocumentList.fromJson(parsed);
}

/// It makes a GET request to the server, and if the response is successful, it returns a DocumentList
/// object
///
/// Returns:
///   A Future<DocumentList>
// ignore: long-method
Future<DocumentList> getDocuments(String? path) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.filesUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = path != null
      ? await dioClient.get(
          '${Constants.filesPath}${UserUtils.currentEnterprise?.id}${Constants.documentsPath}$path',
        )
      : await dioClient.get(
          '${Constants.filesPath}${UserUtils.currentEnterprise?.id}${Constants.documentsPath}',
        );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseDocuments(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}
