import 'package:neivor_flutter_app/domain/models/documents/document_list.dart';

/// Interface to create methods of documents features.
abstract class IDocumentsRepository {
  Future<DocumentList> getDocuments();
}
