import 'package:neivor_flutter_app/domain/models/wish/wish_request.dart';
import 'package:neivor_flutter_app/domain/models/wish/wish_response.dart';

/// Interface to create methods of wish feature.
abstract class IWishRepository {
  Future<WishResponse> makeWish(WishRequest wishRequest);
}
