import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:neivor_flutter_app/data/repository/wish/wish_repository.dart';
import 'package:neivor_flutter_app/domain/models/wish/wish_response.dart';
import 'package:neivor_flutter_app/domain/models/wish/wish_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';

class WishRepository implements IWishRepository {
  ///
  /// Making neivor wish, by POST request.
  ///
  /// Param:
  /// [WishRequest] provided by: feedbackCommentary, idEnterprise, idZyosUser & userCreation;
  ///
  /// return success [WishResponse] DTO when is success, exception either
  @override
  Future<WishResponse> makeWish(WishRequest wishRequest) async {
    String url = await AppUrls().getUrl(AppApiConstants.authUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    var response = await dioClient.put(
      Constants.feedbackPath,
      data: wishRequest.toJson(),
      options: Options(),
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return WishResponse.fromJson(response.data);
    } else {
      throw Exception("Cant make neivor wish");
    }
  }
}
