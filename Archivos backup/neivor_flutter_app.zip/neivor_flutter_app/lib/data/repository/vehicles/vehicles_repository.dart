import 'package:neivor_flutter_app/domain/models/vehicles/vehicles.dart';

/// Interface to create methods of documents features.
abstract class IVehiclesRepository {
  Future<VehiclesResponse> getVehicles();
}
