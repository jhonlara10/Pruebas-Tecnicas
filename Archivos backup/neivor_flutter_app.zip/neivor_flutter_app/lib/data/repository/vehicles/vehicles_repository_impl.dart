import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';
import 'package:neivor_flutter_app/domain/models/vehicles/vehicles_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// It takes a API response, converts each one to a VehiclesResponse object, and returns a
/// list of VehiclesResponse objects
///
/// Args:
///   parsed (List<dynamic>): The list of JSON objects that you want to convert to a list of
/// VehiclesResponse objects.
///
/// Returns:
///   A list of VehiclesResponse objects.
List<VehiclesResponse> parseVehicles(List<dynamic> parsed) {
  List<VehiclesResponse> converted = [];
  for (var element in parsed) {
    converted.add(VehiclesResponse.fromJson(element));
  }
  return converted;
}

/// It makes a GET request to the server, to get vehicles list, it returns a list of
/// VehiclesResponse objects
///
/// Args:
///   idServicePoint (int): The id of the service point
///
/// Returns:
///   A Future<List<VehiclesResponse>>
Future<List<VehiclesResponse>> getVehicles(int idServicePoint) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient
      .get('${Constants.vehiclesPath}${Constants.servicePoint}$idServicePoint');

  if (response.statusCode == Constants.httpSuccessCode) {
    return parseVehicles(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

/// It takes a map of data, sends it to the server to create a new vehicle, and returns a response
///
/// Args:
///   data (Map<String, dynamic>): {
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> addVehicle(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.post(Constants.vehiclePath, data: data);
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

/// It takes a map of data, sends it to the server to update a vehicle, and returns a response
///
/// Args:
///   data (Map<String, dynamic>): {
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> updateVehicle(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.put(Constants.vehiclePath, data: data);
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load document list");
  }
}

/// deletes a vehicle
///
/// Args:
///   data (Map<String, dynamic>): {
///
/// Returns:
///   A Future<EmergencyResponse>
Future<EmergencyResponse> deleteVehicle(Map<String, dynamic> data) async {
  String url = await AppUrls().getUrl(AppApiConstants.structureUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final Response response;
  response = await dioClient.delete(
    Constants.vehiclePath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return EmergencyResponse.fromJson(response.data);
  } else {
    throw Exception("Can't Create emergency data");
  }
}
