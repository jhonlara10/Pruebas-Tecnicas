import 'package:neivor_flutter_app/domain/models/login/first_mail_request.dart';
import 'package:neivor_flutter_app/domain/models/login/first_mail_response.dart';
import 'package:neivor_flutter_app/domain/models/login/google_sign_in_request.dart';
import 'package:neivor_flutter_app/domain/models/login/login_request.dart';
import 'package:neivor_flutter_app/domain/models/login/login_response.dart';

/// Interface to create methods of login feature.
abstract class ILoginRepository {
  Future<LoginResponse> makeLogin(LoginRequest loginRequest);
  Future<LoginResponse> makeGoogleLogin(GoogleSignInRequest loginRequest);
  Future<FirstMailResponse> makeFirstMail(FirstMailRequest firstMailRequest);
}
