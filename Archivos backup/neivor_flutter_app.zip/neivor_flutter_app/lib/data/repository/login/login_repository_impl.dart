import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:neivor_flutter_app/data/repository/login/login_repository.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:neivor_flutter_app/domain/models/login/first_mail_response.dart';
import 'package:neivor_flutter_app/domain/models/login/first_mail_request.dart';
import 'package:neivor_flutter_app/domain/models/login/google_sign_in_request.dart';
import 'package:neivor_flutter_app/domain/models/login/login_response.dart';
import 'package:neivor_flutter_app/domain/models/login/login_request.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginRepositoryImpl implements ILoginRepository {
  /// It makes a POST request to the server, and if the response is successful, it returns a [LoginResponse] object
  /// to be stored on SharedPreferences after jwt is decoded, using JwtDEcoder dart class.
  ///
  /// Params:
  /// LoginRequest with username, password, loginAuthType and firebaseToken object
  ///
  /// Returns:
  /// A [Future<LoginResponse>] object to the UI
  @override
  // ignore: long-method
  Future<LoginResponse> makeLogin(LoginRequest loginRequest) async {
    String url = await AppUrls().getUrl(AppApiConstants.authUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    var sharePreferences = await SharedPreferences.getInstance();
    try {
      final response = await dioClient.post(
        Constants.loginPath,
        data: loginRequest.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return processLoginResponse(response, sharePreferences);
      } else {
        throw Exception("Can't make login");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  /// It makes a POST request to the server, and if the response is successful, it returns a [LoginResponse] object
  /// to be stored on SharedPreferences after jwt is decoded, using JwtDEcoder dart class.
  ///
  /// Params:
  /// GoogleSignInRequest with loginAuthType, apiToken, photo, firebaseToken and email object
  ///
  /// Returns:
  /// A [Future<LoginResponse>] object to the UI
  @override
  // ignore: long-method
  Future<LoginResponse> makeGoogleLogin(
    GoogleSignInRequest loginRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.authUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    var sharedPreferences = await SharedPreferences.getInstance();
    try {
      final response = await dioClient.post(
        Constants.loginPath,
        data: loginRequest.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return processLoginResponse(response, sharedPreferences);
      } else {
        throw Exception("Can't make login");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  @override
  // ignore: long-method
  Future<FirstMailResponse> makeFirstMail(
    FirstMailRequest firstMailRequest,
  ) async {
    String url = await AppUrls().getUrl(AppApiConstants.authUrl);
    Dio dioClient = HttpClientFactory.getHttpClient(url);
    try {
      final response = await dioClient.post(
        Constants.firstMailPath,
        data: firstMailRequest.toJson(),
        options: Options(),
      );
      if (response.statusCode == Constants.httpSuccessCode) {
        return FirstMailResponse.fromJson(response.data);
      } else {
        throw Exception("Can't make first mail");
      }
    } catch (e) {
      throw Exception(e);
    }
  }

  // ignore: long-method
  LoginResponse processLoginResponse(
    Response<dynamic> response,
    SharedPreferences sharePreferences,
  ) {
    var loginResponse = LoginResponse.fromJson(response.data);
    try {
      Map<String, dynamic> decodedToken =
          JwtDecoder.decode(loginResponse.jwt ?? "");
      User user = User.fromJson(decodedToken);
      sharePreferences.setString(
        "currentUser",
        jsonEncode(user),
      );
      sharePreferences.setInt("currentEnterpriseIndex", 0);
      // ignore: empty_catches
    } catch (e) {
    } finally {
      // ignore: control_flow_in_finally
      return loginResponse;
    }
  }
}
