import 'package:neivor_flutter_app/domain/models/settings/country.dart';
import 'package:neivor_flutter_app/domain/models/settings/setting.dart';

/// Interface to create methods of country features.
abstract class ICountryRepository {
  Future<List<Country>> getCountries();
  Future<List<Setting>> getSettingsByCountry(
    String countryCode,
    int countryId,
  );
}
