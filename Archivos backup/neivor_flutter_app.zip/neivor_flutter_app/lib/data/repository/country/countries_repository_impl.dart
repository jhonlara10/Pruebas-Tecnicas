import 'dart:convert';

import 'package:neivor_flutter_app/domain/models/settings/country.dart';
import 'package:neivor_flutter_app/data/repository/country/countries_repository.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/settings/setting.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Repository implementation for Countries settings API.
class CountryRepository implements ICountryRepository {
  /// Getting generic httpClient using master API base url.
  Dio dioClient = HttpClientFactory.getHttpClient(Constants.masterBaseUrl);

  /// Obtaining countries list from API of settings by [enviroment]
  ///
  /// Returns [Country] list if API response is 200.
  /// [Exception] if any error is on the way
  @override
  Future<List<Country>> getCountries() async {
    String enviroment = await getEnviromentKey();
    final response = await dioClient.get(Constants.countriesPath + enviroment);
    if (response.statusCode == Constants.httpSuccessCode) {
      return parseCountries(response.data);
    } else {
      throw Exception("Can't load countries");
    }
  }

  @override
  Future<List<Setting>> getSettingsByCountry(
    String countryCode,
    int countryId,
  ) async {
    String enviroment = await getEnviromentKey();
    final response = await dioClient.get(Constants.settingsPath +
        countryCode +
        Constants.countryPath +
        enviroment +
        Constants.enviromentPath);
    if (response.statusCode == Constants.httpSuccessCode) {
      var settingsList = parseSettings(response.data);
      var sharedPreferences = await SharedPreferences.getInstance();
      sharedPreferences.setInt("countryId", countryId);
      sharedPreferences.setString("settings", jsonEncode(settingsList));
      return settingsList;
    } else {
      throw Exception("Can't load settings");
    }
  }

  /// Parsing API response body of country list to map list.
  ///
  /// Returns [Country] list.
  List<Country> parseCountries(dynamic parsed) {
    return parsed.map<Country>((json) => Country.fromJson(json)).toList();
  }

  /// Parsing API response body of settings list to map list.
  ///
  /// Returns [Country] list.
  List<Setting> parseSettings(dynamic parsed) {
    return parsed.map<Setting>((json) => Setting.fromJson(json)).toList();
  }

  Future<String> getEnviromentKey() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    var isTest = sharedPreferences.getBool("isTest");
    if (isTest != null && isTest) {
      // ignore: format-comment
      // Test Key
      return "8KGEHEChQbxWbHeFJVCgp1Pmc9qTatzhqP5vSg44o0IK0sxWSY";
    } else {
      // ignore: format-comment
      // Production key
      return "b7lWpPRnRUnfHhRHrDQWb21f1vjHdlpkeu3G7M7HBBZgDccwdI";
    }
  }
}
