// ignore_for_file: use_build_context_synchronously

import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/data/repository/utils/httpclient_factory.dart';
import 'package:neivor_flutter_app/domain/models/payment/associate/associate_payment_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/collections/header_admin_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_request.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/debts/service_points_debts_reponse.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/download_balance_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice_request.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/pay_response_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/payment_methods_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/delete_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/delete_schedule_pay.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/discount_data_log_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/get_schedules_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/payment_schedule_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/update_schedule_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/pse/pse_pay_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/spei/davivienda_payment_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/delete_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/historic_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/mail_send_transaction_request.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/mail_send_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_invoice_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A ServicePointDebtsResponse object.
ServicePointDebtsResponse parseServicePointDebtsResponse(dynamic parsed) {
  return ServicePointDebtsResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A List of ConciliationResponse objects.
List<ConciliationResponse> parseConciliationResponse(dynamic parsed) {
  return parsed
      .map<ConciliationResponse>(
        (json) => ConciliationResponse.fromJson(json),
      )
      .toList();
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A List of ConciliationResponse objects.
HistoricTransactionResponse parseHistoricTransaction(dynamic parsed) {
  return HistoricTransactionResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A List of Invoice objects.
List<Invoice> parseInvoicesResponse(dynamic parsed) {
  return parsed
      .map<Invoice>(
        (json) => Invoice.fromJson(json),
      )
      .toList();
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A TransactionResponse object.
TransactionsResponse parseTransactionsResponse(dynamic parsed) {
  return TransactionsResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A TransactionResponse object.
TransactionByInvoiceResponse parseTransactionsInvoiceResponse(dynamic parsed) {
  return TransactionByInvoiceResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A TransactionResponse object.
PendingTransactionResponse parsePendingTransactionResponse(dynamic parsed) {
  return PendingTransactionResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A DeletePendingTransactionResponse object.
DeletePendingTransactionResponse parseDeletePendingTransactionResponse(
  dynamic parsed,
) {
  return DeletePendingTransactionResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A TransactionResponse object.
ZyosUserClabe parseZyosUserClabeResponse(dynamic parsed) {
  return ZyosUserClabe.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A PaymentMethodsResponse object.
PaymentMethodsResponse parsePaymentMethodsResponse(dynamic parsed) {
  return PaymentMethodsResponse.fromJson(parsed);
}

/// It takes a JSON object and returns a Dart object
///
/// Args:
///   parsed (dynamic): The JSON data that you want to parse.
///
/// Returns:
///   A MailSendTransactionResponse object.
MailSendTransactionResponse parseMailSendTransactionResponse(dynamic parsed) {
  return MailSendTransactionResponse.fromJson(parsed);
}

List<UserPaymentMethodResponse> parseUserPaymentMethodsResponse(
  dynamic parsed,
) {
  List<UserPaymentMethodResponse> parsedList = [];
  parsed.forEach((element) {
    parsedList.add(UserPaymentMethodResponse.fromJson(element));
  });
  return parsedList;
}

/// It makes a GET request to the server, and if the response is successful, it returns a ServicePointDebtsResponse
/// object
///
/// Returns:
///   A Future<ServicePointDebtsResponse>
@override
Future<ServicePointDebtsResponse> getServicePointsDebts() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.paymentServicePointPath +
      (UserUtils.currentServicePoint?.id.toString() ?? '') +
      Constants.debtsPath);
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseServicePointDebtsResponse(response.data);
  } else {
    throw Exception("Can't load debts list");
  }
}

/// It makes a GET request to the server, and if the response is successful, it returns a TransactionsResponse
/// object
///
/// Returns:
///   A Future<TransactionsResponse>
@override
// ignore: long-method
Future<TransactionsResponse> getTransactions(int? servicePointId) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.paymentServicePointPath +
      (servicePointId == null
          ? (UserUtils.currentServicePoint?.id.toString() ?? '')
          : servicePointId.toString()) +
      Constants.transactionsPath);
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseTransactionsResponse(response.data);
  } else {
    throw Exception("Can't load transaction list");
  }
}

/// Bring details of the invoice with state approved
///
/// Args:
///   invoice is the number of id invoice
/// Returns:
///   A Future<TransactionByInvoiceResponse>
@override
Future<TransactionByInvoiceResponse> getTransactionByInvoice(
  String invoice,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(
    '${Constants.paymentsPath}${UserUtils.currentEnterprise?.id.toString() ?? ""}${Constants.transactionsPath}?invoice=$invoice&state=0',
  );

  if (response.statusCode == Constants.httpSuccessCode) {
    return parseTransactionsInvoiceResponse(response.data);
  } else {
    throw Exception("Can't load transaction list");
  }
}

/// Send mail with the selected transactions
///
/// Args:
///   transactionData is the list of transactions will send by email
/// Returns:
///   A Future<MailSendTransactionResponse>
@override
// ignore: long-method
Future<MailSendTransactionResponse> sendMailTransaction(
  List<TransactionList> transactionData,
  String initDate,
  String dateCreation,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    Constants.sendMailTransaction,
    data: MailSendTransactionRequest()
        .getMailSendTransactionRequest(transactionData, initDate, dateCreation)
        .toJson()['dataTransactionList'],
    options: Options(),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseMailSendTransactionResponse(response.data);
  } else {
    throw Exception("Couldn't not send mail");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a ServicePointDebtsResponse
/// object
///
/// Returns:
/// A Future<List<ConciliationResponse>>
@override
Future<List<ConciliationResponse>> getConciliation() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    Constants.conciliationPath,
    data: ConciliationRequest().getConciliationRequestByRole().toJson(),
    options: Options(),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseConciliationResponse(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a Invoice
/// object
///
/// Returns:
/// A Future<List<Invoice>>
@override
Future<List<Invoice>> getInvoices(bool isHistory, int? servicePointId) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    Constants.invoicesPath,
    data:
        InvoicesRequest().getInvoiceRequest(isHistory, servicePointId).toJson(),
    options: Options(),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseInvoicesResponse(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a PendingTransaction
/// object
///
/// Returns:
/// A Future<PendingTransaction>
@override
// ignore: long-method
Future<PendingTransactionResponse> getPendingTransaction(
  BuildContext context,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.paymentServicePointPath +
      (UserUtils.currentServicePoint?.id.toString() ?? '') +
      Constants.daviviendaOfficePaymentPath);
  if (response.statusCode == Constants.httpSuccessCode) {
    BlocProvider.of<PaymentsBloc>(context).add(NewPendingTransaction(
      pendingTransactionData: parsePendingTransactionResponse(response.data),
    ));
    return parsePendingTransactionResponse(response.data);
  } else {
    throw Exception("Can't load pending transaction");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a ZyosUserClabe
/// object
///
/// Returns:
/// A Future<ZyosUserClabe>
@override
Future<ZyosUserClabe> getZyosUserClabe() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.paymentServicePointPath +
      (UserUtils.currentServicePoint?.id.toString() ?? "") +
      Constants.zyosUserClabesPath);
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseZyosUserClabeResponse(response.data);
  } else {
    throw Exception("Can't load zyos user clabe object");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a DeletePendingTransactionResponse
/// object
///
/// Returns:
/// A Future<DeletePendingTransactionResponse>
@override
Future<DeletePendingTransactionResponse> deletePendingTransaction(
  int? idTransaction,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.delete(
    Constants.daviviendaOfficePaymentDeletePath + (idTransaction.toString()),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseDeletePendingTransactionResponse(response.data);
  } else {
    throw Exception("Can't delete pending transaction");
  }
}

/// It makes a get request to the server, and if the response is successful, it returns a PaymentMethodsResponse
/// object
///
/// Returns:
/// A Future<PaymentMethodsResponse>
@override
Future<PaymentMethodsResponse> getActivePaymentMethods() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.paymentsPath +
      (UserUtils.currentEnterprise?.id.toString() ?? "") +
      Constants.activePaymentMethodsPath);
  if (response.statusCode == Constants.httpSuccessCode) {
    return parsePaymentMethodsResponse(response.data);
  } else {
    throw Exception("Can't load payment methods object");
  }
}

/// It makes a get request to the server, and if the response is successful, it returns a List<UserPaymentMethodResponse>
/// object
///
/// Returns:
/// A Future<List<UserPaymentMethodResponse>>

Future<List<UserPaymentMethodResponse>> getUserPaymentMethods() async {
  final Response response;
  final currentUser = UserUtils.currentUser;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.userPaymentMethodPath +
      (currentUser?.id.toString() ?? "") +
      Constants.methods);
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseUserPaymentMethodsResponse(response.data);
  } else {
    throw Exception("Can't load payment methods object");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a DaviviendaPaymentResponse
/// object
///
/// Returns:
/// A Future<DaviviendaPaymentResponse>

Future<DaviviendaPaymentResponse> addSpeiPayment(
  Map<String, dynamic> data,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response =
      await dioClient.post(Constants.daviviendaOfficepayments, data: data);
  if (response.statusCode == Constants.httpSuccessCode) {
    return DaviviendaPaymentResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load payment methods object");
  }
}

/// It makes a get request to the server, and if the response is successful, it returns a HeaderAdminResponse
/// object
///
/// Returns:
/// A Future<HeaderAdminResponse>
Future<HeaderAdminResponse> getHeaderAdminInfo(BuildContext context) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  final currentUser = UserUtils.currentUser;
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.collectonsFirstPath +
      (currentUser?.currentEnterprise?.id.toString() ?? "") +
      Constants.collectionThirdPath);
  if (response.statusCode == Constants.httpSuccessCode) {
    BlocProvider.of<PaymentsBloc>(context).add(NewBalance(
      balance: HeaderAdminResponse.fromJson(response.data),
    ));
    return HeaderAdminResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load payment methods object");
  }
}

/// It makes a post request to the server, and if the response is successful, it returns a ServicePointDebtsResponse
/// object
///
/// Returns:
/// A Future<List<ConciliationResponse>>
@override
Future<HistoricTransactionResponse> getHistoricTransaction() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(
    Constants.paymentsPath +
        (UserUtils.currentEnterprise?.id.toString() ?? "") +
        Constants.historicTransaction,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseHistoricTransaction(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

Future<PsePayResponse> psePay(
  Map<String, dynamic> data,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    url + Constants.payPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return PsePayResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load pending transaction");
  }
}

/// Associate payments service
///
/// Arg:
///   data: is a json built before calling the service
///
/// Returns:
///   AsociatePaymentResponse object
///
@override
// ignore: long-method
Future<AssociatePaymentResponse> associatePayment(
  Map<String, dynamic> data,
) async {
  var idBalance = data['id'];
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.patch(
    "$url${Constants.balancesPath}${idBalance.toString()}",
    data: data,
    options: Options(),
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return AssociatePaymentResponse.fromJson(response.data);
  } else {
    throw Exception("Can't associate payment");
  }
}

Future<PayResponseResponse> getInvoiceResponseInfo(String dpq) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(Constants.payResponsePath + dpq);
  if (response.statusCode == Constants.httpSuccessCode) {
    return PayResponseResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load payment methods object");
  }
}

Future<DownloadBalanceResponse> downloadBalance(
  Map<String, dynamic> request,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    Constants.downloadBalancePath,
    data: request,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return DownloadBalanceResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

// ignore: long-method
Future<PaymentScheduleResponse> schedulePayment(
  Map<String, dynamic> request,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  try {
    response = await dioClient.post(
      Constants.schedulePaymentPath,
      data: request,
    );
    if (response.statusCode == Constants.httpSuccessCode) {
      return PaymentScheduleResponse.fromJson(response.data);
    } else {
      throw Exception("Can't load conciliation list");
    }
  } on DioError catch (e) {
    return PaymentScheduleResponse.fromJson(e.response?.data);
  }
}

Future<GetSchedulesResponse> getSchedulePayment() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(
    "${Constants.getSchedulePayPath}${UserUtils.currentEnterprise?.id}${Constants.getSchedulePayFinalPath}",
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return GetSchedulesResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

Future<DeletePaymentMethodResponse> deletePaymetMethod(
  Map<String, dynamic> data,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.delete(
    Constants.deletePaymentMethodPath,
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return DeletePaymentMethodResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

Future<DeleteSchedulePay> deleteSchedulePay(
  int idPaymentSchedule,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient
      .delete("${Constants.deleteSchedulePay}$idPaymentSchedule", data: {
    "userChange": UserUtils.currentUser?.id ?? 0,
  });
  if (response.statusCode == Constants.httpSuccessCode) {
    return DeleteSchedulePay.fromJson(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

Future<UpdateScheduleResponse> updateSchedule(
  int idPaymentSchedule,
  Map<String, dynamic> reqObj,
) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.patch(
    "${Constants.deleteSchedulePay}$idPaymentSchedule",
    data: reqObj,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return UpdateScheduleResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}

Future<DiscountDataLogResponse> getDiscountsDataLog() async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.paymentUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.get(
    "${Constants.paymentsPath}${UserUtils.currentEnterprise?.id}${Constants.discountDataLogs}",
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return DiscountDataLogResponse.fromJson(response.data);
  } else {
    throw Exception("Can't load conciliation list");
  }
}
