import 'package:neivor_flutter_app/domain/models/payment/associate/associate_payment_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/debts/service_points_debts_reponse.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/delete_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/mail_send_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_invoice_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';

abstract class IPaymentRepository {
  Future<ServicePointDebtsResponse> getServicePointsDebts();
  Future<List<ConciliationResponse>> getConciliation();
  Future<List<Invoice>> getInvoices(bool isHistory);
  Future<TransactionsResponse> getTransactions();
  Future<PendingTransaction> getPendingTransaction();
  Future<ZyosUserClabe> getZyosUserClabe();
  Future<DeletePendingTransactionResponse> deletePendingTransaction(
    int? idTransaction,
  );
  Future<TransactionByInvoiceResponse> getTransactionByInvoice();
  Future<MailSendTransactionResponse> sendMailTransaction();
  Future<AssociatePaymentResponse> associatePayment();
}
