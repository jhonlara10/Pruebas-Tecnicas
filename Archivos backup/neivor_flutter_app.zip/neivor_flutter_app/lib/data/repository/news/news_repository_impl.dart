import 'package:dio/dio.dart';
import 'package:neivor_flutter_app/domain/models/news/create_new_response.dart';
import 'package:neivor_flutter_app/domain/models/news/delete_new_request.dart';
import 'package:neivor_flutter_app/domain/models/news/delete_new_response.dart';
import 'package:neivor_flutter_app/domain/models/news/list_news_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import '../../../domain/models/news/news.dart';
import '../utils/constants.dart';
import '../utils/httpclient_factory.dart';

/// ------- Parsers -------.
NewData parseNews(dynamic parsed) {
  return NewData.fromJson(parsed);
}

List<ListNewsResponse> parseListNewsResponse(List<dynamic> parsed) {
  List<ListNewsResponse> converted = [];
  for (var element in parsed) {
    converted.add(ListNewsResponse.fromJson(element));
  }

  return converted;
}

/// -------- Request --------.
Future<CreateNewResponse> createNew(Map<String, dynamic> data) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.noticesUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    '/private/insert-notice',
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return CreateNewResponse.fromJson(response.data);
  } else {
    throw Exception("Can't create New");
  }
}

Future<List<ListNewsResponse>> getNews(int idEnterprise) async {
  String url = await AppUrls().getUrl(AppApiConstants.noticesUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final response = await dioClient.get('/private/wall/$idEnterprise');
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseListNewsResponse(response.data);
  } else {
    throw Exception("Can't get New");
  }
}

Future<NewData> updateNew() async {
  String url = await AppUrls().getUrl(AppApiConstants.noticesUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  final response = await dioClient.get('/private/update-notice');
  if (response.statusCode == Constants.httpSuccessCode) {
    return parseNews(response.data);
  } else {
    throw Exception("Can't update New");
  }
}

Future<DeleteNewResponse> deleteNew(DeleteNewRequest data) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.noticesUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.post(
    '/private/delete-notice-by-id',
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return DeleteNewResponse.fromJson(response.data);
  } else {
    throw Exception("Can't delete New");
  }
}

Future<CreateNewResponse> editNew(Map<String, dynamic> data) async {
  final Response response;
  String url = await AppUrls().getUrl(AppApiConstants.noticesUrl);
  Dio dioClient = HttpClientFactory.getHttpClient(url);
  response = await dioClient.put(
    '/private/update-notice',
    data: data,
  );
  if (response.statusCode == Constants.httpSuccessCode) {
    return CreateNewResponse.fromJson(response.data);
  } else {
    throw Exception("Can't delete New");
  }
}
