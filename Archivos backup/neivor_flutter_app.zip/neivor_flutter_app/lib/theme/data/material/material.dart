import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Material extends Equatable {
  final Color background;

  const Material({required this.background});

  factory Material.light() => const Material(
        background: Color.fromARGB(255, 255, 255, 255),
      );
  factory Material.dark() => const Material(
        background: Color.fromARGB(255, 0, 0, 0),
      );

  @override
  List<Object?> get props => [
        background,
      ];
}
