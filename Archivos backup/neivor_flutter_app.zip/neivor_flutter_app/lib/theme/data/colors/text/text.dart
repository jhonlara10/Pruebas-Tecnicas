import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Text extends Equatable {
  final Color primary;
  final Color secondary;
  final Color placeholders;
  final Color white;

  const Text({
    required this.primary,
    required this.secondary,
    required this.placeholders,
    required this.white,
  });

  factory Text.light() => const Text(
        primary: Color(0xFF222222),
        secondary: Color(0xFF595959),
        placeholders: Color(0xFF717171),
        white: Color(0xFFFFFFFF),
      );

  factory Text.dark() => const Text(
        primary: Color(0xFF222222),
        secondary: Color(0xFF595959),
        placeholders: Color(0xFF717171),
        white: Color(0xFFFFFFFF),
      );

  @override
  List<Object?> get props => [primary, secondary, placeholders, white];
}
