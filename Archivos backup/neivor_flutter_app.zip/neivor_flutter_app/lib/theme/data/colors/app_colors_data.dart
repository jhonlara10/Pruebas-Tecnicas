import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/theme/data/colors/backgrounds/backgrounds.dart';
import 'package:neivor_flutter_app/theme/data/colors/button/button.dart';
import 'package:neivor_flutter_app/theme/data/colors/icons/icons.dart';
import 'package:neivor_flutter_app/theme/data/colors/opacityBackgrounds/opacity_backgrounds.dart';
import 'package:neivor_flutter_app/theme/data/colors/primary/primary.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/secondary.dart';
import 'package:neivor_flutter_app/theme/data/colors/text/text.dart';

class AppColorsData extends Equatable {
  final Text text;
  final Primary primary;
  final Secondary secondary;
  final Button button;
  final OpacityBackgrounds opacityBackgrounds;
  final Backgrounds backgrounds;
  final Icons icons;

  const AppColorsData({
    required this.text,
    required this.primary,
    required this.secondary,
    required this.button,
    required this.opacityBackgrounds,
    required this.backgrounds,
    required this.icons,
  });

  factory AppColorsData.light() => AppColorsData(
        text: Text.light(),
        primary: Primary.light(),
        secondary: Secondary.light(),
        button: Button.light(),
        opacityBackgrounds: OpacityBackgrounds.light(),
        backgrounds: Backgrounds.light(),
        icons: Icons.light(),
      );

  factory AppColorsData.dark() => AppColorsData(
        text: Text.dark(),
        primary: Primary.light(),
        secondary: Secondary.light(),
        button: Button.light(),
        opacityBackgrounds: OpacityBackgrounds.light(),
        backgrounds: Backgrounds.dark(),
        icons: Icons.dark(),
      );

  @override
  List<Object?> get props => [
        text,
        primary,
        secondary,
        button,
        opacityBackgrounds,
        backgrounds,
        icons,
      ];
}
