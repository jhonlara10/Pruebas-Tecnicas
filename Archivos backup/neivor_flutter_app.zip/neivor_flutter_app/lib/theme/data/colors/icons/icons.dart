import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Icons extends Equatable {
  final Color main;
  final Color black;
  final Color hover;
  final Color disabled;
  final Color white;
  final Color coral;
  final Color coralHover;
  final Color turquoise;
  final Color turquoiseHover;
  final Color error;
  final Color success;
  final Color info;
  final Color warning;

  const Icons({
    required this.black,
    required this.hover,
    required this.disabled,
    required this.coral,
    required this.coralHover,
    required this.error,
    required this.info,
    required this.success,
    required this.turquoise,
    required this.turquoiseHover,
    required this.warning,
    required this.white,
    required this.main,
  });

  factory Icons.light() => const Icons(
        black: Color(0xFF222222),
        hover: Color(0xFF575F68),
        disabled: Color(0xFFA1A5AE),
        white: Color(0xFFFFFFFF),
        coral: Color(0xFFFF595A),
        coralHover: Color(0xFFD44B4B),
        turquoise: Color(0xFF287D71),
        turquoiseHover: Color(0xFF226C62),
        error: Color(0xFFFF4E78),
        success: Color(0xFF0EC564),
        info: Color(0xFF2F69F2),
        warning: Color(0xFFFFAB1B),
        //ignore: no-equal-arguments
        main: Color(0xFF222222),
      );
  factory Icons.dark() => const Icons(
        black: Color(0xFF222222),
        hover: Color(0xFF575F68),
        disabled: Color(0xFFA1A5AE),
        white: Color(0xFFFFFFFF),
        coral: Color(0xFFFF595A),
        coralHover: Color(0xFFD44B4B),
        turquoise: Color(0xFF287D71),
        turquoiseHover: Color(0xFF226C62),
        error: Color(0xFFFF4E78),
        success: Color(0xFF0EC564),
        info: Color(0xFF2F69F2),
        warning: Color(0xFFFFAB1B),
        //ignore: no-equal-arguments
        main: Color(0xFFFFFFFF),
      );

  @override
  List<Object?> get props => [
        black,
        hover,
        disabled,
        white,
        coral,
        coralHover,
        turquoise,
        turquoiseHover,
        error,
        success,
        info,
        warning,
      ];
}
