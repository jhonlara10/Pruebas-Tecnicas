import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class PersianBlue extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const PersianBlue({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory PersianBlue.light() => const PersianBlue(
        main: Color(0xFF0045BE),
        v1: Color(0xFFE6EDF9),
        v2: Color(0xFFCCDAF2),
        v3: Color(0xFF80A2DF),
        v4: Color(0xFF002C7A),
        v5: Color(0xFF004DD4),
      );

  @override
  List<Object?> get props => [
        main,
        v1,
        v2,
        v3,
        v4,
        v5,
      ];
}
