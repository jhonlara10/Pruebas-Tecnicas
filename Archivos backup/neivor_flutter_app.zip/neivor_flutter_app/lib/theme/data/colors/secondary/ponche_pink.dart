import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class PonchePink extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const PonchePink({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory PonchePink.light() => const PonchePink(
        main: Color(0xFFFF4E78),
        v1: Color(0xFFFFEEF2),
        v2: Color(0xFFFFDBE4),
        v3: Color(0xFFFFA6BC),
        v4: Color(0xFF942D45),
        v5: Color(0xFFFF6E91),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
