import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/cobalt_blue.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/harlequin_green.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/indigo_blue.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/lavanda.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/persian_blue.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/ponche_pink.dart';
import 'package:neivor_flutter_app/theme/data/colors/secondary/yellow.dart';

class Secondary extends Equatable {
  final PonchePink ponchePink;
  final CobaltBlue cobaltBlue;
  final HarlequinGreen harlequinGreen;
  final IndigoBlue indigoBlue;
  final Yellow yellow;
  final PersianBlue persianBlue;
  final Lavanda lavanda;

  const Secondary({
    required this.ponchePink,
    required this.cobaltBlue,
    required this.harlequinGreen,
    required this.indigoBlue,
    required this.yellow,
    required this.persianBlue,
    required this.lavanda,
  });

  factory Secondary.light() => Secondary(
        ponchePink: PonchePink.light(),
        cobaltBlue: CobaltBlue.light(),
        harlequinGreen: HarlequinGreen.light(),
        indigoBlue: IndigoBlue.light(),
        yellow: Yellow.light(),
        persianBlue: PersianBlue.light(),
        lavanda: Lavanda.light(),
      );

  @override
  List<Object?> get props =>
      [ponchePink, cobaltBlue, harlequinGreen, indigoBlue, yellow];
}
