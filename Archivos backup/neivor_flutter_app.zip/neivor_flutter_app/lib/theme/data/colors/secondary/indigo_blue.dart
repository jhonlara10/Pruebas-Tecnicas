import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class IndigoBlue extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const IndigoBlue({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory IndigoBlue.light() => const IndigoBlue(
        main: Color(0xFF3C76FF),
        v1: Color(0xFFECF2FF),
        v2: Color(0xFFD8E3FE),
        v3: Color(0xFF9FB9FF),
        v4: Color(0xFF244596),
        v5: Color(0xFF5284FF),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
