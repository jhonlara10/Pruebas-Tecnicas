import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Lavanda extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const Lavanda({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory Lavanda.light() => const Lavanda(
        main: Color(0xFF7367E9),
        v1: Color(0xFFF1F0FD),
        v2: Color(0xFFE3E0FB),
        v3: Color(0xFFB8B3F4),
        v4: Color(0xFF473EA1),
        v5: Color(0xFF867AFF),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
