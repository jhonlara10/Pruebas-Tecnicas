import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class IvoryBeige extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const IvoryBeige({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory IvoryBeige.light() => const IvoryBeige(
        main: Color(0xFFF2ECE2),
        v1: Color(0xFFFEFEFD),
        v2: Color(0xFFFFEED1),
        v3: Color(0xFFF8F6F0),
        v4: Color(0xFF7D7568),
        v5: Color(0xFFF7F6F4),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
