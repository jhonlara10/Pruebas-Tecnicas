import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class HarlequinGreen extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const HarlequinGreen({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory HarlequinGreen.light() => const HarlequinGreen(
        main: Color(0xFF0EC564),
        v1: Color(0xFFE6FAF0),
        v2: Color(0xFFCEF3E0),
        v3: Color(0xFF85E2B2),
        v4: Color(0xFF076E39),
        v5: Color(0xFF0BD66D),
      );

  @override
  List<Object?> get props => [
        main,
        v1,
        v2,
        v3,
        v4,
        v5,
      ];
}
