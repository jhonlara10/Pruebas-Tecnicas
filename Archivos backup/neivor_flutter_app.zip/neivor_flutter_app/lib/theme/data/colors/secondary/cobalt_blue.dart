import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class CobaltBlue extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const CobaltBlue({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory CobaltBlue.light() => const CobaltBlue(
        main: Color(0xFF233963),
        v1: Color(0xFFEAECF0),
        v2: Color(0xFFD3D7E0),
        v3: Color(0xFF919CB1),
        v4: Color(0xFF111B30),
        v5: Color(0xFF2A4578),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
