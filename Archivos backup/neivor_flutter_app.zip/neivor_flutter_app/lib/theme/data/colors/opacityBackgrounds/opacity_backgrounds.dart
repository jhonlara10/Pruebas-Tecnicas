import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class OpacityBackgrounds extends Equatable {
  final Color coral;
  final Color turquoise;
  final Color yellow;
  final Color black;
  final Color harlequinGreen;
  final Color indigoBlueOpacity;
  final Color ponchepink;
  static const double _opacity = 0.08;

  const OpacityBackgrounds({
    required this.coral,
    required this.turquoise,
    required this.yellow,
    required this.black,
    required this.harlequinGreen,
    required this.indigoBlueOpacity,
    required this.ponchepink,
  });

  factory OpacityBackgrounds.light() => OpacityBackgrounds(
        coral: const Color(0xFFFF595A).withOpacity(_opacity),
        turquoise: const Color(0xFF3EC7B5).withOpacity(_opacity),
        yellow: const Color(0xFFFFAB1B).withOpacity(_opacity),
        black: const Color(0xFF0D0E0F).withOpacity(_opacity),
        harlequinGreen: const Color(0xFF0EC564).withOpacity(_opacity),
        indigoBlueOpacity: const Color(0xFF3C76FF).withOpacity(_opacity),
        ponchepink: const Color(0xFFFF4E78).withOpacity(_opacity),
      );

  @override
  List<Object?> get props => [
        coral,
        turquoise,
        yellow,
        harlequinGreen,
        ponchepink,
      ];
}
