import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Coral extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const Coral({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory Coral.light() => const Coral(
        main: Color(0xFFFF595A),
        v1: Color(0xFFFFEEEF),
        v2: Color(0xFFFFDEDE),
        v3: Color(0xFFFFADAC),
        v4: Color(0xFFD44B4B),
        v5: Color(0xFFFF7374),
      );

  @override
  List<Object?> get props => [
        main,
        v1,
        v2,
        v3,
        v4,
        v5,
      ];
}
