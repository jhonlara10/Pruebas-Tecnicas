import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Black extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const Black({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory Black.light() => const Black(
        main: Color(0xFF0D0E0F),
        v1: Color(0xFFEBEBEB),
        v2: Color(0xFFD5D6D7),
        v3: Color(0xFF97999B),
        v4: Color(0xFF000000),
        v5: Color(0xFF1A1C1F),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
