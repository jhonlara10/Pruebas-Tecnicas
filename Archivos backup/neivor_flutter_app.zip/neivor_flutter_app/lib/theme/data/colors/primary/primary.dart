import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/theme/data/colors/primary/arctic_gray.dart';
import 'package:neivor_flutter_app/theme/data/colors/primary/black.dart';
import 'package:neivor_flutter_app/theme/data/colors/primary/coral.dart';
import 'package:neivor_flutter_app/theme/data/colors/primary/turquoise.dart';

class Primary extends Equatable {
  final Coral coral;
  final Turquoise turquoise;
  final Black black;
  final ArcticGray arcticGray;

  const Primary({
    required this.coral,
    required this.turquoise,
    required this.black,
    required this.arcticGray,
  });

  factory Primary.light() => Primary(
        coral: Coral.light(),
        turquoise: Turquoise.light(),
        black: Black.light(),
        arcticGray: ArcticGray.light(),
      );

  factory Primary.dark() => Primary(
        coral: Coral.light(),
        turquoise: Turquoise.light(),
        black: Black.light(),
        arcticGray: ArcticGray.light(),
      );

  @override
  List<Object?> get props => [coral, turquoise, black, arcticGray];
}
