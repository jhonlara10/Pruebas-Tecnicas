import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class ArcticGray extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const ArcticGray({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory ArcticGray.light() => const ArcticGray(
        main: Color(0xFFF5F5F5),
        v1: Color(0xFFFEFEFE),
        v2: Color(0xFFFDFDFD),
        v3: Color(0xFFFAFAFA),
        v4: Color(0xFF787878),
        v5: Color(0xFFFFFFFF),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
