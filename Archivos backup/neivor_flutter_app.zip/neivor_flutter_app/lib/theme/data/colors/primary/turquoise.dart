import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class Turquoise extends Equatable {
  final Color main;
  final Color v1;
  final Color v2;
  final Color v3;
  final Color v4;
  final Color v5;

  const Turquoise({
    required this.main,
    required this.v1,
    required this.v2,
    required this.v3,
    required this.v4,
    required this.v5,
  });

  factory Turquoise.light() => const Turquoise(
        main: Color(0xFF3EC7B5),
        v1: Color(0xFFECF9F8),
        v2: Color(0xFFD8F4F0),
        v3: Color(0xFF9FE3DA),
        v4: Color(0xFF287D71),
        v5: Color(0xFF42D4C0),
      );

  @override
  List<Object?> get props => [main, v1, v2, v3, v4, v5];
}
