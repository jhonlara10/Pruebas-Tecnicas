import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Backgrounds extends Equatable {
  final LinearGradient gradientCoral;
  final LinearGradient gradientTurquoise;
  final Color white;
  final Color main;

  const Backgrounds({
    required this.gradientCoral,
    required this.gradientTurquoise,
    required this.white,
    required this.main,
  });

  // ignore: long-method
  factory Backgrounds.light() => const Backgrounds(
        gradientCoral: LinearGradient(
          colors: [
            Color(0xFFFF595A),
            Color(0xFFFF4D78),
          ],
        ),
        gradientTurquoise: LinearGradient(
          colors: [
            Color(0xFFFF595A),
            Color(0xFF3EC7B5),
            Color(0xFF02C9FD),
          ],
        ),
        white: Color(0xFFFFFFFF),
        //ignore: no-equal-arguments
        main: Color(0xFFFFFFFF),
        // Main: Color(0xFFF5F5F5),.
      );

  // ignore: long-method
  factory Backgrounds.dark() => const Backgrounds(
        gradientCoral: LinearGradient(
          colors: [
            Color(0xFFFF595A),
            Color(0xFFFF4D78),
          ],
        ),
        gradientTurquoise: LinearGradient(
          colors: [
            Color(0xFFFF595A),
            Color(0xFF3EC7B5),
            Color(0xFF02C9FD),
          ],
        ),
        white: Color(0xFFFFFFFF),
        main: Color(0xFF000000),
      );

  @override
  List<Object?> get props => [
        gradientCoral,
        gradientTurquoise,
        white,
        main,
      ];
}
