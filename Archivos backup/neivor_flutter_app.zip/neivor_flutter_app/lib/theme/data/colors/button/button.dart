import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/theme/data/colors/button/coral.dart';
import 'package:neivor_flutter_app/theme/data/colors/button/outline.dart';
import 'package:neivor_flutter_app/theme/data/colors/button/text.dart';
import 'package:neivor_flutter_app/theme/data/colors/button/turquoise.dart';

class Button extends Equatable {
  final Text text;
  final Coral coral;
  final Turquoise turquoise;
  final Outline outline;

  const Button({
    required this.text,
    required this.coral,
    required this.turquoise,
    required this.outline,
  });

  factory Button.light() => Button(
        text: Text.light(),
        coral: Coral.light(),
        turquoise: Turquoise.light(),
        outline: Outline.light(),
      );

  @override
  List<Object?> get props => [text];
}
