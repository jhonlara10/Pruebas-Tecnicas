import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Text extends Equatable {
  final Color black;
  final Color blackHover;
  final Color white;
  final Color disabled;
  final Color turquoise;
  final Color turquoiseHover;

  const Text({
    required this.black,
    required this.blackHover,
    required this.white,
    required this.disabled,
    required this.turquoise,
    required this.turquoiseHover,
  });

  factory Text.light() => const Text(
        black: Color(0xFF222222),
        blackHover: Color(0xFF575F68),
        white: Color(0xFFFFFFFF),
        disabled: Color(0xFFA1A5AE),
        turquoise: Color(0XFF287D71),
        turquoiseHover: Color(0XFF226C62),
      );

  @override
  List<Object?> get props =>
      [black, blackHover, white, disabled, turquoise, turquoiseHover];
}
