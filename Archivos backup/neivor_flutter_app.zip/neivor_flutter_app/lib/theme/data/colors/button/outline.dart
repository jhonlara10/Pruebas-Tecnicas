import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Outline extends Equatable {
  final Color main;
  final Color hover;
  final Color disabled;

  const Outline({
    required this.main,
    required this.hover,
    required this.disabled,
  });

  factory Outline.light() => const Outline(
        main: Color(0xFF353535),
        hover: Color(0xFF575F68),
        disabled: Color(0xFFEFEFEF),
      );

  @override
  List<Object?> get props => [main, hover, disabled];
}
