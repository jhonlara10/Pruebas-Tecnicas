import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Turquoise extends Equatable {
  final Color main;
  final Color hover;
  final Color disabled;

  const Turquoise({
    required this.main,
    required this.hover,
    required this.disabled,
  });

  factory Turquoise.light() => const Turquoise(
        main: Color(0xFF287D71),
        hover: Color(0xFF226C62),
        disabled: Color(0xFFEFEFEF),
      );

  @override
  List<Object?> get props => [main, hover, disabled];
}
