import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class Coral extends Equatable {
  final Color main;
  final Color hover;
  final Color disabled;

  const Coral({
    required this.main,
    required this.hover,
    required this.disabled,
  });

  factory Coral.light() => const Coral(
        main: Color(0xFFFF595A),
        hover: Color(0xFFD44B4B),
        disabled: Color(0xFFEFEFEF),
      );

  @override
  List<Object?> get props => [main, hover, disabled];
}
