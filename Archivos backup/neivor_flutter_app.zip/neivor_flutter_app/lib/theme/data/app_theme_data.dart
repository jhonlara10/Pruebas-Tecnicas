import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';
import 'package:neivor_flutter_app/theme/data/colors/backgrounds/backgrounds.dart';
import 'package:neivor_flutter_app/theme/data/colors/opacityBackgrounds/opacity_backgrounds.dart';
import 'package:neivor_flutter_app/theme/data/material/material.dart';
import 'package:neivor_flutter_app/theme/data/shadows/shadows.dart';
import 'package:neivor_flutter_app/theme/data/typography/typography.dart';

class AppThemeData extends Equatable {
  final AppColorsData colors;
  final Typography typography;
  final Shadows shadows;
  final Material material;
  final OpacityBackgrounds opacityBackgrounds;
  final Backgrounds backgrounds;

  const AppThemeData({
    required this.colors,
    required this.typography,
    required this.shadows,
    required this.material,
    required this.opacityBackgrounds,
    required this.backgrounds,
  });

  factory AppThemeData.light() => AppThemeData(
        colors: AppColorsData.light(),
        typography: Typography.light(),
        shadows: Shadows.light(),
        material: Material.light(),
        opacityBackgrounds: OpacityBackgrounds.light(),
        backgrounds: Backgrounds.light(),
      );
  factory AppThemeData.dark() => AppThemeData(
        colors: AppColorsData.dark(),
        typography: Typography.dark(),
        shadows: Shadows.dark(),
        material: Material.dark(),
        opacityBackgrounds: OpacityBackgrounds.light(),
        backgrounds: Backgrounds.dark(),
      );
  @override
  List<Object?> get props => [
        colors,
        typography,
        shadows,
        material,
        opacityBackgrounds,
      ];
}
