import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

const Color shadowColor = Color(0xFF101828);
const Color shadowDarkColor = Color(0xFFFFFFFF);
// #region Light Theme.
List<BoxShadow> xSmallBase = [
  BoxShadow(
    offset: const Offset(0, 1),
    blurRadius: 2,
    spreadRadius: 0,
    color: shadowColor.withOpacity(0.05),
  ),
];
List<BoxShadow> smallBase = [
  BoxShadow(
    offset: const Offset(0, 1),
    blurRadius: 3,
    spreadRadius: 0,
    color: shadowColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 1),
    blurRadius: 2,
    spreadRadius: -1,
    color: shadowColor.withOpacity(0.1),
  ),
];
List<BoxShadow> mediumBase = [
  BoxShadow(
    offset: const Offset(0, 4),
    blurRadius: 6,
    spreadRadius: -1,
    color: shadowColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 2),
    blurRadius: 4,
    spreadRadius: -2,
    color: shadowColor.withOpacity(0.1),
  ),
];
List<BoxShadow> largeBase = [
  BoxShadow(
    offset: const Offset(0, 10),
    blurRadius: 15,
    spreadRadius: -3,
    color: shadowColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 4),
    blurRadius: 6,
    spreadRadius: -4,
    color: shadowColor.withOpacity(0.1),
  ),
];
List<BoxShadow> xLargeBase = [
  BoxShadow(
    offset: const Offset(0, 20),
    blurRadius: 25,
    spreadRadius: -5,
    color: shadowColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 8),
    blurRadius: 10,
    spreadRadius: -6,
    color: shadowColor.withOpacity(0.1),
  ),
];
List<BoxShadow> xxLargeBase = [
  BoxShadow(
    offset: const Offset(0, 25),
    blurRadius: 50,
    spreadRadius: -12,
    color: shadowColor.withOpacity(0.25),
  ),
];
// #endregion.
// #region Dark Theme.
List<BoxShadow> xSmallDark = [
  BoxShadow(
    offset: const Offset(0, 1),
    blurRadius: 2,
    spreadRadius: 0,
    color: shadowDarkColor.withOpacity(0.05),
  ),
];
List<BoxShadow> smallDark = [
  BoxShadow(
    offset: const Offset(0, 1),
    blurRadius: 3,
    spreadRadius: 0,
    color: shadowDarkColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 1),
    blurRadius: 2,
    spreadRadius: -1,
    color: shadowDarkColor.withOpacity(0.1),
  ),
];
List<BoxShadow> mediumDark = [
  BoxShadow(
    offset: const Offset(0, 4),
    blurRadius: 6,
    spreadRadius: -1,
    color: shadowDarkColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 2),
    blurRadius: 4,
    spreadRadius: -2,
    color: shadowColor.withOpacity(0.1),
  ),
];
List<BoxShadow> largeDark = [
  BoxShadow(
    offset: const Offset(0, 10),
    blurRadius: 15,
    spreadRadius: -3,
    color: shadowDarkColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 4),
    blurRadius: 6,
    spreadRadius: -4,
    color: shadowDarkColor.withOpacity(0.1),
  ),
];
List<BoxShadow> xLargeDark = [
  BoxShadow(
    offset: const Offset(0, 20),
    blurRadius: 25,
    spreadRadius: -5,
    color: shadowDarkColor.withOpacity(0.1),
  ),
  BoxShadow(
    offset: const Offset(0, 8),
    blurRadius: 10,
    spreadRadius: -6,
    color: shadowDarkColor.withOpacity(0.1),
  ),
];
List<BoxShadow> xxLargeDark = [
  BoxShadow(
    offset: const Offset(0, 25),
    blurRadius: 50,
    spreadRadius: -12,
    color: shadowDarkColor.withOpacity(0.25),
  ),
];
// #endregion.

class Shadows extends Equatable {
  final List<BoxShadow> xSmall;
  final List<BoxShadow> small;
  final List<BoxShadow> medium;
  final List<BoxShadow> large;
  final List<BoxShadow> xLarge;
  final List<BoxShadow> xxLarge;

  const Shadows({
    required this.xSmall,
    required this.small,
    required this.medium,
    required this.large,
    required this.xLarge,
    required this.xxLarge,
  });

  factory Shadows.light() => Shadows(
        xSmall: xSmallBase,
        small: smallBase,
        medium: mediumBase,
        large: largeBase,
        xLarge: xLargeBase,
        xxLarge: xxLargeBase,
      );
  factory Shadows.dark() => Shadows(
        xSmall: xSmallDark,
        small: smallDark,
        medium: mediumDark,
        large: largeDark,
        xLarge: xLargeDark,
        xxLarge: xxLargeDark,
      );

  @override
  List<Object?> get props => [xSmall, small, medium, large, xLarge, xxLarge];
}
