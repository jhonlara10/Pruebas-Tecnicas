import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/theme/data/typography/body2.dart';
import 'package:neivor_flutter_app/theme/data/typography/button.dart';
import 'package:neivor_flutter_app/theme/data/typography/body1.dart';
import 'package:neivor_flutter_app/theme/data/typography/caption.dart';
import 'package:neivor_flutter_app/theme/data/typography/headline1.dart';
import 'package:neivor_flutter_app/theme/data/typography/headline2.dart';
import 'package:neivor_flutter_app/theme/data/typography/headline3.dart';
import 'package:neivor_flutter_app/theme/data/typography/headline4.dart';
import 'package:neivor_flutter_app/theme/data/typography/headline5.dart';
import 'package:neivor_flutter_app/theme/data/typography/subtitle1.dart';

class Typography extends Equatable {
  final Headline1 h1;
  final Headline2 h2;
  final Headline3 h3;
  final Headline4 h4;
  final Headline5 h5;
  final Subtitle1 st1;
  final Body1 bd1;
  final Body2 bd2;
  final Caption caption;
  final Button button;

  const Typography({
    required this.h1,
    required this.h2,
    required this.h3,
    required this.h4,
    required this.h5,
    required this.st1,
    required this.bd1,
    required this.bd2,
    required this.caption,
    required this.button,
  });

  factory Typography.light() => Typography(
        h1: Headline1.light(),
        h2: Headline2.light(),
        h3: Headline3.light(),
        h4: Headline4.light(),
        h5: Headline5.light(),
        st1: Subtitle1.light(),
        bd1: Body1.light(),
        bd2: Body2.light(),
        caption: Caption.light(),
        button: Button.light(),
      );
  factory Typography.dark() => Typography(
        h1: Headline1.dark(),
        h2: Headline2.dark(),
        h3: Headline3.dark(),
        h4: Headline4.dark(),
        h5: Headline5.dark(),
        st1: Subtitle1.dark(),
        bd1: Body1.dark(),
        bd2: Body2.dark(),
        caption: Caption.dark(),
        button: Button.dark(),
      );

  @override
  List<Object?> get props => [
        h1,
        h2,
        h3,
        h4,
        h5,
        st1,
        bd1,
        caption,
        button,
      ];
}
