import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Headline1 extends Equatable {
  final TextStyle semibold;
  static final _semibold = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w600,
    fontSize: 32, //ignore: no-magic-number
    height: 1.25, //ignore: no-magic-number
    color: AppColorsData.light().text.primary,
  );
  static final _semiboldDark = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w600,
    fontSize: 32, //ignore: no-magic-number
    height: 1.25, //ignore: no-magic-number
    color: AppColorsData.light().text.white,
  );

  const Headline1({required this.semibold});

  factory Headline1.light() => Headline1(
        semibold: _semibold,
      );
  factory Headline1.dark() => Headline1(
        semibold: _semiboldDark,
      );

  @override
  List<Object?> get props => [semibold];
}
