import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Headline2 extends Equatable {
  final TextStyle semibold;
  final TextStyle regular;

  static final TextStyle _semibold = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w600,
    fontSize: 26,
    height: 1.23,
    color: AppColorsData.light().text.primary,
  );
  static final TextStyle _regular =
      _semibold.copyWith(fontWeight: FontWeight.w400);
  static final TextStyle _semiBoldDark =
      _semibold.copyWith(color: AppColorsData.light().text.white);
  static final TextStyle _regularDark =
      _regular.copyWith(color: AppColorsData.light().text.white);

  const Headline2({required this.semibold, required this.regular});

  factory Headline2.light() => Headline2(
        semibold: _semibold,
        regular: _regular,
      );
  factory Headline2.dark() => Headline2(
        semibold: _semiBoldDark,
        regular: _regularDark,
      );

  @override
  List<Object?> get props => [semibold, regular];
}
