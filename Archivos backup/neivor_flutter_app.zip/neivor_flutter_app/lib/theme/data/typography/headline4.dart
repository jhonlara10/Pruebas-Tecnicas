import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Headline4 extends Equatable {
  final TextStyle semibold;
  final TextStyle medium;
  final TextStyle light;
  static final TextStyle _semibold = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w600,
    fontSize: 22,
    height: 1.33,
    color: AppColorsData.light().text.primary,
  );
  static final _medium = _semibold.copyWith(fontWeight: FontWeight.w500);
  static final _light = _semibold.copyWith(fontWeight: FontWeight.w300);
  static final _semiboldDark =
      _semibold.copyWith(color: AppColorsData.light().text.white);
  static final _mediumDark =
      _medium.copyWith(color: AppColorsData.light().text.white);
  static final _lightDark =
      _light.copyWith(color: AppColorsData.light().text.white);

  const Headline4({
    required this.semibold,
    required this.medium,
    required this.light,
  });

  factory Headline4.light() => Headline4(
        semibold: _semibold,
        medium: _medium,
        light: _light,
      );
  factory Headline4.dark() => Headline4(
        semibold: _semiboldDark,
        medium: _mediumDark,
        light: _lightDark,
      );

  @override
  List<Object?> get props => [semibold, medium, light];
}
