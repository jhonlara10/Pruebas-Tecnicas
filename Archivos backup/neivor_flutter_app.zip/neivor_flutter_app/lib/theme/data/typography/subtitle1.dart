import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Subtitle1 extends Equatable {
  final TextStyle medium;
  final TextStyle light;
  static final TextStyle _medium = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w500,
    fontSize: 20,
    height: 1.2,
    color: AppColorsData.light().text.primary,
  );
  static final TextStyle _light = _medium.copyWith(fontWeight: FontWeight.w300);
  static final TextStyle _mediumDark =
      _medium.copyWith(color: AppColorsData.light().text.white);
  static final TextStyle _lightDark =
      _light.copyWith(color: AppColorsData.light().text.white);

  const Subtitle1({required this.medium, required this.light});

  factory Subtitle1.light() => Subtitle1(
        medium: _medium,
        light: _light,
      );
  factory Subtitle1.dark() => Subtitle1(
        medium: _mediumDark,
        light: _lightDark,
      );

  @override
  List<Object?> get props => [medium, light];
}
