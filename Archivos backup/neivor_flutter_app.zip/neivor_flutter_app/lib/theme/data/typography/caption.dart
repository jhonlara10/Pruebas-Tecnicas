import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Caption extends Equatable {
  final TextStyle xxsMedium;
  final TextStyle xxsLight;
  final TextStyle xxxsMedium;
  final TextStyle xxxsLight;

// #region lighht theme.
  static final TextStyle _xxsMedium = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w500,
    fontSize: 12,
    height: 1.333,
    color: AppColorsData.light().text.primary,
  );
  static final TextStyle _xxsLight =
      _xxsMedium.copyWith(fontWeight: FontWeight.w300);
  static final TextStyle _xxxsMedium =
      _xxsMedium.copyWith(fontSize: 10, height: 1.4);
  static final TextStyle _xxxsLight =
      _xxxsMedium.copyWith(fontWeight: FontWeight.w300);
// #endregion
// #region Dark theme.
  static final TextStyle _xxsMediumDark =
      _xxsMedium.copyWith(color: AppColorsData.light().text.white);
  static final TextStyle _xxsLightDark =
      _xxsLight.copyWith(color: AppColorsData.light().text.white);
  static final TextStyle _xxxsMediumDark =
      _xxxsMedium.copyWith(fontSize: 10, height: 1.4);
  static final TextStyle _xxxsLightDark =
      _xxxsMedium.copyWith(color: AppColorsData.light().text.white);
// #endregion.

  const Caption({
    required this.xxsMedium,
    required this.xxsLight,
    required this.xxxsMedium,
    required this.xxxsLight,
  });

  factory Caption.light() => Caption(
        xxsMedium: _xxsMedium,
        xxsLight: _xxsLight,
        xxxsMedium: _xxxsMedium,
        xxxsLight: _xxxsLight,
      );
  factory Caption.dark() => Caption(
        xxsMedium: _xxsMediumDark,
        xxsLight: _xxsLightDark,
        xxxsMedium: _xxxsMediumDark,
        xxxsLight: _xxxsLightDark,
      );

  @override
  List<Object?> get props => [
        xxsMedium,
        xxsLight,
        xxxsMedium,
        xxxsMedium,
      ];
}
