import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Button extends Equatable {
  final TextStyle medium;
  final TextStyle underlinedMedium;
  final TextStyle light;

// #region lighht theme.
  static final TextStyle _medium = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w500,
    fontSize: 16,
    height: 1.5,
    color: AppColorsData.light().button.text.turquoise,
  );
  static final TextStyle _underlinedMedium =
      _medium.copyWith(decoration: TextDecoration.underline);
  static final TextStyle _light = _medium.copyWith(fontWeight: FontWeight.w300);
// #endregion.
// #region Dark theme.
  static final TextStyle _mediumDark = _medium;
  static final TextStyle _underlinedMediumDark = _underlinedMedium;
  static final TextStyle _lightDark = _light;
// #endregion.

  const Button({
    required this.medium,
    required this.underlinedMedium,
    required this.light,
  });

  factory Button.light() => Button(
        medium: _medium,
        underlinedMedium: _underlinedMedium,
        light: _light,
      );
  factory Button.dark() => Button(
        medium: _mediumDark,
        underlinedMedium: _underlinedMediumDark,
        light: _lightDark,
      );

  @override
  List<Object?> get props => [
        medium,
        underlinedMedium,
        light,
      ];
}
