import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Headline5 extends Equatable {
  final TextStyle semibold;
  final TextStyle medium;
  final TextStyle light;
  static final TextStyle _semibold = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w600,
    fontSize: 20,
    height: 1.2,
    color: AppColorsData.light().text.primary,
  );
  static final TextStyle _medium =
      _semibold.copyWith(fontWeight: FontWeight.w500);
  static final TextStyle _light =
      _semibold.copyWith(fontWeight: FontWeight.w300);
  static final _semiboldDark =
      _semibold.copyWith(color: AppColorsData.light().text.white);
  static final _mediumDark =
      _medium.copyWith(color: AppColorsData.light().text.white);
  static final _lightDark =
      _light.copyWith(color: AppColorsData.light().text.white);

  const Headline5({
    required this.semibold,
    required this.medium,
    required this.light,
  });

  factory Headline5.light() => Headline5(
        semibold: _semibold,
        medium: _medium.copyWith(fontWeight: FontWeight.w500),
        light: _light.copyWith(fontWeight: FontWeight.w300),
      );
  factory Headline5.dark() => Headline5(
        semibold: _semiboldDark,
        medium: _mediumDark.copyWith(fontWeight: FontWeight.w500),
        light: _lightDark.copyWith(fontWeight: FontWeight.w300),
      );

  @override
  List<Object?> get props => [semibold, medium, light];
}
