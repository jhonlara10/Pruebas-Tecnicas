import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/colors/app_colors_data.dart';

class Body1 extends Equatable {
  final TextStyle medium;
  final TextStyle light;
  final TextStyle mediumUnderLine;
  final TextStyle lightUnderLine;
  final TextStyle linethroughtMedium;
  final TextStyle linethroughtLight;
  final TextStyle italicMedium;
  final TextStyle italicLight;

  static final TextStyle _medium = TextStyle(
    fontFamily: 'Jost',
    fontWeight: FontWeight.w500,
    fontSize: 16,
    height: 1.5,
    color: AppColorsData.light().text.primary,
  );
  static final TextStyle _light = _medium.copyWith(fontWeight: FontWeight.w300);
  static final TextStyle _mediumDark = _medium.copyWith(
    color: AppColorsData.light().text.white,
  );
  static final TextStyle _lightDark = _light.copyWith(
    color: AppColorsData.light().text.white,
  );

  const Body1({
    required this.medium,
    required this.light,
    required this.mediumUnderLine,
    required this.lightUnderLine,
    required this.linethroughtMedium,
    required this.linethroughtLight,
    required this.italicMedium,
    required this.italicLight,
  });

  factory Body1.light() => Body1(
        medium: _medium,
        light: _light,
        mediumUnderLine: _medium.copyWith(decoration: TextDecoration.underline),
        lightUnderLine: _light.copyWith(decoration: TextDecoration.underline),
        linethroughtMedium:
            _medium.copyWith(decoration: TextDecoration.lineThrough),
        linethroughtLight:
            _light.copyWith(decoration: TextDecoration.lineThrough),
        italicMedium: _medium.copyWith(fontStyle: FontStyle.italic),
        italicLight: _light.copyWith(fontStyle: FontStyle.italic),
      );
  factory Body1.dark() => Body1(
        medium: _mediumDark,
        light: _lightDark,
        mediumUnderLine:
            _mediumDark.copyWith(decoration: TextDecoration.underline),
        lightUnderLine:
            _lightDark.copyWith(decoration: TextDecoration.underline),
        linethroughtMedium:
            _mediumDark.copyWith(decoration: TextDecoration.lineThrough),
        linethroughtLight:
            _light.copyWith(decoration: TextDecoration.lineThrough),
        italicMedium: _mediumDark.copyWith(fontStyle: FontStyle.italic),
        italicLight: _lightDark.copyWith(fontStyle: FontStyle.italic),
      );

  @override
  List<Object?> get props => [
        medium,
        light,
        mediumUnderLine,
        lightUnderLine,
        linethroughtMedium,
        linethroughtLight,
      ];
}
