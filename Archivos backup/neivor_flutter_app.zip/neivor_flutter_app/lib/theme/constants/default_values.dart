import 'package:flutter/material.dart';
import 'package:html_editor_enhanced/utils/shims/dart_ui_real.dart';

class DefaultValues {
  static EdgeInsets padding = const EdgeInsets.symmetric(
    horizontal: 16,
    vertical: 8,
  );
  static EdgeInsets padding2 = const EdgeInsets.symmetric(
    horizontal: 16,
    vertical: 24,
  );
  static BorderRadius borderRadius = const BorderRadius.all(Radius.circular(4));
  static BorderRadius borderRadius2 =
      const BorderRadius.all(Radius.circular(8));
  static ImageFilter backdropBlur = ImageFilter.blur(sigmaX: 2, sigmaY: 2);
}
