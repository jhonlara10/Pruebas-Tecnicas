// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/data/app_theme_data.dart';
export 'data/colors/app_colors_data.dart';

class AppTheme extends StatefulWidget {
  final Widget child;

  const AppTheme({Key? key, required this.child}) : super(key: key);

  static _AppThemeState of(BuildContext context) {
    //ignore: avoid-non-null-assertion
    return context.findAncestorStateOfType<_AppThemeState>()!;
  }

  @override
  State<AppTheme> createState() => _AppThemeState();
}

class _AppThemeState extends State<AppTheme> {
  AppThemeData defaultTheme = AppThemeData.light();

  void setTheme(AppThemeData theme) {
    setState(() {
      defaultTheme = theme;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppThemeScope(data: defaultTheme, child: widget.child);
  }
}
