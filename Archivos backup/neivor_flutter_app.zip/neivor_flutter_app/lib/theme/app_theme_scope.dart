import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/data/app_theme_data.dart';

class AppThemeScope extends InheritedWidget {
  final AppThemeData data;

  const AppThemeScope({Key? key, required this.data, required Widget child})
      : super(
          key: key,
          child: child,
        );

  static AppThemeData of(BuildContext context) {
    final widget = context.dependOnInheritedWidgetOfExactType<AppThemeScope>();
    return widget!.data; //ignore: avoid-non-null-assertion
  }

  @override
  bool updateShouldNotify(covariant AppThemeScope oldWidget) {
    return data != oldWidget.data;
  }
}
