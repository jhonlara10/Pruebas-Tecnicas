import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class NvTabBar extends StatelessWidget {
  final List<Tab> tabs;

  const NvTabBar({
    Key? key,
    required this.tabs,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;
    final shadows = AppThemeScope.of(context).shadows;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: colors.primary.arcticGray.main,
        borderRadius: const BorderRadius.all(Radius.circular(600)),
      ),
      child: TabBar(
        padding: const EdgeInsets.all(4),
        onTap: (value) => FocusManager.instance.primaryFocus?.unfocus(),
        indicator: BoxDecoration(
          color: colors.backgrounds.white,
          borderRadius: const BorderRadius.all(Radius.circular(600)),
          boxShadow: shadows.medium,
        ),
        overlayColor: MaterialStateProperty.all(Colors.transparent),
        labelColor: colors.button.turquoise.main,
        automaticIndicatorColorAdjustment: true,
        unselectedLabelStyle: typo.bd2.light,
        labelStyle: typo.bd1.medium,
        unselectedLabelColor: typo.bd2.light.color,
        tabs: tabs,
      ),
    );
  }
}
