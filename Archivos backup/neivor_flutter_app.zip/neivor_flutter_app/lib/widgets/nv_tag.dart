import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';

class NvTag extends StatelessWidget {
  final TagVariant? state;
  final String? label;

  const NvTag({
    Key? key,
    this.label = '',
    this.state = TagVariant.harlequinGreen,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    // ignore: long-method
    TextStyle getTypography() {
      switch (state) {
        case TagVariant.harlequinGreen:
          return typo.caption.xxsMedium
              .copyWith(color: colors.secondary.harlequinGreen.main);
        case TagVariant.black:
          return typo.caption.xxsMedium
              .copyWith(color: colors.primary.black.v4);
        case TagVariant.yellow:
          return typo.caption.xxsMedium
              .copyWith(color: colors.secondary.yellow.v4);
        case TagVariant.coral:
          return typo.caption.xxsMedium
              .copyWith(color: colors.primary.coral.v4);
        case TagVariant.blue:
          return typo.caption.xxsMedium
              .copyWith(color: colors.secondary.indigoBlue.v4);
        case TagVariant.red:
          return typo.caption.xxsMedium
              .copyWith(color: colors.secondary.ponchePink.main);
        case TagVariant.ponchePink:
          return typo.caption.xxsMedium
              .copyWith(color: colors.secondary.ponchePink.v4);
        default:
          return typo.caption.xxsMedium
              .copyWith(color: colors.secondary.harlequinGreen.main);
      }
    }

    // ignore: long-method
    Color getColor() {
      switch (state) {
        case TagVariant.harlequinGreen:
          return colors.opacityBackgrounds.harlequinGreen;
        case TagVariant.black:
          return colors.opacityBackgrounds.black;
        case TagVariant.yellow:
          return colors.secondary.yellow.v1;
        case TagVariant.coral:
          return colors.primary.coral.v1;
        case TagVariant.blue:
          return colors.opacityBackgrounds.turquoise;
        case TagVariant.red:
          return colors.opacityBackgrounds.coral;
        case TagVariant.ponchePink:
          return colors.opacityBackgrounds.ponchepink;
        default:
          return colors.opacityBackgrounds.harlequinGreen;
      }
    }

    BorderRadius getBorderRadius() {
      switch (state) {
        default:
          return DefaultValues.borderRadius;
      }
    }

    return DecoratedBox(
      decoration: BoxDecoration(
        color: getColor(),
        borderRadius: getBorderRadius(),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        child: Text(
          label ?? '',
          style: getTypography(),
        ),
      ),
    );
  }
}

enum TagVariant { harlequinGreen, black, yellow, coral, red, blue, ponchePink }
