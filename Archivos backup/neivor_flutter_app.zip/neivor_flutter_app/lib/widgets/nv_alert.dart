import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/styles/nv_button/primary.dart';

class NvAlert extends StatelessWidget {
  const NvAlert({
    Key? key,
    this.type,
    required this.content,
    this.acceptFn,
    this.cancelFn,
    this.hasTitle,
    this.titleText,
  }) : super(key: key);
  final String? type;
  final String content;
  final Function? acceptFn;
  final Function? cancelFn;
  final bool? hasTitle;
  final String? titleText;
  static const double _animationSize = 150;

  // ignore: long-method
  Widget? getIcon(context) {
    if (type != null) {
      switch (type) {
        case "success":
          return Lottie.network(
            'https://assets3.lottiefiles.com/datafiles/OhIfcxnkLsj1Jxj/data.json',
            width: _animationSize,
            height: _animationSize,
          );
        case "warning":
          return Lottie.network(
            'https://assets2.lottiefiles.com/packages/lf20_qbuxqwzg.json',
            width: _animationSize,
            height: _animationSize,
          );
        case "error":
          return Lottie.network(
            'https://assets9.lottiefiles.com/packages/lf20_qpwbiyxf.json',
            width: _animationSize,
            height: _animationSize,
          );
        default:
          return null;
      }
    }
    return null;
  }

  /// If the widget has a title, and a type, then return a column with the title and the icon. If the
  /// widget has a title, but no type, then return the title. If the widget has no title, but has a
  /// type, then return the icon. If the widget has neither a title nor a type, then return an empty
  /// text widget
  ///
  /// Args:
  ///   context: BuildContext
  ///
  /// Returns:
  ///   A widget.
  Widget titleBuilder(context) {
    if ((hasTitle ?? false) && type != null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          getIcon(context) ?? const Text(''),
          Text(
            titleText ?? '',
            textAlign: TextAlign.center,
          ),
        ],
      );
    } else if ((hasTitle ?? false) && type == null) {
      return Text(titleText ?? '');
    } else {
      return getIcon(context) ?? const Text('');
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return AlertDialog(
      content: Text(content, textAlign: TextAlign.center),
      title: titleBuilder(context),
      actions: [
        if (acceptFn != null)
          TextButton(
            style: getPrimaryButtonStyle(context),
            onPressed: () {
              //ignore: avoid-non-null-assertion
              acceptFn!();
            },
            child: Text(
              AppMessages().getCopy('common.accept'), //"Aceptar",
            ),
          ),
        if (cancelFn != null)
          TextButton(
            onPressed: () {
              //ignore: avoid-non-null-assertion
              cancelFn!(); // ! usually Navigator.pop(context); but avoid use it with autoclosed dialog.
            },
            child: Text(
              AppMessages().getCopy('common.cancel'), //"Cancelar",
              style: TextStyle(color: colors.primary.black.v3),
            ),
          ),
      ],
    );
  }
}
