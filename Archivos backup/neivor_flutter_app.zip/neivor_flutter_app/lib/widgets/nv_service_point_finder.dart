import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:neivor_flutter_app/data/repository/general/general_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/service_point_body.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/servicepoint_finder_view.dart';

class NvServicePointFinder extends StatefulWidget {
  final void Function(ServicePointObject) onSearch;
  final EdgeInsets? padding;

  const NvServicePointFinder({Key? key, required this.onSearch, this.padding})
      : super(key: key);

  @override
  State<NvServicePointFinder> createState() => _NvServicePointFinderState();
}

// ignore: prefer-correct-type-name
class _NvServicePointFinderState extends State<NvServicePointFinder> {
  static final _copy = AppMessages().getCopy;
  static final PagingController<int, ServicePointObject> _pagingController =
      PagingController(firstPageKey: 0);
  final ServicePointBody _body = ServicePointBody.defaultValues();
  String? _servicePointName;

  @override
  void initState() {
    _pagingController.addPageRequestListener(pageRequetListener);
    super.initState();
  }

  @override
  void dispose() {
    _pagingController.removePageRequestListener(pageRequetListener);
    super.dispose();
  }

  pageRequetListener(pageKey) => _fetchPage(pageKey, _body);

  _searchServicePoint(String? name) {
    setState(() {
      _servicePointName = name;
      _pagingController.itemList = null;
    });
  }

  // ignore: long-method
  Future<void> _fetchPage(int pageKey, ServicePointBody body) async {
    body.dynamicName = _servicePointName;
    if (body.dynamicName == null) return;
    try {
      var response = await getServicePointList(body);
      if (response.success == true) {
        final data = response.data;
        final list = data?.list;
        final isLastPage =
            (data?.totalRow ?? 1) <= (_pagingController.itemList?.length ?? 0);
        if (isLastPage) {
          _pagingController.appendLastPage(list ?? []);
        } else {
          _pagingController.appendPage(
            (list ?? []),
            pageKey + 1,
          );
        }
      }
    } catch (error) {
      _pagingController.error = error;
    }
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;

    return ListView(
      padding: widget.padding,
      children: [
        Text(_copy('packages.search-apartment'), style: typo.bd1.medium),
        const SizedBox(height: 8),
        TextFormField(
          onFieldSubmitted: _searchServicePoint,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            hintText: _copy('packages.search-apartment-ex'),
          ),
        ),
        const SizedBox(height: 24),
        if (_servicePointName != null)
          ServicePointFinderView(
            onSelect: widget.onSearch,
            pagingController: _pagingController,
          ),
      ],
    );
  }
}
