import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/widgets/styles/nv_button/nv_button.dart';

class NvButton extends StatelessWidget {
  const NvButton({
    Key? key,
    required this.label,
    required this.action,
    this.variant = ButtonVariant.primary,
    this.textColor = Colors.white,
  }) : super(key: key);

  final String label;
  final VoidCallback? action;
  final String variant;
  final Color? textColor;
  static const _height = 48.0;
  static const _fontSize = 16.0;

  @override
  Widget build(BuildContext context) {
    // ignore: long-method
    ButtonStyle _getButtonStyle() {
      switch (variant) {
        case ButtonVariant.primary:
          return getPrimaryButtonStyle(context);
        case ButtonVariant.secondary:
          return getSecondaryButtonStyle(context);
        case ButtonVariant.secondaryText:
          return getSecondaryButtonStyle(
            context,
            variant: SecondaryButtonVariant.text,
          );
        case ButtonVariant.tertiary:
          return getTertiaryButtonStyle(context);
        case ButtonVariant.tertiaryLink:
          return getTertiaryButtonStyle(
            context,
            variant: TertiaryButtonVariant.link,
          );
        case ButtonVariant.bottomSheetPrimary:
          return getPrimaryButtonStyle(context);
        case ButtonVariant.bottomSheetSecondary:
          return getSecondaryButtonStyle(context);
        default:
          return getPrimaryButtonStyle(context);
      }
    }

    return SizedBox(
      width: variant.contains("tertiary") ? null : double.infinity,
      height: _height,
      child: TextButton(
        onPressed: action,
        style: _getButtonStyle(),
        child: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: _fontSize,
            decoration: variant == ButtonVariant.tertiaryLink
                ? TextDecoration.underline
                : null,
          ),
        ),
      ),
    );
  }
}

abstract class ButtonVariant {
  static const primary = 'primary';
  static const secondary = 'secondary';
  static const secondaryText = 'secondaryText';
  static const tertiary = 'tertiary';
  static const tertiaryLink = 'tertiary-link';
  static const bottomSheetPrimary = 'nv-bottom-sheet-primary';
  static const bottomSheetSecondary = 'nv-bottom-sheet-secondary';
}
