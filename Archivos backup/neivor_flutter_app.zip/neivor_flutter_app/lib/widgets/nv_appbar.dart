import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';

class NvAppBar extends StatelessWidget with PreferredSizeWidget {
  final String? title;
  final String? subtitle;
  final double? elevation;
  final List<Widget>? actions;
  final Function backAction;
  final Color? bgColor;
  const NvAppBar({
    Key? key,
    this.title,
    this.elevation,
    this.actions,
    this.subtitle,
    required this.backAction,
    this.bgColor,
  }) : super(key: key);
  static const double _backSize = 45;
  static const double _backSpacing = 20;
  static const double _height = 58;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: bgColor ?? Colors.white,
      actions: actions,
      leadingWidth: _backSize,
      leading: GestureDetector(
        onTap: () => backAction(),
        child: Transform.translate(
          offset: const Offset(10, 0),
          child: const CircleAvatar(
            backgroundColor: AppTheme.grayBackIcon,
            radius: 75,
            child: Icon(
              Icons.keyboard_backspace,
              color: AppTheme.black0Main,
            ),
          ),
        ),
      ),
      titleSpacing: _backSpacing,
      title: subtitle == null
          ? Text(title ?? '')
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title ?? ''),
                Text(
                  subtitle ?? '',
                  style: const TextStyle(
                    fontWeight: FontWeight.w300,
                    fontSize: 10,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ],
            ),
      toolbarHeight: _height,
      elevation: elevation ?? 0,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
