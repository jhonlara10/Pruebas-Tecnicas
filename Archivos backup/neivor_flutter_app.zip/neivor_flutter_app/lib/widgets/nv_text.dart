import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';

/// Generic Text Widget class.
///
/// Params:
/// [String] textHolder - Text to be displayed.
/// [String] fontFamily - Component font (this font needs to be referenced locally).
/// [FontWeight] fontWeight - bold, italic, etc. Example: [FontWeight.bold]
/// [double] fontSize - Text size, example: ([10]).
/// [Color] color - Text Color, ref [Colors] class, example: [Colors.black]
/// [TextAlign] textAlign - center, left, right.
///
/// Returns:
/// [NvText] Widget to display in UI

class NvText extends StatelessWidget {
  const NvText({
    Key? key,
    this.textHolder,
    this.copy,
    this.fontFamily,
    required this.fontWeight,
    required this.fontSize,
    required this.color,
    this.maxLines,
    this.textAlign,
    this.textDecoration = TextDecoration.none,
    this.overflow,
  }) : super(key: key);

  final String? copy;
  final String? textHolder;
  final String? fontFamily;
  final FontWeight? fontWeight;
  final double? fontSize;
  final Color? color;
  final TextAlign? textAlign;
  final TextDecoration? textDecoration;
  final int? maxLines;
  final TextOverflow? overflow;

  @override
  Widget build(BuildContext context) {
    return Text(
      copy == null ? textHolder ?? "" : AppMessages().getCopy(copy),
      maxLines: maxLines,
      textAlign: textAlign,
      style: TextStyle(
        fontFamily: fontFamily,
        fontWeight: fontWeight,
        fontSize: fontSize,
        color: color,
        decoration: textDecoration,
        overflow: overflow,
      ),
    );
  }
}
