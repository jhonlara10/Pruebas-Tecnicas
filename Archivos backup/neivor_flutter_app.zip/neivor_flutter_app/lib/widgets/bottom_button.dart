import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

class BottomButton extends StatelessWidget {
  final void Function()? action;
  final void Function()? secondaryAction;
  final String buttonText;
  final String? variant;
  final bool disabled;
  final String secondaryText;
  final String secondaryVariant;
  final bool secondaryDisabled;
  final Axis direction;
  static const height = 200.0;

  const BottomButton({
    Key? key,
    required this.action,
    this.secondaryAction,
    required this.buttonText,
    this.variant,
    this.disabled = false,
    this.secondaryVariant = ButtonVariant.secondary,
    this.secondaryDisabled = false,
    this.secondaryText = '',
    this.direction = Axis.horizontal,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    const verticalPadding = 24.0;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: colors.backgrounds.main,
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            colors.backgrounds.main.withOpacity(0.2), //ignore: no-magic-number
            colors.backgrounds.main,
          ],
          stops: const [0.0, 0.25],
        ),
      ),
      child: Padding(
        padding: DefaultValues.padding.copyWith(
          top: verticalPadding,
          bottom: verticalPadding, // ignore: no-equal-arguments
        ),
        child: Flex(
          verticalDirection: direction == Axis.vertical
              ? VerticalDirection.up
              : VerticalDirection.down,
          mainAxisSize:
              direction == Axis.vertical ? MainAxisSize.min : MainAxisSize.max,
          direction: direction,
          children: [
            if (secondaryText != '')
              Expanded(
                flex: direction == Axis.horizontal ? 1 : 0,
                child: NvButton(
                  label: secondaryText,
                  action: secondaryDisabled ? null : secondaryAction,
                  variant: secondaryVariant,
                ),
              ),
            if (secondaryText != '') const SizedBox(width: 8, height: 8),
            Expanded(
              flex: direction == Axis.horizontal ? 1 : 0,
              child: NvButton(
                label: buttonText,
                action: disabled ? null : action,
                variant: variant ?? '',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
