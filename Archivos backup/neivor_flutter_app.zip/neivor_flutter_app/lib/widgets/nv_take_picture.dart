// A screen that allows users to take a picture using a given camera.
import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_id_photo.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_plate_photo.dart';

class NvTakePicture extends StatefulWidget {
  final String from;
  final CameraDescription camera;
  final String visitorName;
  final ServicePointObject? servicePointObject;
  final Map<String, dynamic> data;

  const NvTakePicture({
    Key? key,
    required this.camera,
    required this.from,
    required this.visitorName,
    this.servicePointObject,
    required this.data,
  }) : super(key: key);

  @override
  NvTakePictureState createState() => NvTakePictureState();
}

class NvTakePictureState extends State<NvTakePicture> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;

  @override
  void initState() {
    super.initState();
    // To display the current output from the Camera,
    // create a CameraController.
    _controller = CameraController(
      // Get a specific camera from the list of available cameras.
      widget.camera,
      // Define the resolution to use.
      ResolutionPreset.max,
    );

    // Next, initialize the controller. This returns a Future.
    _initializeControllerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    // Dispose of the controller when the widget is disposed.
    _controller.dispose();
    super.dispose();
  }

  goToPlatePhoto(String base64Image, String path) {
    widget.data["base64IdPhoto"] = base64Image;
    widget.data["idPhotoPath"] = path;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitIdPhoto(
          visitorName: widget.visitorName,
          servicePointObject: widget.servicePointObject,
          data: widget.data,
          path: path,
        ),
      ),
    );
  }

  goToResume(String base64Image, String path) {
    widget.data["base64PlatePhoto"] = base64Image;
    widget.data["platePhotoPath"] = path;
    widget.data['licensePlate'] = '';
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitPlatePhoto(
          visitorName: widget.visitorName,
          servicePointObject: widget.servicePointObject,
          data: widget.data,
          path: path,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // You must wait until the controller is initialized before displaying the
      // camera preview. Use a FutureBuilder to display a loading spinner until the
      // controller has finished initializing.
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            // If the Future is complete, display the preview.
            return Stack(children: [
              Center(
                child: CameraPreview(_controller),
              ),
            ]);
          } else {
            // Otherwise, display a loading indicator.
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        // Provide an onPressed callback.
        // ignore: prefer-extracting-callbacks
        onPressed: () async {
          // Take the Picture in a try / catch block. If anything goes wrong,
          // catch the error.
          try {
            // Ensure that the camera is initialized.
            await _initializeControllerFuture;

            // Attempt to take a picture and get the file `image`
            // where it was saved.
            final image = await _controller.takePicture();

            final bytes = File(image.path).readAsBytesSync();
            String base64Image = "data:image/png;base64,${base64Encode(bytes)}";

            if (widget.from != "photo-id") {
              goToResume(base64Image, image.path);
            } else {
              goToPlatePhoto(base64Image, image.path);
            }

            if (!mounted) return;
          } catch (e) {
            // If an error occurs, log the error to the console.
            print(e);
          }
        },
        child: const Icon(Icons.camera_alt),
      ),
    );
  }
}
