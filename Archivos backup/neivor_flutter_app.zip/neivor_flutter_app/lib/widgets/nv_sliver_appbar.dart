import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';

/// Custom amenities appbar.
class NvSliverAppbar extends StatelessWidget {
  final String title;
  final Widget? flexibleSpace;
  final void Function()? onGoBack;
  final double expandedHeight;
  final double toolbarHeight;
  static const defaultToolbarHeight = 122.0;
  static const defaultExpandeHeight = 170.0;

  const NvSliverAppbar({
    Key? key,
    this.title = '',
    this.onGoBack,
    this.flexibleSpace,
    this.toolbarHeight = defaultToolbarHeight,
    this.expandedHeight = defaultExpandeHeight,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;
    const arrowBackContainerSize = 32.0;
    const staticHeight = 58.0;

    return SliverAppBar(
      pinned: true,
      iconTheme: IconThemeData(color: typo.bd1.medium.color),
      floating: true,
      titleSpacing: 0,
      toolbarHeight: flexibleSpace == null ? staticHeight : toolbarHeight,
      expandedHeight: flexibleSpace == null ? staticHeight : expandedHeight,
      backgroundColor: Colors.transparent,
      elevation: 0,
      automaticallyImplyLeading: false,
      flexibleSpace: flexibleSpace ??
          FlexibleSpaceBar(
            titlePadding: DefaultValues.padding.copyWith(top: 0, bottom: 0),
            title: Align(
              alignment: Alignment.centerLeft,
              child: Row(
                children: [
                  GestureDetector(
                    onTap: onGoBack ?? () => Navigator.pop(context),
                    child: Container(
                      width: arrowBackContainerSize,
                      height: arrowBackContainerSize,
                      decoration: BoxDecoration(
                        color: colors.primary.arcticGray.main,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.arrow_back),
                    ),
                  ),
                ],
              ),
            ),
          ),
    );
  }
}
