// ignore_for_file: avoid-non-null-assertion
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

/// This Widget was builded to have a generic BottomSheet popup, according to
/// design system alert.
///
/// Params:
/// [double] bottomSheetHeight - Container height
/// [String] iconRoute - Icon asset referenced locally
/// [String] title - Title alert
/// [String] subtitle - Subtitule alert
/// [String] primaryButtonText - First Button text
/// [String] secondaryButtonText - Second Button text
/// [String] primaryButtonVariant - Button variant style (Ref. on [NVButton] class)
/// [String] secondaryButtonVariant - Button variant style (Ref. on [NVButton] class)
/// [VoidCallback] primaryButtonAction - Function called in parent UI when primary button is clicked
/// [VoidCallback] secondaryButtonAction - Function called in parent UI when secondary button is clicked
///
/// Returns:
/// [NvBottomSheet] Widget to display in UI
class NvBottomSheet extends StatelessWidget {
  final double bottomSheetHeight;
  final String iconRoute;
  final String title;
  final String subtitle;
  final String? primaryButtonText;
  final String? secondaryButtonText;
  final String? primaryButtonVariant;
  final String? secondaryButtonVariant;
  final VoidCallback? primaryButtonAction;
  final VoidCallback? secondaryButtonAction;

  const NvBottomSheet({
    Key? key,
    required this.bottomSheetHeight,
    required this.iconRoute,
    required this.title,
    required this.subtitle,
    this.primaryButtonText,
    this.secondaryButtonText,
    this.primaryButtonVariant,
    this.secondaryButtonVariant,
    this.primaryButtonAction,
    this.secondaryButtonAction,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16.0),
          topRight: Radius.circular(16.0),
        ),
      ),
      height: bottomSheetHeight,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(iconRoute, height: 40, width: 40),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: (NvText(
                textHolder: title,
                fontFamily: 'Jost',
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.black,
                textAlign: TextAlign.center,
              )),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: (NvText(
                textHolder: subtitle,
                fontFamily: 'Jost',
                fontWeight: FontWeight.normal,
                fontSize: 15,
                color: Colors.black,
                textAlign: TextAlign.center,
              )),
            ),
            if (primaryButtonText != null)
              Padding(
                padding: const EdgeInsets.only(top: 16, left: 20, right: 20),
                child: NvButton(
                  label: primaryButtonText!,
                  variant: primaryButtonVariant!,
                  action: primaryButtonAction,
                ),
              ),
            if (secondaryButtonText != null)
              Padding(
                padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
                child: NvButton(
                  label: secondaryButtonText!,
                  action: secondaryButtonAction,
                  variant: secondaryButtonVariant!,
                  textColor: Colors.black,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
