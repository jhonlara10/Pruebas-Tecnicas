import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class NvMessage extends StatelessWidget {
  final Widget? child;
  const NvMessage({Key? key, this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    const radius = Radius.circular(4);
    const borderWidth = 8.0;

    return Stack(
      fit: StackFit.loose,
      children: [
        Row(
          children: [
            Expanded(
              child: Container(
                margin: const EdgeInsetsDirectional.only(start: 8),
                decoration: BoxDecoration(
                  color: colors.opacityBackgrounds.indigoBlueOpacity,
                  borderRadius: const BorderRadius.only(
                    topRight: radius,
                    //ignore: no-equal-arguments
                    bottomRight: radius,
                  ),
                ),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  child: child,
                ),
              ),
            ),
          ],
        ),
        Positioned.fill(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: borderWidth,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: colors.secondary.indigoBlue.main,
                    borderRadius: const BorderRadius.only(
                      topLeft: radius,
                      bottomLeft: radius,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
