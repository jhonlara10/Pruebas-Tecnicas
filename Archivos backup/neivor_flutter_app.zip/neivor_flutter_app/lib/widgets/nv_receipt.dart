import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/dashed_divider.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class NvReceipt extends StatelessWidget {
  final String? title;
  final String? subtitle;
  final Widget body;
  final String? icon;
  final Color? iconColor;
  final void Function()? onGoBack;
  final bool hideHeader;

  const NvReceipt({
    Key? key,
    this.title,
    this.subtitle,
    this.hideHeader = false,
    required this.body,
    this.onGoBack,
    this.icon = 'Interface, Essential/Done, Check',
    this.iconColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final backgrounds = AppThemeScope.of(context).backgrounds;
    final colors = AppThemeScope.of(context).colors;
    final shadows = AppThemeScope.of(context).shadows;
    final typo = AppThemeScope.of(context).typography;
    final copy = AppMessages().getCopy;
    const backgroundBoxHeight = 258.0;
    const dividerThickness = 0.1;
    const successIconWidth = 48.0;

    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          SizedBox(
            height: backgroundBoxHeight,
            width: double.infinity,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(
                  bottom: Radius.circular(16),
                ),
                gradient: backgrounds.gradientCoral,
              ),
            ),
          ),
          SafeArea(
            child: CustomScrollView(
              slivers: [
                NvSliverAppbar(onGoBack: onGoBack),
                SliverPadding(
                  padding: DefaultValues.padding,
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      Container(
                        padding: const EdgeInsets.fromLTRB(24, 40, 24, 32),
                        decoration: BoxDecoration(
                          color: colors.backgrounds.main,
                          borderRadius: DefaultValues.borderRadius2,
                          boxShadow: shadows.xLarge,
                        ),
                        child: Column(
                          children: [
                            if (!hideHeader)
                              Column(
                                children: [
                                  NvImage(
                                    icon: icon,
                                    width: successIconWidth,
                                    color: iconColor ?? colors.icons.success,
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    title ?? '',
                                    style: typo.h2.semibold,
                                  ),
                                  if (subtitle != null)
                                    Column(
                                      children: [
                                        const SizedBox(height: 8),
                                        Text(
                                          subtitle ?? '',
                                          style: typo.bd2.light,
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            const SizedBox(height: 24),
                            DashedDivider(
                              thickness: dividerThickness,
                              color: colors.primary.arcticGray.v4,
                            ),
                            const SizedBox(height: 24),
                            body,
                          ],
                        ),
                      ),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomButton(
        action: onGoBack ?? () => Navigator.pop(context),
        buttonText: copy('common.back'),
        variant: ButtonVariant.secondary,
      ),
    );
  }
}
