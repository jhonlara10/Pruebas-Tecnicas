import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';

class NvTopBar extends StatelessWidget with PreferredSizeWidget {
  const NvTopBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppTheme.grayArtic0main,
            ),
            child: const Icon(
              Icons.keyboard_backspace,
              size: 24,
            ),
          ),
        ),
      ),
      elevation: 0,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
