import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class NvDropdown<T> extends StatelessWidget {
  final List? items;
  final String? label;
  final ValueChanged<dynamic>? onChanged;
  final String? placeholder;
  final Map<String, dynamic>? value;

  const NvDropdown({
    Key? key,
    this.placeholder = 'Seleccionar',
    this.items,
    this.label = 'name',
    this.value,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;
    const double buttonHeight = 48;

    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        buttonHeight: buttonHeight,
        buttonPadding: const EdgeInsets.only(left: 16, right: 16),
        buttonDecoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          border: Border.all(color: colors.primary.black.v2, width: 1),
        ),
        value: value,
        isExpanded: true,
        hint: Text(
          placeholder ?? '',
          style: typo.bd1.light.copyWith(color: colors.text.placeholders),
        ),
        items: items
            ?.map((value) => DropdownMenuItem(
                  value: value,
                  child: Text(
                    value[label],
                    style: typo.bd1.light,
                  ),
                ))
            .toList(),
        icon: const Icon(Icons.keyboard_arrow_down),
        onChanged: onChanged,
      ),
    );
  }
}
