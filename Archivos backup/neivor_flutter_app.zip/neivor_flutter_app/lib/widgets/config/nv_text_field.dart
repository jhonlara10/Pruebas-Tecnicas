import 'dart:io';

import 'package:flutter/material.dart';

import '../../theme/app_theme_scope.dart';

class NvTextField extends StatelessWidget {
  const NvTextField({
    Key? key,
    required this.textHolder,
    required this.label,
    required this.controller,
    required this.formValues,
    required this.action,
    this.textType = 'text',
    this.maxLength = 999999,
    this.icon,
  }) : super(key: key);

  final String textHolder;
  final String textType;
  final String label;
  final Icon? icon;
  final Function action;
  final TextEditingController controller;
  final Map<String, dynamic> formValues;
  final int maxLength;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return TextField(
      controller: controller,
      keyboardType: textType == 'number'
          ? (Platform.isAndroid
              ? TextInputType.number
              : const TextInputType.numberWithOptions(
                  signed: true,
                  decimal: true,
                ))
          : null,
      maxLength: maxLength,
      decoration: InputDecoration(
        counterText: "",
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16.0,
          vertical: 12.5,
        ),
        prefixIcon: icon,
        hintText: textHolder,
        hintStyle: const TextStyle(
          fontSize: 14.0,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          borderSide: BorderSide(
            color: colors.primary.black.v2,
            width: 1.0,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          borderSide: BorderSide(
            color: colors.primary.black.v2,
            width: 1.0,
          ),
        ),
      ),
      onChanged: (value) {
        action(value);
        formValues[label] = value;
      },
    );
  }
}
