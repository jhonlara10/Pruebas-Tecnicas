import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class NvCarousel extends StatefulWidget {
  final List<String>? images;

  const NvCarousel({
    Key? key,
    this.images = const [],
  }) : super(key: key);

  @override
  State<NvCarousel> createState() => _NvCarouselState();
}

class _NvCarouselState extends State<NvCarousel> {
  static final CarouselController _carouselController = CarouselController();
  int _currentIndex = 0;

  void _setIndex(int index, CarouselPageChangedReason? reason) {
    setState(() {
      _currentIndex = index;
    });
  }

  void _onDotClick(int index) {
    _carouselController.animateToPage(index);
    _setIndex(index, null);
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        CarouselSlider(
          carouselController: _carouselController,
          items: widget.images
              ?.map((e) => NvImage(
                    imageUrl: e,
                    isStatic: true,
                    fit: BoxFit.fill,
                    width: double.infinity,
                  ))
              .toList(),
          options: CarouselOptions(
            height: 192, //ignore: no-magic-number
            viewportFraction: 1.0,
            enlargeCenterPage: false,
            onPageChanged: _setIndex,
          ),
        ),
        Container(
          padding: const EdgeInsets.only(bottom: 10),
          child: AnimatedSmoothIndicator(
            activeIndex: _currentIndex,
            count: widget.images?.length ?? 0,
            effect: ExpandingDotsEffect(
              dotHeight: 10, //ignore: no-magic-number
              dotWidth: 10, //ignore: no-magic-number
              //ignore: no-magic-number
              dotColor: colors.backgrounds.white.withOpacity(0.8),
              //ignore: no-equal-arguments
              activeDotColor: colors.backgrounds.white,
              expansionFactor: 2, //ignore: no-magic-number
            ),
            onDotClicked: _onDotClick,
          ),
        ),
      ],
    );
  }
}
