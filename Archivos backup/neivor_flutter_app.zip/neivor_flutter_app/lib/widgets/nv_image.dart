import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:lottie/lottie.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class NvImage extends StatelessWidget {
  final String? imageUrl;
  final bool? shadow;
  final double? width;
  final double? height;
  final Color? color;
  final bool? isUserImage;
  final bool? isStatic;
  final bool? enterpriseLogo;
  final BoxFit? fit;
  final String? icon;

  const NvImage({
    Key? key,
    this.imageUrl,
    this.shadow,
    this.width,
    this.height,
    this.color,
    this.isUserImage,
    this.fit,
    this.isStatic,
    this.icon,
    this.enterpriseLogo,
  }) : super(key: key);

  final String regex = "[^\\s]+(.*?)\\.(jpg|jpeg|png|gif|JPG|JPEG|PNG|GIF)\$";
  static const double _blurRadius = 7;

  /// It returns true if the url is an image, false otherwise
  ///
  /// Args:
  ///   url (String): The URL of the image.
  ///
  /// Returns:
  ///   A boolean value.
  bool isSvg(String? url) {
    if (url == null) {
      return false;
    }
    return !(RegExp(regex).hasMatch(url));
  }

  @override
  Widget build(BuildContext context) {
    //ignore: avoid-non-null-assertion, no_leading_underscores_for_local_identifiers
    final _icon = icon != null ? '/ds/icons/${icon!}.svg' : null;
    final colors = AppThemeScope.of(context).colors;

    Color? getColor() {
      if (icon != null && color == null) {
        return colors.icons.main;
      }
      return color;
    }

    if ((imageUrl == null && _icon == null)) {
      return Image.asset(
        "assets/images/no_avatar.png",
        width: width,
        height: height,
      );
    } else if (imageUrl?.contains("googleusercontent") ?? false) {
      return FadeInImage(
        width: width,
        height: height,
        fit: fit,
        image: NetworkImage(imageUrl ?? ''),
        placeholder: const NetworkImage(
          "https://cdn.neivor.com/cdn/mexico/static/ds/icons/loadingSpinner.gif",
        ),
      );
    } else {
      return isSvg(imageUrl ?? _icon)
          ? Container(
              decoration: BoxDecoration(boxShadow: [
                if ((shadow ?? false))
                  BoxShadow(
                    color: Colors.black.withOpacity(Constants.twentyPercent),
                    spreadRadius: 0,
                    blurRadius: _blurRadius,
                    offset: const Offset(5, 5),
                  ),
              ]),
              child: SvgPicture.network(
                GlobalUtils().staticCdn(imageUrl ?? _icon ?? ''),
                width: width,
                height: height,
                color: getColor(),
              ),
            )
          : Container(
              decoration: BoxDecoration(boxShadow: [
                if ((shadow ?? false))
                  BoxShadow(
                    color: Colors.black.withOpacity(Constants.twentyPercent),
                    spreadRadius: 0,
                    blurRadius: _blurRadius,
                    offset: const Offset(5, 5),
                  ),
              ]),
              child: FadeInImage(
                width: width,
                height: height,
                fit: fit,
                image: !(enterpriseLogo ?? false)
                    // ignore: avoid-nested-conditional-expressions
                    ? (NetworkImage((isUserImage ?? isStatic ?? false)
                        ? GlobalUtils().cdn(imageUrl ?? _icon ?? '')
                        : GlobalUtils().staticCdn(imageUrl ?? _icon ?? '')))
                    : NetworkImage(
                        // ignore: avoid-nested-conditional-expressions
                        "https://cdn.neivor.com/cdn/${GlobalUtils.countryId == Constants.mxIntIdCode ? 'mexico' : 'colombia'}/resources/web/$imageUrl",
                      ),
                placeholder: const NetworkImage(
                  "https://cdn.neivor.com/cdn/mexico/static/ds/icons/loadingSpinner.gif",
                ),
                imageErrorBuilder: (
                  BuildContext context,
                  Object object,
                  StackTrace? stackTrace,
                ) {
                  return (isUserImage ?? false)
                      ? NvImage(
                          isUserImage: true,
                          imageUrl: '/default/no_avatar.png',
                          width: width,
                          height: height,
                        )
                      : Lottie.network(
                          'https://assets10.lottiefiles.com/packages/lf20_rwq6ciql.json',
                          width: width,
                          height: height,
                        );
                },
              ),
            );
    }
  }
}
