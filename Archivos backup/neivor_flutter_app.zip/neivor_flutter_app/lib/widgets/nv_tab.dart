import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class NvTab extends StatelessWidget {
  const NvTab({
    Key? key,
    required this.name,
    this.active = false,
  }) : super(key: key);

  final String name;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    TextStyle getTypography() {
      if (active) {
        return typo.bd1.medium.copyWith(color: colors.primary.turquoise.main);
      }
      return typo.bd1.light.copyWith(color: colors.primary.black.main);
    }

    return Container(
      height: 48.0,
      width: double.infinity,
      padding: const EdgeInsets.all(8.0),
      color: colors.primary.arcticGray.v5,
      child: (Text(
        name,
        style: getTypography(),
      )),
    );
  }
}
