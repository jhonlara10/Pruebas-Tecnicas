import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/widgets/nv_youtube_player.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import 'nv_vimeo_player.dart';

class NvVideoPlayer extends StatefulWidget {
  NvVideoPlayer({Key? key, required this.videoUrl}) : super(key: key);

  String videoUrl;

  @override
  _NvVideoPlayerState createState() => _NvVideoPlayerState();
}

class _NvVideoPlayerState extends State<NvVideoPlayer> {
  var videoId;
  String? videoPlatform;
  late YoutubePlayerController _controller;

  /// State initializer.
  @override
  void initState() {
    super.initState();
    videoPlatform = getVideoPlatform(widget.videoUrl);
  }

  /// Validate type of URL.
  getVideoPlatform(videoUrl) {
    if (!RegExp(
      r"^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$",
    ).hasMatch(videoUrl)) {
      return "vimeo";
    } else {
      return "youtube";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (videoPlatform == 'youtube')
          NvYoutubeVideoPlayer(videoUrl: widget.videoUrl),
        if (videoPlatform == 'vimeo')
          VimeoVideoPlayer(
            url: widget.videoUrl,
          ),
      ],
    );
  }
}
