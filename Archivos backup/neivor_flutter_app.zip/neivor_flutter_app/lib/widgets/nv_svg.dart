import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class NvSvg extends StatelessWidget {
  final String svgName;
  final bool shadow;
  final double? width;
  final double? height;
  final Color? color;

  @Deprecated("""Use [NvImage] instead""")
  const NvSvg({
    Key? key,
    required this.svgName,
    required this.shadow,
    this.width,
    this.height,
    this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(boxShadow: [
        if (shadow)
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            spreadRadius: 0,
            blurRadius: 7,
            offset: const Offset(5, 5),
          ),
      ]),
      child: SvgPicture.network(
        'https://miedificio.co/cdn/dev/static/$svgName',
        width: width,
        height: height,
        color: color,
      ),
    );
  }
}
