import 'package:flutter/material.dart';

class AppTheme {
  // Colors.
  static const Color coral0Main = Color(0xFFFF595A);
  static const Color colar1Main = Color(0xFFFF4D78);
  static const Color black0Main = Color(0xFF0D0E0F);
  static const Color black1 = Color(0xFFEBEBEB);
  static const Color black2 = Color(0xFFD5D6D7);
  static const Color black3 = Color(0xFF97999B);
  static const Color black4 = Color(0xFF000000);
  static const Color black5 = Color(0xFF1A1C1F);
  static const Color grayBorder = Color(0xFFDDDDDD);
  static const Color blueButtons = Color(0xFFEEF3F8);
  // Text Main color.
  static const Color textPrimary = Color(0xFF222222);
  // Button outline default.
  static const Color buttonOutline = Color(0xFF353535);
  // Icons Colors.
  static const Color iconSuccess = Color(0XFF0EC564);
  static const Color iconError = Color(0xFFFF4E78);
  // Turquoise - Tones - Background.
  static const Color turquoise0Main = Color(0xFF3EC7B5);
  static const Color turquoise2 = Color(0xFFD8F4F0);
  static const Color turquoise4 = Color(0xFF287D71);
  // Yellow.
  static const Color yellow0Main = Color(0xFFFFFB1B);
  static const Color yellow4 = Color(0xFFD47611);
  // Blue Indigo.
  static const Color blueIndigo0Main = Color(0xFF3C76FF);
  static const Color blueIndigo4 = Color(0xFF244596);
  // Green Arlequin.
  static const Color greenArlequin0main = Color(0xFF0EC564);
  static const Color greenArlequin4 = Color(0xFF076E39);
  // Gray Artic.
  static const Color grayArtic0main = Color(0xFFF5F5F5);
  static const Color grayArtic5 = Colors.white;
  // Rose Ponche.
  static const Color rosePonche0Main = Color(0xFFFF4E78);
  // Light theme.
  static const Color grayBackIcon = Color(0xFFF3F3F4);
  static const Color turquoiseLink = Color(0xFF287D71);

  static const Color purpleColor = Color(0xFF0045BE);
  static const Color cobaltoBlue = Color(0xFF111B30);
  static const Color cobalto2Blue = Color(0xFF233963);
  static const Color cobalto3Blue = Color(0xFFD3D7E0);

  static const Color warningColor = Color(0xFFFFAB1B);
  static const Color turquoiseGreen = Color(0xFF287D71);

  static final ThemeData lightTheme = ThemeData.light().copyWith(
    //ignore: avoid-missing-enum-constant-in-map
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.iOS: ZoomPageTransitionsBuilder(),
      TargetPlatform.android: CupertinoPageTransitionsBuilder(),
    }),
    textTheme: const TextTheme(
      headline4: TextStyle(
        fontFamily: 'Jost',
        color: black0Main,
        fontWeight: FontWeight.w500,
        fontSize: 14,
      ),
      bodyText1: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      bodyText2: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      button: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      caption: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      headline1: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      headline2: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      headline3: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      headline5: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      headline6: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      overline: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      subtitle1: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
      subtitle2: TextStyle(
        color: black0Main,
        fontFamily: 'Jost',
      ),
    ),
    canvasColor: Colors.white,
    // Primary color.
    primaryColor: coral0Main,
    appBarTheme: const AppBarTheme(
      color: grayArtic5,
      titleTextStyle: TextStyle(
        color: black0Main,
        fontSize: 20,
        fontWeight: FontWeight.w500,
      ),
      iconTheme: IconThemeData(
        color: black0Main,
        size: 32,
      ),
    ),
    // Text buttons.
    textButtonTheme:
        TextButtonThemeData(style: TextButton.styleFrom(primary: coral0Main)),
    // Floatin action button.
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: coral0Main,
      elevation: 5,
    ),
    // Elevated button.
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        primary: AppTheme.coral0Main,
        shape: const StadiumBorder(),
        elevation: 0,
      ),
    ),
    // Input decoration.
    inputDecorationTheme: const InputDecorationTheme(
      hintStyle: TextStyle(
        fontStyle: FontStyle.italic,
        fontFamily: "Jost",
        fontWeight: FontWeight.w400,
        fontSize: 12,
      ),
      isDense: true,
      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      floatingLabelStyle: TextStyle(color: black0Main),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: black1),
        borderRadius: BorderRadius.all(
          Radius.circular(4),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: black1),
        borderRadius: BorderRadius.all(
          Radius.circular(4),
        ),
      ),
      border: OutlineInputBorder(
        borderSide: BorderSide(color: black1),
        borderRadius: BorderRadius.all(
          Radius.circular(4),
        ),
      ),
    ),
    scaffoldBackgroundColor: grayArtic5,
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: Colors.transparent,
    ),
    //!to discuss
    // End.
  );

  static final ThemeData darkTheme = ThemeData.dark().copyWith(
    primaryColor: coral0Main,
    appBarTheme: const AppBarTheme(color: coral0Main),
  );
}
