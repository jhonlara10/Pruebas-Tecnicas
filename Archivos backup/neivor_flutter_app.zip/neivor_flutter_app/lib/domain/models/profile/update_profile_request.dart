class UpdateProfileRequest {
  int? id;
  int? userChange;
  String? mobilePhone;
  String? documentNumber;
  String? ocupation;
  String? alias;
  String? name;

  UpdateProfileRequest({
    this.id,
    this.userChange,
    this.mobilePhone,
    this.documentNumber,
    this.ocupation,
    this.alias,
    this.name,
  });

  UpdateProfileRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userChange = json['userChange'];
    mobilePhone = json['mobilePhone'];
    documentNumber = json['documentNumber'];
    ocupation = json['ocupation'];
    alias = json['alias'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userChange'] = userChange;
    data['mobilePhone'] = mobilePhone;
    data['documentNumber'] = documentNumber;
    data['ocupation'] = ocupation;
    data['alias'] = alias;
    data['name'] = name;
    return data;
  }
}
