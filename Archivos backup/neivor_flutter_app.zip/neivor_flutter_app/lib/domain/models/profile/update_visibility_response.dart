class UpdateVisibilityResponse {
  bool? successEditUser;
  String? message;
  String? validationBirthday;

  UpdateVisibilityResponse({
    this.successEditUser,
    this.message,
    this.validationBirthday,
  });

  UpdateVisibilityResponse.fromJson(Map<String, dynamic> json) {
    successEditUser = json['successEditUser'];
    message = json['message'];
    validationBirthday = json['validationBirthday'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successEditUser'] = successEditUser;
    data['message'] = message;
    data['validationBirthday'] = validationBirthday;
    return data;
  }
}
