class UpdateProfileResponse {
  bool? successEditUser;
  String? message;
  String? validationBirthday;

  UpdateProfileResponse({
    this.successEditUser,
    this.message,
    this.validationBirthday,
  });

  UpdateProfileResponse.fromJson(Map<String, dynamic> json) {
    successEditUser = json['successEditUser'];
    message = json['message'];
    validationBirthday = json['validationBirthday'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successEditUser'] = successEditUser;
    data['message'] = message;
    data['validationBirthday'] = validationBirthday;
    return data;
  }
}
