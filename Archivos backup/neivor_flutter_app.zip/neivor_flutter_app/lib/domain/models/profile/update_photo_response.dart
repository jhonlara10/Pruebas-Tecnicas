class UpdatePhotoResponse {
  bool? successUpdatePhoto;
  String? photo;

  UpdatePhotoResponse({this.successUpdatePhoto, this.photo});

  UpdatePhotoResponse.fromJson(Map<String, dynamic> json) {
    successUpdatePhoto = json['successUpdatePhoto'];
    photo = json['photo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successUpdatePhoto'] = successUpdatePhoto;
    data['photo'] = photo;
    return data;
  }
}
