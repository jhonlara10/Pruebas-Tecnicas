class UpdatePhotoRequest {
  int? id;
  int? idEnterprise;
  String? photo;
  int? userChange;

  UpdatePhotoRequest({this.id, this.idEnterprise, this.photo, this.userChange});

  UpdatePhotoRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idEnterprise = json['idEnterprise'];
    photo = json['photo'];
    userChange = json['userChange'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idEnterprise'] = idEnterprise;
    data['photo'] = photo;
    data['userChange'] = userChange;
    return data;
  }
}
