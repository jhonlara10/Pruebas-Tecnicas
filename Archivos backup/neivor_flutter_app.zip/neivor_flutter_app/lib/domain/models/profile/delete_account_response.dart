class DeleteAccounResponse {
  bool? success;
  Info? info;
  Data? data;

  DeleteAccounResponse({this.success, this.info, this.data});

  DeleteAccounResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = data;
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  String? userChange;
  int? state;
  int? blackList;
  String? alias;

  Data({this.id, this.userChange, this.state, this.blackList, this.alias});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userChange = json['userChange'];
    state = json['state'];
    blackList = json['blackList'];
    alias = json['alias'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userChange'] = userChange;
    data['state'] = state;
    data['blackList'] = blackList;
    data['alias'] = alias;
    return data;
  }
}
