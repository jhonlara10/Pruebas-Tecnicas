class ProfileData {
  int? id;
  String? dateCreation;
  String? userCreation;
  int? state;
  bool? skipOnboard;
  String? documentNumber;
  String? name;
  String? phone;
  String? mobilePhone;
  String? email;
  int? blackList;
  int? idDocumentType;
  String? ocupation;
  String? photo;
  int? hideUserFromNeighbors;
  String? alias;
  double? costAdmon;
  List<ZyosUserEnterprise>? zyosUserEnterprise;

  ProfileData({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.state,
    this.skipOnboard,
    this.documentNumber,
    this.name,
    this.phone,
    this.mobilePhone,
    this.email,
    this.blackList,
    this.idDocumentType,
    this.ocupation,
    this.photo,
    this.hideUserFromNeighbors,
    this.alias,
    this.costAdmon,
    this.zyosUserEnterprise,
  });

  // ignore: long-method
  ProfileData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    state = json['state'];
    skipOnboard = json['skipOnboard'];
    documentNumber = json['documentNumber'];
    name = json['name'];
    phone = json['phone'];
    mobilePhone = json['mobilePhone'];
    email = json['email'];
    blackList = json['blackList'];
    idDocumentType = json['idDocumentType'];
    ocupation = json['ocupation'];
    photo = json['photo'];
    hideUserFromNeighbors = json['hideUserFromNeighbors'];
    alias = json['alias'];
    costAdmon = json['costAdmon'];
    if (json['zyosUserEnterprise'] != null) {
      zyosUserEnterprise = <ZyosUserEnterprise>[];
      json['zyosUserEnterprise'].forEach((v) {
        zyosUserEnterprise?.add(ZyosUserEnterprise.fromJson(v));
      });
    }
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['state'] = state;
    data['skipOnboard'] = skipOnboard;
    data['documentNumber'] = documentNumber;
    data['name'] = name;
    data['phone'] = phone;
    data['mobilePhone'] = mobilePhone;
    data['email'] = email;
    data['blackList'] = blackList;
    data['idDocumentType'] = idDocumentType;
    data['ocupation'] = ocupation;
    data['photo'] = photo;
    data['hideUserFromNeighbors'] = hideUserFromNeighbors;
    data['alias'] = alias;
    data['costAdmon'] = costAdmon;
    if (zyosUserEnterprise != null) {
      data['zyosUserEnterprise'] =
          zyosUserEnterprise?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ZyosUserEnterprise {
  int? idEnterprise;
  int? idZyosUser;

  ZyosUserEnterprise({this.idEnterprise, this.idZyosUser});

  ZyosUserEnterprise.fromJson(Map<String, dynamic> json) {
    idEnterprise = json['idEnterprise'];
    idZyosUser = json['idZyosUser'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEnterprise'] = idEnterprise;
    data['idZyosUser'] = idZyosUser;
    return data;
  }
}
