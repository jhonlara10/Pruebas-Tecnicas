class GetChatMsgsResponse {
  double? dateCreation;
  int? totalRow;
  int? idConversation;
  int? idComplaintDemand;
  int? numberMembers;
  bool? read;
  String? messageBody;
  String? photoUserDestiny;
  String? nameConversation;
  bool? group;
  bool? newMessage;
  bool? pqr;
  // ignore: prefer-correct-identifier-length
  double? dateCreationConversation;
  int? idZyosUserDestiny;

  GetChatMsgsResponse({
    this.dateCreation,
    this.totalRow,
    this.idConversation,
    this.idComplaintDemand,
    this.numberMembers,
    this.read,
    this.messageBody,
    this.photoUserDestiny,
    this.nameConversation,
    this.group,
    this.newMessage,
    this.pqr,
    this.dateCreationConversation,
    this.idZyosUserDestiny,
  });

  GetChatMsgsResponse.fromJson(Map<String, dynamic> json) {
    dateCreation = json['dateCreation'];
    totalRow = json['totalRow'];
    idConversation = json['idConversation'];
    idComplaintDemand = json['idComplaintDemand'];
    numberMembers = json['numberMembers'];
    read = json['read'];
    messageBody = json['messageBody'];
    photoUserDestiny = json['photoUserDestiny'];
    nameConversation = json['nameConversation'];
    group = json['group'];
    newMessage = json['newMessage'];
    pqr = json['pqr'];
    dateCreationConversation = json['dateCreationConversation'];
    idZyosUserDestiny = json['idZyosUserDestiny'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['dateCreation'] = dateCreation;
    data['totalRow'] = totalRow;
    data['idConversation'] = idConversation;
    data['idComplaintDemand'] = idComplaintDemand;
    data['numberMembers'] = numberMembers;
    data['read'] = read;
    data['messageBody'] = messageBody;
    data['photoUserDestiny'] = photoUserDestiny;
    data['nameConversation'] = nameConversation;
    data['group'] = group;
    data['newMessage'] = newMessage;
    data['pqr'] = pqr;
    data['dateCreationConversation'] = dateCreationConversation;
    data['idZyosUserDestiny'] = idZyosUserDestiny;
    return data;
  }
}
