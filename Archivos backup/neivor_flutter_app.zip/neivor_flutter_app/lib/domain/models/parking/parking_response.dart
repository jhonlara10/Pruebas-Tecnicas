class ParkingResponse {
  int? id;
  double? dateCreation;
  String? name;
  int? idServicePoint;
  double? cost;

  ParkingResponse({
    this.id,
    this.dateCreation,
    this.name,
    this.idServicePoint,
    this.cost,
  });

  ParkingResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    name = json['name'];
    idServicePoint = json['idServicePoint'];
    cost = json['cost'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['name'] = name;
    data['idServicePoint'] = idServicePoint;
    data['cost'] = cost;
    return data;
  }
}
