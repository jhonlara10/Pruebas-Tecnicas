/// DTO Country class to get API response from settings service.
class Country {
  int? id;
  int? state;
  String? name;
  String? indicative;
  String? code;
  String? locale;
  String? currency;
  String? language;
  int? idEnviroment;

  Country({
    this.id,
    this.state,
    this.name,
    this.indicative,
    this.code,
    this.locale,
    this.currency,
    this.language,
    this.idEnviroment,
  });

  Country.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    name = json['name'];
    indicative = json['indicative'];
    code = json['code'];
    locale = json['locale'];
    currency = json['currency'];
    language = json['language'];
    idEnviroment = json['idEnviroment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['name'] = name;
    data['indicative'] = indicative;
    data['code'] = code;
    data['locale'] = locale;
    data['currency'] = currency;
    data['language'] = language;
    data['idEnviroment'] = idEnviroment;
    return data;
  }
}
