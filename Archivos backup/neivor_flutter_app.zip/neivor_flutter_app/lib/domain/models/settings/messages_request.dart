class MessagesRequest {
  String? idLanguage;
  int? idSource;
  String? idCountry;
  bool? forceReload;

  MessagesRequest(
    this.idLanguage,
    this.idSource,
    this.idCountry,
    this.forceReload,
  );

  MessagesRequest.fromJson(Map<String, dynamic> json) {
    idLanguage = json['idLanguage'];
    idSource = json['idSource'];
    idCountry = json['idCountry'];
    forceReload = json['forceReload'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idLanguage'] = idLanguage;
    data['idSource'] = idSource;
    data['idCountry'] = idCountry;
    data['forceReload'] = forceReload;
    return data;
  }
}
