class Setting {
  int? id;
  int? state;
  String? name;
  String? value;

  Setting({this.id, this.state, this.name, this.value});

  Setting.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    name = json['name'];
    value = json['value'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['name'] = name;
    data['value'] = value;
    return data;
  }
}
