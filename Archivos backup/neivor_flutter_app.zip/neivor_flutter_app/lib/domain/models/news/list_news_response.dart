class ListNewsResponse {
  int? id;
  double? dateCreation;
  int? userCreation;
  double? dateChange;
  int? state;
  int? idEnterprise;
  String? name;
  String? description;
  String? videoUri;
  int? idNoticeType;
  int? idNoticePublicationType;
  bool? publish;
  ZyosUser? zyosUser;
  String? image;
  ReactionCountJson? reactionCountJson;

  ListNewsResponse({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.dateChange,
    this.state,
    this.idEnterprise,
    this.name,
    this.description,
    this.videoUri,
    this.idNoticeType,
    this.idNoticePublicationType,
    this.publish,
    this.zyosUser,
    this.image,
    this.reactionCountJson,
  });

  // ignore: long-method
  ListNewsResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    dateChange = json['dateChange'];
    state = json['state'];
    idEnterprise = json['idEnterprise'];
    name = json['name'];
    description = json['description'];
    videoUri = json['videoUri'];
    idNoticeType = json['idNoticeType'];
    idNoticePublicationType = json['idNoticePublicationType'];
    publish = json['publish'];
    zyosUser =
        json['zyosUser'] != null ? ZyosUser.fromJson(json['zyosUser']) : null;
    image = json['image'];
    reactionCountJson = json['reactionCountJson'] != null
        ? ReactionCountJson.fromJson(json['reactionCountJson'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['dateChange'] = dateChange;
    data['state'] = state;
    data['idEnterprise'] = idEnterprise;
    data['name'] = name;
    data['description'] = description;
    data['videoUri'] = videoUri;
    data['idNoticeType'] = idNoticeType;
    data['idNoticePublicationType'] = idNoticePublicationType;
    data['publish'] = publish;
    data['image'] = image;
    if (zyosUser != null) {
      data['zyosUser'] = zyosUser?.toJson();
    }
    if (reactionCountJson != null) {
      data['reactionCountJson'] = reactionCountJson?.toJson();
    }
    return data;
  }
}

class ReactionCountJson {
  int? totalReaction;
  int? totalComment;
  int? totalLike;
  int? totalLove;
  int? totalWow;

  ReactionCountJson({
    this.totalReaction,
    this.totalComment,
    this.totalLike,
    this.totalLove,
    this.totalWow,
  });

  ReactionCountJson.fromJson(Map<String, dynamic> json) {
    totalReaction = json['totalReaction'];
    totalComment = json['totalComment'];
    totalLike = json['totalLike'];
    totalLove = json['totalLove'];
    totalWow = json['totalWow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['totalReaction'] = totalReaction;
    data['totalComment'] = totalComment;
    data['totalLike'] = totalLike;
    data['totalLove'] = totalLove;
    data['totalWow'] = totalWow;
    return data;
  }
}

class ZyosUser {
  int? id;
  String? dateCreation;
  String? userCreation;
  int? state;
  bool? skipOnboard;
  String? documentNumber;
  String? name;
  String? phone;
  String? mobilePhone;
  String? email;
  int? blackList;
  int? idDocumentType;
  String? ocupation;
  int? hideUserFromNeighbors;
  String? alias;
  List<ZyosUserEnterprise>? zyosUserEnterprise;

  ZyosUser({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.state,
    this.skipOnboard,
    this.documentNumber,
    this.name,
    this.phone,
    this.mobilePhone,
    this.email,
    this.blackList,
    this.idDocumentType,
    this.ocupation,
    this.hideUserFromNeighbors,
    this.alias,
    this.zyosUserEnterprise,
  });

  // ignore: long-method
  ZyosUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    state = json['state'];
    skipOnboard = json['skipOnboard'];
    documentNumber = json['documentNumber'];
    name = json['name'];
    phone = json['phone'];
    mobilePhone = json['mobilePhone'];
    email = json['email'];
    blackList = json['blackList'];
    idDocumentType = json['idDocumentType'];
    ocupation = json['ocupation'];
    hideUserFromNeighbors = json['hideUserFromNeighbors'];
    alias = json['alias'];
    if (json['zyosUserEnterprise'] != null) {
      zyosUserEnterprise = <ZyosUserEnterprise>[];
      json['zyosUserEnterprise'].forEach((v) {
        zyosUserEnterprise?.add(ZyosUserEnterprise.fromJson(v));
      });
    }
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['state'] = state;
    data['skipOnboard'] = skipOnboard;
    data['documentNumber'] = documentNumber;
    data['name'] = name;
    data['phone'] = phone;
    data['mobilePhone'] = mobilePhone;
    data['email'] = email;
    data['blackList'] = blackList;
    data['idDocumentType'] = idDocumentType;
    data['ocupation'] = ocupation;
    data['hideUserFromNeighbors'] = hideUserFromNeighbors;
    data['alias'] = alias;
    if (zyosUserEnterprise != null) {
      data['zyosUserEnterprise'] =
          zyosUserEnterprise?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ZyosUserEnterprise {
  int? idEnterprise;
  int? idZyosUser;

  ZyosUserEnterprise({this.idEnterprise, this.idZyosUser});

  ZyosUserEnterprise.fromJson(Map<String, dynamic> json) {
    idEnterprise = json['idEnterprise'];
    idZyosUser = json['idZyosUser'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEnterprise'] = idEnterprise;
    data['idZyosUser'] = idZyosUser;
    return data;
  }
}
