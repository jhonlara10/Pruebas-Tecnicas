class CreateNewResponse {
  bool? successRequestNotice;
  String? message;

  CreateNewResponse(this.successRequestNotice, this.message);

  CreateNewResponse.fromJson(Map<String, dynamic> json) {
    successRequestNotice = json['successRequestNotice'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successRequestNotice'] = successRequestNotice;
    data['message'] = message;
    return data;
  }
}
