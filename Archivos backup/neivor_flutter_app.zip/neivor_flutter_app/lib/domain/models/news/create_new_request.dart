class CreateNewRequet {
  String? description;
  String? enterpriseName;
  int? idEnterprise;
  int? idMailOption;
  int? idNoticePublicationType;
  int? idNoticeType;
  String? image;
  String? name;
  int? state;
  int? userCreation;
  String? userSessionFirstName;
  String? videoUri;

  CreateNewRequet(
    this.idNoticePublicationType,
    this.idNoticeType,
    this.name,
    this.description,
    this.idEnterprise,
    this.enterpriseName,
    this.userSessionFirstName,
    this.state,
    this.idMailOption,
    this.videoUri,
    this.userCreation,
    this.image,
  );

  CreateNewRequet.fromJson(Map<String, dynamic> json) {
    idNoticePublicationType = json['idNoticePublicationType'];
    idNoticeType = json['idNoticeType'];
    name = json['name'];
    description = json['description'];
    idEnterprise = json['idEnterprise'];
    enterpriseName = json['enterpriseName'];
    userSessionFirstName = json['userSessionFirstName'];
    state = json['state'];
    idMailOption = json['idMailOption'];
    videoUri = json['videoUri'];
    userCreation = json['userCreation'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idNoticePublicationType'] = idNoticePublicationType;
    data['idNoticeType'] = idNoticeType;
    data['name'] = name;
    data['description'] = description;
    data['idEnterprise'] = idEnterprise;
    data['enterpriseName'] = enterpriseName;
    data['userSessionFirstName'] = userSessionFirstName;
    data['state'] = state;
    data['idMailOption'] = idMailOption;
    data['videoUri'] = videoUri;
    data['userCreation'] = userCreation;
    data['image'] = image;
    return data;
  }
}
