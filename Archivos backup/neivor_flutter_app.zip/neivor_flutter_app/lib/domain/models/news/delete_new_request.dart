class DeleteNewRequest {
  String? fileNameToDelete;
  int? id;
  int? idEnterprise;
  int? userChange;

  DeleteNewRequest({
    this.id,
    this.idEnterprise,
    this.fileNameToDelete,
    this.userChange,
  });

  DeleteNewRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idEnterprise = json['idEnterprise'];
    fileNameToDelete = json['fileNameToDelete'];
    userChange = json['userChange'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idEnterprise'] = idEnterprise;
    data['fileNameToDelete'] = fileNameToDelete;
    data['userChange'] = userChange;
    return data;
  }
}
