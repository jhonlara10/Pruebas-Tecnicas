class DeleteNewResponse {
  String? message;
  bool? successRequestNotice;

  DeleteNewResponse(this.successRequestNotice, this.message);

  DeleteNewResponse.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    successRequestNotice = json['successRequestNotice'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    data['successRequestNotice'] = successRequestNotice;
    return data;
  }
}
