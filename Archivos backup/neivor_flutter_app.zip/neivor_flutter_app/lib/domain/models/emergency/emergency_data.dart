class EmergencyData {
  int? id;
  double? dateCreation;
  String? name;
  int? idRelationship;
  String? phoneOne;
  int? idServicePoint;
  String? email;

  EmergencyData({
    this.id,
    this.dateCreation,
    this.name,
    this.idRelationship,
    this.phoneOne,
    this.idServicePoint,
    this.email,
  });

  EmergencyData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    name = json['name'];
    idRelationship = json['idRelationship'];
    phoneOne = json['phoneOne'];
    idServicePoint = json['idServicePoint'];
    email = json['email'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['name'] = name;
    data['idRelationship'] = idRelationship;
    data['phoneOne'] = phoneOne;
    data['idServicePoint'] = idServicePoint;
    data['email'] = email;
    return data;
  }
}
