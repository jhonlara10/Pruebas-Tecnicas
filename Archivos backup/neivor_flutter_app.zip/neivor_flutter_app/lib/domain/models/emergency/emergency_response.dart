class EmergencyResponse {
  bool? sucessRequest;
  String? message;

  EmergencyResponse({this.sucessRequest, this.message});

  EmergencyResponse.fromJson(Map<String, dynamic> json) {
    sucessRequest = json['sucessRequest'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sucessRequest'] = sucessRequest;
    data['message'] = message;
    return data;
  }
}
