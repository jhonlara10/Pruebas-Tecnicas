class EmergencyRequest {
  int? userCreation;
  String? name;
  int? idRelationship;
  String? phoneOne;
  int? idServicePoint;
  int? idEnterprise;
  String? email;

  EmergencyRequest({
    this.userCreation,
    this.name,
    this.idRelationship,
    this.phoneOne,
    this.idServicePoint,
    this.idEnterprise,
    this.email,
  });

  EmergencyRequest.fromJson(Map<String, dynamic> json) {
    userCreation = json['userCreation'];
    name = json['name'];
    idRelationship = json['idRelationship'];
    phoneOne = json['phoneOne'];
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    email = json['email'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['userCreation'] = userCreation;
    data['name'] = name;
    data['idRelationship'] = idRelationship;
    data['phoneOne'] = phoneOne;
    data['idServicePoint'] = idServicePoint;
    data['idEnterprise'] = idEnterprise;
    data['email'] = email;
    return data;
  }
}
