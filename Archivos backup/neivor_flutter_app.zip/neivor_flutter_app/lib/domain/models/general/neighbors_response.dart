class NeighborsResponse {
  int? id;
  String? documentNumber;
  String? name;
  String? servicePointName;
  String? phone;
  String? mobilePhone;
  String? email;
  int? blackList;
  String? ocupation;
  String? photo;
  int? hideUserFromNeighbors;
  int? sipNumber;
  String? alias;
  int? idEnterprise;
  List<ZyosUserGroup>? zyosUserGroup;

  NeighborsResponse({
    this.id,
    this.documentNumber,
    this.name,
    this.servicePointName,
    this.phone,
    this.mobilePhone,
    this.email,
    this.blackList,
    this.ocupation,
    this.photo,
    this.hideUserFromNeighbors,
    this.sipNumber,
    this.alias,
    this.idEnterprise,
    this.zyosUserGroup,
  });

  // ignore: long-method
  NeighborsResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    documentNumber = json['documentNumber'];
    name = json['name'];
    servicePointName = json['servicePointName'];
    phone = json['phone'];
    mobilePhone = json['mobilePhone'];
    email = json['email'];
    blackList = json['blackList'];
    ocupation = json['ocupation'];
    photo = json['photo'];
    hideUserFromNeighbors = json['hideUserFromNeighbors'];
    sipNumber = json['sipNumber'];
    alias = json['alias'];
    idEnterprise = json['idEnterprise'];
    if (json['zyosUserGroup'] != null) {
      zyosUserGroup = <ZyosUserGroup>[];
      json['zyosUserGroup'].forEach((v) {
        zyosUserGroup?.add(ZyosUserGroup.fromJson(v));
      });
    }
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['documentNumber'] = documentNumber;
    data['name'] = name;
    data['servicePointName'] = servicePointName;
    data['phone'] = phone;
    data['mobilePhone'] = mobilePhone;
    data['email'] = email;
    data['blackList'] = blackList;
    data['ocupation'] = ocupation;
    data['photo'] = photo;
    data['hideUserFromNeighbors'] = hideUserFromNeighbors;
    data['sipNumber'] = sipNumber;
    data['alias'] = alias;
    data['idEnterprise'] = idEnterprise;
    if (zyosUserGroup != null) {
      data['zyosUserGroup'] = zyosUserGroup?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ZyosUserGroup {
  int? idGroup;

  ZyosUserGroup({this.idGroup});

  ZyosUserGroup.fromJson(Map<String, dynamic> json) {
    idGroup = json['idGroup'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idGroup'] = idGroup;
    return data;
  }
}
