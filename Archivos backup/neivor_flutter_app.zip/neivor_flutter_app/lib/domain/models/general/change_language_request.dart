class ChangeLanguageRequest {
  String? appLanguage;
  int? userChange;

  ChangeLanguageRequest({this.appLanguage, this.userChange});

  ChangeLanguageRequest.fromJson(Map<String, dynamic> json) {
    appLanguage = json['appLanguage'];
    userChange = json['userChange'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['appLanguage'] = appLanguage;
    data['userChange'] = userChange;
    return data;
  }
}
