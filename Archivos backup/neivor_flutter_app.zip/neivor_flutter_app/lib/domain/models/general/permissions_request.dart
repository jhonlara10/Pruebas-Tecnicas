import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class PermissionsRequest {
  int? idZyosGroup;
  int? idEnterprise;

  PermissionsRequest({this.idZyosGroup, this.idEnterprise});

  PermissionsRequest.fromJson(Map<String, dynamic> json) {
    idZyosGroup = json['idZyosGroup'];
    idEnterprise = json['idEnterprise'];
  }

  factory PermissionsRequest.defaultValues() => PermissionsRequest(
        idEnterprise: UserUtils.currentEnterprise?.id,
        idZyosGroup: UserUtils.currentZyosGroup?.id,
      );

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idZyosGroup'] = idZyosGroup;
    data['idEnterprise'] = idEnterprise;
    return data;
  }
}
