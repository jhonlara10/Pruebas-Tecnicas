class DocumentTypesResponse {
  int? id;
  int? state;
  String? name;
  String? code;

  DocumentTypesResponse({this.id, this.state, this.name, this.code});

  DocumentTypesResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    name = json['name'];
    code = json['code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['name'] = name;
    data['code'] = code;
    return data;
  }
}
