class DocumentList {
  List<Document>? list;
  Info? info;
  bool? success;

  DocumentList({this.list, this.info, this.success});

  DocumentList.fromJson(Map<String, dynamic> json) {
    info = Info.fromJson(json['info']);
    success = json['success'];
    if (json['list'] != null) {
      list = <Document>[];
      json['list'].forEach((v) {
        list?.add(Document.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['info'] = info?.toJson();

    data['Document'] = list?.map((v) => v.toJson()).toList();

    data['success'] = success;
    return data;
  }

  String get getInfo {
    return info?.message ?? " Error message null";
  }

  bool get getSuccess {
    return success ?? false;
  }

  List<Document>? get getList {
    return list;
  }
}

class Document {
  String? name;
  String? type;
  int? size;
  String? lastUpdate;
  String? url;
  String? encodeUrl;

  Document({
    this.name,
    this.type,
    this.size,
    this.lastUpdate,
    this.url,
    this.encodeUrl,
  });

  Document.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    type = json['type'];
    size = json['size'];
    lastUpdate = json['lastUpdate'];
    url = json['url'];
    encodeUrl = json['encodeUrl'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['type'] = type;
    data['size'] = size;
    data['lastUpdate'] = lastUpdate;
    data['url'] = url;
    data['encodeUrl'] = encodeUrl;
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}
