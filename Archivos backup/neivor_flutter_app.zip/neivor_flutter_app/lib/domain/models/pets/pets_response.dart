class PetsResponse {
  int? id;
  double? dateCreation;
  int? idPetType;
  int? idServicePoint;
  String? name;

  PetsResponse({
    this.id,
    this.dateCreation,
    this.idPetType,
    this.idServicePoint,
    this.name,
  });

  PetsResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    idPetType = json['idPetType'];
    idServicePoint = json['idServicePoint'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['idPetType'] = idPetType;
    data['idServicePoint'] = idServicePoint;
    data['name'] = name;
    return data;
  }
}
