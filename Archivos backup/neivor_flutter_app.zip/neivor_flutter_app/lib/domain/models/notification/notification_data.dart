class NotificationData {
  String? sound;
  String? action;
  String? title;
  String? message;
  String? route;
  String? idEnterprise;

  NotificationData({this.sound, this.action, this.title, this.message});

  NotificationData.fromJson(Map<String, dynamic> json) {
    sound = json['sound'];
    action = json['action'];
    title = json['title'];
    message = json['message'];
    route = json['route'];
    idEnterprise = json['idEnterprise'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sound'] = sound;
    data['action'] = action;
    data['title'] = title;
    data['message'] = message;
    data['route'] = route;
    data['idEnterprise'] = idEnterprise;
    return data;
  }
}
