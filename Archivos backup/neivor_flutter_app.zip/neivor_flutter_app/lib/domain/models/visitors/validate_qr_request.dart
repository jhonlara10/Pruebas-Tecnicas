class ValidateQrRequest {
  int? idEnterprise;
  String? textQr;

  ValidateQrRequest({this.idEnterprise, this.textQr});

  ValidateQrRequest.fromJson(Map<String, dynamic> json) {
    idEnterprise = json['idEnterprise'];
    textQr = json['textQr'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEnterprise'] = idEnterprise;
    data['textQr'] = textQr;
    return data;
  }
}
