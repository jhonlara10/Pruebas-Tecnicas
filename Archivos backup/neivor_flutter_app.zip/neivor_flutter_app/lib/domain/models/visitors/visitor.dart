class Visitor {
  String? name;
  String? mobilePhone;
  String? favorite;
  String? documentNumber;
  int? idDocumentType;

  Visitor({
    this.name,
    this.mobilePhone,
    this.favorite,
    this.documentNumber,
    this.idDocumentType,
  });

  Visitor.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    mobilePhone = json['mobilePhone'];
    favorite = json['favorite'];
    documentNumber = json['documentNumber'];
    idDocumentType = int.tryParse(json['idDocumentType'].toString());
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['mobilePhone'] = mobilePhone;
    data['favorite'] = favorite;
    data['documentNumber'] = documentNumber;
    data['idDocumentType'] = idDocumentType;
    return data;
  }
}
