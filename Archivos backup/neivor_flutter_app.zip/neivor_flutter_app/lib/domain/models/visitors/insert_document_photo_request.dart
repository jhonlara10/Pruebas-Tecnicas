// ignore: prefer-correct-type-name
class InsertDocumentPhotoRequest {
  int? id;
  int? userChange;
  int? idEnterprise;
  String? image;

  InsertDocumentPhotoRequest({
    this.id,
    this.userChange,
    this.idEnterprise,
    this.image,
  });

  InsertDocumentPhotoRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userChange = json['userChange'];
    idEnterprise = json['idEnterprise'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userChange'] = userChange;
    data['idEnterprise'] = idEnterprise;
    data['image'] = image;
    return data;
  }
}
