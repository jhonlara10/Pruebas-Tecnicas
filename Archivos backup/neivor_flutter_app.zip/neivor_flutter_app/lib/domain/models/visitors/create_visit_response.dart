class CreateVisitResponse {
  bool? sucessRequestVisit;
  String? message;
  String? textQr;

  CreateVisitResponse({this.sucessRequestVisit, this.message, this.textQr});

  CreateVisitResponse.fromJson(Map<String, dynamic> json) {
    sucessRequestVisit = json['sucessRequestVisit'];
    message = json['message'];
    textQr = json['textQr'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sucessRequestVisit'] = sucessRequestVisit;
    data['message'] = message;
    data['textQr'] = textQr;
    return data;
  }
}
