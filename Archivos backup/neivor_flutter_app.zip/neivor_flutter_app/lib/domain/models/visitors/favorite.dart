class Favorite {
  int? id;
  String? name;
  String? documentNumber;
  String? favorite;
  int? idDocumentType;

  Favorite({
    this.id,
    this.name,
    this.documentNumber,
    this.favorite,
    this.idDocumentType,
  });

  Favorite.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    documentNumber = json['documentNumber'];
    favorite = json['favorite'];
    idDocumentType = json['idDocumentType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['documentNumber'] = documentNumber;
    data['favorite'] = favorite;
    data['idDocumentType'] = idDocumentType;
    return data;
  }
}
