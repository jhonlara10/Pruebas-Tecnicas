// ignore_for_file: unnecessary_this

class InsertPlatePhotoRequest {
  int? idServicePoint;
  int? idEnterprise;
  int? idVisitCategory;
  int? idVisitPeriod;
  String? nameEnterprise;
  String? userName;
  String? email;
  int? idZyosUser;
  int? userCreation;
  Visitor? visitor;
  String? visitDateAsString;
  int? id;
  String? plateImage;
  String? initDateAsString;
  String? lastDateAsString;
  int? idVehicleType;

  InsertPlatePhotoRequest({
    this.idServicePoint,
    this.idEnterprise,
    this.idVisitCategory,
    this.idVisitPeriod,
    this.nameEnterprise,
    this.userName,
    this.email,
    this.idZyosUser,
    this.userCreation,
    this.visitor,
    this.visitDateAsString,
    this.id,
    this.plateImage,
    this.initDateAsString,
    this.lastDateAsString,
    this.idVehicleType,
  });

  // ignore: long-method
  InsertPlatePhotoRequest.fromJson(Map<String, dynamic> json) {
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    idVisitCategory = json['idVisitCategory'];
    idVisitPeriod = json['idVisitPeriod'];
    nameEnterprise = json['nameEnterprise'];
    userName = json['userName'];
    email = json['email'];
    idZyosUser = json['idZyosUser'];
    userCreation = json['userCreation'];
    visitor =
        json['visitor'] != null ? Visitor.fromJson(json['visitor']) : null;
    visitDateAsString = json['visitDateAsString'];
    id = json['id'];
    plateImage = json['plateImage'];
    initDateAsString = json['initDateAsString'];
    lastDateAsString = json['lastDateAsString'];
    idVehicleType = json['idVehicleType'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idServicePoint'] = this.idServicePoint;
    data['idEnterprise'] = this.idEnterprise;
    data['idVisitCategory'] = this.idVisitCategory;
    data['idVisitPeriod'] = this.idVisitPeriod;
    data['nameEnterprise'] = this.nameEnterprise;
    data['userName'] = this.userName;
    data['email'] = this.email;
    data['idZyosUser'] = this.idZyosUser;
    data['userCreation'] = this.userCreation;
    if (this.visitor != null) {
      data['visitor'] = this.visitor!.toJson();
    }
    data['visitDateAsString'] = this.visitDateAsString;
    data['id'] = this.id;
    data['plateImage'] = this.plateImage;
    data['initDateAsString'] = initDateAsString;
    data['lastDateAsString'] = lastDateAsString;
    data['idVehicleType'] = idVehicleType;
    return data;
  }
}

class Visitor {
  String? name;
  String? documentNumber;
  int? idDocumentType;
  String? favorite;

  Visitor({this.name, this.documentNumber, this.idDocumentType, this.favorite});

  Visitor.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    documentNumber = json['documentNumber'];
    idDocumentType = int.tryParse(json['idDocumentType'].toString());
    favorite = json['favorite'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = this.name;
    data['documentNumber'] = this.documentNumber;
    data['idDocumentType'] = this.idDocumentType;
    data['favorite'] = this.favorite;
    return data;
  }
}
