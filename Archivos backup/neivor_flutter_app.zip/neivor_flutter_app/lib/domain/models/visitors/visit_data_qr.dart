import 'package:neivor_flutter_app/domain/models/visitors/create_visit_response.dart';

class VisitDataQr {
  CreateVisitResponse? response;
  String? userVisit;
  String? visitDate;
  String? servicePointInfo;
  String? phone;
  int? visitId;
  String? initDate;
  String? lastDate;
  int? idVisitPeriod;

  VisitDataQr({
    this.userVisit,
    this.visitDate,
    this.servicePointInfo,
    this.phone,
    this.visitId,
    this.initDate,
    this.lastDate,
    this.idVisitPeriod,
  });

  VisitDataQr.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null
        ? CreateVisitResponse.fromJson(json['response'])
        : null;
    userVisit = json['userVisit'];
    visitDate = json['visitDate'];
    servicePointInfo = json['servicePointInfo'];
    phone = json['phone'];
    visitId = json['visitId'];
    initDate = json['initDate'];
    lastDate = json['lastDate'];
    idVisitPeriod = json['idVisitPeriod'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (response != null) {
      data['visitor'] = response!.toJson();
    }
    data['userVisit'] = userVisit;
    data['visitDate'] = visitDate;
    data['servicePointInfo'] = servicePointInfo;
    data['phone'] = phone;
    data['visitId'] = visitId;
    data['initDate'] = initDate;
    data['lastDate'] = lastDate;
    data['idVisitPeriod'] = idVisitPeriod;
    return data;
  }
}
