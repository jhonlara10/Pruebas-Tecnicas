// ignore: prefer-correct-type-name
class InsertPlatePhotoResponse {
  bool? success;
  Info? info;
  Data? data;

  InsertPlatePhotoResponse({this.success, this.info, this.data});

  InsertPlatePhotoResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? userCreation;
  int? idServicePoint;
  int? idZyosUser;
  int? idVisitPeriod;
  int? idVisitCategory;
  int? idEnterprise;
  int? idVisitor;
  String? email;
  String? generatedQR;
  String? userName;
  int? visitDate;
  String? visitDateAsString;
  Visitor? visitor;

  Data({
    this.id,
    this.userCreation,
    this.idServicePoint,
    this.idZyosUser,
    this.idVisitPeriod,
    this.idVisitCategory,
    this.idEnterprise,
    this.idVisitor,
    this.email,
    this.generatedQR,
    this.userName,
    this.visitDate,
    this.visitDateAsString,
    this.visitor,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCreation = json['userCreation'];
    idServicePoint = json['idServicePoint'];
    idZyosUser = json['idZyosUser'];
    idVisitPeriod = json['idVisitPeriod'];
    idVisitCategory = json['idVisitCategory'];
    idEnterprise = json['idEnterprise'];
    idVisitor = json['idVisitor'];
    email = json['email'];
    generatedQR = json['generatedQR'];
    userName = json['userName'];
    visitDate = json['visitDate'];
    visitDateAsString = json['visitDateAsString'];
    visitor =
        json['visitor'] != null ? Visitor.fromJson(json['visitor']) : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userCreation'] = userCreation;
    data['idServicePoint'] = idServicePoint;
    data['idZyosUser'] = idZyosUser;
    data['idVisitPeriod'] = idVisitPeriod;
    data['idVisitCategory'] = idVisitCategory;
    data['idEnterprise'] = idEnterprise;
    data['idVisitor'] = idVisitor;
    data['email'] = email;
    data['generatedQR'] = generatedQR;
    data['userName'] = userName;
    data['visitDate'] = visitDate;
    data['visitDateAsString'] = visitDateAsString;
    if (visitor != null) {
      data['visitor'] = visitor!.toJson();
    }
    return data;
  }
}

class Visitor {
  int? id;
  String? name;
  String? documentNumber;
  String? favorite;
  int? idDocumentType;

  Visitor({
    this.id,
    this.name,
    this.documentNumber,
    this.favorite,
    this.idDocumentType,
  });

  Visitor.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    documentNumber = json['documentNumber'];
    favorite = json['favorite'];
    idDocumentType = json['idDocumentType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['documentNumber'] = documentNumber;
    data['favorite'] = favorite;
    data['idDocumentType'] = idDocumentType;
    return data;
  }
}
