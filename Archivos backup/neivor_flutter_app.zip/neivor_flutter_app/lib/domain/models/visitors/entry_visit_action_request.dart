class EntryVisitActionRequest {
  int? id;
  String? name;
  int? userChange;
  String? entryDateAsString;

  EntryVisitActionRequest({
    this.id,
    this.name,
    this.userChange,
    this.entryDateAsString,
  });

  EntryVisitActionRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    userChange = json['userChange'];
    entryDateAsString = json['entryDateAsString'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['userChange'] = this.userChange;
    data['entryDateAsString'] = this.entryDateAsString;
    return data;
  }
}
