import 'package:neivor_flutter_app/domain/models/visitors/visitor.dart';

class CreateVisitRequest {
  int? idServicePoint;
  String? nameEnterprise;
  String? userName;
  String? email;
  int? idZyosUser;
  int? userCreation;
  Visitor? visitor;
  String? eventName;
  int? idVisitPeriod;
  int? idVisitCategory;
  String? visitDateAsString;
  String? initDateAsString;
  String? lastDateAsString;
  int? idVisitType;
  int? idEnterprise;
  int? idVehicleType;
  String? licensePlate;

  CreateVisitRequest({
    this.idServicePoint,
    this.nameEnterprise,
    this.userName,
    this.email,
    this.idZyosUser,
    this.userCreation,
    this.visitor,
    this.eventName,
    this.idVisitPeriod,
    this.idVisitCategory,
    this.visitDateAsString,
    this.initDateAsString,
    this.lastDateAsString,
    this.idVisitType,
    this.idEnterprise,
    this.idVehicleType,
    this.licensePlate,
  });

  // ignore: long-method
  CreateVisitRequest.fromJson(Map<String, dynamic> json) {
    idServicePoint = json['idServicePoint'];
    idVehicleType = json['idVehicleType'];
    licensePlate = json['licensePlate'];
    nameEnterprise = json['nameEnterprise'];
    idEnterprise = json['idEnterprise'];
    userName = json['userName'];
    email = json['email'];
    idZyosUser = json['idZyosUser'];
    userCreation = json['userCreation'];
    visitor =
        json['visitor'] != null ? Visitor.fromJson(json['visitor']) : null;
    eventName = json['eventName'];
    idVisitPeriod = json['idVisitPeriod'];
    idVisitCategory = json['idVisitCategory'];
    visitDateAsString = json['visitDateAsString'];
    initDateAsString = json['initDateAsString'];
    lastDateAsString = json['lastDateAsString'];
    idVisitType = json['idVisitType'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idServicePoint'] = idServicePoint;
    data['idVehicleType'] = idVehicleType;
    data['licensePlate'] = licensePlate;
    data['nameEnterprise'] = nameEnterprise;
    data['userName'] = userName;
    data['email'] = email;
    data['idZyosUser'] = idZyosUser;
    data['userCreation'] = userCreation;
    if (visitor != null) {
      data['visitor'] = visitor?.toJson();
    }
    data['eventName'] = eventName;
    data['idVisitPeriod'] = idVisitPeriod;
    data['idVisitCategory'] = idVisitCategory;
    data['visitDateAsString'] = visitDateAsString;
    data['initDateAsString'] = initDateAsString;
    data['lastDateAsString'] = lastDateAsString;
    data['idVisitType'] = idVisitType;
    data['idEnterprise'] = idEnterprise;
    return data;
  }
}
