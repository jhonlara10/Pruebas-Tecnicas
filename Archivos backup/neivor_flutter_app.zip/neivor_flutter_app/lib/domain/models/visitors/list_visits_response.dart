class ListVisitsResponse {
  bool? success;
  Info? info;
  List<Visit>? data;

  ListVisitsResponse({this.success, this.info, this.data});

  ListVisitsResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    if (json['data'] != null) {
      data = <Visit>[];
      json['data'].forEach((v) {
        data!.add(Visit.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info!.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Visit {
  int? id;
  int? idServicePoint;
  int? idOperationZone;
  int? idVisitPeriod;
  int? idVisitCategory;
  int? companions;
  String? generatedQR;
  String? nameOperationZone;
  String? nameServicePoint;
  int? visitDate;
  int? lastDate;
  int? initDate;
  Visitor? visitor;
  bool? pending;

  Visit({
    this.id,
    this.idServicePoint,
    this.idOperationZone,
    this.idVisitPeriod,
    this.idVisitCategory,
    this.companions,
    this.generatedQR,
    this.nameOperationZone,
    this.nameServicePoint,
    this.visitDate,
    this.lastDate,
    this.initDate,
    this.visitor,
    this.pending,
  });

  Visit.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idServicePoint = json['idServicePoint'];
    idOperationZone = json['idOperationZone'];
    idVisitPeriod = json['idVisitPeriod'];
    idVisitCategory = json['idVisitCategory'];
    companions = json['companions'];
    generatedQR = json['generatedQR'];
    nameOperationZone = json['nameOperationZone'];
    nameServicePoint = json['nameServicePoint'];
    visitDate = json['visitDate'];
    lastDate = json['lastDate'];
    initDate = json['initDate'];
    visitor =
        json['visitor'] != null ? Visitor.fromJson(json['visitor']) : null;
    pending = json['pending'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idServicePoint'] = idServicePoint;
    data['idOperationZone'] = idOperationZone;
    data['idVisitPeriod'] = idVisitPeriod;
    data['idVisitCategory'] = idVisitCategory;
    data['companions'] = companions;
    data['generatedQR'] = generatedQR;
    data['nameOperationZone'] = nameOperationZone;
    data['nameServicePoint'] = nameServicePoint;
    data['visitDate'] = visitDate;
    data['initDate'] = initDate;
    data['lastDate'] = lastDate;
    if (visitor != null) {
      data['visitor'] = visitor!.toJson();
    }
    data['lastDate'] = pending;
    return data;
  }
}

class Visitor {
  int? id;
  String? name;
  String? favorite;
  String? mobilePhone;

  Visitor({this.id, this.name, this.favorite, this.mobilePhone});

  Visitor.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    favorite = json['favorite'];
    mobilePhone = json['mobilePhone'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['favorite'] = favorite;
    data['mobilePhone'] = mobilePhone;
    return data;
  }
}
