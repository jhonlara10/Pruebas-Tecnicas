class ScanQrResponse {
  int? id;
  int? dateCreation;
  int? userCreation;
  int? dateChange;
  int? userChange;
  int? state;
  int? idServicePoint;
  int? idZyosUser;
  int? idOperationZone;
  int? idVehicleType;
  int? idVisitPeriod;
  int? idVisitCategory;
  int? idEnterprise;
  int? idVisitor;
  int? companions;
  String? observation;
  String? email;
  String? generatedQR;
  String? licensePlate;
  String? enterpriseName;
  String? userName;
  String? nameOperationZone;
  String? nameServicePoint;
  int? visitDate;
  String? visitDateAsString;
  int? initDate;
  String? initDateAsString;
  int? lastDate;
  String? lastDateAsString;
  int? entryDate;
  int? finishDate;
  String? entryDateAsString;
  String? finishDateAsString;
  Visitor? visitor;
  List? visitorList;
  bool? newVisit;
  String? plateImage;
  bool? recurringDays;
  bool? sucessScanQR;
  String? message;

  ScanQrResponse({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.dateChange,
    this.userChange,
    this.state,
    this.idServicePoint,
    this.idZyosUser,
    this.idOperationZone,
    this.idVehicleType,
    this.idVisitPeriod,
    this.idVisitCategory,
    this.idEnterprise,
    this.idVisitor,
    this.companions,
    this.observation,
    this.email,
    this.generatedQR,
    this.licensePlate,
    this.enterpriseName,
    this.userName,
    this.nameOperationZone,
    this.nameServicePoint,
    this.visitDate,
    this.visitDateAsString,
    this.initDate,
    this.initDateAsString,
    this.lastDate,
    this.lastDateAsString,
    this.entryDate,
    this.finishDate,
    this.entryDateAsString,
    this.finishDateAsString,
    this.visitor,
    this.visitorList,
    this.newVisit,
    this.plateImage,
    this.recurringDays,
    this.sucessScanQR,
    this.message,
  });

  ScanQrResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    dateChange = json['dateChange'];
    userChange = json['userChange'];
    state = json['state'];
    idServicePoint = json['idServicePoint'];
    idZyosUser = json['idZyosUser'];
    idOperationZone = json['idOperationZone'];
    idVehicleType = json['idVehicleType'];
    idVisitPeriod = json['idVisitPeriod'];
    idVisitCategory = json['idVisitCategory'];
    idEnterprise = json['idEnterprise'];
    idVisitor = json['idVisitor'];
    companions = json['companions'];
    observation = json['observation'];
    email = json['email'];
    generatedQR = json['generatedQR'];
    licensePlate = json['licensePlate'];
    enterpriseName = json['enterpriseName'];
    userName = json['userName'];
    nameOperationZone = json['nameOperationZone'];
    nameServicePoint = json['nameServicePoint'];
    visitDate = json['visitDate'];
    visitDateAsString = json['visitDateAsString'];
    initDate = json['initDate'];
    initDateAsString = json['initDateAsString'];
    lastDate = json['lastDate'];
    lastDateAsString = json['lastDateAsString'];
    entryDate = json['entryDate'];
    finishDate = json['finishDate'];
    entryDateAsString = json['entryDateAsString'];
    finishDateAsString = json['finishDateAsString'];
    visitor =
        json['visitor'] != null ? Visitor.fromJson(json['visitor']) : null;
    visitorList = json['visitorList'];
    newVisit = json['newVisit'];
    plateImage = json['plateImage'];
    recurringDays = json['recurringDays'];
    sucessScanQR = json['sucessScanQR'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['dateChange'] = dateChange;
    data['userChange'] = userChange;
    data['state'] = state;
    data['idServicePoint'] = idServicePoint;
    data['idZyosUser'] = idZyosUser;
    data['idOperationZone'] = idOperationZone;
    data['idVehicleType'] = idVehicleType;
    data['idVisitPeriod'] = idVisitPeriod;
    data['idVisitCategory'] = idVisitCategory;
    data['idEnterprise'] = idEnterprise;
    data['idVisitor'] = idVisitor;
    data['companions'] = companions;
    data['observation'] = observation;
    data['email'] = email;
    data['generatedQR'] = generatedQR;
    data['licensePlate'] = licensePlate;
    data['enterpriseName'] = enterpriseName;
    data['userName'] = userName;
    data['nameOperationZone'] = nameOperationZone;
    data['nameServicePoint'] = nameServicePoint;
    data['visitDate'] = visitDate;
    data['visitDateAsString'] = visitDateAsString;
    data['initDate'] = initDate;
    data['initDateAsString'] = initDateAsString;
    data['lastDate'] = lastDate;
    data['lastDateAsString'] = lastDateAsString;
    data['entryDate'] = entryDate;
    data['finishDate'] = finishDate;
    data['entryDateAsString'] = entryDateAsString;
    data['finishDateAsString'] = finishDateAsString;
    if (visitor != null) {
      data['visitor'] = visitor!.toJson();
    }
    data['visitorList'] = visitorList;
    data['newVisit'] = newVisit;
    data['plateImage'] = plateImage;
    data['recurringDays'] = recurringDays;
    data['sucessScanQR'] = sucessScanQR;
    data['message'] = message;
    return data;
  }
}

class Visitor {
  int? id;
  DateTime? dateCreation;
  int? userCreation;
  DateTime? dateChange;
  int? userChange;
  int? state;
  String? name;
  String? documentNumber;
  String? favorite;
  String? image;
  String? nameImageToDelete;
  int? idDocumentType;
  int? idEnterprise;
  String? mobilephone;

  Visitor({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.dateChange,
    this.userChange,
    this.state,
    this.name,
    this.documentNumber,
    this.favorite,
    this.image,
    this.nameImageToDelete,
    this.idDocumentType,
    this.idEnterprise,
    this.mobilephone,
  });

  Visitor.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    dateChange = json['dateChange'];
    userChange = json['userChange'];
    state = json['state'];
    name = json['name'];
    documentNumber = json['documentNumber'];
    favorite = json['favorite'];
    image = json['image'];
    nameImageToDelete = json['nameImageToDelete'];
    idDocumentType = json['idDocumentType'];
    idEnterprise = json['idEnterprise'];
    mobilephone = json['mobilephone'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['dateChange'] = dateChange;
    data['userChange'] = userChange;
    data['state'] = state;
    data['name'] = name;
    data['documentNumber'] = documentNumber;
    data['favorite'] = favorite;
    data['image'] = image;
    data['nameImageToDelete'] = nameImageToDelete;
    data['idDocumentType'] = idDocumentType;
    data['idEnterprise'] = idEnterprise;
    data['mobilephone'] = mobilephone;
    return data;
  }
}
