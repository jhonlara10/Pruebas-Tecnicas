class WishRequest {
  String? feedbackCommentary;
  int? idEnterprise;
  int? idZyosUser;
  int? userCreation;

  WishRequest({
    this.feedbackCommentary,
    this.idEnterprise,
    this.idZyosUser,
    this.userCreation,
  });

  WishRequest.fromJson(Map<String, dynamic> json) {
    feedbackCommentary = json['feedbackCommentary'];
    idEnterprise = json['idEnterprise'];
    idZyosUser = json['idZyosUser'];
    userCreation = json['userCreation'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['feedbackCommentary'] = feedbackCommentary;
    data['idEnterprise'] = idEnterprise;
    data['idZyosUser'] = idZyosUser;
    data['userCreation'] = userCreation;
    return data;
  }
}
