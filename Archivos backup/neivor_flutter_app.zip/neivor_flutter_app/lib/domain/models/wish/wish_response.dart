class WishResponse {
  bool? sucessRequestFeedback;
  String? message;

  WishResponse({this.sucessRequestFeedback, this.message});

  WishResponse.fromJson(Map<String, dynamic> json) {
    sucessRequestFeedback = json['sucessRequestFeedback'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sucessRequestFeedback'] = sucessRequestFeedback;
    data['message'] = message;
    return data;
  }
}
