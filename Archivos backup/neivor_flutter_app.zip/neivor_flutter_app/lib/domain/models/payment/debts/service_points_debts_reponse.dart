import 'package:neivor_flutter_app/domain/models/payment/debts/data.dart';
import 'package:neivor_flutter_app/domain/models/payment/debts/info.dart';

// ignore: prefer-correct-type-name
class ServicePointDebtsResponse {
  bool? success;
  Info? info;
  Data? data;

  ServicePointDebtsResponse({this.success, this.info, this.data});

  ServicePointDebtsResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}
