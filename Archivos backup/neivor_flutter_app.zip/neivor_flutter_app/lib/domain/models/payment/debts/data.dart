class Data {
  double? dueDebt;
  double? totalDebt;

  Data({this.dueDebt, this.totalDebt});

  Data.fromJson(Map<String, dynamic> json) {
    dueDebt = json['dueDebt'];
    totalDebt = json['totalDebt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['dueDebt'] = dueDebt;
    data['totalDebt'] = totalDebt;
    return data;
  }
}
