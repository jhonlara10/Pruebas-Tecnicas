class PsePayResponse {
  Error? error;
  int? idZyosPaymentState;
  PaymentOperation? paymentOperation;
  bool? success;

  PsePayResponse({
    this.error,
    this.idZyosPaymentState,
    this.paymentOperation,
    this.success,
  });

  PsePayResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'] != null ? Error.fromJson(json['error']) : null;
    idZyosPaymentState = json['idZyosPaymentState'];
    paymentOperation = json['paymentOperation'] != null
        ? PaymentOperation.fromJson(json['paymentOperation'])
        : null;
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (error != null) {
      data['error'] = error?.toJson();
    }
    data['idZyosPaymentState'] = idZyosPaymentState;
    if (paymentOperation != null) {
      data['paymentOperation'] = paymentOperation?.toJson();
    }
    data['success'] = success;
    return data;
  }
}

class Error {
  String? message;

  Error({this.message});

  Error.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class PaymentOperation {
  bool? successPay;
  bool? successAsyncRegister;
  bool? requirePayValidate;
  bool? formInscription;
  String? message;
  String? codRespuesta;
  bool? redirect;
  String? url;

  PaymentOperation({
    this.successPay,
    this.successAsyncRegister,
    this.requirePayValidate,
    this.formInscription,
    this.message,
    this.codRespuesta,
    this.redirect,
    this.url,
  });

  PaymentOperation.fromJson(Map<String, dynamic> json) {
    successPay = json['successPay'];
    successAsyncRegister = json['successAsyncRegister'];
    requirePayValidate = json['requirePayValidate'];
    formInscription = json['formInscription'];
    message = json['message'];
    codRespuesta = json['codRespuesta'];
    redirect = json['redirect'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successPay'] = successPay;
    data['successAsyncRegister'] = successAsyncRegister;
    data['requirePayValidate'] = requirePayValidate;
    data['formInscription'] = formInscription;
    data['message'] = message;
    data['codRespuesta'] = codRespuesta;
    data['redirect'] = redirect;
    data['url'] = url;
    return data;
  }
}
