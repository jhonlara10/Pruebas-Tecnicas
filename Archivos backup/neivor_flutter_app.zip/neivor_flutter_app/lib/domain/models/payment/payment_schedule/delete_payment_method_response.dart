// ignore: prefer-correct-type-name
class DeletePaymentMethodResponse {
  PaymentMethodOperation? paymentMethodOperation;
  bool? success;

  DeletePaymentMethodResponse({this.paymentMethodOperation, this.success});

  DeletePaymentMethodResponse.fromJson(Map<String, dynamic> json) {
    paymentMethodOperation = json['paymentMethodOperation'] != null
        ? PaymentMethodOperation.fromJson(json['paymentMethodOperation'])
        : null;
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (paymentMethodOperation != null) {
      data['paymentMethodOperation'] = paymentMethodOperation?.toJson();
    }
    data['success'] = success;
    return data;
  }
}

class PaymentMethodOperation {
  bool? redirect;
  bool? formInscription;
  bool? subscription;
  bool? successDelete;

  PaymentMethodOperation({
    this.redirect,
    this.formInscription,
    this.subscription,
    this.successDelete,
  });

  PaymentMethodOperation.fromJson(Map<String, dynamic> json) {
    redirect = json['redirect'];
    formInscription = json['formInscription'];
    subscription = json['subscription'];
    successDelete = json['successDelete'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['redirect'] = redirect;
    data['formInscription'] = formInscription;
    data['subscription'] = subscription;
    data['successDelete'] = successDelete;
    return data;
  }
}
