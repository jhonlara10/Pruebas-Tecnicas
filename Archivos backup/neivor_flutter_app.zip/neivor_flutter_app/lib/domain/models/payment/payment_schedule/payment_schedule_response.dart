class PaymentScheduleResponse {
  bool? success;
  Info? info;
  Data? data;

  PaymentScheduleResponse({this.success, this.info, this.data});

  PaymentScheduleResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? userCreation;
  int? idPaymentProductType;
  int? idPaymentMethod;
  int? idPaymentPeriod;
  int? idServicePoint;
  double? limitAmount;
  int? paymentDay;

  Data({
    this.id,
    this.userCreation,
    this.idPaymentProductType,
    this.idPaymentMethod,
    this.idPaymentPeriod,
    this.idServicePoint,
    this.limitAmount,
    this.paymentDay,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCreation = json['userCreation'];
    idPaymentProductType = json['idPaymentProductType'];
    idPaymentMethod = json['idPaymentMethod'];
    idPaymentPeriod = json['idPaymentPeriod'];
    idServicePoint = json['idServicePoint'];
    limitAmount = json['limitAmount'];
    paymentDay = json['paymentDay'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userCreation'] = userCreation;
    data['idPaymentProductType'] = idPaymentProductType;
    data['idPaymentMethod'] = idPaymentMethod;
    data['idPaymentPeriod'] = idPaymentPeriod;
    data['idServicePoint'] = idServicePoint;
    data['limitAmount'] = limitAmount;
    data['paymentDay'] = paymentDay;
    return data;
  }
}
