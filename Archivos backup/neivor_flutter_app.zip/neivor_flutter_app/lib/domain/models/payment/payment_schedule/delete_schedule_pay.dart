class DeleteSchedulePay {
  bool? success;
  Info? info;
  Data? data;

  DeleteSchedulePay({this.success, this.info, this.data});

  DeleteSchedulePay.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? userChange;
  int? state;

  Data({this.id, this.userChange, this.state});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userChange = json['userChange'];
    state = json['state'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userChange'] = userChange;
    data['state'] = state;
    return data;
  }
}
