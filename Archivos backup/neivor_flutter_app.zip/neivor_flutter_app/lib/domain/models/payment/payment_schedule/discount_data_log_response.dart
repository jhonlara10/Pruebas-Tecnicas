class DiscountDataLogResponse {
  bool? success;
  Data? data;

  DiscountDataLogResponse({this.success, this.data});

  DiscountDataLogResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Data {
  int? id;
  List<DiscountDataList>? discountDataList;

  Data({this.id, this.discountDataList});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DiscountDataList {
  bool? permanentDiscount;
  bool? roundingValue;
  bool? roundingBeforeDiscount;
  double? discount;
  int? idCriteriaDiscount;
  int? maxDateOfDiscount;

  DiscountDataList({
    this.permanentDiscount,
    this.roundingValue,
    this.roundingBeforeDiscount,
    this.discount,
    this.idCriteriaDiscount,
    this.maxDateOfDiscount,
  });

  DiscountDataList.fromJson(Map<String, dynamic> json) {
    permanentDiscount = json['permanentDiscount'];
    roundingValue = json['roundingValue'];
    roundingBeforeDiscount = json['roundingBeforeDiscount'];
    discount = json['discount'];
    idCriteriaDiscount = json['idCriteriaDiscount'];
    maxDateOfDiscount = json['maxDateOfDiscount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['permanentDiscount'] = permanentDiscount;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeDiscount'] = roundingBeforeDiscount;
    data['discount'] = discount;
    data['idCriteriaDiscount'] = idCriteriaDiscount;
    data['maxDateOfDiscount'] = maxDateOfDiscount;
    return data;
  }
}
