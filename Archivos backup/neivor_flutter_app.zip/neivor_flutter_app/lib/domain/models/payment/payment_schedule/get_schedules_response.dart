class GetSchedulesResponse {
  bool? success;
  Info? info;
  List<Data>? data;

  GetSchedulesResponse({this.success, this.info, this.data});

  GetSchedulesResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data?.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? userCreation;
  int? state;
  int? idPaymentProductType;
  int? idPaymentMethod;
  int? idPaymentPeriod;
  int? idServicePoint;
  double? limitAmount;
  int? paymentDay;
  PaymentProductType? paymentProductType;
  PaymentProductType? paymentMethod;
  PaymentPeriod? paymentPeriod;
  ServicePoint? servicePoint;

  Data({
    this.id,
    this.userCreation,
    this.state,
    this.idPaymentProductType,
    this.idPaymentMethod,
    this.idPaymentPeriod,
    this.idServicePoint,
    this.limitAmount,
    this.paymentDay,
    this.paymentProductType,
    this.paymentMethod,
    this.paymentPeriod,
    this.servicePoint,
  });

  // ignore: long-method
  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCreation = json['userCreation'];
    state = json['state'];
    idPaymentProductType = json['idPaymentProductType'];
    idPaymentMethod = json['idPaymentMethod'];
    idPaymentPeriod = json['idPaymentPeriod'];
    idServicePoint = json['idServicePoint'];
    limitAmount = json['limitAmount'];
    paymentDay = json['paymentDay'];
    paymentProductType = json['paymentProductType'] != null
        ? PaymentProductType.fromJson(json['paymentProductType'])
        : null;
    paymentMethod = json['paymentMethod'] != null
        ? PaymentProductType.fromJson(json['paymentMethod'])
        : null;
    paymentPeriod = json['paymentPeriod'] != null
        ? PaymentPeriod.fromJson(json['paymentPeriod'])
        : null;
    servicePoint = json['servicePoint'] != null
        ? ServicePoint.fromJson(json['servicePoint'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userCreation'] = userCreation;
    data['state'] = state;
    data['idPaymentProductType'] = idPaymentProductType;
    data['idPaymentMethod'] = idPaymentMethod;
    data['idPaymentPeriod'] = idPaymentPeriod;
    data['idServicePoint'] = idServicePoint;
    data['limitAmount'] = limitAmount;
    data['paymentDay'] = paymentDay;
    if (paymentProductType != null) {
      data['paymentProductType'] = paymentProductType?.toJson();
    }
    if (paymentMethod != null) {
      data['paymentMethod'] = paymentMethod?.toJson();
    }
    if (paymentPeriod != null) {
      data['paymentPeriod'] = paymentPeriod?.toJson();
    }
    if (servicePoint != null) {
      data['servicePoint'] = servicePoint?.toJson();
    }
    return data;
  }
}

class PaymentProductType {
  int? id;
  String? name;

  PaymentProductType({this.id, this.name});

  PaymentProductType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class PaymentPeriod {
  int? id;
  String? description;

  PaymentPeriod({this.id, this.description});

  PaymentPeriod.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['description'] = description;
    return data;
  }
}

class ServicePoint {
  int? id;
  int? state;
  int? totalRow;
  int? idEnterprise;
  int? idOperationZone;
  String? reference;
  String? name;
  double? costAdmon;
  double? adminCost;
  int? legalCharge;
  PaymentProductType? operationZone;
  Enterprise? enterprise;
  int? idZyosUser;

  ServicePoint({
    this.id,
    this.state,
    this.totalRow,
    this.idEnterprise,
    this.idOperationZone,
    this.reference,
    this.name,
    this.costAdmon,
    this.adminCost,
    this.legalCharge,
    this.operationZone,
    this.enterprise,
    this.idZyosUser,
  });

  // ignore: long-method
  ServicePoint.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    totalRow = json['totalRow'];
    idEnterprise = json['idEnterprise'];
    idOperationZone = json['idOperationZone'];
    reference = json['reference'];
    name = json['name'];
    costAdmon = json['costAdmon'];
    adminCost = json['adminCost'];
    legalCharge = json['legalCharge'];
    operationZone = json['operationZone'] != null
        ? PaymentProductType.fromJson(json['operationZone'])
        : null;
    enterprise = json['enterprise'] != null
        ? Enterprise.fromJson(json['enterprise'])
        : null;
    idZyosUser = json['idZyosUser'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['totalRow'] = totalRow;
    data['idEnterprise'] = idEnterprise;
    data['idOperationZone'] = idOperationZone;
    data['reference'] = reference;
    data['name'] = name;
    data['costAdmon'] = costAdmon;
    data['adminCost'] = adminCost;
    data['legalCharge'] = legalCharge;
    if (operationZone != null) {
      data['operationZone'] = operationZone?.toJson();
    }
    if (enterprise != null) {
      data['enterprise'] = enterprise?.toJson();
    }
    data['idZyosUser'] = idZyosUser;
    return data;
  }
}

class Enterprise {
  int? id;
  String? name;
  String? paymentData;
  int? idStateEnterprise;
  int? invoiceCount;
  int? startInvoiceConsecutive;
  PaymentDataObj? paymentDataObj;
  CfdiSettingsObj? cfdiSettingsObj;
  String? logoUrl;
  String? nameLogo;

  Enterprise({
    this.id,
    this.name,
    this.paymentData,
    this.idStateEnterprise,
    this.invoiceCount,
    this.startInvoiceConsecutive,
    this.paymentDataObj,
    this.cfdiSettingsObj,
    this.logoUrl,
    this.nameLogo,
  });

  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    paymentData = json['paymentData'];
    idStateEnterprise = json['idStateEnterprise'];
    invoiceCount = json['invoiceCount'];
    startInvoiceConsecutive = json['startInvoiceConsecutive'];
    paymentDataObj = json['paymentDataObj'] != null
        ? PaymentDataObj.fromJson(json['paymentDataObj'])
        : null;
    cfdiSettingsObj = json['cfdiSettingsObj'] != null
        ? CfdiSettingsObj.fromJson(json['cfdiSettingsObj'])
        : null;
    logoUrl = json['logoUrl'];
    nameLogo = json['nameLogo'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['paymentData'] = paymentData;
    data['idStateEnterprise'] = idStateEnterprise;
    data['invoiceCount'] = invoiceCount;
    data['startInvoiceConsecutive'] = startInvoiceConsecutive;
    if (paymentDataObj != null) {
      data['paymentDataObj'] = paymentDataObj?.toJson();
    }
    if (cfdiSettingsObj != null) {
      data['cfdiSettingsObj'] = cfdiSettingsObj?.toJson();
    }
    data['logoUrl'] = logoUrl;
    data['nameLogo'] = nameLogo;
    return data;
  }
}

class PaymentDataObj {
  bool? consolidatePayment;
  bool? notShowValuePay;
  bool? sendPaymentSummaryMail;
  bool? allowSubEnterprise;
  // ignore: prefer-correct-identifier-length
  bool? notShowInvoiceInPaymentList;
  String? wizard;
  num? userInternetPayment;
  int? paymentIntegrationId;
  String? paymentURL;
  String? agreementID;
  String? enterpriseNumberID;
  String? sftpUser;
  String? sftpPassword;
  String? idAdquiriente;
  String? idTerminal;

  PaymentDataObj({
    this.consolidatePayment,
    this.notShowValuePay,
    this.sendPaymentSummaryMail,
    this.allowSubEnterprise,
    this.notShowInvoiceInPaymentList,
    this.wizard,
    this.userInternetPayment,
    this.paymentIntegrationId,
    this.paymentURL,
    this.agreementID,
    this.enterpriseNumberID,
    this.sftpUser,
    this.sftpPassword,
    this.idAdquiriente,
    this.idTerminal,
  });

  PaymentDataObj.fromJson(Map<String, dynamic> json) {
    consolidatePayment = json['consolidatePayment'];
    notShowValuePay = json['notShowValuePay'];
    sendPaymentSummaryMail = json['sendPaymentSummaryMail'];
    allowSubEnterprise = json['allowSubEnterprise'];
    notShowInvoiceInPaymentList = json['notShowInvoiceInPaymentList'];
    wizard = json['wizard'];
    userInternetPayment = json['userInternetPayment'];
    paymentIntegrationId = json['paymentIntegrationId'];
    paymentURL = json['paymentURL'];
    agreementID = json['agreementID'];
    enterpriseNumberID = json['enterpriseNumberID'];
    sftpUser = json['sftpUser'];
    sftpPassword = json['sftpPassword'];
    idAdquiriente = json['idAdquiriente'];
    idTerminal = json['idTerminal'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['consolidatePayment'] = consolidatePayment;
    data['notShowValuePay'] = notShowValuePay;
    data['sendPaymentSummaryMail'] = sendPaymentSummaryMail;
    data['allowSubEnterprise'] = allowSubEnterprise;
    data['notShowInvoiceInPaymentList'] = notShowInvoiceInPaymentList;
    data['wizard'] = wizard;
    data['userInternetPayment'] = userInternetPayment;
    data['paymentIntegrationId'] = paymentIntegrationId;
    data['paymentURL'] = paymentURL;
    data['agreementID'] = agreementID;
    data['enterpriseNumberID'] = enterpriseNumberID;
    data['sftpUser'] = sftpUser;
    data['sftpPassword'] = sftpPassword;
    data['idAdquiriente'] = idAdquiriente;
    data['idTerminal'] = idTerminal;
    return data;
  }
}

class CfdiSettingsObj {
  bool? state;
  bool? billAll;
  String? rfc;
  String? swToken;
  String? zipCode;
  String? address;
  String? businessName;
  String? taxRegimeCode;
  String? taxRegimeId;

  CfdiSettingsObj({
    this.state,
    this.billAll,
    this.rfc,
    this.swToken,
    this.zipCode,
    this.address,
    this.businessName,
    this.taxRegimeCode,
    this.taxRegimeId,
  });

  CfdiSettingsObj.fromJson(Map<String, dynamic> json) {
    state = json['state'];
    billAll = json['billAll'];
    rfc = json['rfc'];
    swToken = json['swToken'];
    zipCode = json['zipCode'];
    address = json['address'];
    businessName = json['businessName'];
    taxRegimeCode = json['taxRegimeCode'];
    taxRegimeId = json['taxRegimeId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['state'] = state;
    data['billAll'] = billAll;
    data['rfc'] = rfc;
    data['swToken'] = swToken;
    data['zipCode'] = zipCode;
    data['address'] = address;
    data['businessName'] = businessName;
    data['taxRegimeCode'] = taxRegimeCode;
    data['taxRegimeId'] = taxRegimeId;
    return data;
  }
}
