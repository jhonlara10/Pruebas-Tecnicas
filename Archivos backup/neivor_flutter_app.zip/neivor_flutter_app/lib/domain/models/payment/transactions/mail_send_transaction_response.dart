class MailSendTransactionResponse {
  MapObjectResponse? map;
  bool? empty;

  MailSendTransactionResponse({this.map, this.empty});

  MailSendTransactionResponse.fromJson(Map<String, dynamic> json) {
    map = json['map'] != null ? MapObjectResponse.fromJson(json['map']) : null;
    empty = json['empty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (map != null) {
      data['map'] = map?.toJson();
    }
    data['empty'] = empty;
    return data;
  }
}

class MapObjectResponse {
  bool? success;
  String? message;

  MapObjectResponse({this.success, this.message});

  MapObjectResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    return data;
  }
}
