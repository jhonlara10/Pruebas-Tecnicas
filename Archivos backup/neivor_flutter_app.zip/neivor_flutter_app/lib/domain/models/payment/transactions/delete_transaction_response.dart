class DeletePendingTransactionResponse {
  bool? success;
  Info? info;

  DeletePendingTransactionResponse({this.success, this.info});

  DeletePendingTransactionResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}
