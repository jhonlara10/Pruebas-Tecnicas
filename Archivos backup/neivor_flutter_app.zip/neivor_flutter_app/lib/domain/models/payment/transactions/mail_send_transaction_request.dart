import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_invoice_response.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class MailSendTransactionRequest {
  List<MailSendTransaction>? mailTransactionList;

  MailSendTransactionRequest({
    this.mailTransactionList,
  });

  // ignore: long-method
  MailSendTransactionRequest getMailSendTransactionRequest(
    List<TransactionList> listTrans,
    String initDate,
    String dateCreation,
  ) {
    var user = UserUtils.currentUser;
    var idUser = user?.id;
    var newList = listTrans.map(
      (e) {
        return MailSendTransaction(
          balanceNumber: e.balanceNumber,
          idBalance: e.idBalance,
          idEnterprise: user?.currentEnterprise?.id,
          idPaymentState: e.idPaymentState,
          idServicePoint: e.idServicePoint,
          invoice: InvoiceMailRequest(
            dateCreation: dateCreation,
            initialDate: initDate,
            descriptionService: e.invoiceTransaction?.descriptionService,
          ),
          idPaymentType: e.idPaymentType,
          payedValue: e.payedValue,
          balanceTransaction: e.balanceTransaction,
          date: e.date,
          descRespuesta: e.descRespuesta,
          dpqTransaction: e.dpqTransaction,
          idZyosUser: idUser,
          manualPayment: e.manualPayment,
          paymentType:
              PaymentTypeMail(id: e.paymentType?.id, name: e.paymentType?.name),
          state: e.state,
          transactionCost: e.transactionCost,
          transactionType: e.transactionType,
        );
      },
    ).toList();
    return MailSendTransactionRequest(
      mailTransactionList: newList,
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (mailTransactionList != null) {
      data['dataTransactionList'] =
          mailTransactionList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class MailSendTransaction {
  int? balanceNumber;
  String? balanceTransaction;
  String? date;
  String? descRespuesta;
  String? dpqTransaction;
  int? idBalance;
  int? idEnterprise;
  int? idPaymentState;
  int? idPaymentType;
  int? idServicePoint;
  int? idZyosUser;
  InvoiceMailRequest? invoice;
  bool? manualPayment;
  double? payedValue;
  PaymentTypeMail? paymentType;
  int? state;
  double? transactionCost;
  int? transactionType;

  MailSendTransaction({
    this.balanceNumber,
    this.balanceTransaction,
    this.date,
    this.descRespuesta,
    this.dpqTransaction,
    this.idBalance,
    this.idEnterprise,
    this.idPaymentState,
    this.idPaymentType,
    this.idServicePoint,
    this.idZyosUser,
    this.invoice,
    this.manualPayment,
    this.payedValue,
    this.paymentType,
    this.state,
    this.transactionCost,
    this.transactionType,
  });

  // ignore: long-method
  MailSendTransaction.fromJson(Map<String, dynamic> json) {
    balanceNumber = json['balanceNumber'];
    balanceTransaction = json['balanceTransaction'];
    date = json['date'];
    descRespuesta = json['descRespuesta'];
    dpqTransaction = json['dpqTransaction'];
    idBalance = json['idBalance'];
    idEnterprise = json['idEnterprise'];
    idPaymentState = json['idPaymentState'];
    idPaymentType = json['idPaymentType'];
    idServicePoint = json['idServicePoint'];
    idZyosUser = json['idZyosUser'];
    invoice = json['invoice'] != null
        ? InvoiceMailRequest.fromJson(json['invoice'])
        : null;
    manualPayment = json['manualPayment'];
    payedValue = json['payedValue'];
    paymentType = json['paymentType'] != null
        ? PaymentTypeMail.fromJson(json['paymentType'])
        : null;
    state = json['state'];
    transactionCost = json['transactionCost'];
    transactionType = json['transactionType'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['balanceNumber'] = balanceNumber;
    data['balanceTransaction'] = balanceTransaction;
    data['date'] = date;
    data['descRespuesta'] = descRespuesta;
    data['dpqTransaction'] = dpqTransaction;
    data['idBalance'] = idBalance;
    data['idEnterprise'] = idEnterprise;
    data['idPaymentState'] = idPaymentState;
    data['idPaymentType'] = idPaymentType;
    data['idServicePoint'] = idServicePoint;
    data['idZyosUser'] = idZyosUser;
    if (invoice != null) {
      data['invoice'] = invoice?.toJson();
    }
    data['manualPayment'] = manualPayment;
    data['payedValue'] = payedValue;
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['state'] = state;
    data['transactionCost'] = transactionCost;
    data['transactionType'] = transactionType;
    return data;
  }
}

class InvoiceMailRequest {
  String? dateCreation;
  String? descriptionService;
  String? initialDate;

  InvoiceMailRequest({
    this.dateCreation,
    this.descriptionService,
    this.initialDate,
  });

  InvoiceMailRequest.fromJson(Map<String, dynamic> json) {
    dateCreation = json['dateCreation'];
    descriptionService = json['descriptionService'];
    initialDate = json['initialDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['dateCreation'] = dateCreation;
    data['descriptionService'] = descriptionService;
    data['initialDate'] = initialDate;
    return data;
  }
}

class PaymentTypeMail {
  int? id;
  String? name;

  PaymentTypeMail({this.id, this.name});

  PaymentTypeMail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}
