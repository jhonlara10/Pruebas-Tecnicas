// ignore_for_file: prefer_collection_literals

class Transaction {
  int? idDaviviendaPaymentQuery;
  int? idBalance;
  int? idEnterprise;
  int? idServicePoint;
  int? idPaymentIntegration;
  String? date;
  InvoiceObject? invoice;
  String? descRespuesta;
  double? payedValue;
  double? transactionCost;
  String? balanceTransaction;
  String? dpqTransaction;
  String? idTransaction;
  int? state;
  PaymentMethodType? paymentMethodType;
  PaymentMethod? paymentMethod;
  int? idPaymentType;
  PaymentType? paymentType;
  int? idPaymentState;
  bool? manualPayment;
  int? balanceNumber;
  int? transactionType;
  PositiveBalance? positiveBalance;

  Transaction({
    this.idDaviviendaPaymentQuery,
    this.idBalance,
    this.idEnterprise,
    this.idServicePoint,
    this.idPaymentIntegration,
    this.date,
    this.invoice,
    this.descRespuesta,
    this.payedValue,
    this.transactionCost,
    this.balanceTransaction,
    this.dpqTransaction,
    this.idTransaction,
    this.state,
    this.paymentMethodType,
    this.paymentMethod,
    this.idPaymentType,
    this.paymentType,
    this.idPaymentState,
    this.manualPayment,
    this.balanceNumber,
    this.transactionType,
    this.positiveBalance,
  });

  // ignore: long-method
  Transaction.fromJson(Map<String, dynamic> json) {
    idDaviviendaPaymentQuery = json['idDaviviendaPaymentQuery'];
    idBalance = json['idBalance'];
    idEnterprise = json['idEnterprise'];
    idServicePoint = json['idServicePoint'];
    idPaymentIntegration = json['idPaymentIntegration'];
    date = json['date'];
    invoice = json['invoice'] != null
        ? InvoiceObject.fromJson(json['invoice'])
        : null;
    descRespuesta = json['descRespuesta'];
    payedValue = json['payedValue'];
    transactionCost = json['transactionCost'];
    balanceTransaction = json['balanceTransaction'];
    dpqTransaction = json['dpqTransaction'];
    idTransaction = json['idTransaction'];
    state = json['state'];
    paymentMethodType = json['paymentMethodType'] != null
        ? PaymentMethodType.fromJson(json['paymentMethodType'])
        : null;
    paymentMethod = json['paymentMethod'] != null
        ? PaymentMethod.fromJson(json['paymentMethod'])
        : null;
    idPaymentType = json['idPaymentType'];
    paymentType = json['paymentType'] != null
        ? PaymentType.fromJson(json['paymentType'])
        : null;
    idPaymentState = json['idPaymentState'];
    manualPayment = json['manualPayment'];
    balanceNumber = json['balanceNumber'];
    transactionType = json['transactionType'];
    positiveBalance = json['positiveBalance'] != null
        ? PositiveBalance.fromJson(json['positiveBalance'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idDaviviendaPaymentQuery'] = idDaviviendaPaymentQuery;
    data['idBalance'] = idBalance;
    data['idEnterprise'] = idEnterprise;
    data['idServicePoint'] = idServicePoint;
    data['idPaymentIntegration'] = idPaymentIntegration;
    data['date'] = date;
    if (invoice != null) {
      data['invoice'] = invoice?.toJson();
    }
    data['descRespuesta'] = descRespuesta;
    data['payedValue'] = payedValue;
    data['transactionCost'] = transactionCost;
    data['balanceTransaction'] = balanceTransaction;
    data['dpqTransaction'] = dpqTransaction;
    data['idTransaction'] = idTransaction;
    data['state'] = state;
    if (paymentMethodType != null) {
      data['paymentMethodType'] = paymentMethodType?.toJson();
    }
    if (paymentMethod != null) {
      data['paymentMethod'] = paymentMethod?.toJson();
    }
    data['idPaymentType'] = idPaymentType;
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['idPaymentState'] = idPaymentState;
    data['manualPayment'] = manualPayment;
    data['balanceNumber'] = balanceNumber;
    data['transactionType'] = transactionType;
    data['positiveBalance'] = positiveBalance?.toJson();
    return data;
  }
}

class InvoiceObject {
  String? reference;
  double? paidValue;
  int? calculateFine;
  int? manuallyModified;
  List<DiscountDataList>? discountDataList;
  bool? haveBalanceAnnulled;
  String? descriptionService;

  InvoiceObject({
    this.reference,
    this.paidValue,
    this.calculateFine,
    this.manuallyModified,
    this.discountDataList,
    this.haveBalanceAnnulled,
    this.descriptionService,
  });

  InvoiceObject.fromJson(Map<String, dynamic> json) {
    reference = json['reference'];
    descriptionService = json['descriptionService'];
    paidValue = json['paidValue'];
    calculateFine = json['calculateFine'];
    manuallyModified = json['manuallyModified'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
    haveBalanceAnnulled = json['haveBalanceAnnulled'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['descriptionService'] = descriptionService;
    data['reference'] = reference;
    data['paidValue'] = paidValue;
    data['calculateFine'] = calculateFine;
    data['manuallyModified'] = manuallyModified;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    data['haveBalanceAnnulled'] = haveBalanceAnnulled;
    return data;
  }
}

class PaymentMethodType {
  String? name;

  PaymentMethodType({this.name});

  PaymentMethodType.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    return data;
  }
}

class PaymentMethod {
  String? name;
  CreditCard? creditCard;

  PaymentMethod({this.name, this.creditCard});

  PaymentMethod.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    creditCard = json['creditCard'] != null
        ? CreditCard.fromJson(json['creditCard'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    if (creditCard != null) {
      data['creditCard'] = creditCard?.toJson();
    }
    return data;
  }
}

class CreditCard {
  String? cardNumber;
  int? cvv;
  String? franchise;
  int? installment;
  bool? tokenize;
  bool? dynamicCvv;
  bool? active;

  CreditCard({
    this.cardNumber,
    this.cvv,
    this.franchise,
    this.installment,
    this.tokenize,
    this.dynamicCvv,
    this.active,
  });

  CreditCard.fromJson(Map<String, dynamic> json) {
    cardNumber = json['cardNumber'];
    cvv = json['cvv'];
    franchise = json['franchise'];
    installment = json['installment'];
    tokenize = json['tokenize'];
    dynamicCvv = json['dynamicCvv'];
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cardNumber'] = cardNumber;
    data['cvv'] = cvv;
    data['franchise'] = franchise;
    data['installment'] = installment;
    data['tokenize'] = tokenize;
    data['dynamicCvv'] = dynamicCvv;
    data['active'] = active;
    return data;
  }
}

class DiscountDataList {
  bool? permanentDiscount;
  bool? roundingValue;
  bool? roundingBeforeDiscount;
  int? discount;
  int? idCriteriaDiscount;
  int? maxDateOfDiscount;

  DiscountDataList({
    this.permanentDiscount,
    this.roundingValue,
    this.roundingBeforeDiscount,
    this.discount,
    this.idCriteriaDiscount,
    this.maxDateOfDiscount,
  });

  DiscountDataList.fromJson(Map<String, dynamic> json) {
    permanentDiscount = json['permanentDiscount'];
    roundingValue = json['roundingValue'];
    roundingBeforeDiscount = json['roundingBeforeDiscount'];
    discount = json['discount'];
    idCriteriaDiscount = json['idCriteriaDiscount'];
    maxDateOfDiscount = json['maxDateOfDiscount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['permanentDiscount'] = permanentDiscount;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeDiscount'] = roundingBeforeDiscount;
    data['discount'] = discount;
    data['idCriteriaDiscount'] = idCriteriaDiscount;
    data['maxDateOfDiscount'] = maxDateOfDiscount;
    return data;
  }
}

class PaymentType {
  int? id;
  String? name;

  PaymentType({this.id, this.name});

  PaymentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class PositiveBalance {
  int? id;
  String? dateCreation;
  String? hourCreation;
  int? state;
  String? datePayed;
  String? hourPayed;
  String? cycleDate;
  int? idEnterprise;
  int? idPaymentType;
  int? idServicePoint;
  PaymentType? paymentType;
  String? observation;
  String? invoiceReference;
  double? value;
  double? initialValue;
  String? payReference;
  int? balanceNumber;
  String? paymentTypeName;
  String? bankAccountNumber;
  InvoiceServiceType? invoiceServiceType;
  BankAccount? bankAccount;
  int? idBalanceState;
  bool? fatherBalance;
  List<PaymentInvoiceValueList>? paymentInvoiceValueList;

  PositiveBalance({
    this.id,
    this.dateCreation,
    this.hourCreation,
    this.state,
    this.datePayed,
    this.hourPayed,
    this.cycleDate,
    this.idEnterprise,
    this.idPaymentType,
    this.idServicePoint,
    this.paymentType,
    this.observation,
    this.invoiceReference,
    this.value,
    this.initialValue,
    this.payReference,
    this.balanceNumber,
    this.paymentTypeName,
    this.bankAccountNumber,
    this.invoiceServiceType,
    this.bankAccount,
    this.idBalanceState,
    this.fatherBalance,
    this.paymentInvoiceValueList,
  });

  // ignore: long-method
  PositiveBalance.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    hourCreation = json['hourCreation'];
    state = json['state'];
    datePayed = json['datePayed'];
    hourPayed = json['hourPayed'];
    cycleDate = json['cycleDate'];
    idEnterprise = json['idEnterprise'];
    idPaymentType = json['idPaymentType'];
    idServicePoint = json['idServicePoint'];
    paymentType = json['paymentType'] != null
        ? PaymentType.fromJson(json['paymentType'])
        : null;
    observation = json['observation'];
    invoiceReference = json['invoiceReference'];
    value = json['value'];
    initialValue = json['initialValue'];
    payReference = json['payReference'];
    balanceNumber = json['balanceNumber'];
    paymentTypeName = json['paymentTypeName'];
    bankAccountNumber = json['bankAccountNumber'];
    invoiceServiceType = json['invoiceServiceType'] != null
        ? InvoiceServiceType.fromJson(json['invoiceServiceType'])
        : null;
    bankAccount = json['bankAccount'] != null
        ? BankAccount.fromJson(json['bankAccount'])
        : null;
    idBalanceState = json['idBalanceState'];
    fatherBalance = json['fatherBalance'];
    if (json['paymentInvoiceValueList'] != null) {
      paymentInvoiceValueList = <PaymentInvoiceValueList>[];
      json['paymentInvoiceValueList'].forEach((v) {
        paymentInvoiceValueList!.add(PaymentInvoiceValueList.fromJson(v));
      });
    }
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['hourCreation'] = hourCreation;
    data['state'] = state;
    data['datePayed'] = datePayed;
    data['hourPayed'] = hourPayed;
    data['cycleDate'] = cycleDate;
    data['idEnterprise'] = idEnterprise;
    data['idPaymentType'] = idPaymentType;
    data['idServicePoint'] = idServicePoint;
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['observation'] = observation;
    data['invoiceReference'] = invoiceReference;
    data['value'] = value;
    data['initialValue'] = initialValue;
    data['payReference'] = payReference;
    data['balanceNumber'] = balanceNumber;
    data['paymentTypeName'] = paymentTypeName;
    data['bankAccountNumber'] = bankAccountNumber;
    if (invoiceServiceType != null) {
      data['invoiceServiceType'] = invoiceServiceType?.toJson();
    }
    if (bankAccount != null) {
      data['bankAccount'] = bankAccount?.toJson();
    }
    data['idBalanceState'] = idBalanceState;
    data['fatherBalance'] = fatherBalance;
    if (paymentInvoiceValueList != null) {
      data['paymentInvoiceValueList'] =
          paymentInvoiceValueList!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class PaymentInvoiceValueList {
  int? idInvoice;
  double? payedValue;

  PaymentInvoiceValueList({this.idInvoice, this.payedValue});

  PaymentInvoiceValueList.fromJson(Map<String, dynamic> json) {
    idInvoice = json['idInvoice'];
    payedValue = json['payedValue'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['idInvoice'] = idInvoice;
    data['payedValue'] = payedValue;
    return data;
  }
}

class InvoiceServiceType {
  InvoiceServiceType();

  InvoiceServiceType.fromJson(Map<String, dynamic> json);

  Map<String, dynamic> toJson() {
    return <String, dynamic>{};
  }
}

class BankAccount {
  int? id;
  String? accountNumber;

  BankAccount({this.id, this.accountNumber});

  BankAccount.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    accountNumber = json['accountNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['accountNumber'] = accountNumber;
    return data;
  }
}
