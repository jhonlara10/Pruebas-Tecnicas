import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction.dart';

class TransactionsResponse {
  bool? success;
  Info? info;
  Data? data;

  TransactionsResponse({this.success, this.info, this.data});

  TransactionsResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Data {
  List<Transaction>? transactionList;

  Data({this.transactionList});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['transactionList'] != null) {
      transactionList = <Transaction>[];
      json['transactionList'].forEach((v) {
        transactionList?.add(Transaction.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (transactionList != null) {
      data['transactionList'] =
          transactionList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}
