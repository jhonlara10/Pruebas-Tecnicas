// ignore: prefer-correct-type-name
class HistoricTransactionRequest {
  Enterprise? enterprise;

  HistoricTransactionRequest({this.enterprise});

  HistoricTransactionRequest.fromJson(Map<String, dynamic> json) {
    enterprise = json['enterprise'] != null
        ? Enterprise.fromJson(json['enterprise'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (enterprise != null) {
      data['enterprise'] = enterprise?.toJson();
    }
    return data;
  }
}

class Enterprise {
  int? id;

  Enterprise({this.id});

  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}
