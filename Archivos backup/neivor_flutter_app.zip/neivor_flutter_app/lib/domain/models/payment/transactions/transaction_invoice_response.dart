class TransactionByInvoiceResponse {
  bool? success;
  Info? info;
  Entity? entity;

  TransactionByInvoiceResponse({this.success, this.info, this.entity});

  TransactionByInvoiceResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    entity = json['entity'] != null ? Entity.fromJson(json['entity']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (entity != null) {
      data['entity'] = entity?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Entity {
  List<TransactionList>? transactionList;

  Entity({this.transactionList});

  Entity.fromJson(Map<String, dynamic> json) {
    if (json['transactionList'] != null) {
      transactionList = <TransactionList>[];
      json['transactionList'].forEach((v) {
        transactionList?.add(TransactionList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (transactionList != null) {
      data['transactionList'] =
          transactionList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class TransactionList {
  int? idBalance;
  int? idEnterprise;
  int? idServicePoint;
  String? date;
  InvoiceTransaction? invoiceTransaction;
  String? descRespuesta;
  double? payedValue;
  double? transactionCost;
  String? balanceTransaction;
  String? dpqTransaction;
  int? state;
  int? idPaymentType;
  PaymentType? paymentType;
  int? idPaymentState;
  bool? manualPayment;
  int? balanceNumber;
  int? transactionType;

  TransactionList({
    this.idBalance,
    this.idEnterprise,
    this.idServicePoint,
    this.date,
    this.invoiceTransaction,
    this.descRespuesta,
    this.payedValue,
    this.transactionCost,
    this.balanceTransaction,
    this.dpqTransaction,
    this.state,
    this.idPaymentType,
    this.paymentType,
    this.idPaymentState,
    this.manualPayment,
    this.balanceNumber,
    this.transactionType,
  });

  // ignore: long-method
  TransactionList.fromJson(Map<String, dynamic> json) {
    idBalance = json['idBalance'];
    idEnterprise = json['idEnterprise'];
    idServicePoint = json['idServicePoint'];
    date = json['date'];
    if (json['invoice'] != null) {
      invoiceTransaction = InvoiceTransaction.fromJson(json['invoice']);
    } else {
      invoiceTransaction = null;
    }
    descRespuesta = json['descRespuesta'];
    payedValue = json['payedValue'];
    transactionCost = json['transactionCost'];
    balanceTransaction = json['balanceTransaction'];
    dpqTransaction = json['dpqTransaction'];
    state = json['state'];
    idPaymentType = json['idPaymentType'];
    paymentType = json['paymentType'] != null
        ? PaymentType.fromJson(json['paymentType'])
        : null;
    idPaymentState = json['idPaymentState'];
    manualPayment = json['manualPayment'];
    balanceNumber = json['balanceNumber'];
    transactionType = json['transactionType'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idBalance'] = idBalance;
    data['idEnterprise'] = idEnterprise;
    data['idServicePoint'] = idServicePoint;
    data['date'] = date;
    if (invoiceTransaction != null) {
      data['invoice'] = invoiceTransaction?.toJson();
    }
    data['descRespuesta'] = descRespuesta;
    data['payedValue'] = payedValue;
    data['transactionCost'] = transactionCost;
    data['balanceTransaction'] = balanceTransaction;
    data['dpqTransaction'] = dpqTransaction;
    data['state'] = state;
    data['idPaymentType'] = idPaymentType;
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['idPaymentState'] = idPaymentState;
    data['manualPayment'] = manualPayment;
    data['balanceNumber'] = balanceNumber;
    data['transactionType'] = transactionType;
    return data;
  }
}

class InvoiceTransaction {
  String? descriptionService;
  String? reference;
  double? paidValue;
  int? calculateFine;
  int? manuallyModified;
  List<DiscountDataList>? discountDataList;
  bool? haveBalanceAnnulled;

  InvoiceTransaction({
    this.descriptionService,
    this.reference,
    this.paidValue,
    this.calculateFine,
    this.manuallyModified,
    this.discountDataList,
    this.haveBalanceAnnulled,
  });

  InvoiceTransaction.fromJson(Map<String, dynamic> json) {
    descriptionService = json['descriptionService'];
    reference = json['reference'];
    paidValue = json['paidValue'];
    calculateFine = json['calculateFine'];
    manuallyModified = json['manuallyModified'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
    haveBalanceAnnulled = json['haveBalanceAnnulled'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['descriptionService'] = descriptionService;
    data['reference'] = reference;
    data['paidValue'] = paidValue;
    data['calculateFine'] = calculateFine;
    data['manuallyModified'] = manuallyModified;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    data['haveBalanceAnnulled'] = haveBalanceAnnulled;
    return data;
  }
}

class PaymentType {
  int? id;
  String? name;

  PaymentType({this.id, this.name});

  PaymentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class DiscountDataList {
  bool? permanentDiscount;
  bool? roundingValue;
  bool? roundingBeforeDiscount;
  double? discount;
  int? idCriteriaDiscount;
  int? maxDateOfDiscount;

  DiscountDataList({
    this.permanentDiscount,
    this.roundingValue,
    this.roundingBeforeDiscount,
    this.discount,
    this.idCriteriaDiscount,
    this.maxDateOfDiscount,
  });

  DiscountDataList.fromJson(Map<String, dynamic> json) {
    permanentDiscount = json['permanentDiscount'];
    roundingValue = json['roundingValue'];
    roundingBeforeDiscount = json['roundingBeforeDiscount'];
    discount = json['discount'];
    idCriteriaDiscount = json['idCriteriaDiscount'];
    maxDateOfDiscount = json['maxDateOfDiscount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['permanentDiscount'] = permanentDiscount;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeDiscount'] = roundingBeforeDiscount;
    data['discount'] = discount;
    data['idCriteriaDiscount'] = idCriteriaDiscount;
    data['maxDateOfDiscount'] = maxDateOfDiscount;
    return data;
  }
}
