class HistoricTransactionResponse {
  bool? success;
  Info? info;
  Entity? entity;
  Entity? data;

  HistoricTransactionResponse({
    this.success,
    this.info,
    this.entity,
    this.data,
  });

  HistoricTransactionResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    entity = json['entity'] != null ? Entity.fromJson(json['entity']) : null;
    data = json['data'] != null ? Entity.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (entity != null) {
      data['entity'] = entity?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Entity {
  List<HistoricTransactionList>? transactionList;

  Entity({this.transactionList});

  Entity.fromJson(Map<String, dynamic> json) {
    if (json['transactionList'] != null) {
      transactionList = <HistoricTransactionList>[];
      json['transactionList'].forEach((v) {
        transactionList?.add(HistoricTransactionList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (transactionList != null) {
      data['transactionList'] =
          transactionList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class HistoricTransactionList {
  // ignore: prefer-correct-identifier-length
  int? idDaviviendaPaymentQuery;
  int? idEnterprise;
  int? idServicePoint;
  int? idPaymentIntegration;
  String? date;
  HistoricTransactionInvoice? invoice;
  double? payedValue;
  double? transactionCost;
  String? balanceTransaction;
  String? dpqTransaction;
  int? state;
  PaymentMethodType? paymentMethodType;
  int? idPaymentType;
  PaymentType? paymentType;
  int? idPaymentState;
  bool? manualPayment;
  int? transactionType;
  ServicePoint? servicePoint;
  int? idBalance;
  String? descRespuesta;
  int? balanceNumber;
  String? idTransaction;
  PaymentMethod? paymentMethod;

  HistoricTransactionList({
    this.idDaviviendaPaymentQuery,
    this.idEnterprise,
    this.idServicePoint,
    this.idPaymentIntegration,
    this.date,
    this.invoice,
    this.payedValue,
    this.transactionCost,
    this.balanceTransaction,
    this.dpqTransaction,
    this.state,
    this.paymentMethodType,
    this.idPaymentType,
    this.paymentType,
    this.idPaymentState,
    this.manualPayment,
    this.transactionType,
    this.servicePoint,
    this.idBalance,
    this.descRespuesta,
    this.balanceNumber,
    this.idTransaction,
    this.paymentMethod,
  });

  // ignore: long-method
  HistoricTransactionList.fromJson(Map<String, dynamic> json) {
    idDaviviendaPaymentQuery = json['idDaviviendaPaymentQuery'];
    idEnterprise = json['idEnterprise'];
    idServicePoint = json['idServicePoint'];
    idPaymentIntegration = json['idPaymentIntegration'];
    date = json['date'];
    invoice = json['invoice'] != null
        ? HistoricTransactionInvoice.fromJson(json['invoice'])
        : null;
    payedValue = json['payedValue'];
    transactionCost = json['transactionCost'];
    balanceTransaction = json['balanceTransaction'];
    dpqTransaction = json['dpqTransaction'];
    state = json['state'];
    paymentMethodType = json['paymentMethodType'] != null
        ? PaymentMethodType.fromJson(json['paymentMethodType'])
        : null;
    idPaymentType = json['idPaymentType'];
    paymentType = json['paymentType'] != null
        ? PaymentType.fromJson(json['paymentType'])
        : null;
    idPaymentState = json['idPaymentState'];
    manualPayment = json['manualPayment'];
    transactionType = json['transactionType'];
    servicePoint = json['servicePoint'] != null
        ? ServicePoint.fromJson(json['servicePoint'])
        : null;
    idBalance = json['idBalance'];
    descRespuesta = json['descRespuesta'];
    balanceNumber = json['balanceNumber'];
    idTransaction = json['idTransaction'];
    paymentMethod = json['paymentMethod'] != null
        ? PaymentMethod.fromJson(json['paymentMethod'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idDaviviendaPaymentQuery'] = idDaviviendaPaymentQuery;
    data['idEnterprise'] = idEnterprise;
    data['idServicePoint'] = idServicePoint;
    data['idPaymentIntegration'] = idPaymentIntegration;
    data['date'] = date;
    if (invoice != null) {
      data['invoice'] = invoice?.toJson();
    }
    data['payedValue'] = payedValue;
    data['transactionCost'] = transactionCost;
    data['balanceTransaction'] = balanceTransaction;
    data['dpqTransaction'] = dpqTransaction;
    data['state'] = state;
    if (paymentMethodType != null) {
      data['paymentMethodType'] = paymentMethodType?.toJson();
    }
    data['idPaymentType'] = idPaymentType;
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['idPaymentState'] = idPaymentState;
    data['manualPayment'] = manualPayment;
    data['transactionType'] = transactionType;
    if (servicePoint != null) {
      data['servicePoint'] = servicePoint?.toJson();
    }
    data['idBalance'] = idBalance;
    data['descRespuesta'] = descRespuesta;
    data['balanceNumber'] = balanceNumber;
    data['idTransaction'] = idTransaction;
    if (paymentMethod != null) {
      data['paymentMethod'] = paymentMethod?.toJson();
    }
    return data;
  }
}

class DiscountDataList {
  bool? permanentDiscount;
  bool? roundingValue;
  bool? roundingBeforeDiscount;
  double? discount;
  int? idCriteriaDiscount;
  int? maxDateOfDiscount;

  DiscountDataList({
    this.permanentDiscount,
    this.roundingValue,
    this.roundingBeforeDiscount,
    this.discount,
    this.idCriteriaDiscount,
    this.maxDateOfDiscount,
  });

  DiscountDataList.fromJson(Map<String, dynamic> json) {
    permanentDiscount = json['permanentDiscount'];
    roundingValue = json['roundingValue'];
    roundingBeforeDiscount = json['roundingBeforeDiscount'];
    discount = json['discount'];
    idCriteriaDiscount = json['idCriteriaDiscount'];
    maxDateOfDiscount = json['maxDateOfDiscount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['permanentDiscount'] = permanentDiscount;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeDiscount'] = roundingBeforeDiscount;
    data['discount'] = discount;
    data['idCriteriaDiscount'] = idCriteriaDiscount;
    data['maxDateOfDiscount'] = maxDateOfDiscount;
    return data;
  }
}

class HistoricTransactionInvoice {
  String? reference;
  double? paidValue;
  int? calculateFine;
  int? manuallyModified;
  List<DiscountDataList>? discountDataList;
  bool? haveBalanceAnnulled;
  String? descriptionService;

  HistoricTransactionInvoice({
    this.reference,
    this.paidValue,
    this.calculateFine,
    this.manuallyModified,
    this.discountDataList,
    this.haveBalanceAnnulled,
    this.descriptionService,
  });

  HistoricTransactionInvoice.fromJson(Map<String, dynamic> json) {
    reference = json['reference'];
    paidValue = json['paidValue'];
    calculateFine = json['calculateFine'];
    manuallyModified = json['manuallyModified'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
    haveBalanceAnnulled = json['haveBalanceAnnulled'];
    descriptionService = json['descriptionService'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['reference'] = reference;
    data['paidValue'] = paidValue;
    data['calculateFine'] = calculateFine;
    data['manuallyModified'] = manuallyModified;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    data['haveBalanceAnnulled'] = haveBalanceAnnulled;
    data['descriptionService'] = descriptionService;
    return data;
  }
}

class PaymentMethodType {
  String? name;

  PaymentMethodType({this.name});

  PaymentMethodType.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    return data;
  }
}

class PaymentType {
  int? id;
  String? name;

  PaymentType({this.id, this.name});

  PaymentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class ServicePoint {
  int? id;
  int? state;
  int? totalRow;
  int? idEnterprise;
  int? idOperationZone;
  String? reference;
  String? name;
  double? costAdmon;
  double? adminCost;
  int? idZyosUser;
  int? legalCharge;
  PaymentType? operationZone;
  Enterprise? enterprise;

  ServicePoint({
    this.id,
    this.state,
    this.totalRow,
    this.idEnterprise,
    this.idOperationZone,
    this.reference,
    this.name,
    this.costAdmon,
    this.adminCost,
    this.idZyosUser,
    this.legalCharge,
    this.operationZone,
    this.enterprise,
  });

  // ignore: long-method
  ServicePoint.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    totalRow = json['totalRow'];
    idEnterprise = json['idEnterprise'];
    idOperationZone = json['idOperationZone'];
    reference = json['reference'];
    name = json['name'];
    costAdmon = json['costAdmon'];
    adminCost = json['adminCost'];
    idZyosUser = json['idZyosUser'];
    legalCharge = json['legalCharge'];
    operationZone = json['operationZone'] != null
        ? PaymentType.fromJson(json['operationZone'])
        : null;
    enterprise = json['enterprise'] != null
        ? Enterprise.fromJson(json['enterprise'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['totalRow'] = totalRow;
    data['idEnterprise'] = idEnterprise;
    data['idOperationZone'] = idOperationZone;
    data['reference'] = reference;
    data['name'] = name;
    data['costAdmon'] = costAdmon;
    data['adminCost'] = adminCost;
    data['idZyosUser'] = idZyosUser;
    data['legalCharge'] = legalCharge;
    if (operationZone != null) {
      data['operationZone'] = operationZone?.toJson();
    }
    if (enterprise != null) {
      data['enterprise'] = enterprise?.toJson();
    }
    return data;
  }
}

class Enterprise {
  int? id;
  String? name;
  String? nameLogo;
  String? paymentData;
  int? idStateEnterprise;
  int? invoiceCount;
  int? startInvoiceConsecutive;
  PaymentDataObj? paymentDataObj;
  CfdiSettingsObj? cfdiSettingsObj;

  Enterprise({
    this.id,
    this.name,
    this.nameLogo,
    this.paymentData,
    this.idStateEnterprise,
    this.invoiceCount,
    this.startInvoiceConsecutive,
    this.paymentDataObj,
    this.cfdiSettingsObj,
  });

  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    nameLogo = json['nameLogo'];
    paymentData = json['paymentData'];
    idStateEnterprise = json['idStateEnterprise'];
    invoiceCount = json['invoiceCount'];
    startInvoiceConsecutive = json['startInvoiceConsecutive'];
    paymentDataObj = json['paymentDataObj'] != null
        ? PaymentDataObj.fromJson(json['paymentDataObj'])
        : null;
    cfdiSettingsObj = json['cfdiSettingsObj'] != null
        ? CfdiSettingsObj.fromJson(json['cfdiSettingsObj'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['nameLogo'] = nameLogo;
    data['paymentData'] = paymentData;
    data['idStateEnterprise'] = idStateEnterprise;
    data['invoiceCount'] = invoiceCount;
    data['startInvoiceConsecutive'] = startInvoiceConsecutive;
    if (paymentDataObj != null) {
      data['paymentDataObj'] = paymentDataObj?.toJson();
    }
    if (cfdiSettingsObj != null) {
      data['cfdiSettingsObj'] = cfdiSettingsObj?.toJson();
    }
    return data;
  }
}

class PaymentDataObj {
  bool? consolidatePayment;
  bool? notShowValuePay;
  bool? sendPaymentSummaryMail;
  bool? allowSubEnterprise;
  // ignore: prefer-correct-identifier-length
  bool? notShowInvoiceInPaymentList;
  String? paymentURL;
  String? agreementID;
  String? enterpriseNumberID;
  String? sftpUser;
  String? sftpPassword;
  String? wizard;
  String? idAdquiriente;
  String? idTerminal;
  double? userInternetPayment;
  int? paymentIntegrationId;

  PaymentDataObj({
    this.consolidatePayment,
    this.notShowValuePay,
    this.sendPaymentSummaryMail,
    this.allowSubEnterprise,
    this.notShowInvoiceInPaymentList,
    this.paymentURL,
    this.agreementID,
    this.enterpriseNumberID,
    this.sftpUser,
    this.sftpPassword,
    this.wizard,
    this.idAdquiriente,
    this.idTerminal,
    this.userInternetPayment,
    this.paymentIntegrationId,
  });

  PaymentDataObj.fromJson(Map<String, dynamic> json) {
    consolidatePayment = json['consolidatePayment'];
    notShowValuePay = json['notShowValuePay'];
    sendPaymentSummaryMail = json['sendPaymentSummaryMail'];
    allowSubEnterprise = json['allowSubEnterprise'];
    notShowInvoiceInPaymentList = json['notShowInvoiceInPaymentList'];
    paymentURL = json['paymentURL'];
    agreementID = json['agreementID'];
    enterpriseNumberID = json['enterpriseNumberID'];
    sftpUser = json['sftpUser'];
    sftpPassword = json['sftpPassword'];
    wizard = json['wizard'];
    idAdquiriente = json['idAdquiriente'];
    idTerminal = json['idTerminal'];
    userInternetPayment = json['userInternetPayment'];
    paymentIntegrationId = json['paymentIntegrationId'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['consolidatePayment'] = consolidatePayment;
    data['notShowValuePay'] = notShowValuePay;
    data['sendPaymentSummaryMail'] = sendPaymentSummaryMail;
    data['allowSubEnterprise'] = allowSubEnterprise;
    data['notShowInvoiceInPaymentList'] = notShowInvoiceInPaymentList;
    data['paymentURL'] = paymentURL;
    data['agreementID'] = agreementID;
    data['enterpriseNumberID'] = enterpriseNumberID;
    data['sftpUser'] = sftpUser;
    data['sftpPassword'] = sftpPassword;
    data['wizard'] = wizard;
    data['idAdquiriente'] = idAdquiriente;
    data['idTerminal'] = idTerminal;
    data['userInternetPayment'] = userInternetPayment;
    data['paymentIntegrationId'] = paymentIntegrationId;
    return data;
  }
}

class CfdiSettingsObj {
  bool? state;
  bool? billAll;
  String? rfc;
  String? swToken;
  String? zipCode;
  String? address;
  String? businessName;
  String? taxRegimeCode;
  String? taxRegimeId;

  CfdiSettingsObj({
    this.state,
    this.billAll,
    this.rfc,
    this.swToken,
    this.zipCode,
    this.address,
    this.businessName,
    this.taxRegimeCode,
    this.taxRegimeId,
  });

  CfdiSettingsObj.fromJson(Map<String, dynamic> json) {
    state = json['state'];
    billAll = json['billAll'];
    rfc = json['rfc'];
    swToken = json['swToken'];
    zipCode = json['zipCode'];
    address = json['address'];
    businessName = json['businessName'];
    taxRegimeCode = json['taxRegimeCode'];
    taxRegimeId = json['taxRegimeId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['state'] = state;
    data['billAll'] = billAll;
    data['rfc'] = rfc;
    data['swToken'] = swToken;
    data['zipCode'] = zipCode;
    data['address'] = address;
    data['businessName'] = businessName;
    data['taxRegimeCode'] = taxRegimeCode;
    data['taxRegimeId'] = taxRegimeId;
    return data;
  }
}

class PaymentMethod {
  String? name;
  CreditCard? creditCard;

  PaymentMethod({this.name, this.creditCard});

  PaymentMethod.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    creditCard = json['creditCard'] != null
        ? CreditCard.fromJson(json['creditCard'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    if (creditCard != null) {
      data['creditCard'] = creditCard?.toJson();
    }
    return data;
  }
}

class CreditCard {
  String? cardNumber;
  int? cvv;
  String? franchise;
  int? installment;
  bool? tokenize;
  bool? dynamicCvv;
  bool? active;

  CreditCard({
    this.cardNumber,
    this.cvv,
    this.franchise,
    this.installment,
    this.tokenize,
    this.dynamicCvv,
    this.active,
  });

  CreditCard.fromJson(Map<String, dynamic> json) {
    cardNumber = json['cardNumber'];
    cvv = json['cvv'];
    franchise = json['franchise'];
    installment = json['installment'];
    tokenize = json['tokenize'];
    dynamicCvv = json['dynamicCvv'];
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cardNumber'] = cardNumber;
    data['cvv'] = cvv;
    data['franchise'] = franchise;
    data['installment'] = installment;
    data['tokenize'] = tokenize;
    data['dynamicCvv'] = dynamicCvv;
    data['active'] = active;
    return data;
  }
}
