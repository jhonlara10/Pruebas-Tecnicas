class PendingTransactionResponse {
  bool? success;
  List<PendingTransaction>? list;

  PendingTransactionResponse({this.success, this.list});

  PendingTransactionResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['list'] != null) {
      list = <PendingTransaction>[];
      json['list'].forEach((v) {
        list?.add(PendingTransaction.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (list != null) {
      data['list'] = list?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class PendingTransaction {
  int? id;
  int? state;
  int? idEnterprise;
  int? idPaymentType;
  int? idServicePoint;
  int? idPaymentIntegration;
  String? cycleDate;
  String? datePayed;
  String? invoiceReference;
  String? transactionData;
  String? paymentInvoiceValue;
  double? value;
  double? initialValue;
  String? payReference;
  double? transactionCost;
  List<PaymentInvoiceValueList>? paymentInvoiceValueList;
  double? valueToPay;

  PendingTransaction({
    this.id,
    this.state,
    this.idEnterprise,
    this.idPaymentType,
    this.idServicePoint,
    this.idPaymentIntegration,
    this.cycleDate,
    this.datePayed,
    this.invoiceReference,
    this.transactionData,
    this.paymentInvoiceValue,
    this.value,
    this.initialValue,
    this.payReference,
    this.transactionCost,
    this.paymentInvoiceValueList,
    this.valueToPay,
  });

  // ignore: long-method
  PendingTransaction.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    idEnterprise = json['idEnterprise'];
    idPaymentType = json['idPaymentType'];
    idServicePoint = json['idServicePoint'];
    idPaymentIntegration = json['idPaymentIntegration'];
    cycleDate = json['cycleDate'];
    datePayed = json['datePayed'];
    invoiceReference = json['invoiceReference'];
    transactionData = json['transactionData'];
    paymentInvoiceValue = json['paymentInvoiceValue'];
    value = json['value'];
    initialValue = json['initialValue'];
    payReference = json['payReference'];
    transactionCost = json['transactionCost'];
    if (json['paymentInvoiceValueList'] != null) {
      paymentInvoiceValueList = <PaymentInvoiceValueList>[];
      json['paymentInvoiceValueList'].forEach((v) {
        paymentInvoiceValueList?.add(PaymentInvoiceValueList.fromJson(v));
      });
    }
    valueToPay = json['valueToPay'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['idEnterprise'] = idEnterprise;
    data['idPaymentType'] = idPaymentType;
    data['idServicePoint'] = idServicePoint;
    data['idPaymentIntegration'] = idPaymentIntegration;
    data['cycleDate'] = cycleDate;
    data['datePayed'] = datePayed;
    data['invoiceReference'] = invoiceReference;
    data['transactionData'] = transactionData;
    data['paymentInvoiceValue'] = paymentInvoiceValue;
    data['value'] = value;
    data['initialValue'] = initialValue;
    data['payReference'] = payReference;
    data['transactionCost'] = transactionCost;
    if (paymentInvoiceValueList != null) {
      data['paymentInvoiceValueList'] =
          paymentInvoiceValueList?.map((v) => v.toJson()).toList();
    }
    data['valueToPay'] = valueToPay;
    return data;
  }
}

class PaymentInvoiceValueList {
  int? idInvoice;
  double? value;
  String? descriptionService;

  PaymentInvoiceValueList({
    this.idInvoice,
    this.value,
    this.descriptionService,
  });

  PaymentInvoiceValueList.fromJson(Map<String, dynamic> json) {
    idInvoice = json['idInvoice'];
    value = json['value'];
    descriptionService = json['descriptionService'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idInvoice'] = idInvoice;
    data['value'] = value;
    data['descriptionService'] = descriptionService;
    return data;
  }
}
