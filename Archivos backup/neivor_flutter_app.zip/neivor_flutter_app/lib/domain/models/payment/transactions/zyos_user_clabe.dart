class ZyosUserClabe {
  bool? success;
  Entity? entity;

  ZyosUserClabe({this.success, this.entity});

  ZyosUserClabe.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    entity = json['entity'] != null ? Entity.fromJson(json['entity']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (entity != null) {
      data['entity'] = entity?.toJson();
    }
    return data;
  }
}

class Entity {
  int? id;
  int? idZyosUser;
  int? idServicePoint;
  String? referenceNumber;
  String? subscriptionId;

  Entity({
    this.id,
    this.idZyosUser,
    this.idServicePoint,
    this.referenceNumber,
    this.subscriptionId,
  });

  Entity.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idZyosUser = json['idZyosUser'];
    idServicePoint = json['idServicePoint'];
    referenceNumber = json['referenceNumber'];
    subscriptionId = json['subscriptionId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idZyosUser'] = idZyosUser;
    data['idServicePoint'] = idServicePoint;
    data['referenceNumber'] = referenceNumber;
    data['subscriptionId'] = subscriptionId;
    return data;
  }
}
