import 'dart:convert';

class PaymentMethodsResponse {
  bool? success;
  Info? info;
  List<PaymentMethod>? data;

  PaymentMethodsResponse({this.success, this.info, this.data});

  PaymentMethodsResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    if (json['data'] != null) {
      data = <PaymentMethod>[];
      json['data'].forEach((v) {
        data?.add(PaymentMethod.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class PaymentMethod {
  int? id;
  int? idPaymentIntegration;
  int? methodOrder;
  String? name;
  String? code;
  String? paymentGuide;
  String? description;
  String? logoUrl;
  PaymentCommission? paymentCommission;
  String? setting;
  PaymentIntegration? paymentIntegration;
  EnterpriseIntegrationPaymentMethodType?
      // ignore: prefer-correct-identifier-length
      enterpriseIntegrationPaymentMethodType;

  PaymentMethod({
    this.id,
    this.idPaymentIntegration,
    this.methodOrder,
    this.name,
    this.code,
    this.paymentGuide,
    this.description,
    this.logoUrl,
    this.paymentCommission,
    this.setting,
    this.paymentIntegration,
    this.enterpriseIntegrationPaymentMethodType,
  });

  // ignore: long-method
  PaymentMethod.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idPaymentIntegration = json['idPaymentIntegration'];
    methodOrder = json['methodOrder'];
    name = json['name'];
    code = json['code'];
    paymentGuide = json['paymentGuide'];
    description = json['description'];
    logoUrl = json['logoUrl'];

    setting = json['setting'];
    paymentCommission = json['paymentCommission'] != null
        ? PaymentCommission.fromJson(jsonDecode(json['paymentCommission']))
        : null;
    paymentIntegration = json['paymentIntegration'] != null
        ? PaymentIntegration.fromJson(json['paymentIntegration'])
        : null;
    enterpriseIntegrationPaymentMethodType =
        json['enterpriseIntegrationPaymentMethodType'] != null
            ? EnterpriseIntegrationPaymentMethodType.fromJson(
                json['enterpriseIntegrationPaymentMethodType'],
              )
            : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idPaymentIntegration'] = idPaymentIntegration;
    data['methodOrder'] = methodOrder;
    data['name'] = name;
    data['code'] = code;
    data['paymentGuide'] = paymentGuide;
    data['description'] = description;
    data['logoUrl'] = logoUrl;
    data['paymentCommission'] = paymentCommission;
    data['setting'] = setting;
    if (paymentIntegration != null) {
      data['paymentIntegration'] = paymentIntegration?.toJson();
    }
    if (enterpriseIntegrationPaymentMethodType != null) {
      data['enterpriseIntegrationPaymentMethodType'] =
          enterpriseIntegrationPaymentMethodType?.toJson();
    }
    return data;
  }
}

class PaymentCommission {
  List<PaymentCommissionList>? paymentCommissionList;

  PaymentCommission({this.paymentCommissionList});

  PaymentCommission.fromJson(Map<String, dynamic> json) {
    if (json['paymentCommissionList'] != null) {
      paymentCommissionList = <PaymentCommissionList>[];
      json['paymentCommissionList'].forEach((v) {
        paymentCommissionList?.add(PaymentCommissionList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (paymentCommissionList != null) {
      data['paymentCommissionList'] =
          paymentCommissionList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class PaymentCommissionList {
  int? idCommissionCriteria;
  String? concept;
  num? value;
  int? state;

  PaymentCommissionList({
    this.idCommissionCriteria,
    this.concept,
    this.value,
    this.state,
  });

  PaymentCommissionList.fromJson(Map<String, dynamic> json) {
    idCommissionCriteria = json['idCommissionCriteria'];
    concept = json['concept'];
    value = json['value'];
    state = json['state'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idCommissionCriteria'] = idCommissionCriteria;
    data['concept'] = concept;
    data['value'] = value;
    data['state'] = state;
    return data;
  }
}

class PaymentIntegration {
  int? id;
  String? name;
  String? logoUrl;
  int? decimalRound;

  PaymentIntegration({this.id, this.name, this.logoUrl, this.decimalRound});

  PaymentIntegration.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    logoUrl = json['logoUrl'];
    decimalRound = json['decimalRound'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['logoUrl'] = logoUrl;
    data['decimalRound'] = decimalRound;
    return data;
  }
}

// ignore: prefer-correct-type-name
class EnterpriseIntegrationPaymentMethodType {
  int? id;
  int? idEnterprise;
  bool? active;
  bool? acceptPayCommission;
  String? settings;

  EnterpriseIntegrationPaymentMethodType({
    this.id,
    this.idEnterprise,
    this.active,
    this.acceptPayCommission,
    this.settings,
  });

  EnterpriseIntegrationPaymentMethodType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idEnterprise = json['idEnterprise'];
    active = json['active'];
    acceptPayCommission = json['acceptPayCommission'];
    settings = json['settings'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idEnterprise'] = idEnterprise;
    data['active'] = active;
    data['acceptPayCommission'] = acceptPayCommission;
    data['settings'] = settings;
    return data;
  }
}
