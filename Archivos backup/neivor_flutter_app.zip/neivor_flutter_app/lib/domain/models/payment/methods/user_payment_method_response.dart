class UserPaymentMethodResponse {
  int? id;
  double? dateCreation;
  int? state;
  String? name;
  int? idZyosUser;
  int? idPaymentMethodType;
  String? codTransaction;
  String? activationState;
  int? idEnterprise;
  Payer? payer;
  String? subscriptionId;

  UserPaymentMethodResponse({
    this.id,
    this.dateCreation,
    this.state,
    this.name,
    this.idZyosUser,
    this.idPaymentMethodType,
    this.codTransaction,
    this.activationState,
    this.idEnterprise,
    this.payer,
    this.subscriptionId,
  });

  UserPaymentMethodResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    state = json['state'];
    name = json['name'];
    idZyosUser = json['idZyosUser'];
    idPaymentMethodType = json['idPaymentMethodType'];
    codTransaction = json['codTransaction'];
    activationState = json['activationState'];
    idEnterprise = json['idEnterprise'];
    payer = json['payer'] != null ? Payer.fromJson(json['payer']) : null;
    subscriptionId = json['subscriptionId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['state'] = state;
    data['name'] = name;
    data['idZyosUser'] = idZyosUser;
    data['idPaymentMethodType'] = idPaymentMethodType;
    data['codTransaction'] = codTransaction;
    data['activationState'] = activationState;
    data['idEnterprise'] = idEnterprise;
    if (payer != null) {
      data['payer'] = payer?.toJson();
    }
    data['subscriptionId'] = subscriptionId;
    return data;
  }
}

class Payer {
  String? documentNumber;
  String? name;
  String? lastname;
  String? contactPhone;

  Payer({this.documentNumber, this.name, this.lastname, this.contactPhone});

  Payer.fromJson(Map<String, dynamic> json) {
    documentNumber = json['documentNumber'];
    name = json['name'];
    lastname = json['lastname'];
    contactPhone = json['contactPhone'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['documentNumber'] = documentNumber;
    data['name'] = name;
    data['lastname'] = lastname;
    data['contactPhone'] = contactPhone;
    return data;
  }
}
