import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class ConciliationRequest {
  Enterprise? enterprise;
  List<int>? idServicePointList;

  ConciliationRequest({this.enterprise, this.idServicePointList});

  ConciliationRequest.fromJson(Map<String, dynamic> json) {
    enterprise = json['enterprise'] != null
        ? Enterprise.fromJson(json['enterprise'])
        : null;
    idServicePointList = json['idServicePointList'].cast<int>();
  }

  /// Obtain the propper ConciliationRequest according to user role
  ///
  /// Returns:
  /// A ConciliationRequest object

  ConciliationRequest getConciliationRequestByRole() {
    return UserUtils().isAdminUser() == false
        ? ConciliationRequest(
            enterprise: Enterprise(id: UserUtils.currentEnterprise?.id),
            idServicePointList: UserUtils.currentUser?.getServicePointList(),
          )
        : ConciliationRequest(
            enterprise: Enterprise(id: UserUtils.currentEnterprise?.id),
            idServicePointList: [],
          );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (enterprise != null) {
      data['enterprise'] = enterprise?.toJson();
    }
    data['idServicePointList'] = idServicePointList;
    return data;
  }
}

class Enterprise {
  int? id;

  Enterprise({this.id});

  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}
