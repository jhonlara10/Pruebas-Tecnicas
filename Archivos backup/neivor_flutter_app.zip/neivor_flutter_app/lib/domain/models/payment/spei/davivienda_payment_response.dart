class DaviviendaPaymentResponse {
  PaymentOperation? paymentOperation;
  bool? success;

  DaviviendaPaymentResponse({this.paymentOperation, this.success});

  DaviviendaPaymentResponse.fromJson(Map<String, dynamic> json) {
    paymentOperation = json['paymentOperation'] != null
        ? PaymentOperation.fromJson(json['paymentOperation'])
        : null;
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (paymentOperation != null) {
      data['paymentOperation'] = paymentOperation?.toJson();
    }
    data['success'] = success;
    return data;
  }
}

class PaymentOperation {
  bool? successPay;
  bool? successAsyncRegister;
  bool? requirePayValidate;
  bool? formInscription;
  bool? redirect;

  PaymentOperation({
    this.successPay,
    this.successAsyncRegister,
    this.requirePayValidate,
    this.formInscription,
    this.redirect,
  });

  PaymentOperation.fromJson(Map<String, dynamic> json) {
    successPay = json['successPay'];
    successAsyncRegister = json['successAsyncRegister'];
    requirePayValidate = json['requirePayValidate'];
    formInscription = json['formInscription'];
    redirect = json['redirect'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successPay'] = successPay;
    data['successAsyncRegister'] = successAsyncRegister;
    data['requirePayValidate'] = requirePayValidate;
    data['formInscription'] = formInscription;
    data['redirect'] = redirect;
    return data;
  }
}
