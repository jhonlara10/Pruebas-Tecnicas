class HeaderAdminResponse {
  // ignore: prefer-correct-identifier-length
  double? totalValueMaintenanceMonth;
  double? totalValueAdvanceMonth;
  double? totalValueOverdueMonth;
  double? totalValueOtherIncome;
  double? balanceNoUsedMonth;
  double? totalValueWithoutIdList;
  double? totalAdminPaymentMonth;
  double? totalValueIncome;

  HeaderAdminResponse({
    this.totalValueMaintenanceMonth,
    this.totalValueAdvanceMonth,
    this.totalValueOverdueMonth,
    this.totalValueOtherIncome,
    this.balanceNoUsedMonth,
    this.totalValueWithoutIdList,
    this.totalAdminPaymentMonth,
    this.totalValueIncome,
  });

  HeaderAdminResponse.fromJson(Map<String, dynamic> json) {
    totalValueMaintenanceMonth = json['totalValueMaintenanceMonth'];
    totalValueAdvanceMonth = json['totalValueAdvanceMonth'];
    totalValueOverdueMonth = json['totalValueOverdueMonth'];
    totalValueOtherIncome = json['totalValueOtherIncome'];
    balanceNoUsedMonth = json['balanceNoUsedMonth'];
    totalValueWithoutIdList = json['totalValueWithoutIdList'];
    totalAdminPaymentMonth = json['totalAdminPaymentMonth'];
    totalValueIncome = json['totalValueIncome'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['totalValueMaintenanceMonth'] = totalValueMaintenanceMonth;
    data['totalValueAdvanceMonth'] = totalValueAdvanceMonth;
    data['totalValueOverdueMonth'] = totalValueOverdueMonth;
    data['totalValueOtherIncome'] = totalValueOtherIncome;
    data['balanceNoUsedMonth'] = balanceNoUsedMonth;
    data['totalValueWithoutIdList'] = totalValueWithoutIdList;
    data['totalAdminPaymentMonth'] = totalAdminPaymentMonth;
    data['totalValueIncome'] = totalValueIncome;
    return data;
  }
}
