class AssociatePaymentResponse {
  bool? success;
  Info? info;
  Data? data;

  AssociatePaymentResponse({this.success, this.info, this.data});

  AssociatePaymentResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  String? dateCreation;
  String? hourCreation;
  String? dateChange;
  String? hourChange;
  String? userChange;
  int? state;
  String? datePayed;
  String? hourPayed;
  String? cycleDate;
  int? idEnterprise;
  int? idPaymentType;
  int? idServicePoint;
  PaymentType? paymentType;
  String? observation;
  String? invoiceReference;
  double? value;
  double? initialValue;
  String? payReference;
  int? balanceNumber;
  List<PaymentInvoiceValueList>? paymentInvoiceValueList;
  String? paymentTypeName;
  String? bankAccountNumber;
  InvoiceServiceType? invoiceServiceType;
  BankAccount? bankAccount;
  int? idBalanceState;
  bool? fatherBalance;

  Data({
    this.id,
    this.dateCreation,
    this.hourCreation,
    this.dateChange,
    this.hourChange,
    this.userChange,
    this.state,
    this.datePayed,
    this.hourPayed,
    this.cycleDate,
    this.idEnterprise,
    this.idPaymentType,
    this.idServicePoint,
    this.paymentType,
    this.observation,
    this.invoiceReference,
    this.value,
    this.initialValue,
    this.payReference,
    this.balanceNumber,
    this.paymentInvoiceValueList,
    this.paymentTypeName,
    this.bankAccountNumber,
    this.invoiceServiceType,
    this.bankAccount,
    this.idBalanceState,
    this.fatherBalance,
  });

  // ignore: long-method
  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    hourCreation = json['hourCreation'];
    dateChange = json['dateChange'];
    hourChange = json['hourChange'];
    userChange = json['userChange'];
    state = json['state'];
    datePayed = json['datePayed'];
    hourPayed = json['hourPayed'];
    cycleDate = json['cycleDate'];
    idEnterprise = json['idEnterprise'];
    idPaymentType = json['idPaymentType'];
    idServicePoint = json['idServicePoint'];
    paymentType = json['paymentType'] != null
        ? PaymentType.fromJson(json['paymentType'])
        : null;
    observation = json['observation'];
    invoiceReference = json['invoiceReference'];
    value = json['value'];
    initialValue = json['initialValue'];
    payReference = json['payReference'];
    balanceNumber = json['balanceNumber'];
    if (json['paymentInvoiceValueList'] != null) {
      paymentInvoiceValueList = <PaymentInvoiceValueList>[];
      json['paymentInvoiceValueList'].forEach((v) {
        paymentInvoiceValueList?.add(PaymentInvoiceValueList.fromJson(v));
      });
    }
    paymentTypeName = json['paymentTypeName'];
    bankAccountNumber = json['bankAccountNumber'];
    invoiceServiceType = json['invoiceServiceType'] != null
        ? InvoiceServiceType.fromJson(json['invoiceServiceType'])
        : null;
    bankAccount = json['bankAccount'] != null
        ? BankAccount.fromJson(json['bankAccount'])
        : null;
    idBalanceState = json['idBalanceState'];
    fatherBalance = json['fatherBalance'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['hourCreation'] = hourCreation;
    data['dateChange'] = dateChange;
    data['hourChange'] = hourChange;
    data['userChange'] = userChange;
    data['state'] = state;
    data['datePayed'] = datePayed;
    data['hourPayed'] = hourPayed;
    data['cycleDate'] = cycleDate;
    data['idEnterprise'] = idEnterprise;
    data['idPaymentType'] = idPaymentType;
    data['idServicePoint'] = idServicePoint;
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['observation'] = observation;
    data['invoiceReference'] = invoiceReference;
    data['value'] = value;
    data['initialValue'] = initialValue;
    data['payReference'] = payReference;
    data['balanceNumber'] = balanceNumber;
    if (paymentInvoiceValueList != null) {
      data['paymentInvoiceValueList'] =
          paymentInvoiceValueList?.map((v) => v.toJson()).toList();
    }
    data['paymentTypeName'] = paymentTypeName;
    data['bankAccountNumber'] = bankAccountNumber;
    if (invoiceServiceType != null) {
      data['invoiceServiceType'] = invoiceServiceType?.toJson();
    }
    if (bankAccount != null) {
      data['bankAccount'] = bankAccount?.toJson();
    }
    data['idBalanceState'] = idBalanceState;
    data['fatherBalance'] = fatherBalance;
    return data;
  }
}

class PaymentType {
  int? id;
  String? name;

  PaymentType({this.id, this.name});

  PaymentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class PaymentInvoiceValueList {
  int? idInvoice;
  double? payedValue;

  PaymentInvoiceValueList({this.idInvoice, this.payedValue});

  PaymentInvoiceValueList.fromJson(Map<String, dynamic> json) {
    idInvoice = json['idInvoice'];
    payedValue = json['payedValue'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idInvoice'] = idInvoice;
    data['payedValue'] = payedValue;
    return data;
  }
}

class InvoiceServiceType {
  InvoiceServiceType();

  InvoiceServiceType.fromJson(Map<String, dynamic> json);

  Map<String, dynamic> toJson() {
    return <String, dynamic>{};
  }
}

class BankAccount {
  int? id;
  String? accountNumber;

  BankAccount({this.id, this.accountNumber});

  BankAccount.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    accountNumber = json['accountNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['accountNumber'] = accountNumber;
    return data;
  }
}
