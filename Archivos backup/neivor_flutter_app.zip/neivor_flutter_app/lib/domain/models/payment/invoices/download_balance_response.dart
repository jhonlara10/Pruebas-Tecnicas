class DownloadBalanceResponse {
  bool? success;
  Info? info;
  Data? data;

  DownloadBalanceResponse({this.success, this.info, this.data});

  DownloadBalanceResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? idEnterprise;
  int? millisDelay;
  bool? document;
  String? url;

  Data({this.idEnterprise, this.millisDelay, this.document, this.url});

  Data.fromJson(Map<String, dynamic> json) {
    idEnterprise = json['idEnterprise'];
    millisDelay = json['millisDelay'];
    document = json['document'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEnterprise'] = idEnterprise;
    data['millisDelay'] = millisDelay;
    data['document'] = document;
    data['url'] = url;
    return data;
  }
}
