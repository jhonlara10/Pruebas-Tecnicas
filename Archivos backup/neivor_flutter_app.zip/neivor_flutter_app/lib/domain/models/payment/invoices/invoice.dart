class Invoice {
  int? id;
  String? dateCreation;
  double? initialDebt;
  double? chargeInterest;
  int? idServicePoint;
  int? idEnterprise;
  String? descriptionService;
  int? idInvoiceType;
  int? invoiceNumber;
  String? reference;
  String? initialDate;
  String? expirationDate;
  String? discountDate;
  double? discountValue;
  double? value;
  double? initialValue;
  double? fineValue;
  double? paidValue;
  double? paymentSumValue;
  int? idInvoiceState;
  InvoiceState? invoiceState;
  InvoiceServiceType? invoiceServiceType;
  int? calculateFine;
  int? idRecordPayment;
  int? manuallyModified;
  double? valueToPay;
  int? idDiscountDataLog;
  DiscountDataLog? discountDataLog;
  double? debt;
  List<DiscountDataList>? discountDataList;
  int? condonedPay;
  int? idSanctionDataLog;
  String? sanctionDate;
  List<SanctionDataLog>? sanctionDataLog;
  double? sanctionValueToShow;
  int? totalRows;
  String? sanctionDataLogJson;
  bool? haveBalanceAnnulled;

  Invoice({
    this.id,
    this.dateCreation,
    this.initialDebt,
    this.chargeInterest,
    this.idServicePoint,
    this.idEnterprise,
    this.descriptionService,
    this.idInvoiceType,
    this.invoiceNumber,
    this.reference,
    this.initialDate,
    this.expirationDate,
    this.discountDate,
    this.discountValue,
    this.value,
    this.initialValue,
    this.fineValue,
    this.paidValue,
    this.paymentSumValue,
    this.idInvoiceState,
    this.invoiceState,
    this.invoiceServiceType,
    this.calculateFine,
    this.idRecordPayment,
    this.manuallyModified,
    this.valueToPay,
    this.idDiscountDataLog,
    this.discountDataLog,
    this.debt,
    this.discountDataList,
    this.condonedPay,
    this.idSanctionDataLog,
    this.sanctionDate,
    this.sanctionDataLog,
    this.sanctionValueToShow,
    this.totalRows,
    this.sanctionDataLogJson,
    this.haveBalanceAnnulled,
  });

  // ignore: long-method
  Invoice.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    initialDebt = json['initialDebt'];
    chargeInterest = json['chargeInterest'];
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    descriptionService = json['descriptionService'];
    idInvoiceType = json['idInvoiceType'];
    invoiceNumber = json['invoiceNumber'];
    reference = json['reference'];
    initialDate = json['initialDate'];
    expirationDate = json['expirationDate'];
    discountDate = json['discountDate'];
    discountValue = json['discountValue'];
    value = json['value'];
    initialValue = json['initialValue'];
    fineValue = json['fineValue'];
    paidValue = json['paidValue'];
    paymentSumValue = json['paymentSumValue'];
    idInvoiceState = json['idInvoiceState'];
    invoiceState = json['invoiceState'] != null
        ? InvoiceState.fromJson(json['invoiceState'])
        : null;
    invoiceServiceType = json['invoiceServiceType'] != null
        ? InvoiceServiceType.fromJson(json['invoiceServiceType'])
        : null;
    calculateFine = json['calculateFine'];
    idRecordPayment = json['idRecordPayment'];
    manuallyModified = json['manuallyModified'];
    valueToPay = json['valueToPay'];
    idDiscountDataLog = json['idDiscountDataLog'];
    discountDataLog = json['discountDataLog'] != null
        ? DiscountDataLog.fromJson(json['discountDataLog'])
        : null;
    debt = json['debt'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
    condonedPay = json['condonedPay'];
    idSanctionDataLog = json['idSanctionDataLog'];
    sanctionDate = json['sanctionDate'];
    if (json['sanctionDataLog'] != null) {
      sanctionDataLog = <SanctionDataLog>[];
      json['sanctionDataLog'].forEach((v) {
        sanctionDataLog?.add(SanctionDataLog.fromJson(v));
      });
    }
    sanctionValueToShow = json['sanctionValueToShow'];
    totalRows = json['totalRows'];
    sanctionDataLogJson = json['sanctionDataLogJson'];
    haveBalanceAnnulled = json['haveBalanceAnnulled'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['initialDebt'] = initialDebt;
    data['chargeInterest'] = chargeInterest;
    data['idServicePoint'] = idServicePoint;
    data['idEnterprise'] = idEnterprise;
    data['descriptionService'] = descriptionService;
    data['idInvoiceType'] = idInvoiceType;
    data['invoiceNumber'] = invoiceNumber;
    data['reference'] = reference;
    data['initialDate'] = initialDate;
    data['expirationDate'] = expirationDate;
    data['discountDate'] = discountDate;
    data['discountValue'] = discountValue;
    data['value'] = value;
    data['initialValue'] = initialValue;
    data['fineValue'] = fineValue;
    data['paidValue'] = paidValue;
    data['paymentSumValue'] = paymentSumValue;
    data['idInvoiceState'] = idInvoiceState;
    if (invoiceState != null) {
      data['invoiceState'] = invoiceState?.toJson();
    }
    if (invoiceServiceType != null) {
      data['invoiceServiceType'] = invoiceServiceType?.toJson();
    }
    data['calculateFine'] = calculateFine;
    data['idRecordPayment'] = idRecordPayment;
    data['manuallyModified'] = manuallyModified;
    data['valueToPay'] = valueToPay;
    data['idDiscountDataLog'] = idDiscountDataLog;
    if (discountDataLog != null) {
      data['discountDataLog'] = discountDataLog?.toJson();
    }
    data['debt'] = debt;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    data['condonedPay'] = condonedPay;
    data['idSanctionDataLog'] = idSanctionDataLog;
    data['sanctionDate'] = sanctionDate;
    if (sanctionDataLog != null) {
      data['sanctionDataLog'] =
          sanctionDataLog?.map((v) => v.toJson()).toList();
    }
    data['sanctionValueToShow'] = sanctionValueToShow;
    data['totalRows'] = totalRows;
    data['sanctionDataLogJson'] = sanctionDataLogJson;
    data['haveBalanceAnnulled'] = haveBalanceAnnulled;
    return data;
  }
}

class InvoiceState {
  int? id;
  String? name;

  InvoiceState({this.id, this.name});

  InvoiceState.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class InvoiceServiceType {
  int? orderPay;

  InvoiceServiceType({this.orderPay});

  InvoiceServiceType.fromJson(Map<String, dynamic> json) {
    orderPay = json['orderPay'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['orderPay'] = orderPay;
    return data;
  }
}

class DiscountDataLog {
  int? id;
  String? discountData;
  List<DiscountDataList>? discountDataList;

  DiscountDataLog({this.id, this.discountData, this.discountDataList});

  DiscountDataLog.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    discountData = json['discountData'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['discountData'] = discountData;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DiscountDataList {
  double? discount;
  double? discountCalculated;
  int? idCriteriaDiscount;
  int? maxDateOfDiscount;
  bool? permanentDiscount;
  bool? roundingBeforeDiscount;
  bool? roundingValue;

  DiscountDataList({
    this.permanentDiscount,
    this.roundingValue,
    this.roundingBeforeDiscount,
    this.discount,
    this.idCriteriaDiscount,
    this.maxDateOfDiscount,
  });

  DiscountDataList.fromJson(Map<String, dynamic> json) {
    permanentDiscount = json['permanentDiscount'];
    roundingValue = json['roundingValue'];
    roundingBeforeDiscount = json['roundingBeforeDiscount'];
    discount = json['discount'];
    idCriteriaDiscount = json['idCriteriaDiscount'];
    maxDateOfDiscount = json['maxDateOfDiscount'];
    discountCalculated = json['discountCalculated'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['permanentDiscount'] = permanentDiscount;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeDiscount'] = roundingBeforeDiscount;
    data['discount'] = discount;
    data['idCriteriaDiscount'] = idCriteriaDiscount;
    data['maxDateOfDiscount'] = maxDateOfDiscount;
    data['discountCalculated'] = discountCalculated;
    return data;
  }
}

class SanctionDataLog {
  double? sanction;
  int? idCriteriaSanction;
  int? minDateOfSanction;
  bool? permanentSanction;
  bool? roundingValue;
  bool? roundingBeforeSanction;

  SanctionDataLog({
    this.sanction,
    this.idCriteriaSanction,
    this.minDateOfSanction,
    this.permanentSanction,
    this.roundingValue,
    this.roundingBeforeSanction,
  });

  SanctionDataLog.fromJson(Map<String, dynamic> json) {
    sanction = json['sanction'];
    idCriteriaSanction = json['idCriteriaSanction'];
    minDateOfSanction = json['minDateOfSanction'];
    permanentSanction = json['permanentSanction'];
    roundingValue = json['roundingValue'];
    roundingBeforeSanction = json['roundingBeforeSanction'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sanction'] = sanction;
    data['idCriteriaSanction'] = idCriteriaSanction;
    data['minDateOfSanction'] = minDateOfSanction;
    data['permanentSanction'] = permanentSanction;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeSanction'] = roundingBeforeSanction;
    return data;
  }
}
