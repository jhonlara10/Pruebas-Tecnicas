import 'package:neivor_flutter_app/data/repository/utils/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class InvoicesRequest {
  List<int>? idInvoiceStateList;
  List<int>? idServicePointList;
  Enterprise? enterprise;
  bool? orderDesc = true;

  InvoicesRequest({
    this.idInvoiceStateList,
    this.idServicePointList,
    this.enterprise,
  });

  // ignore: long-method
  InvoicesRequest getInvoiceRequest(bool isHistory, int? servicePointId) {
    return InvoicesRequest(
      idInvoiceStateList: !isHistory
          ? [
              Constants.invoicePending,
              Constants.invoiceOverdue,
              Constants.invoicePartialPayment,
              Constants.invoiceProcess,
            ]
          : [
              Constants.invoicePayed,
            ],
      idServicePointList: servicePointId == null
          ? UserUtils.currentUser?.getServicePointList() ?? []
          : [servicePointId],
      enterprise: Enterprise(
        id: UserUtils.currentEnterprise?.id,
      ),
    );
  }

  InvoicesRequest.fromJson(Map<String, dynamic> json) {
    idInvoiceStateList = json['idInvoiceStateList'].cast<int>();
    idServicePointList = json['idServicePointList'].cast<int>();
    enterprise = json['enterprise'] != null
        ? Enterprise.fromJson(json['enterprise'])
        : null;
    orderDesc = json['orderDesc'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idInvoiceStateList'] = idInvoiceStateList;
    data['idServicePointList'] = idServicePointList;
    if (enterprise != null) {
      data['enterprise'] = enterprise?.toJson();
    }
    data['orderDesc'] = orderDesc;
    return data;
  }
}

class Enterprise {
  int? id;

  Enterprise({this.id});

  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}
