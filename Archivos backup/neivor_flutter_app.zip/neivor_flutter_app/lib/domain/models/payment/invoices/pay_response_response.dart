class PayResponseResponse {
  // ignore: prefer-correct-identifier-length
  int? idDaviviendaPaymentQuery;
  int? idBalance;
  int? idEnterprise;
  int? idServicePoint;
  int? idPaymentIntegration;
  String? date;
  InvoiceResponse? invoice;
  String? descRespuesta;
  double? payedValue;
  double? transactionCost;
  String? dpqTransaction;
  String? idTransaction;
  int? state;
  PaymentMethodType? paymentMethodType;
  PaymentMethod? paymentMethod;
  int? idPaymentType;
  List<PaymentList>? paymentList;
  PaymentType? paymentType;
  int? transactionType;
  PaymentError? paymentError;

  PayResponseResponse({
    this.idDaviviendaPaymentQuery,
    this.idBalance,
    this.idEnterprise,
    this.idServicePoint,
    this.idPaymentIntegration,
    this.date,
    this.invoice,
    this.descRespuesta,
    this.payedValue,
    this.transactionCost,
    this.dpqTransaction,
    this.idTransaction,
    this.state,
    this.paymentMethodType,
    this.paymentMethod,
    this.idPaymentType,
    this.paymentList,
    this.paymentType,
    this.transactionType,
    this.paymentError,
  });

  // ignore: long-method
  PayResponseResponse.fromJson(Map<String, dynamic> json) {
    idDaviviendaPaymentQuery = json['idDaviviendaPaymentQuery'];
    idBalance = json['idBalance'];
    idEnterprise = json['idEnterprise'];
    idServicePoint = json['idServicePoint'];
    idPaymentIntegration = json['idPaymentIntegration'];
    date = json['date'];
    invoice = json['invoice'] != null
        ? InvoiceResponse.fromJson(json['invoice'])
        : null;
    descRespuesta = json['descRespuesta'];
    payedValue = json['payedValue'];
    transactionCost = json['transactionCost'];
    dpqTransaction = json['dpqTransaction'];
    idTransaction = json['idTransaction'];
    state = json['state'];
    paymentMethodType = json['paymentMethodType'] != null
        ? PaymentMethodType.fromJson(json['paymentMethodType'])
        : null;
    paymentMethod = json['paymentMethod'] != null
        ? PaymentMethod.fromJson(json['paymentMethod'])
        : null;
    idPaymentType = json['idPaymentType'];
    if (json['paymentList'] != null) {
      paymentList = <PaymentList>[];
      json['paymentList'].forEach((v) {
        paymentList?.add(PaymentList.fromJson(v));
      });
    }
    paymentType = json['paymentType'] != null
        ? PaymentType.fromJson(json['paymentType'])
        : null;
    transactionType = json['transactionType'];
    paymentError = json['paymentError'] != null
        ? PaymentError.fromJson(json['paymentError'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idDaviviendaPaymentQuery'] = idDaviviendaPaymentQuery;
    data['idBalance'] = idBalance;
    data['idEnterprise'] = idEnterprise;
    data['idServicePoint'] = idServicePoint;
    data['idPaymentIntegration'] = idPaymentIntegration;
    data['date'] = date;
    if (invoice != null) {
      data['invoice'] = invoice?.toJson();
    }
    data['descRespuesta'] = descRespuesta;
    data['payedValue'] = payedValue;
    data['transactionCost'] = transactionCost;
    data['dpqTransaction'] = dpqTransaction;
    data['idTransaction'] = idTransaction;
    data['state'] = state;
    if (paymentMethodType != null) {
      data['paymentMethodType'] = paymentMethodType?.toJson();
    }
    if (paymentMethod != null) {
      data['paymentMethod'] = paymentMethod?.toJson();
    }
    data['idPaymentType'] = idPaymentType;
    if (paymentList != null) {
      data['paymentList'] = paymentList?.map((v) => v.toJson()).toList();
    }
    if (paymentType != null) {
      data['paymentType'] = paymentType?.toJson();
    }
    data['transactionType'] = transactionType;
    if (paymentError != null) {
      data['error'] = paymentError?.toJson();
    }
    return data;
  }
}

class PaymentError {
  String? message;

  PaymentError({this.message});

  PaymentError.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class InvoiceResponse {
  String? reference;
  double? paidValue;
  num? calculateFine;
  num? manuallyModified;
  List<DiscountDataList>? discountDataList;
  bool? haveBalanceAnnulled;

  InvoiceResponse({
    this.reference,
    this.paidValue,
    this.calculateFine,
    this.manuallyModified,
    this.discountDataList,
    this.haveBalanceAnnulled,
  });

  InvoiceResponse.fromJson(Map<String, dynamic> json) {
    reference = json['reference'];
    paidValue = json['paidValue'];
    calculateFine = json['calculateFine'];
    manuallyModified = json['manuallyModified'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
    haveBalanceAnnulled = json['haveBalanceAnnulled'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['reference'] = reference;
    data['paidValue'] = paidValue;
    data['calculateFine'] = calculateFine;
    data['manuallyModified'] = manuallyModified;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    data['haveBalanceAnnulled'] = haveBalanceAnnulled;
    return data;
  }
}

class DiscountDataList {
  bool? permanentDiscount;
  bool? roundingValue;
  bool? roundingBeforeDiscount;
  double? discount;
  int? idCriteriaDiscount;
  int? maxDateOfDiscount;

  DiscountDataList({
    this.permanentDiscount,
    this.roundingValue,
    this.roundingBeforeDiscount,
    this.discount,
    this.idCriteriaDiscount,
    this.maxDateOfDiscount,
  });

  DiscountDataList.fromJson(Map<String, dynamic> json) {
    permanentDiscount = json['permanentDiscount'];
    roundingValue = json['roundingValue'];
    roundingBeforeDiscount = json['roundingBeforeDiscount'];
    discount = json['discount'];
    idCriteriaDiscount = json['idCriteriaDiscount'];
    maxDateOfDiscount = json['maxDateOfDiscount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['permanentDiscount'] = permanentDiscount;
    data['roundingValue'] = roundingValue;
    data['roundingBeforeDiscount'] = roundingBeforeDiscount;
    data['discount'] = discount;
    data['idCriteriaDiscount'] = idCriteriaDiscount;
    data['maxDateOfDiscount'] = maxDateOfDiscount;
    return data;
  }
}

class PaymentMethodType {
  String? name;

  PaymentMethodType({this.name});

  PaymentMethodType.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    return data;
  }
}

class PaymentMethod {
  String? name;
  CreditCard? creditCard;

  PaymentMethod({this.name, this.creditCard});

  PaymentMethod.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    creditCard = json['creditCard'] != null
        ? CreditCard.fromJson(json['creditCard'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    if (creditCard != null) {
      data['creditCard'] = creditCard?.toJson();
    }
    return data;
  }
}

class CreditCard {
  String? cardNumber;
  int? cvv;
  String? franchise;
  int? installment;
  bool? tokenize;
  bool? dynamicCvv;
  bool? active;

  CreditCard({
    this.cardNumber,
    this.cvv,
    this.franchise,
    this.installment,
    this.tokenize,
    this.dynamicCvv,
    this.active,
  });

  CreditCard.fromJson(Map<String, dynamic> json) {
    cardNumber = json['cardNumber'];
    cvv = json['cvv'];
    franchise = json['franchise'];
    installment = json['installment'];
    tokenize = json['tokenize'];
    dynamicCvv = json['dynamicCvv'];
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cardNumber'] = cardNumber;
    data['cvv'] = cvv;
    data['franchise'] = franchise;
    data['installment'] = installment;
    data['tokenize'] = tokenize;
    data['dynamicCvv'] = dynamicCvv;
    data['active'] = active;
    return data;
  }
}

class PaymentList {
  double? value;
  InvoiceAlt? invoice;

  PaymentList({this.value, this.invoice});

  PaymentList.fromJson(Map<String, dynamic> json) {
    value = json['value'];
    invoice =
        json['invoice'] != null ? InvoiceAlt.fromJson(json['invoice']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['value'] = value;
    if (invoice != null) {
      data['invoice'] = invoice?.toJson();
    }
    return data;
  }
}

class InvoiceAlt {
  String? descriptionService;
  double? paidValue;
  num? calculateFine;
  num? manuallyModified;
  List<DiscountDataList>? discountDataList;
  bool? haveBalanceAnnulled;

  InvoiceAlt({
    this.descriptionService,
    this.paidValue,
    this.calculateFine,
    this.manuallyModified,
    this.discountDataList,
    this.haveBalanceAnnulled,
  });

  InvoiceAlt.fromJson(Map<String, dynamic> json) {
    descriptionService = json['descriptionService'];
    paidValue = json['paidValue'];
    calculateFine = json['calculateFine'];
    manuallyModified = json['manuallyModified'];
    if (json['discountDataList'] != null) {
      discountDataList = <DiscountDataList>[];
      json['discountDataList'].forEach((v) {
        discountDataList?.add(DiscountDataList.fromJson(v));
      });
    }
    haveBalanceAnnulled = json['haveBalanceAnnulled'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['descriptionService'] = descriptionService;
    data['paidValue'] = paidValue;
    data['calculateFine'] = calculateFine;
    data['manuallyModified'] = manuallyModified;
    if (discountDataList != null) {
      data['discountDataList'] =
          discountDataList?.map((v) => v.toJson()).toList();
    }
    data['haveBalanceAnnulled'] = haveBalanceAnnulled;
    return data;
  }
}

class PaymentType {
  int? id;

  PaymentType({this.id});

  PaymentType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}
