import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class ApproveBookingBody {
  int? id;
  int? idEnterprise;
  String? enterpriseName;
  int? idServicePointRequest;
  String? title;
  String? eventStartString;
  String? eventEndString;
  int? idUserRequest;
  int? userChange;
  String? costEvent;

  ApproveBookingBody({
    this.id,
    this.idEnterprise,
    this.enterpriseName,
    this.idServicePointRequest,
    this.title,
    this.eventStartString,
    this.eventEndString,
    this.idUserRequest,
    this.userChange,
    this.costEvent,
  });

  factory ApproveBookingBody.defaultValues() => ApproveBookingBody(
        idEnterprise: UserUtils.currentEnterprise?.id,
        enterpriseName: UserUtils.currentEnterprise?.name,
        idServicePointRequest: UserUtils.currentServicePoint?.id,
        userChange: UserUtils.currentUser?.id,
        costEvent: '0',
      );

  ApproveBookingBody.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idEnterprise = json['idEnterprise'];
    enterpriseName = json['enterpriseName'];
    idServicePointRequest = json['idServicePointRequest'];
    title = json['title'];
    eventStartString = json['eventStartString'];
    eventEndString = json['eventEndString'];
    idUserRequest = json['idUserRequest'];
    userChange = json['userChange'];
    costEvent = json['costEvent'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idEnterprise'] = idEnterprise;
    data['enterpriseName'] = enterpriseName;
    data['idServicePointRequest'] = idServicePointRequest;
    data['title'] = title;
    data['eventStartString'] = eventStartString;
    data['eventEndString'] = eventEndString;
    data['idUserRequest'] = idUserRequest;
    data['userChange'] = userChange;
    data['costEvent'] = costEvent;
    return data;
  }
}
