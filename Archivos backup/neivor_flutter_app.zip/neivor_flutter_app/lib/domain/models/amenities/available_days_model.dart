class AvailableDaysModel {
  bool? success;
  AvailableDaysData? data;

  AvailableDaysModel({this.success, this.data});

  AvailableDaysModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data =
        json['data'] != null ? AvailableDaysData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      //ignore: avoid-non-null-assertion
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class AvailableDaysData {
  List<String>? list;
  int? totalRow;

  AvailableDaysData({this.list, this.totalRow});

  AvailableDaysData.fromJson(Map<String, dynamic> json) {
    list = json['list'].cast<String>();
    totalRow = json['totalRow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['list'] = list;
    data['totalRow'] = totalRow;
    return data;
  }
}
