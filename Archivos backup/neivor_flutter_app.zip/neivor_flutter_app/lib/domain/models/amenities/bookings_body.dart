import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class BookingsBody {
  int? enterprise;
  List<int?>? servicePoint;
  List<int>? eventState;
  String? eventStart;
  int? page;
  int? pageSize;
  static const _pageSize = 6;

  BookingsBody({
    this.enterprise,
    this.servicePoint,
    this.eventState,
    this.eventStart,
    this.page = 0,
    this.pageSize = _pageSize,
  });

  factory BookingsBody.defaultValues() => BookingsBody(
        enterprise: UserUtils.currentEnterprise?.id,
        servicePoint: List.of([UserUtils.currentServicePoint?.id ?? -1]),
      );

  BookingsBody.fromJson(Map<String, dynamic> json) {
    enterprise = json['enterprise'];
    servicePoint = json['servicePoint'].cast<int>();
    eventState = json['eventState'].cast<int>();
    eventStart = json['eventStart'];
    page = json['page'];
    pageSize = json['pageSize'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['enterprise'] = enterprise;
    data['servicePoint'] = servicePoint;
    data['eventState'] = eventState;
    data['eventStart'] = eventStart;
    data['page'] = page;
    data['pageSize'] = pageSize;
    return data;
  }
}
