class AddedBookingModel {
  int? id;
  int? userCreation;
  int? userChange;
  int? state;
  int? idSocialArea;
  int? idEventState;
  String? title;
  int? idEventType;
  int? publicationType;
  int? idUserRequest;
  int? idUserApproves;
  String? responsible;
  int? idServicePointRequest;
  int? companionsNumber;
  int? idEnterprise;
  String? enterpriseName;
  int? idOperationZone;
  String? paymentReference;
  String? eventStartString;
  String? eventEndString;
  double? eventStart;
  double? eventEnd;

  AddedBookingModel({
    this.id,
    this.userCreation,
    this.userChange,
    this.state,
    this.idSocialArea,
    this.idEventState,
    this.title,
    this.idEventType,
    this.publicationType,
    this.idUserRequest,
    this.idUserApproves,
    this.responsible,
    this.idServicePointRequest,
    this.companionsNumber,
    this.idEnterprise,
    this.enterpriseName,
    this.idOperationZone,
    this.paymentReference,
    this.eventStartString,
    this.eventEndString,
    this.eventStart,
    this.eventEnd,
  });

  // ignore: long-method
  AddedBookingModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCreation = json['userCreation'];
    userChange = json['userChange'];
    state = json['state'];
    idSocialArea = json['idSocialArea'];
    idEventState = json['idEventState'];
    title = json['title'];
    idEventType = json['idEventType'];
    publicationType = json['publicationType'];
    idUserRequest = json['idUserRequest'];
    idUserApproves = json['idUserApproves'];
    responsible = json['responsible'];
    idServicePointRequest = json['idServicePointRequest'];
    companionsNumber = json['companionsNumber'];
    idEnterprise = json['idEnterprise'];
    enterpriseName = json['enterpriseName'];
    idOperationZone = json['idOperationZone'];
    paymentReference = json['paymentReference'];
    eventStartString = json['eventStartString'];
    eventEndString = json['eventEndString'];
    eventStart = json['eventStart'];
    eventEnd = json['eventEnd'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userCreation'] = userCreation;
    data['userChange'] = userChange;
    data['state'] = state;
    data['idSocialArea'] = idSocialArea;
    data['idEventState'] = idEventState;
    data['title'] = title;
    data['idEventType'] = idEventType;
    data['publicationType'] = publicationType;
    data['idUserRequest'] = idUserRequest;
    data['idUserApproves'] = idUserApproves;
    data['responsible'] = responsible;
    data['idServicePointRequest'] = idServicePointRequest;
    data['companionsNumber'] = companionsNumber;
    data['idEnterprise'] = idEnterprise;
    data['enterpriseName'] = enterpriseName;
    data['idOperationZone'] = idOperationZone;
    data['paymentReference'] = paymentReference;
    data['eventStartString'] = eventStartString;
    data['eventEndString'] = eventEndString;
    data['eventStart'] = eventStart;
    data['eventEnd'] = eventEnd;
    return data;
  }
}
