import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class CancelBookingBody {
  int? id;
  int? idEnterprise;
  int? idServicePointRequest;
  int? idSocialArea;
  int? idUserRequest;
  String? eventStartString;
  int? userChange;
  String? title;

  CancelBookingBody({
    this.id,
    this.idEnterprise,
    this.idServicePointRequest,
    this.idSocialArea,
    this.idUserRequest,
    this.eventStartString,
    this.userChange,
    this.title,
  });

  factory CancelBookingBody.defaultValues() => CancelBookingBody(
        idEnterprise: UserUtils.currentEnterprise?.id,
        idUserRequest: UserUtils.currentUser?.id,
        //ignore: no-equal-arguments
        userChange: UserUtils.currentUser?.id,
        idServicePointRequest: UserUtils.currentServicePoint?.id,
      );

  CancelBookingBody.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    idEnterprise = json['idEnterprise'];
    idServicePointRequest = json['idServicePointRequest'];
    idSocialArea = json['idSocialArea'];
    idUserRequest = json['idUserRequest'];
    eventStartString = json['eventStartString'];
    userChange = json['userChange'];
    title = json['title'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['idEnterprise'] = idEnterprise;
    data['idServicePointRequest'] = idServicePointRequest;
    data['idSocialArea'] = idSocialArea;
    data['idUserRequest'] = idUserRequest;
    data['eventStartString'] = eventStartString;
    data['userChange'] = userChange;
    data['title'] = title;
    return data;
  }
}
