import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class BookingBody {
  int? idEventType;
  int? publicationType;
  String? title;
  int? idUserRequest;
  String? responsible;
  int? companionsNumber;
  int? idEnterprise;
  String? enterpriseName;
  int? idOperationZone;
  int? idServicePointRequest;
  int? idSocialArea;
  String? eventStartString;
  String? eventEndString;
  int? userCreation;
  String? description;
  String? costEvent;
  static const _bySocialArea = 2;
  static const _private = 0;
  static const _none = 0;

  BookingBody({
    this.idEventType,
    this.publicationType,
    this.title,
    this.idUserRequest,
    this.responsible,
    this.companionsNumber,
    this.idEnterprise,
    this.enterpriseName,
    this.idOperationZone,
    this.idServicePointRequest,
    this.idSocialArea,
    this.eventStartString,
    this.eventEndString,
    this.userCreation,
    this.description,
    this.costEvent,
  });

  factory BookingBody.defaultValues() => BookingBody(
        idEventType: _bySocialArea,
        publicationType: _private,
        idUserRequest: UserUtils.currentUser?.id,
        responsible: UserUtils.currentUser?.name,
        companionsNumber: _none,
        idEnterprise: UserUtils.currentEnterprise?.id,
        enterpriseName: UserUtils.currentEnterprise?.name,
        idOperationZone: UserUtils
            .currentEnterprise?.servicePointList?.first.operationZone?.id,
        //TODO: Ask to the back-end dev to use only one of these (idUserRequest, user Creation)
        //ignore: no-equal-arguments
        userCreation: UserUtils.currentUser?.id,
        idServicePointRequest: UserUtils.currentServicePoint?.id,
        costEvent: '0',
      );

  BookingBody.fromJson(Map<String, dynamic> json) {
    idEventType = json['idEventType'];
    publicationType = json['publicationType'];
    title = json['title'];
    idUserRequest = json['idUserRequest'];
    responsible = json['responsible'];
    companionsNumber = json['companionsNumber'];
    idEnterprise = json['idEnterprise'];
    enterpriseName = json['enterpriseName'];
    idOperationZone = json['idOperationZone'];
    idServicePointRequest = json['idServicePointRequest'];
    idSocialArea = json['idSocialArea'];
    eventStartString = json['eventStartString'];
    eventEndString = json['eventEndString'];
    userCreation = json['userCreation'];
    costEvent = json['costEvent'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idEventType'] = idEventType;
    data['publicationType'] = publicationType;
    data['title'] = title;
    data['idUserRequest'] = idUserRequest;
    data['responsible'] = responsible;
    data['companionsNumber'] = companionsNumber;
    data['idEnterprise'] = idEnterprise;
    data['enterpriseName'] = enterpriseName;
    data['idOperationZone'] = idOperationZone;
    data['idServicePointRequest'] = idServicePointRequest;
    data['idSocialArea'] = idSocialArea;
    data['eventStartString'] = eventStartString;
    data['eventEndString'] = eventEndString;
    data['userCreation'] = userCreation;
    data['description'] = description;
    data['costEvent'] = costEvent;
    return data;
  }
}
