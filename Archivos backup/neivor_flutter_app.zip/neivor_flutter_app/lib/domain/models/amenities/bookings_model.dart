class BookingsModel {
  bool? success;
  Info? info;
  List<Booking>? data;

  BookingsModel({this.success, this.info, this.data});

  BookingsModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    if (json['data'] != null) {
      data = <Booking>[];
      json['data'].forEach((v) {
        //ignore: avoid-non-null-assertion
        data!.add(Booking.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      //ignore: avoid-non-null-assertion
      data['info'] = info!.toJson();
    }
    if (this.data != null) {
      //ignore: avoid-non-null-assertion
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Booking {
  int? id;
  String? userCreation;
  String? userChange;
  int? state;
  int? totalRow;
  int? idSocialArea;
  int? idEventState;
  String? title;
  int? idEventType;
  int? publicationType;
  int? idUserRequest;
  String? responsible;
  int? idServicePointRequest;
  int? companionsNumber;
  int? idEnterprise;
  String? nameEventState;
  int? allDayIndicator;
  String? color;
  String? nameServicePoint;
  int? idOperationZone;
  String? nameOperationZone;
  String? eventStartString;
  String? eventEndString;
  double? eventStart;
  double? eventEnd;
  List<String>? imageList;

  Booking({
    this.id,
    this.userCreation,
    this.userChange,
    this.state,
    this.totalRow,
    this.idSocialArea,
    this.idEventState,
    this.title,
    this.idEventType,
    this.publicationType,
    this.idUserRequest,
    this.responsible,
    this.idServicePointRequest,
    this.companionsNumber,
    this.idEnterprise,
    this.nameEventState,
    this.allDayIndicator,
    this.color,
    this.nameServicePoint,
    this.idOperationZone,
    this.nameOperationZone,
    this.eventStartString,
    this.eventEndString,
    this.eventStart,
    this.eventEnd,
    this.imageList,
  });

  // ignore: long-method
  Booking.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCreation = json['userCreation'];
    userChange = json['userChange'];
    state = json['state'];
    totalRow = json['totalRow'];
    idSocialArea = json['idSocialArea'];
    idEventState = json['idEventState'];
    title = json['title'];
    idEventType = json['idEventType'];
    publicationType = json['publicationType'];
    idUserRequest = json['idUserRequest'];
    responsible = json['responsible'];
    idServicePointRequest = json['idServicePointRequest'];
    companionsNumber = json['companionsNumber'];
    idEnterprise = json['idEnterprise'];
    nameEventState = json['nameEventState'];
    allDayIndicator = json['allDayIndicator'];
    color = json['color'];
    nameServicePoint = json['nameServicePoint'];
    idOperationZone = json['idOperationZone'];
    nameOperationZone = json['nameOperationZone'];
    eventStartString = json['eventStartString'];
    eventEndString = json['eventEndString'];
    eventStart = json['eventStart'];
    eventEnd = json['eventEnd'];
    imageList = json['imageList'].cast<String>();
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userCreation'] = userCreation;
    data['userChange'] = userChange;
    data['state'] = state;
    data['totalRow'] = totalRow;
    data['idSocialArea'] = idSocialArea;
    data['idEventState'] = idEventState;
    data['title'] = title;
    data['idEventType'] = idEventType;
    data['publicationType'] = publicationType;
    data['idUserRequest'] = idUserRequest;
    data['responsible'] = responsible;
    data['idServicePointRequest'] = idServicePointRequest;
    data['companionsNumber'] = companionsNumber;
    data['idEnterprise'] = idEnterprise;
    data['nameEventState'] = nameEventState;
    data['allDayIndicator'] = allDayIndicator;
    data['color'] = color;
    data['nameServicePoint'] = nameServicePoint;
    data['idOperationZone'] = idOperationZone;
    data['nameOperationZone'] = nameOperationZone;
    data['eventStartString'] = eventStartString;
    data['eventEndString'] = eventEndString;
    data['eventStart'] = eventStart;
    data['eventEnd'] = eventEnd;
    data['imageList'] = imageList;
    return data;
  }
}
