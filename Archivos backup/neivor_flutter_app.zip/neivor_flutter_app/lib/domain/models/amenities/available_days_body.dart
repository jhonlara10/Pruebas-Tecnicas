import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class AvailableDaysBody {
  int? socialArea;
  int? enterprise;
  String? startDate;
  String? endDate;

  AvailableDaysBody({
    this.socialArea,
    this.enterprise,
    this.startDate,
    this.endDate,
  });

  AvailableDaysBody.fromJson(Map<String, dynamic> json) {
    socialArea = json['social-area'];
    enterprise = json['enterprise'];
    startDate = json['start-date'];
    endDate = json['end-date'];
  }

  factory AvailableDaysBody.defaultValues() => AvailableDaysBody(
        enterprise: UserUtils.currentEnterprise?.id,
      );

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['social-area'] = socialArea;
    data['enterprise'] = enterprise;
    data['start-date'] = startDate;
    data['end-date'] = endDate;
    return data;
  }
}
