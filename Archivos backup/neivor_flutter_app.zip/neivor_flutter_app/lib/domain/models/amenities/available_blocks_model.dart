// ignore_for_file: avoid-non-null-assertion
class AvailableBlocksModel {
  bool? success;
  Data? data;

  AvailableBlocksModel({this.success, this.data});

  AvailableBlocksModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<Block>? list;
  int? totalRow;

  Data({this.list, this.totalRow});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <Block>[];
      json['list'].forEach((v) {
        list!.add(Block.fromJson(v));
      });
    }
    totalRow = json['totalRow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (list != null) {
      data['list'] = list!.map((v) => v.toJson()).toList();
    }
    data['totalRow'] = totalRow;
    return data;
  }
}

class Block {
  String? startHour;
  String? endHour;
  int? occupiedCapacity;
  bool? available;
  String? unavailableMessage;
  bool? blockOverApprovedEvent;

  Block({
    this.startHour,
    this.endHour,
    this.occupiedCapacity,
    this.available,
    this.unavailableMessage,
    this.blockOverApprovedEvent,
  });

  Block.fromJson(Map<String, dynamic> json) {
    startHour = json['startHour'];
    endHour = json['endHour'];
    occupiedCapacity = json['occupiedCapacity'];
    available = json['available'];
    unavailableMessage = json['unavailableMessage'];
    blockOverApprovedEvent = json['blockOverApprovedEvent'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['startHour'] = startHour;
    data['endHour'] = endHour;
    data['occupiedCapacity'] = occupiedCapacity;
    data['available'] = available;
    data['unavailableMessage'] = unavailableMessage;
    data['blockOverApprovedEvent'] = blockOverApprovedEvent;
    return data;
  }
}
