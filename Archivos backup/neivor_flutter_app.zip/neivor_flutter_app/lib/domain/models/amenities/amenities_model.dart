class AmenitiesModel {
  bool? success;
  AmenitiesData? data;

  AmenitiesModel({this.success, this.data});

  AmenitiesModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? AmenitiesData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      //ignore: avoid-non-null-assertion
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class AmenitiesData {
  List<Amenity>? list;
  int? page;
  int? pageSize;
  int? totalRow;

  AmenitiesData({this.list, this.page, this.pageSize, this.totalRow});

  AmenitiesData.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <Amenity>[];
      json['list'].forEach((v) {
        //ignore: avoid-non-null-assertion
        list!.add(Amenity.fromJson(v));
      });
    }
    page = json['page'];
    pageSize = json['pageSize'];
    totalRow = json['totalRow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (list != null) {
      // ignore: avoid-non-null-assertion
      data['list'] = list!.map((v) => v.toJson()).toList();
    }
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['totalRow'] = totalRow;
    return data;
  }
}

class Amenity {
  int? id;
  double? dateCreation;
  int? userCreation;
  double? dateChange;
  int? userChange;
  int? totalRow;
  String? name;
  bool? isPerHour;
  double? rentCost;
  String? email;
  String? color;
  String? phone;
  String? mobilePhone;
  String? blockPeriod;
  bool? isRowBooking;
  String? timeBetween;
  bool? inMaintenance;
  bool? needApprobation;
  int? maxCompanionsNumber;
  int? capacity;
  int? cancellationTime;
  bool? uniqueReserve;
  int? idEnterprise;
  int? anticipationTime;
  int? socialAreaState;
  String? socialAreaConfiguration;
  int? idSocialAreaType;
  String? socialAreaType;
  // ignore: prefer-correct-identifier-length
  SocialAreaConfigurationObj? socialAreaConfigurationObj;
  List<String>? imageList;
  List<AvailabilityList>? availabilityList;
  int? allDay;

  Amenity({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.dateChange,
    this.userChange,
    this.totalRow,
    this.name,
    this.isPerHour,
    this.rentCost,
    this.email,
    this.color,
    this.phone,
    this.mobilePhone,
    this.blockPeriod,
    this.isRowBooking,
    this.timeBetween,
    this.inMaintenance,
    this.needApprobation,
    this.maxCompanionsNumber,
    this.capacity,
    this.cancellationTime,
    this.uniqueReserve,
    this.idEnterprise,
    this.anticipationTime,
    this.socialAreaState,
    this.socialAreaConfiguration,
    this.idSocialAreaType,
    this.socialAreaType,
    this.socialAreaConfigurationObj,
    this.imageList,
    this.availabilityList,
    this.allDay,
  });

  // ignore: long-method
  Amenity.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    dateChange = json['dateChange'];
    userChange = json['userChange'];
    totalRow = json['totalRow'];
    name = json['name'];
    isPerHour = json['isPerHour'];
    rentCost = json['rentCost'];
    email = json['email'];
    color = json['color'];
    phone = json['phone'];
    mobilePhone = json['mobilePhone'];
    blockPeriod = json['blockPeriod'];
    isRowBooking = json['isRowBooking'];
    timeBetween = json['timeBetween'];
    inMaintenance = json['inMaintenance'];
    needApprobation = json['needApprobation'];
    maxCompanionsNumber = json['maxCompanionsNumber'];
    capacity = json['capacity'];
    cancellationTime = json['cancellationTime'];
    uniqueReserve = json['uniqueReserve'];
    idEnterprise = json['idEnterprise'];
    anticipationTime = json['anticipationTime'];
    socialAreaState = json['socialAreaState'];
    socialAreaConfiguration = json['socialAreaConfiguration'];
    idSocialAreaType = json['idSocialAreaType'];
    socialAreaType = json['socialAreaType'];
    socialAreaConfigurationObj = json['socialAreaConfigurationObj'] != null
        ? SocialAreaConfigurationObj.fromJson(
            json['socialAreaConfigurationObj'],
          )
        : null;
    imageList = json['imageList'].cast<String>();
    if (json['availabilityList'] != null) {
      availabilityList = <AvailabilityList>[];
      json['availabilityList'].forEach((v) {
        //ignore: avoid-non-null-assertion
        availabilityList!.add(AvailabilityList.fromJson(v));
      });
    }
    allDay = json['allDay'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['dateChange'] = dateChange;
    data['userChange'] = userChange;
    data['totalRow'] = totalRow;
    data['name'] = name;
    data['isPerHour'] = isPerHour;
    data['rentCost'] = rentCost;
    data['email'] = email;
    data['color'] = color;
    data['phone'] = phone;
    data['mobilePhone'] = mobilePhone;
    data['blockPeriod'] = blockPeriod;
    data['isRowBooking'] = isRowBooking;
    data['timeBetween'] = timeBetween;
    data['inMaintenance'] = inMaintenance;
    data['needApprobation'] = needApprobation;
    data['maxCompanionsNumber'] = maxCompanionsNumber;
    data['capacity'] = capacity;
    data['cancellationTime'] = cancellationTime;
    data['uniqueReserve'] = uniqueReserve;
    data['idEnterprise'] = idEnterprise;
    data['anticipationTime'] = anticipationTime;
    data['socialAreaState'] = socialAreaState;
    data['socialAreaConfiguration'] = socialAreaConfiguration;
    data['idSocialAreaType'] = idSocialAreaType;
    data['socialAreaType'] = socialAreaType;
    if (socialAreaConfigurationObj != null) {
      data['socialAreaConfigurationObj'] =
          //ignore: avoid-non-null-assertion
          socialAreaConfigurationObj!.toJson();
    }
    data['imageList'] = imageList;
    if (availabilityList != null) {
      data['availabilityList'] =
          //ignore: avoid-non-null-assertion
          availabilityList!.map((v) => v.toJson()).toList();
    }
    data['allDay'] = allDay;
    return data;
  }
}

// ignore: prefer-correct-type-name
class SocialAreaConfigurationObj {
  int? reservationWindowTime;
  String? rules;

  SocialAreaConfigurationObj({this.reservationWindowTime, this.rules});

  SocialAreaConfigurationObj.fromJson(Map<String, dynamic> json) {
    reservationWindowTime = json['reservationWindowTime'];
    rules = json['rules'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['reservationWindowTime'] = reservationWindowTime;
    data['rules'] = rules;
    return data;
  }
}

class AvailabilityList {
  int? id;
  int? state;
  int? idSocialArea;
  String? startHour;
  String? endHour;
  String? weekDayList;

  AvailabilityList({
    this.id,
    this.state,
    this.idSocialArea,
    this.startHour,
    this.endHour,
    this.weekDayList,
  });

  AvailabilityList.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    idSocialArea = json['idSocialArea'];
    startHour = json['startHour'];
    endHour = json['endHour'];
    weekDayList = json['weekDayList'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['idSocialArea'] = idSocialArea;
    data['startHour'] = startHour;
    data['endHour'] = endHour;
    data['weekDayList'] = weekDayList;
    return data;
  }
}
