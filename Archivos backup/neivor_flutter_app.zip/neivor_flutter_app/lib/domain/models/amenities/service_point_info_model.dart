class ServicePointInfoModel {
  int? id;
  bool? hasPendingPayments;
  // ignore: prefer-correct-identifier-length
  int? eventReservationCapacityIndicator;
  // ignore: prefer-correct-identifier-length
  int? eventReservationCapacityMonthly;
  // ignore: prefer-correct-identifier-length
  int? eventReservationCapacityWeekly;
  int? monthlyEventCount;
  int? weeklyEventCount;
  bool? hasActiveReserve;

  ServicePointInfoModel({
    this.id,
    this.hasPendingPayments,
    this.eventReservationCapacityIndicator,
    this.eventReservationCapacityMonthly,
    this.eventReservationCapacityWeekly,
    this.monthlyEventCount,
    this.weeklyEventCount,
    this.hasActiveReserve,
  });

  ServicePointInfoModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    hasPendingPayments = json['hasPendingPayments'];
    eventReservationCapacityIndicator =
        json['eventReservationCapacityIndicator'];
    eventReservationCapacityMonthly = json['eventReservationCapacityMonthly'];
    eventReservationCapacityWeekly = json['eventReservationCapacityWeekly'];
    monthlyEventCount = json['monthlyEventCount'];
    weeklyEventCount = json['weeklyEventCount'];
    hasActiveReserve = json['hasActiveReserve'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['hasPendingPayments'] = hasPendingPayments;
    data['eventReservationCapacityIndicator'] =
        eventReservationCapacityIndicator;
    data['eventReservationCapacityMonthly'] = eventReservationCapacityMonthly;
    data['eventReservationCapacityWeekly'] = eventReservationCapacityWeekly;
    data['monthlyEventCount'] = monthlyEventCount;
    data['weeklyEventCount'] = weeklyEventCount;
    data['hasActiveReserve'] = hasActiveReserve;
    return data;
  }
}
