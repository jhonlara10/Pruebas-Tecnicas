class VehiclesResponse {
  int? id;
  double? dateCreation;
  String? vehicleModel;
  int? idVehicleType;
  String? color;
  int? idServicePoint;
  String? brand;
  String? numberPlate;

  VehiclesResponse({
    this.id,
    this.dateCreation,
    this.vehicleModel,
    this.idVehicleType,
    this.color,
    this.idServicePoint,
    this.brand,
    this.numberPlate,
  });

  VehiclesResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    vehicleModel = json['vehicleModel'];
    idVehicleType = json['idVehicleType'];
    color = json['color'];
    idServicePoint = json['idServicePoint'];
    brand = json['brand'];
    numberPlate = json['numberPlate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['vehicleModel'] = vehicleModel;
    data['idVehicleType'] = idVehicleType;
    data['color'] = color;
    data['idServicePoint'] = idServicePoint;
    data['brand'] = brand;
    data['numberPlate'] = numberPlate;
    return data;
  }
}
