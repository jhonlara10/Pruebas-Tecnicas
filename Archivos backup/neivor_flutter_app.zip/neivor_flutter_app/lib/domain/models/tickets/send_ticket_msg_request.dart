class SendTicketMsgRequest {
  bool? newMessage;
  int? userCreation;
  int? idZyosUserCreator;
  int? recipients;
  int? idEnterprise;
  String? messageBody;
  int? idConversation;
  bool? pqr;
  bool? adminUser;

  SendTicketMsgRequest({
    this.newMessage,
    this.userCreation,
    this.idZyosUserCreator,
    this.recipients,
    this.idEnterprise,
    this.messageBody,
    this.idConversation,
    this.pqr,
    this.adminUser,
  });

  SendTicketMsgRequest.fromJson(Map<String, dynamic> json) {
    newMessage = json['newMessage'];
    userCreation = json['userCreation'];
    idZyosUserCreator = json['idZyosUserCreator'];
    recipients = json['recipients'];
    idEnterprise = json['idEnterprise'];
    messageBody = json['messageBody'];
    idConversation = json['idConversation'];
    pqr = json['pqr'];
    adminUser = json['adminUser'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['newMessage'] = newMessage;
    data['userCreation'] = userCreation;
    data['idZyosUserCreator'] = idZyosUserCreator;
    data['recipients'] = recipients;
    data['idEnterprise'] = idEnterprise;
    data['messageBody'] = messageBody;
    data['idConversation'] = idConversation;
    data['pqr'] = pqr;
    data['adminUser'] = adminUser;
    return data;
  }
}
