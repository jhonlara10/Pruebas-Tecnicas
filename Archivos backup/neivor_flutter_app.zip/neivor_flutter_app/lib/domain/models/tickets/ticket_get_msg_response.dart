class TicketGetMsgResponse {
  int? id;
  double? dateCreation;
  int? state;
  int? totalRow;
  int? idZyosUserCreator;
  int? idConversation;
  bool? read;
  String? messageBody;
  String? photoUserCreator;
  String? nameUserCreator;
  bool? group;
  bool? newMessage;
  bool? pqr;

  TicketGetMsgResponse({
    this.id,
    this.dateCreation,
    this.state,
    this.totalRow,
    this.idZyosUserCreator,
    this.idConversation,
    this.read,
    this.messageBody,
    this.photoUserCreator,
    this.nameUserCreator,
    this.group,
    this.newMessage,
    this.pqr,
  });

  TicketGetMsgResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    state = json['state'];
    totalRow = json['totalRow'];
    idZyosUserCreator = json['idZyosUserCreator'];
    idConversation = json['idConversation'];
    read = json['read'];
    messageBody = json['messageBody'];
    photoUserCreator = json['photoUserCreator'];
    nameUserCreator = json['nameUserCreator'];
    group = json['group'];
    newMessage = json['newMessage'];
    pqr = json['pqr'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['state'] = state;
    data['totalRow'] = totalRow;
    data['idZyosUserCreator'] = idZyosUserCreator;
    data['idConversation'] = idConversation;
    data['read'] = read;
    data['messageBody'] = messageBody;
    data['photoUserCreator'] = photoUserCreator;
    data['nameUserCreator'] = nameUserCreator;
    data['group'] = group;
    data['newMessage'] = newMessage;
    data['pqr'] = pqr;
    return data;
  }
}
