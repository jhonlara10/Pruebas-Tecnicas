class TicketAddRequest {
  int? idComplaintDemandType;
  int? idStateComplaintDemand;
  int? deadLineUpdate;
  int? idResponsible;
  int? idServicePoint;
  int? idEnterprise;
  String? title;
  String? description;
  String? email;
  int? userCreation;
  int? idZyosUser;
  bool? adminUser;

  TicketAddRequest({
    this.idComplaintDemandType,
    this.idStateComplaintDemand,
    this.deadLineUpdate,
    this.idResponsible,
    this.idServicePoint,
    this.idEnterprise,
    this.title,
    this.description,
    this.email,
    this.userCreation,
    this.idZyosUser,
    this.adminUser,
  });

  TicketAddRequest.fromJson(Map<String, dynamic> json) {
    idComplaintDemandType = json['idComplaintDemandType'];
    idStateComplaintDemand = json['idStateComplaintDemand'];
    deadLineUpdate = json['deadLineUpdate'];
    idResponsible = json['idResponsible'];
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    title = json['title'];
    description = json['description'];
    email = json['email'];
    userCreation = json['userCreation'];
    idZyosUser = json['idZyosUser'];
    adminUser = json['adminUser'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idComplaintDemandType'] = idComplaintDemandType;
    data['idStateComplaintDemand'] = idStateComplaintDemand;
    data['deadLineUpdate'] = deadLineUpdate;
    data['idResponsible'] = idResponsible;
    data['idServicePoint'] = idServicePoint;
    data['idEnterprise'] = idEnterprise;
    data['title'] = title;
    data['description'] = description;
    data['email'] = email;
    data['userCreation'] = userCreation;
    data['idZyosUser'] = idZyosUser;
    data['adminUser'] = adminUser;
    return data;
  }
}
