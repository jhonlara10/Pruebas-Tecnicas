class SendTicketMessageResponse {
  bool? sucessRequestChat;
  String? message;
  int? idConversation;

  SendTicketMessageResponse({
    this.sucessRequestChat,
    this.message,
    this.idConversation,
  });

  SendTicketMessageResponse.fromJson(Map<String, dynamic> json) {
    sucessRequestChat = json['sucessRequestChat'];
    message = json['message'];
    idConversation = json['idConversation'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sucessRequestChat'] = sucessRequestChat;
    data['message'] = message;
    data['idConversation'] = idConversation;
    return data;
  }
}
