class TicketEditRequest {
  int? id;
  String? dateCreation;
  String? hourCreation;
  int? state;
  String? title;
  String? description;
  int? idZyosUser;
  int? idResponsible;
  int? idServicePoint;
  int? idEnterprise;
  int? idConversation;
  String? nameServicePoint;
  int? idComplaintDemandType;
  int? idStateComplaintDemand;
  int? daysBetweenDeadLine;
  int? deadLineLong;
  String? numberCD;
  String? nameUser;
  String? nameResponsible;
  String? email;
  bool? messageUnread;
  bool? adminUser;
  bool? updateResponsible;
  int? deadLineUpdate;
  int? userChange;

  TicketEditRequest({
    this.id,
    this.dateCreation,
    this.hourCreation,
    this.state,
    this.title,
    this.description,
    this.idZyosUser,
    this.idResponsible,
    this.idServicePoint,
    this.idEnterprise,
    this.idConversation,
    this.nameServicePoint,
    this.idComplaintDemandType,
    this.idStateComplaintDemand,
    this.daysBetweenDeadLine,
    this.deadLineLong,
    this.numberCD,
    this.nameUser,
    this.nameResponsible,
    this.email,
    this.messageUnread,
    this.adminUser,
    this.updateResponsible,
    this.deadLineUpdate,
    this.userChange,
  });

  // ignore: long-method
  TicketEditRequest.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    hourCreation = json['hourCreation'];
    state = json['state'];
    title = json['title'];
    description = json['description'];
    idZyosUser = json['idZyosUser'];
    idResponsible = json['idResponsible'];
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    idConversation = json['idConversation'];
    nameServicePoint = json['nameServicePoint'];
    idComplaintDemandType = json['idComplaintDemandType'];
    idStateComplaintDemand = json['idStateComplaintDemand'];
    daysBetweenDeadLine = json['daysBetweenDeadLine'];
    deadLineLong = json['deadLineLong'];
    numberCD = json['numberCD'];
    nameUser = json['nameUser'];
    nameResponsible = json['nameResponsible'];
    email = json['email'];
    messageUnread = json['messageUnread'];
    adminUser = json['adminUser'];
    updateResponsible = json['updateResponsible'];
    deadLineUpdate = json['deadLineUpdate'];
    userChange = json['userChange'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['hourCreation'] = hourCreation;
    data['state'] = state;
    data['title'] = title;
    data['description'] = description;
    data['idZyosUser'] = idZyosUser;
    data['idResponsible'] = idResponsible;
    data['idServicePoint'] = idServicePoint;
    data['idEnterprise'] = idEnterprise;
    data['idConversation'] = idConversation;
    data['nameServicePoint'] = nameServicePoint;
    data['idComplaintDemandType'] = idComplaintDemandType;
    data['idStateComplaintDemand'] = idStateComplaintDemand;
    data['daysBetweenDeadLine'] = daysBetweenDeadLine;
    data['deadLineLong'] = deadLineLong;
    data['numberCD'] = numberCD;
    data['nameUser'] = nameUser;
    data['nameResponsible'] = nameResponsible;
    data['email'] = email;
    data['messageUnread'] = messageUnread;
    data['adminUser'] = adminUser;
    data['updateResponsible'] = updateResponsible;
    data['deadLineUpdate'] = deadLineUpdate;
    data['userChange'] = userChange;
    return data;
  }
}
