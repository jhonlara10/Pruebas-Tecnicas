class TicketsAddResponse {
  bool? sucessRequestPqr;
  String? message;
  int? idComplaintDemand;

  TicketsAddResponse({
    this.sucessRequestPqr,
    this.message,
    this.idComplaintDemand,
  });

  TicketsAddResponse.fromJson(Map<String, dynamic> json) {
    sucessRequestPqr = json['sucessRequestPqr'];
    message = json['message'];
    idComplaintDemand = json['idComplaintDemand'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sucessRequestPqr'] = sucessRequestPqr;
    data['message'] = message;
    data['idComplaintDemand'] = idComplaintDemand;
    return data;
  }
}
