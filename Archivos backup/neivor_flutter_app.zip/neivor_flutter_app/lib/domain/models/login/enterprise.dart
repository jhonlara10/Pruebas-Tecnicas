import 'package:neivor_flutter_app/domain/models/login/enterprise_configuration.dart';
import 'package:neivor_flutter_app/domain/models/login/service_point.dart';
import 'package:neivor_flutter_app/domain/models/login/zyos_group.dart';

class Enterprise {
  int? id;
  String? name;
  String? shortName;
  String? nameLogo;
  String? address;
  bool? consolidatePayment;
  bool? exactInvoicePayment;
  bool? hidePay;
  List<ServicePoint>? servicePointList;
  List<ZyosGroup>? zyosGroupList;
  bool? consolidateDue;
  EnterpriseConfiguration? enterpriseConfiguration;

  Enterprise({
    this.id,
    this.name,
    this.shortName,
    this.nameLogo,
    this.address,
    this.consolidatePayment,
    this.exactInvoicePayment,
    this.hidePay,
    this.servicePointList,
    this.zyosGroupList,
    this.consolidateDue,
    this.enterpriseConfiguration,
  });

  // ignore: long-method
  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortName = json['shortName'];
    nameLogo = json['nameLogo'];
    address = json['address'];
    consolidatePayment = json['consolidatePayment'];
    exactInvoicePayment = json['exactInvoicePayment'];
    hidePay = json['hidePay'];
    if (json['servicePointList'] != null) {
      servicePointList = <ServicePoint>[];
      json['servicePointList'].forEach((v) {
        servicePointList?.add(ServicePoint.fromJson(v));
      });
    }
    if (json['zyosGroupList'] != null) {
      zyosGroupList = <ZyosGroup>[];
      json['zyosGroupList'].forEach((v) {
        zyosGroupList?.add(ZyosGroup.fromJson(v));
      });
    }
    consolidateDue = json['consolidateDue'];
    enterpriseConfiguration = json['enterpriseConfiguration'] != null
        ? EnterpriseConfiguration.fromJson(json['enterpriseConfiguration'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['shortName'] = shortName;
    data['nameLogo'] = nameLogo;
    data['address'] = address;
    data['consolidatePayment'] = consolidatePayment;
    data['exactInvoicePayment'] = exactInvoicePayment;
    data['hidePay'] = hidePay;
    if (servicePointList != null) {
      data['servicePointList'] =
          servicePointList?.map((v) => v.toJson()).toList();
    }
    if (zyosGroupList != null) {
      data['zyosGroupList'] = zyosGroupList?.map((v) => v.toJson()).toList();
    }
    data['consolidateDue'] = consolidateDue;
    if (enterpriseConfiguration != null) {
      data['enterpriseConfiguration'] = enterpriseConfiguration?.toJson();
    }
    return data;
  }
}
