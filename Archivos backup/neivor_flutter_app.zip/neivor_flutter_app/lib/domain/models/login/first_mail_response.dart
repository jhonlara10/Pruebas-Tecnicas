class FirstMailResponse {
  int? id;
  bool? skipOnboard;
  String? documentNumber;
  String? name;
  String? phone;
  String? mobilePhone;
  String? email;
  int? voluntary;
  int? blackList;
  String? ocupation;
  int? sipNumber;
  String? alias;
  ZyosLogin? zyosLogin;

  FirstMailResponse({
    this.id,
    this.skipOnboard,
    this.documentNumber,
    this.name,
    this.phone,
    this.mobilePhone,
    this.email,
    this.voluntary,
    this.blackList,
    this.ocupation,
    this.sipNumber,
    this.alias,
    this.zyosLogin,
  });

  FirstMailResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    skipOnboard = json['skipOnboard'];
    documentNumber = json['documentNumber'];
    name = json['name'];
    phone = json['phone'];
    mobilePhone = json['mobilePhone'];
    email = json['email'];
    voluntary = json['voluntary'];
    blackList = json['blackList'];
    ocupation = json['ocupation'];
    sipNumber = json['sipNumber'];
    alias = json['alias'];
    zyosLogin = json['zyosLogin'] != null
        ? ZyosLogin.fromJson(json['zyosLogin'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['skipOnboard'] = skipOnboard;
    data['documentNumber'] = documentNumber;
    data['name'] = name;
    data['phone'] = phone;
    data['mobilePhone'] = mobilePhone;
    data['email'] = email;
    data['voluntary'] = voluntary;
    data['blackList'] = blackList;
    data['ocupation'] = ocupation;
    data['sipNumber'] = sipNumber;
    data['alias'] = alias;
    if (zyosLogin != null) {
      data['zyosLogin'] = zyosLogin?.toJson();
    }
    return data;
  }
}

class ZyosLogin {
  String? dateChange;
  int? idZyosUser;
  String? userLogin;
  String? passwordHash;
  String? passwordMD5;
  bool? firstLogin;

  ZyosLogin({
    this.dateChange,
    this.idZyosUser,
    this.userLogin,
    this.passwordHash,
    this.passwordMD5,
    this.firstLogin,
  });

  ZyosLogin.fromJson(Map<String, dynamic> json) {
    dateChange = json['dateChange'];
    idZyosUser = json['idZyosUser'];
    userLogin = json['userLogin'];
    passwordHash = json['passwordHash'];
    passwordMD5 = json['passwordMD5'];
    firstLogin = json['firstLogin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['dateChange'] = dateChange;
    data['idZyosUser'] = idZyosUser;
    data['userLogin'] = userLogin;
    data['passwordHash'] = passwordHash;
    data['passwordMD5'] = passwordMD5;
    data['firstLogin'] = firstLogin;
    return data;
  }
}
