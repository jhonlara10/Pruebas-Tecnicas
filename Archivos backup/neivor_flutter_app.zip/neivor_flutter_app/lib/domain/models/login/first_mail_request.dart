class FirstMailRequest {
  String? email;
  bool? digitsCode;
  bool? validationCodeLogin;

  FirstMailRequest({this.email, this.digitsCode, this.validationCodeLogin});

  FirstMailRequest.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    digitsCode = json['digitsCode'];
    validationCodeLogin = json['validationCodeLogin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['digitsCode'] = digitsCode;
    data['validationCodeLogin'] = validationCodeLogin;
    return data;
  }
}
