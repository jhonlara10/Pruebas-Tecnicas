class ZyosGroup {
  int? id;
  String? name;
  int? idEnterprise;

  ZyosGroup({this.id, this.name, this.idEnterprise});

  ZyosGroup.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    idEnterprise = json['idEnterprise'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['idEnterprise'] = idEnterprise;
    return data;
  }
}
