import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class ServicePointBody {
  int? page;
  String? dynamicName;
  int? enterprise;
  int? pageSize;
  static const _defaultPageSize = 6;

  ServicePointBody({
    this.page,
    this.dynamicName,
    this.enterprise,
    this.pageSize,
  });

  ServicePointBody.fromJson(Map<String, dynamic> json) {
    page = json['page'];
    dynamicName = json['dynamic-name'];
    enterprise = json['enterprise'];
    pageSize = json['page-size'];
  }

  factory ServicePointBody.defaultValues() => ServicePointBody(
        page: 0,
        pageSize: _defaultPageSize,
        enterprise: UserUtils.currentEnterprise?.id,
      );

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['page'] = page;
    data['dynamic-name'] = dynamicName;
    data['enterprise'] = enterprise;
    data['page-size'] = pageSize;
    return data;
  }
}
