import 'dart:convert';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/wall_notifications/wall_notifications_bloc.dart';
import 'package:neivor_flutter_app/domain/models/login/enterprise.dart';
import 'package:neivor_flutter_app/domain/models/login/service_point.dart';
import 'package:neivor_flutter_app/domain/models/login/zyos_group.dart';
import 'package:neivor_flutter_app/main.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class User {
  String? sub;
  String? issuer;
  int? id;
  String? name;
  String? ocupation;
  String? alias;
  bool? skipOnboard;
  String? documentNumber;
  String? email;
  String? photo;
  String? phone;
  String? mobilePhone;
  int? voluntary;
  bool? firstLogin;
  int? hideUserFromNeighbors;
  int? sipNumber;
  List<Enterprise>? enterpriseList;
  Enterprise? currentEnterprise;
  List<ZyosGroup>? zyosGroupList;
  List<ServicePoint>? servicePointList;
  ServicePoint? currentServicePoint;
  int? iat;

  User({
    this.sub,
    this.issuer,
    this.id,
    this.name,
    this.ocupation,
    this.alias,
    this.skipOnboard,
    this.documentNumber,
    this.email,
    this.photo,
    this.phone,
    this.mobilePhone,
    this.voluntary,
    this.firstLogin,
    this.hideUserFromNeighbors,
    this.sipNumber,
    this.enterpriseList,
    this.currentEnterprise,
    this.zyosGroupList,
    this.servicePointList,
    this.currentServicePoint,
    this.iat,
  });

  // ignore: long-method
  User.fromJson(Map<String, dynamic> json) {
    sub = json['sub'];
    issuer = json['issuer'];
    id = json['id'];
    name = json['name'];
    ocupation = json['ocupation'];
    alias = json['alias'];
    skipOnboard = json['skipOnboard'];
    documentNumber = json['documentNumber'];
    email = json['email'];
    photo = json['photo'];
    phone = json['phone'];
    mobilePhone = json['mobilePhone'];
    voluntary = json['voluntary'];
    firstLogin = json['firstLogin'];
    hideUserFromNeighbors = json['hideUserFromNeighbors'];
    sipNumber = json['sipNumber'];
    if (json['enterpriseList'] != null) {
      enterpriseList = <Enterprise>[];
      json['enterpriseList'].forEach((v) {
        enterpriseList?.add(Enterprise.fromJson(v));
      });
    }
    currentEnterprise = json['currentEnterprise'] != null
        ? Enterprise.fromJson(json['currentEnterprise'])
        : null;
    if (json['zyosGroupList'] != null) {
      zyosGroupList = <ZyosGroup>[];
      json['zyosGroupList'].forEach((v) {
        zyosGroupList?.add(ZyosGroup.fromJson(v));
      });
    }
    if (json['servicePointList'] != null) {
      servicePointList = <ServicePoint>[];
      json['servicePointList'].forEach((v) {
        servicePointList?.add(ServicePoint.fromJson(v));
      });
    }
    currentServicePoint = json['currentServicePoint'] != null
        ? ServicePoint.fromJson(json['currentServicePoint'])
        : null;
    iat = json['iat'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['sub'] = sub;
    data['issuer'] = issuer;
    data['id'] = id;
    data['name'] = name;
    data['ocupation'] = ocupation;
    data['alias'] = alias;
    data['skipOnboard'] = skipOnboard;
    data['documentNumber'] = documentNumber;
    data['email'] = email;
    data['photo'] = photo;
    data['phone'] = phone;
    data['mobilePhone'] = mobilePhone;
    data['voluntary'] = voluntary;
    data['firstLogin'] = firstLogin;
    data['hideUserFromNeighbors'] = hideUserFromNeighbors;
    data['sipNumber'] = sipNumber;
    if (enterpriseList != null) {
      data['enterpriseList'] = enterpriseList?.map((v) => v.toJson()).toList();
    }
    if (currentEnterprise != null) {
      data['currentEnterprise'] = currentEnterprise?.toJson();
    }
    if (zyosGroupList != null) {
      data['zyosGroupList'] = zyosGroupList?.map((v) => v.toJson()).toList();
    }
    if (servicePointList != null) {
      data['servicePointList'] =
          servicePointList?.map((v) => v.toJson()).toList();
    }
    if (currentServicePoint != null) {
      data['currentServicePoint'] = currentServicePoint?.toJson();
    }
    data['iat'] = iat;
    return data;
  }

  List<int>? getServicePointList() {
    var currentEnterprise = UserUtils.currentEnterprise;
    return currentEnterprise?.servicePointList
        ?.map<int>((servicePoint) => servicePoint.id ?? 0)
        .toList();
  }

  Future<User> getCurrentUser() async {
    var sharePreferences = await SharedPreferences.getInstance();
    return User.fromJson(
      jsonDecode(sharePreferences.getString("currentUser") ?? ""),
    );
  }

  Future<Enterprise?> getCurrentEnterprise() async {
    var sharePreferences = await SharedPreferences.getInstance();
    try {
      var index = sharePreferences.getInt("currentEnterpriseIndex");
      if (index == null) {
        return enterpriseList?.first;
      } else {
        return enterpriseList?.elementAt(index);
      }
    } catch (error) {
      sharePreferences.setInt("currentEnterpriseIndex", 0);
      return enterpriseList?.first;
    }
  }

  Future<bool> isAdmin() async {
    var currentRole = await getCurrentRole();
    return currentRole?.id == 2;
  }

  Future<bool> isSecurity() async {
    var currentRole = await getCurrentRole();
    return currentRole?.id == 8;
  }

  Future<bool> isOwner() async {
    var currentRole = await getCurrentRole();
    return currentRole?.id == 5;
  }

  // ignore: long-method
  Future<ServicePoint?> getCurrentServicePoint() async {
    var sharePreferences = await SharedPreferences.getInstance();
    var currentEnterprise = await getCurrentEnterprise();
    try {
      var index = sharePreferences.getInt("currentServicePointIndex");
      if (index == null) {
        BlocProvider.of<WallNotificationsBloc>(
          navigatorKey.currentState!.context,
        ).add(NewCurrentLegalCharge(
          currentLegalCharge: servicePointList?.first.legalCharge ?? 0,
        ));
        return servicePointList?.first;
      } else {
        BlocProvider.of<WallNotificationsBloc>(
          navigatorKey.currentState!.context,
        ).add(NewCurrentLegalCharge(
          currentLegalCharge: currentEnterprise?.servicePointList
                  ?.elementAt(index)
                  .legalCharge ??
              0,
        ));
        return currentEnterprise?.servicePointList?.elementAt(index);
      }
    } catch (error) {
      sharePreferences.setInt("currentServicePointIndex", 0);
      return servicePointList?.first;
    }
  }

  Future<ZyosGroup?> getCurrentRole() async {
    var sharePreferences = await SharedPreferences.getInstance();
    var currentEnterprise = await getCurrentEnterprise();
    try {
      var index = sharePreferences.getInt("currentZyosGroup");
      if (index == null) {
        return currentEnterprise?.zyosGroupList?.first;
      } else {
        return currentEnterprise?.zyosGroupList?.elementAt(index);
      }
    } catch (error) {
      sharePreferences.setInt("currentZyosGroup", 0);
      return currentEnterprise?.zyosGroupList?.first;
    }
  }

  makeBuildingChange(Enterprise? enterprise) async {
    var sharePreferences = await SharedPreferences.getInstance();
    sharePreferences.setString(
      "currentEnterprise",
      jsonEncode(enterprise?.toJson()),
    );
  }
}
