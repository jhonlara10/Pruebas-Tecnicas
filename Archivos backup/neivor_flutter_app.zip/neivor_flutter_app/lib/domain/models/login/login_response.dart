class LoginResponse {
  bool? successLogin;
  String? message;
  String? jwt;

  LoginResponse({this.successLogin, this.message, this.jwt});

  LoginResponse.fromJson(Map<String, dynamic> json) {
    successLogin = json['successLogin'];
    message = json['message'];
    jwt = json['jwt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['successLogin'] = successLogin;
    data['message'] = message;
    data['jwt'] = jwt;
    return data;
  }
}
