class GoogleSignInRequest {
  String? loginAuthType;
  String? apiToken;
  String? photo;
  String? firebaseToken;
  String? email;
  int? appVersion;

  GoogleSignInRequest({
    this.loginAuthType,
    this.apiToken,
    this.photo,
    this.firebaseToken,
    this.email,
    this.appVersion,
  });

  GoogleSignInRequest.fromJson(Map<String, dynamic> json) {
    loginAuthType = json['loginAuthType'];
    apiToken = json['apiToken'];
    photo = json['photo'];
    firebaseToken = json['firebaseToken'];
    email = json['email'];
    appVersion = json['appVersion'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['loginAuthType'] = loginAuthType;
    data['apiToken'] = apiToken;
    data['photo'] = photo;
    data['firebaseToken'] = firebaseToken;
    data['email'] = email;
    data['appVersion'] = appVersion;
    return data;
  }
}
