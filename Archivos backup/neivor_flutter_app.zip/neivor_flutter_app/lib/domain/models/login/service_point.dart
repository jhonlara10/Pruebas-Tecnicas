import 'package:neivor_flutter_app/domain/models/login/operation_zone.dart';

class ServicePoint {
  int? id;
  String? name;
  int? idEnterprise;
  int? legalCharge;
  OperationZone? operationZone;

  ServicePoint({
    this.id,
    this.name,
    this.idEnterprise,
    this.legalCharge,
    this.operationZone,
  });

  ServicePoint.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    idEnterprise = json['idEnterprise'];
    legalCharge = json['legalCharge'];
    operationZone = json['operationZone'] != null
        ? OperationZone.fromJson(json['operationZone'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['idEnterprise'] = idEnterprise;
    data['legalCharge'] = legalCharge;
    if (operationZone != null) {
      data['operationZone'] = operationZone?.toJson();
    }
    return data;
  }
}
