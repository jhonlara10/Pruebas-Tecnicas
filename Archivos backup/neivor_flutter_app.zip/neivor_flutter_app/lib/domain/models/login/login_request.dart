class LoginRequest {
  String? loginAuthType;
  String? userLogin;
  String? password;
  String? firebaseToken;
  String? validationCode;

  LoginRequest({
    this.loginAuthType,
    this.userLogin,
    this.password,
    this.firebaseToken,
    this.validationCode,
  });

  LoginRequest.fromJson(Map<String, dynamic> json) {
    loginAuthType = json['loginAuthType'];
    userLogin = json['userLogin'];
    password = json['password'];
    firebaseToken = json['firebaseToken'];
    validationCode = json['validationCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['loginAuthType'] = loginAuthType;
    data['userLogin'] = userLogin;
    data['password'] = password;
    data['firebaseToken'] = firebaseToken;
    data['validationCode'] = validationCode;
    return data;
  }
}
