class EnterpriseConfiguration {
  double? fineLimitValue;

  EnterpriseConfiguration({this.fineLimitValue});

  EnterpriseConfiguration.fromJson(Map<String, dynamic> json) {
    fineLimitValue = json['fineLimitValue'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['fineLimitValue'] = fineLimitValue;
    return data;
  }
}
