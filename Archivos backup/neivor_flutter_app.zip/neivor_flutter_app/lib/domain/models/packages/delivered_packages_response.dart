class DeliveredPackagesResponse {
  bool? success;
  Info? info;
  List<Data>? data;

  DeliveredPackagesResponse({this.success, this.info, this.data});

  DeliveredPackagesResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data?.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? userChange;
  int? idPackType;
  int? idServicePoint;
  int? idDistributor;
  int? idPackState;
  String? comment;

  Data({
    this.id,
    this.userChange,
    this.idPackType,
    this.idServicePoint,
    this.idDistributor,
    this.idPackState,
    this.comment,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userChange = json['userChange'];
    idPackType = json['idPackType'];
    idServicePoint = json['idServicePoint'];
    idDistributor = json['idDistributor'];
    idPackState = json['idPackState'];
    comment = json['comment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userChange'] = userChange;
    data['idPackType'] = idPackType;
    data['idServicePoint'] = idServicePoint;
    data['idDistributor'] = idDistributor;
    data['idPackState'] = idPackState;
    data['comment'] = comment;
    return data;
  }
}
