class CreatePackRequest {
  int? idPackType;
  int? idServicePoint;
  int? idEnterprise;
  int? idDistributor;
  int? idPackState;
  String? comment;
  int? userCreation;

  CreatePackRequest({
    this.idPackType,
    this.idServicePoint,
    this.idEnterprise,
    this.idDistributor,
    this.idPackState,
    this.comment,
    this.userCreation,
  });

  CreatePackRequest.fromJson(Map<String, dynamic> json) {
    idPackType = json['idPackType'];
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    idDistributor = json['idDistributor'];
    idPackState = json['idPackState'];
    comment = json['comment'];
    userCreation = json['userCreation'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['idPackType'] = idPackType;
    data['idServicePoint'] = idServicePoint;
    data['idEnterprise'] = idEnterprise;
    data['idDistributor'] = idDistributor;
    data['idPackState'] = idPackState;
    data['comment'] = comment;
    data['userCreation'] = userCreation;
    return data;
  }
}
