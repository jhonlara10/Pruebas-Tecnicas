class PackagesDistributorsResponse {
  bool? success;
  Info? info;
  List<Data>? data;

  PackagesDistributorsResponse({this.success, this.info, this.data});

  PackagesDistributorsResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data?.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? state;
  String? name;
  String? image;

  Data({this.id, this.state, this.name, this.image});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    name = json['name'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['name'] = name;
    data['image'] = image;
    return data;
  }
}
