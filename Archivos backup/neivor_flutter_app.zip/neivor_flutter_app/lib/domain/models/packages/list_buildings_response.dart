class ListBuildingsResponse {
  bool? success;
  Data? data;

  ListBuildingsResponse({this.success, this.data});

  ListBuildingsResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Data {
  List<OperationZoneObject>? list;
  int? page;
  int? pageSize;
  int? totalRow;

  Data({this.list, this.page, this.pageSize, this.totalRow});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <OperationZoneObject>[];
      json['list'].forEach((v) {
        list?.add(OperationZoneObject.fromJson(v));
      });
    }
    page = json['page'];
    pageSize = json['pageSize'];
    totalRow = json['totalRow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (list != null) {
      data['list'] = list?.map((v) => v.toJson()).toList();
    }
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['totalRow'] = totalRow;
    return data;
  }
}

class OperationZoneObject {
  int? id;
  int? state;
  int? totalRow;
  int? idEnterprise;
  int? idOperationZone;
  String? reference;
  String? name;
  int? costAdmon;
  int? adminCost;
  int? idZyosUser;
  int? legalCharge;
  OperationZone? operationZone;
  Enterprise? enterprise;

  OperationZoneObject({
    this.id,
    this.state,
    this.totalRow,
    this.idEnterprise,
    this.idOperationZone,
    this.reference,
    this.name,
    this.costAdmon,
    this.adminCost,
    this.idZyosUser,
    this.legalCharge,
    this.operationZone,
    this.enterprise,
  });

  // ignore: long-method
  OperationZoneObject.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    totalRow = json['totalRow'];
    idEnterprise = json['idEnterprise'];
    idOperationZone = json['idOperationZone'];
    reference = json['reference'];
    name = json['name'];
    costAdmon = json['costAdmon'];
    adminCost = json['adminCost'];
    idZyosUser = json['idZyosUser'];
    legalCharge = json['legalCharge'];
    operationZone = json['operationZone'] != null
        ? OperationZone.fromJson(json['operationZone'])
        : null;
    enterprise = json['enterprise'] != null
        ? Enterprise.fromJson(json['enterprise'])
        : null;
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['totalRow'] = totalRow;
    data['idEnterprise'] = idEnterprise;
    data['idOperationZone'] = idOperationZone;
    data['reference'] = reference;
    data['name'] = name;
    data['costAdmon'] = costAdmon;
    data['adminCost'] = adminCost;
    data['idZyosUser'] = idZyosUser;
    data['legalCharge'] = legalCharge;
    if (operationZone != null) {
      data['operationZone'] = operationZone?.toJson();
    }
    if (enterprise != null) {
      data['enterprise'] = enterprise?.toJson();
    }
    return data;
  }
}

class OperationZone {
  int? id;
  String? name;

  OperationZone({this.id, this.name});

  OperationZone.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    return data;
  }
}

class Enterprise {
  int? id;
  String? name;
  String? nameLogo;
  String? paymentData;
  int? idStateEnterprise;
  int? invoiceCount;
  int? startInvoiceConsecutive;
  PaymentDataObj? paymentDataObj;
  CfdiSettingsObj? cfdiSettingsObj;

  Enterprise({
    this.id,
    this.name,
    this.nameLogo,
    this.paymentData,
    this.idStateEnterprise,
    this.invoiceCount,
    this.startInvoiceConsecutive,
    this.paymentDataObj,
    this.cfdiSettingsObj,
  });

  Enterprise.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    nameLogo = json['nameLogo'];
    paymentData = json['paymentData'];
    idStateEnterprise = json['idStateEnterprise'];
    invoiceCount = json['invoiceCount'];
    startInvoiceConsecutive = json['startInvoiceConsecutive'];
    paymentDataObj = json['paymentDataObj'] != null
        ? PaymentDataObj.fromJson(json['paymentDataObj'])
        : null;
    cfdiSettingsObj = json['cfdiSettingsObj'] != null
        ? CfdiSettingsObj.fromJson(json['cfdiSettingsObj'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['nameLogo'] = nameLogo;
    data['paymentData'] = paymentData;
    data['idStateEnterprise'] = idStateEnterprise;
    data['invoiceCount'] = invoiceCount;
    data['startInvoiceConsecutive'] = startInvoiceConsecutive;
    if (paymentDataObj != null) {
      data['paymentDataObj'] = paymentDataObj?.toJson();
    }
    if (cfdiSettingsObj != null) {
      data['cfdiSettingsObj'] = cfdiSettingsObj?.toJson();
    }
    return data;
  }
}

class PaymentDataObj {
  bool? consolidatePayment;
  bool? notShowValuePay;
  bool? sendPaymentSummaryMail;
  bool? allowSubEnterprise;
  // ignore: prefer-correct-identifier-length
  bool? notShowInvoiceInPaymentList;
  String? paymentURL;
  String? agreementID;
  String? enterpriseNumberID;
  String? sftpUser;
  String? sftpPassword;
  String? wizard;
  String? idAdquiriente;
  String? idTerminal;
  int? userInternetPayment;
  int? paymentIntegrationId;

  PaymentDataObj({
    this.consolidatePayment,
    this.notShowValuePay,
    this.sendPaymentSummaryMail,
    this.allowSubEnterprise,
    this.notShowInvoiceInPaymentList,
    this.paymentURL,
    this.agreementID,
    this.enterpriseNumberID,
    this.sftpUser,
    this.sftpPassword,
    this.wizard,
    this.idAdquiriente,
    this.idTerminal,
    this.userInternetPayment,
    this.paymentIntegrationId,
  });

  PaymentDataObj.fromJson(Map<String, dynamic> json) {
    consolidatePayment = json['consolidatePayment'];
    notShowValuePay = json['notShowValuePay'];
    sendPaymentSummaryMail = json['sendPaymentSummaryMail'];
    allowSubEnterprise = json['allowSubEnterprise'];
    notShowInvoiceInPaymentList = json['notShowInvoiceInPaymentList'];
    paymentURL = json['paymentURL'];
    agreementID = json['agreementID'];
    enterpriseNumberID = json['enterpriseNumberID'];
    sftpUser = json['sftpUser'];
    sftpPassword = json['sftpPassword'];
    wizard = json['wizard'];
    idAdquiriente = json['idAdquiriente'];
    idTerminal = json['idTerminal'];
    userInternetPayment = json['userInternetPayment'];
    paymentIntegrationId = json['paymentIntegrationId'];
  }

  // ignore: long-method
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['consolidatePayment'] = consolidatePayment;
    data['notShowValuePay'] = notShowValuePay;
    data['sendPaymentSummaryMail'] = sendPaymentSummaryMail;
    data['allowSubEnterprise'] = allowSubEnterprise;
    data['notShowInvoiceInPaymentList'] = notShowInvoiceInPaymentList;
    data['paymentURL'] = paymentURL;
    data['agreementID'] = agreementID;
    data['enterpriseNumberID'] = enterpriseNumberID;
    data['sftpUser'] = sftpUser;
    data['sftpPassword'] = sftpPassword;
    data['wizard'] = wizard;
    data['idAdquiriente'] = idAdquiriente;
    data['idTerminal'] = idTerminal;
    data['userInternetPayment'] = userInternetPayment;
    data['paymentIntegrationId'] = paymentIntegrationId;
    return data;
  }
}

class CfdiSettingsObj {
  bool? state;
  bool? billAll;
  String? rfc;
  String? swToken;
  String? zipCode;
  String? address;
  String? businessName;
  String? taxRegimeCode;
  String? taxRegimeId;

  CfdiSettingsObj({
    this.state,
    this.billAll,
    this.rfc,
    this.swToken,
    this.zipCode,
    this.address,
    this.businessName,
    this.taxRegimeCode,
    this.taxRegimeId,
  });

  CfdiSettingsObj.fromJson(Map<String, dynamic> json) {
    state = json['state'];
    billAll = json['billAll'];
    rfc = json['rfc'];
    swToken = json['swToken'];
    zipCode = json['zipCode'];
    address = json['address'];
    businessName = json['businessName'];
    taxRegimeCode = json['taxRegimeCode'];
    taxRegimeId = json['taxRegimeId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['state'] = state;
    data['billAll'] = billAll;
    data['rfc'] = rfc;
    data['swToken'] = swToken;
    data['zipCode'] = zipCode;
    data['address'] = address;
    data['businessName'] = businessName;
    data['taxRegimeCode'] = taxRegimeCode;
    data['taxRegimeId'] = taxRegimeId;
    return data;
  }
}
