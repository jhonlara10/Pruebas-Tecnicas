class OperationZonesResponse {
  bool? success;
  Data? data;

  OperationZonesResponse({this.success, this.data});

  OperationZonesResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Data {
  List<OperationZoneObject>? list;
  int? page;
  int? pageSize;
  int? totalRow;

  Data({this.list, this.page, this.pageSize, this.totalRow});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <OperationZoneObject>[];
      json['list'].forEach((v) {
        list?.add(OperationZoneObject.fromJson(v));
      });
    }
    page = json['page'];
    pageSize = json['pageSize'];
    totalRow = json['totalRow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (list != null) {
      data['list'] = list?.map((v) => v.toJson()).toList();
    }
    data['page'] = page;
    data['pageSize'] = pageSize;
    data['totalRow'] = totalRow;
    return data;
  }
}

class OperationZoneObject {
  int? id;
  int? state;
  int? totalRow;
  String? name;
  String? description;
  int? idEnterprise;
  int? idBuildingType;

  OperationZoneObject({
    this.id,
    this.state,
    this.totalRow,
    this.name,
    this.description,
    this.idEnterprise,
    this.idBuildingType,
  });

  OperationZoneObject.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    state = json['state'];
    totalRow = json['totalRow'];
    name = json['name'];
    description = json['description'];
    idEnterprise = json['idEnterprise'];
    idBuildingType = json['idBuildingType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['state'] = state;
    data['totalRow'] = totalRow;
    data['name'] = name;
    data['description'] = description;
    data['idEnterprise'] = idEnterprise;
    data['idBuildingType'] = idBuildingType;
    return data;
  }
}
