class CreatePackResponse {
  bool? success;
  Info? info;
  Data? data;

  CreatePackResponse({this.success, this.info, this.data});

  CreatePackResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class Data {
  int? id;
  int? userCreation;
  int? idPackType;
  int? idServicePoint;
  int? idEnterprise;
  int? idDistributor;
  int? idPackState;
  String? comment;

  Data({
    this.id,
    this.userCreation,
    this.idPackType,
    this.idServicePoint,
    this.idEnterprise,
    this.idDistributor,
    this.idPackState,
    this.comment,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCreation = json['userCreation'];
    idPackType = json['idPackType'];
    idServicePoint = json['idServicePoint'];
    idEnterprise = json['idEnterprise'];
    idDistributor = json['idDistributor'];
    idPackState = json['idPackState'];
    comment = json['comment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['userCreation'] = userCreation;
    data['idPackType'] = idPackType;
    data['idServicePoint'] = idServicePoint;
    data['idEnterprise'] = idEnterprise;
    data['idDistributor'] = idDistributor;
    data['idPackState'] = idPackState;
    data['comment'] = comment;
    return data;
  }
}
