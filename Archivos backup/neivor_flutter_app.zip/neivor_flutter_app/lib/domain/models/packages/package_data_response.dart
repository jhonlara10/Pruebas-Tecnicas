class PackageDataResponse {
  bool? success;
  Data? data;

  PackageDataResponse({this.success, this.data});

  PackageDataResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (this.data != null) {
      data['data'] = this.data?.toJson();
    }
    return data;
  }
}

class Data {
  List<PackageDataObject>? list;
  int? totalRow;

  Data({this.list, this.totalRow});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <PackageDataObject>[];
      json['list'].forEach((v) {
        list?.add(PackageDataObject.fromJson(v));
      });
    }
    totalRow = json['totalRow'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (list != null) {
      data['list'] = list?.map((v) => v.toJson()).toList();
    }
    data['totalRow'] = totalRow;
    return data;
  }
}

class PackageDataObject {
  int? id;
  double? dateCreation;
  int? totalRow;
  int? idPackType;
  int? idServicePoint;
  int? idDistributor;
  int? idPackState;
  int? userChange;
  String? comment;
  String? packTypeName;
  String? imageDistributor;

  PackageDataObject({
    this.id,
    this.dateCreation,
    this.totalRow,
    this.idPackType,
    this.idServicePoint,
    this.idDistributor,
    this.comment,
    this.packTypeName,
    this.imageDistributor,
    this.idPackState,
    this.userChange,
  });

  PackageDataObject.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    totalRow = json['totalRow'];
    idPackType = json['idPackType'];
    idServicePoint = json['idServicePoint'];
    idDistributor = json['idDistributor'];
    comment = json['comment'];
    packTypeName = json['packTypeName'];
    imageDistributor = json['imageDistributor'];
    idPackState = json['idPackState'];
    userChange = json['userChange'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['totalRow'] = totalRow;
    data['idPackType'] = idPackType;
    data['idServicePoint'] = idServicePoint;
    data['idDistributor'] = idDistributor;
    data['comment'] = comment;
    data['packTypeName'] = packTypeName;
    data['imageDistributor'] = imageDistributor;
    data['idPackState'] = idPackState;
    data['userChange'] = userChange;
    return data;
  }
}
