// ignore: prefer-correct-type-name
class KushkiCardSuscriptionResponse {
  String? subscriptionId;
  String? userId;

  KushkiCardSuscriptionResponse({this.subscriptionId, this.userId});

  KushkiCardSuscriptionResponse.fromJson(Map<String, dynamic> json) {
    subscriptionId = json['subscriptionId'];
    userId = json['userId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['subscriptionId'] = subscriptionId;
    data['userId'] = userId;
    return data;
  }
}
