class KushkiSettingsResponse {
  String? country;
  String? merchantName;
  String? prodAccountId;
  String? prodBaconKey;
  String? sandboxAccountId;
  String? sandboxBaconKey;
  bool? active3dsecure;
  Processors? processors;
  String? processorName;

  KushkiSettingsResponse({
    this.country,
    this.merchantName,
    this.prodAccountId,
    this.prodBaconKey,
    this.sandboxAccountId,
    this.sandboxBaconKey,
    this.active3dsecure,
    this.processors,
    this.processorName,
  });

  KushkiSettingsResponse.fromJson(Map<String, dynamic> json) {
    country = json['country'];
    merchantName = json['merchant_name'];
    prodAccountId = json['prodAccountId'];
    prodBaconKey = json['prodBaconKey'];
    sandboxAccountId = json['sandboxAccountId'];
    sandboxBaconKey = json['sandboxBaconKey'];
    active3dsecure = json['active_3dsecure'];
    processors = json['processors'] != null
        ? Processors.fromJson(json['processors'])
        : null;
    processorName = json['processor_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['country'] = country;
    data['merchant_name'] = merchantName;
    data['prodAccountId'] = prodAccountId;
    data['prodBaconKey'] = prodBaconKey;
    data['sandboxAccountId'] = sandboxAccountId;
    data['sandboxBaconKey'] = sandboxBaconKey;
    data['active_3dsecure'] = active3dsecure;
    if (processors != null) {
      data['processors'] = processors?.toJson();
    }
    data['processor_name'] = processorName;
    return data;
  }
}

class Processors {
  List<String>? achTransfer;
  List<Card>? card;
  List<String>? cash;
  List<String>? payoutsCash;
  List<String>? payoutsTransfer;
  List<String>? transfer;
  List<String>? transferSubscriptions;

  Processors({
    this.achTransfer,
    this.card,
    this.cash,
    this.payoutsCash,
    this.payoutsTransfer,
    this.transfer,
    this.transferSubscriptions,
  });

  Processors.fromJson(Map<String, dynamic> json) {
    achTransfer = json['ach transfer'].cast<String>();
    if (json['card'] != null) {
      card = <Card>[];
      json['card'].forEach((v) {
        card?.add(Card.fromJson(v));
      });
    }
    cash = json['cash'].cast<String>();
    payoutsCash = json['payouts-cash'].cast<String>();
    payoutsTransfer = json['payouts-transfer'].cast<String>();
    transfer = json['transfer'].cast<String>();
    transferSubscriptions = json['transfer-subscriptions'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ach transfer'] = achTransfer;
    if (card != null) {
      data['card'] = card?.map((v) => v.toJson()).toList();
    }
    data['cash'] = cash;
    data['payouts-cash'] = payoutsCash;
    data['payouts-transfer'] = payoutsTransfer;
    data['transfer'] = transfer;
    data['transfer-subscriptions'] = transferSubscriptions;
    return data;
  }
}

class Card {
  String? processorName;

  Card({this.processorName});

  Card.fromJson(Map<String, dynamic> json) {
    processorName = json['processorName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['processorName'] = processorName;
    return data;
  }
}
