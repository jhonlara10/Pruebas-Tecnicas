class PaymentMethodResponse {
  Error? error;
  PaymentMethodOperation? paymentMethodOperation;
  bool? success;

  PaymentMethodResponse({
    this.error,
    this.paymentMethodOperation,
    this.success,
  });

  PaymentMethodResponse.fromJson(Map<String, dynamic> json) {
    error = json['error'] != null ? Error.fromJson(json['error']) : null;
    paymentMethodOperation = json['paymentMethodOperation'] != null
        ? PaymentMethodOperation.fromJson(json['paymentMethodOperation'])
        : null;
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (error != null) {
      data['error'] = error?.toJson();
    }
    if (paymentMethodOperation != null) {
      data['paymentMethodOperation'] = paymentMethodOperation?.toJson();
    }
    data['success'] = success;
    return data;
  }
}

class Error {
  String? message;

  Error({this.message});

  Error.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}

class PaymentMethodOperation {
  bool? redirect;
  bool? formInscription;
  bool? subscription;
  bool? successDelete;
  String? subscriptionId;
  PaymentMethodApproved? paymentMethodApproved;

  PaymentMethodOperation({
    this.redirect,
    this.formInscription,
    this.subscription,
    this.successDelete,
    this.subscriptionId,
    this.paymentMethodApproved,
  });

  PaymentMethodOperation.fromJson(Map<String, dynamic> json) {
    redirect = json['redirect'];
    formInscription = json['formInscription'];
    subscription = json['subscription'];
    successDelete = json['successDelete'];
    subscriptionId = json['subscriptionId'];
    paymentMethodApproved = json['paymentMethodApproved'] != null
        ? PaymentMethodApproved.fromJson(json['paymentMethodApproved'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['redirect'] = redirect;
    data['formInscription'] = formInscription;
    data['subscription'] = subscription;
    data['successDelete'] = successDelete;
    data['subscriptionId'] = subscriptionId;
    if (paymentMethodApproved != null) {
      data['paymentMethodApproved'] = paymentMethodApproved?.toJson();
    }
    return data;
  }
}

class PaymentMethodApproved {
  int? id;
  double? dateCreation;
  int? userCreation;
  int? state;
  String? name;
  int? idZyosUser;
  int? idPaymentMethodType;
  String? codTransaction;
  String? activationState;
  int? idEnterprise;
  Payer? payer;

  PaymentMethodApproved({
    this.id,
    this.dateCreation,
    this.userCreation,
    this.state,
    this.name,
    this.idZyosUser,
    this.idPaymentMethodType,
    this.codTransaction,
    this.activationState,
    this.idEnterprise,
    this.payer,
  });

  PaymentMethodApproved.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreation = json['dateCreation'];
    userCreation = json['userCreation'];
    state = json['state'];
    name = json['name'];
    idZyosUser = json['idZyosUser'];
    idPaymentMethodType = json['idPaymentMethodType'];
    codTransaction = json['codTransaction'];
    activationState = json['activationState'];
    idEnterprise = json['idEnterprise'];
    payer = json['payer'] != null ? Payer.fromJson(json['payer']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['dateCreation'] = dateCreation;
    data['userCreation'] = userCreation;
    data['state'] = state;
    data['name'] = name;
    data['idZyosUser'] = idZyosUser;
    data['idPaymentMethodType'] = idPaymentMethodType;
    data['codTransaction'] = codTransaction;
    data['activationState'] = activationState;
    data['idEnterprise'] = idEnterprise;
    if (payer != null) {
      data['payer'] = payer?.toJson();
    }
    return data;
  }
}

class Payer {
  String? email;
  String? documentNumber;
  String? name;
  String? lastname;
  String? contactPhone;

  Payer({
    this.email,
    this.documentNumber,
    this.name,
    this.lastname,
    this.contactPhone,
  });

  Payer.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    documentNumber = json['documentNumber'];
    name = json['name'];
    lastname = json['lastname'];
    contactPhone = json['contactPhone'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['documentNumber'] = documentNumber;
    data['name'] = name;
    data['lastname'] = lastname;
    data['contactPhone'] = contactPhone;
    return data;
  }
}
