class PaymentTokenResponse {
  String? code;
  String? message;
  String? processorError;
  String? token;

  PaymentTokenResponse({
    this.code,
    this.message,
    this.processorError,
    this.token,
  });

  PaymentTokenResponse.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
    processorError = json['processorError'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['code'] = code;
    data['message'] = message;
    data['processorError'] = processorError;
    data['token'] = token;
    return data;
  }
}
