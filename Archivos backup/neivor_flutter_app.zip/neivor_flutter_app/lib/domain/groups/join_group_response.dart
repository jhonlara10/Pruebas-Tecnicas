class JoinGroupResponse {
  bool? success;
  Info? info;
  Info? error;

  JoinGroupResponse({this.success, this.info, this.error});

  JoinGroupResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    info = json['info'] != null ? Info.fromJson(json['info']) : null;
    error = json['error'] != null ? Info.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    if (info != null) {
      data['info'] = info?.toJson();
    }
    if (error != null) {
      data['error'] = error?.toJson();
    }
    return data;
  }
}

class Info {
  String? message;

  Info({this.message});

  Info.fromJson(Map<String, dynamic> json) {
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    return data;
  }
}
