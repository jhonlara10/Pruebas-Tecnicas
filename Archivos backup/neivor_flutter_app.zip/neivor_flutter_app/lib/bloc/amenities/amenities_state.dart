part of 'amenities_bloc.dart';

class AmenitiesState extends Equatable {
  final ServicePointObject? selectedServicePoint;
  const AmenitiesState({this.selectedServicePoint});

  AmenitiesState copyWith({ServicePointObject? newSelectedServicePoint}) {
    return AmenitiesState(
      selectedServicePoint: newSelectedServicePoint ?? selectedServicePoint,
    );
  }

  @override
  List<Object?> get props => [selectedServicePoint];
}
