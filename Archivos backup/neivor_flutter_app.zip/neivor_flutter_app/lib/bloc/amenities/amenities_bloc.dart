import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';

part 'amenities_event.dart';
part 'amenities_state.dart';

class AmenitiesBloc extends Bloc<AmenitiesEvent, AmenitiesState> {
  AmenitiesBloc() : super(const AmenitiesState(selectedServicePoint: null)) {
    on<NewSelectedServicePoint>((event, emit) {
      emit(state.copyWith(newSelectedServicePoint: event.selectedServicePoint));
    });
  }
}
