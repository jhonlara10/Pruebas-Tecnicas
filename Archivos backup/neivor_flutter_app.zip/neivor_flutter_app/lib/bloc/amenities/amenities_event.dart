part of 'amenities_bloc.dart';

abstract class AmenitiesEvent extends Equatable {
  const AmenitiesEvent();

  @override
  List<Object> get props => [];
}

class NewSelectedServicePoint extends AmenitiesEvent {
  final ServicePointObject selectedServicePoint;

  const NewSelectedServicePoint({required this.selectedServicePoint});
}
