import 'package:bloc/bloc.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';

part 'relationship_event.dart';
part 'relationship_state.dart';

class RelationshipBloc extends Bloc<RelationshipEvent, RelationshipState> {
  RelationshipBloc() : super(RelationshipInitial()) {
    on<SetNewRelations>((event, emit) {
      if (event.newRelationList != null &&
          (event.newRelationList?.isNotEmpty ?? false)) {
        event.newRelationList?.sort(
          //ignore: avoid-non-null-assertion
          (a, b) => a.name!.compareTo(b.name!),
        );
      }
      emit(RelationSetState(event.newRelationList));
    });
  }
}
