part of 'relationship_bloc.dart';

abstract class RelationshipEvent {}

class SetNewRelations extends RelationshipEvent {
  final List<Relationship>? newRelationList;

  SetNewRelations(this.newRelationList);
}
