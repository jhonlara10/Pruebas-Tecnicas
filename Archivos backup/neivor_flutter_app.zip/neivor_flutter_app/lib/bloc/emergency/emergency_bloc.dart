import 'package:bloc/bloc.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';

part 'emergency_event.dart';
part 'emergency_state.dart';

class EmergencyBloc extends Bloc<EmergencyEvent, EmergencyState> {
  EmergencyBloc() : super(EmergencyInitial()) {
    on<SetNewEmergencyData>((event, emit) {
      emit(EmergencySetDataState(event.newEmergencyData));
    });
  }
}
