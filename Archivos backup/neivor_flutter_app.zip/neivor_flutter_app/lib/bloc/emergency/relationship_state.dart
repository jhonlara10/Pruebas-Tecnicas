part of 'relationship_bloc.dart';

abstract class RelationshipState {
  final List<Relationship>? relationsList;

  const RelationshipState(this.relationsList);
}

class RelationshipInitial extends RelationshipState {
  RelationshipInitial() : super([]);
}

class RelationSetState extends RelationshipState {
  final List<Relationship>? newRelationList;

  const RelationSetState(this.newRelationList) : super(newRelationList);
}
