part of 'emergency_bloc.dart';

abstract class EmergencyEvent {}

class SetNewEmergencyData extends EmergencyEvent {
  final List<EmergencyData>? newEmergencyData;

  SetNewEmergencyData(this.newEmergencyData);
}
