part of 'emergency_bloc.dart';

abstract class EmergencyState {
  final List<EmergencyData>? emergencyData;

  const EmergencyState(this.emergencyData);
}

class EmergencyInitial extends EmergencyState {
  EmergencyInitial() : super([]);
}

class EmergencySetDataState extends EmergencyState {
  final List<EmergencyData>? newEmergencyData;

  const EmergencySetDataState(this.newEmergencyData) : super(newEmergencyData);
}
