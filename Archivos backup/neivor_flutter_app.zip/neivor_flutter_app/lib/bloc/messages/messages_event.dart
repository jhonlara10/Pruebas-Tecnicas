part of 'messages_bloc.dart';

abstract class MessagesEvent extends Equatable {
  const MessagesEvent();

  @override
  List<Object> get props => [];
}

class NewMessagesEvent extends MessagesEvent {
  final List<GetChatMsgsResponse> messagesList;

  const NewMessagesEvent({required this.messagesList});
}

class NewNeighborsList extends MessagesEvent {
  final List<NeighborsResponse> neighborsList;

  const NewNeighborsList({required this.neighborsList});
}
