import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/domain/models/chat_messages/get_chat_msgs_response.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';

part 'messages_event.dart';
part 'messages_state.dart';

class MessagesBloc extends Bloc<MessagesEvent, MessagesState> {
  MessagesBloc()
      : super(const MessagesState(messagesList: [], neighborsList: [])) {
    on<NewMessagesEvent>((event, emit) {
      emit(state.copyWith(newMessagesList: event.messagesList));
    });
    on<NewNeighborsList>((event, emit) {
      emit(state.copyWith(newNeighborsList: event.neighborsList));
    });
  }
}
