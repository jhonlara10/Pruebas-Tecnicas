part of 'messages_bloc.dart';

class MessagesState extends Equatable {
  final List<GetChatMsgsResponse>? messagesList;
  final List<NeighborsResponse>? neighborsList;

  const MessagesState({this.messagesList, this.neighborsList});

  MessagesState copyWith({
    List<GetChatMsgsResponse>? newMessagesList,
    List<NeighborsResponse>? newNeighborsList,
  }) {
    return MessagesState(
      messagesList: newMessagesList ?? messagesList,
      neighborsList: newNeighborsList ?? neighborsList,
    );
  }

  @override
  List<Object> get props => [
        messagesList ?? [],
        neighborsList ?? [],
      ];
}
