part of 'wall_notifications_bloc.dart';

abstract class WallNotificationsEvent extends Equatable {
  const WallNotificationsEvent();

  @override
  List<Object> get props => [];
}

class NewShowSpeiNotification extends WallNotificationsEvent {
  final bool showSpeiNotification;

  const NewShowSpeiNotification({required this.showSpeiNotification});
}

class NewSuccessfulPayment extends WallNotificationsEvent {
  final bool successfulPayment;

  const NewSuccessfulPayment({required this.successfulPayment});
}

// ignore: prefer-correct-type-name
class NewPaymentPendingAssociate extends WallNotificationsEvent {
  final bool paymentPendingAssociate;

  const NewPaymentPendingAssociate({required this.paymentPendingAssociate});
}

class NewCurrentLegalCharge extends WallNotificationsEvent {
  final int currentLegalCharge;

  const NewCurrentLegalCharge({required this.currentLegalCharge});
}

class NewMessageId extends WallNotificationsEvent {
  final String messageId;

  const NewMessageId({required this.messageId});
}
