import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

part 'wall_notifications_event.dart';
part 'wall_notifications_state.dart';

class WallNotificationsBloc
    extends Bloc<WallNotificationsEvent, WallNotificationsState> {
  WallNotificationsBloc()
      : super(WallNotificationsState(
          showSpeiNotification: false,
          paymentPendingAssociate: false,
          successfulPayment: false,
          currentLegalCharge: UserUtils.currentServicePoint?.legalCharge ?? 0,
          messageId: "",
        )) {
    on<NewShowSpeiNotification>((event, emit) {
      emit(state.copyWith(
        newShowSpeiNotification: event.showSpeiNotification,
      ));
    });
    on<NewSuccessfulPayment>((event, emit) {
      emit(state.copyWith(
        newSuccessfulPayment: event.successfulPayment,
      ));
    });
    on<NewPaymentPendingAssociate>((event, emit) {
      emit(state.copyWith(
        newPaymentPendingAssociate: event.paymentPendingAssociate,
      ));
    });
    on<NewCurrentLegalCharge>((event, emit) {
      emit(state.copyWith(
        newCurrentLegalCharge: event.currentLegalCharge,
      ));
    });
    on<NewMessageId>((event, emit) {
      emit(state.copyWith(
        newMessageId: event.messageId,
      ));
    });
  }
}
