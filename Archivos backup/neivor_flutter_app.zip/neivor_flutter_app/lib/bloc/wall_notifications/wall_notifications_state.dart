part of 'wall_notifications_bloc.dart';

class WallNotificationsState extends Equatable {
  final bool? showSpeiNotification;
  final bool? successfulPayment;
  final bool? paymentPendingAssociate;
  final int currentLegalCharge;
  final String? messageId;
  const WallNotificationsState({
    this.successfulPayment,
    this.paymentPendingAssociate,
    this.showSpeiNotification,
    this.currentLegalCharge = 0,
    this.messageId,
  });

  WallNotificationsState copyWith({
    bool? newShowSpeiNotification,
    bool? newSuccessfulPayment,
    bool? newPaymentPendingAssociate,
    int? newCurrentLegalCharge,
    String? newMessageId,
  }) {
    return WallNotificationsState(
      showSpeiNotification: newShowSpeiNotification ?? showSpeiNotification,
      paymentPendingAssociate:
          newPaymentPendingAssociate ?? paymentPendingAssociate,
      successfulPayment: newSuccessfulPayment ?? newSuccessfulPayment,
      currentLegalCharge: newCurrentLegalCharge ?? currentLegalCharge,
      messageId: newMessageId ?? messageId,
    );
  }

  @override
  List<Object?> get props => [
        showSpeiNotification,
        paymentPendingAssociate,
        successfulPayment,
        currentLegalCharge,
        messageId,
      ];
}
