part of 'payments_bloc.dart';

class PaymentsState extends Equatable {
  final PendingTransactionResponse? pendingTransactionData;
  final List<Invoice>? selectedDebts;
  final HeaderAdminResponse? balance;
  final ConciliationResponse? selectedConciliation;
  const PaymentsState({
    this.selectedDebts,
    this.pendingTransactionData,
    this.balance,
    this.selectedConciliation,
  });

  PaymentsState copyWith({
    PendingTransactionResponse? newPendingTransactionData,
    List<Invoice>? newSelectedDebts,
    HeaderAdminResponse? newBalance,
    ConciliationResponse? newSelectedConciliation,
  }) {
    return PaymentsState(
      selectedDebts: newSelectedDebts ?? selectedDebts,
      pendingTransactionData:
          newPendingTransactionData ?? pendingTransactionData,
      balance: newBalance ?? balance,
      selectedConciliation: newSelectedConciliation ?? selectedConciliation,
    );
  }

  @override
  List<Object?> get props => [
        pendingTransactionData,
        selectedDebts,
        balance,
        selectedConciliation,
      ];
}
