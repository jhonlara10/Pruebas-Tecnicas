import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:neivor_flutter_app/domain/models/payment/collections/header_admin_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';

part 'payments_event.dart';
part 'payments_state.dart';

class PaymentsBloc extends Bloc<PaymentsEvent, PaymentsState> {
  // ignore: long-method
  PaymentsBloc()
      : super(const PaymentsState(
          pendingTransactionData: null,
          selectedDebts: null,
          balance: null,
          selectedConciliation: null,
        )) {
    on<NewPendingTransaction>((event, emit) {
      emit(state.copyWith(
        newPendingTransactionData: event.pendingTransactionData,
      ));
    });
    on<NewSelectedDebts>((event, emit) {
      emit(state.copyWith(
        newSelectedDebts: event.selectedDebts,
      ));
    });
    on<NewBalance>((event, emit) {
      emit(state.copyWith(
        newBalance: event.balance,
      ));
    });
    on<NewSelectedConciliation>((event, emit) {
      emit(state.copyWith(
        newSelectedConciliation: event.selectedConciliation,
      ));
    });
  }
}
