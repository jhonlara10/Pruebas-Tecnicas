part of 'payments_bloc.dart';

abstract class PaymentsEvent extends Equatable {
  const PaymentsEvent();

  @override
  List<Object> get props => [];
}

class NewPendingTransaction extends PaymentsEvent {
  final PendingTransactionResponse pendingTransactionData;

  const NewPendingTransaction({required this.pendingTransactionData});
}

class NewSelectedDebts extends PaymentsEvent {
  final List<Invoice> selectedDebts;

  const NewSelectedDebts({required this.selectedDebts});
}

class NewBalance extends PaymentsEvent {
  final HeaderAdminResponse balance;

  const NewBalance({required this.balance});
}

class NewSelectedConciliation extends PaymentsEvent {
  final ConciliationResponse? selectedConciliation;

  const NewSelectedConciliation({required this.selectedConciliation});
}
