part of 'login_bloc.dart';

class LoginState extends Equatable {
  final bool? firstLogin;
  const LoginState({this.firstLogin});

  LoginState copyWith({
    bool? newFirstLogin,
  }) {
    return LoginState(
      firstLogin: newFirstLogin,
    );
  }

  @override
  List<Object?> get props => [firstLogin];
}

class LoginInitial extends LoginState {}
