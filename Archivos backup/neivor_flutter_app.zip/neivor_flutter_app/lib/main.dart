import 'package:chucker_flutter/chucker_flutter.dart';
import 'package:clevertap_plugin/clevertap_plugin.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/domain/models/notification/notification_data.dart';
import 'package:neivor_flutter_app/presentation/splash/splash.dart';
import 'package:neivor_flutter_app/presentation/util/app_blocs.dart';
import 'package:neivor_flutter_app/presentation/util/app_routes.dart';
import 'package:neivor_flutter_app/presentation/util/notification_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart' as material_theme;

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();
  print('Handling a background message ${message.data.toString()}');
}

// ignore: long-method
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // ignore: prefer-correct-identifier-length
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // ignore: no-empty-block
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    print('Message data: ${message.data}');
    NotificationData data = NotificationData.fromJson(message.data);
    NotificationUtils().processSpeiWallNotification(data);
    if (message.notification != null) {
      print('Message also contained a notification: ${message.notification}');
    }
  });

  CleverTapPlugin.createNotificationChannel(
    "neivor",
    "Neivor",
    "Neivor",
    3,
    true,
  );
  CleverTapPlugin.initializeInbox();
  CleverTapPlugin.registerForPush();

  /// This needs to be ON only when this build will delivered to QA team.
  ChuckerFlutter.showOnRelease = true;
  await FlutterDownloader.initialize(debug: true);

  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('ic_launcher');

  final IOSInitializationSettings initializationSettingsIOS =
      IOSInitializationSettings(
    requestAlertPermission: false,
    requestBadgePermission: false,
    requestSoundPermission: false,
    onDidReceiveLocalNotification: (
      int id,
      String? title,
      String? body,
      String? payload,
    ) async {
      print(payload ?? "");
    },
  );

  var initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
    iOS: initializationSettingsIOS,
  );

  flutterLocalNotificationsPlugin.initialize(
    initializationSettings,
    onSelectNotification: (String? payload) async {
      print('notification payload: $payload');
    },
  );

  runApp(
    const Main(),
  );
}

class Main extends StatelessWidget {
  const Main({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GlobalLoaderOverlay(
      child: MultiBlocProvider(
        providers: AppBlocs.providersList,
        child: AppTheme(child: Builder(builder: (context) {
          return MaterialApp(
            navigatorKey: navigatorKey,
            debugShowCheckedModeBanner: false,
            title: 'Neivor',
            theme: material_theme.AppTheme.lightTheme.copyWith(
              scaffoldBackgroundColor:
                  AppThemeScope.of(context).colors.backgrounds.main,
            ),
            navigatorObservers: [ChuckerFlutter.navigatorObserver],
            home: const Splash(),
            routes: AppRoutes.routes,
          );
        })),
      ),
    );
  }
}
