import 'dart:convert';
import 'package:neivor_flutter_app/domain/models/settings/copy.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppMessages {
  static dynamic preferences;

  getPreferences() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    preferences = jsonDecode(sharedPreferences.getString("copies") ?? "");
  }

  /// Obtain message value from specific key on database.
  ///
  /// Returns [String] value of combination key/value from list.
  @Deprecated("""Use [getCopy] instead
    due the asyncronous call we decide to use non asynchronous calls 
  """)
  Future<String> getMessage(key) async {
    var sharedPreferences = await SharedPreferences.getInstance();
    var copiesJson = jsonDecode(sharedPreferences.getString("copies") ?? "");
    var filteredJson = copiesJson.where((val) => val["key"] == key).toList();
    return Copy.fromJson(filteredJson[0]).value ?? "";
  }

  /// Returns the message that matches with the given [key].
  ///
  /// If a list is passed as the second parameter it will replace the slots of
  /// the messages with the values in the list and returns the new message.
  ///
  /// examples:
  /// ```dart
  /// getCopy('my key') // 'Hi {0}, this is my message.'
  /// getCopy('my key', ['Jhon']) // 'Hi Jhon, this is my message'
  /// ```
  String getCopy(String? key, [List<String>? values]) {
    if (preferences == null) {
      getPreferences();
    }
    var filteredJson = preferences?.where((val) => val["key"] == key).toList();
    String copy = (filteredJson?.length ?? 0) > 0
        ? Copy.fromJson(filteredJson.elementAt(0)).value ?? ""
        : "";

    if (values != null) {
      for (var i = 0; i < values.length; i++) {
        copy = copy.replaceAll('{$i}', values[i]);
      }
    }
    return copy;
  }
}
