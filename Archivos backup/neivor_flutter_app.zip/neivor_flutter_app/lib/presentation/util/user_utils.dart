import 'dart:convert';
import 'package:neivor_flutter_app/data/repository/general/general_repository_impl.dart'
    as general;
import 'package:neivor_flutter_app/domain/models/general/permissions_request.dart';
import 'package:neivor_flutter_app/domain/models/general/Permission.dart';
import 'package:neivor_flutter_app/domain/models/login/enterprise.dart';
import 'package:neivor_flutter_app/domain/models/login/service_point.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/login/zyos_group.dart';
import 'package:shared_preferences/shared_preferences.dart';

//This class contains the current user data and curren user specific
// data getters
class UserUtils {
  static const int idAdmin = 2;
  static const int idSecurity = 8;
  static User? currentUser;
  static Enterprise? currentEnterprise;
  static ServicePoint? currentServicePoint;
  static ZyosGroup? currentZyosGroup;
  static dynamic preferences;

  getPreferences() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    preferences = jsonDecode(sharedPreferences.getString("permissions") ?? "");
  }

  /// It gets the current user from the database and stores it in the currentUser variable.
  getCurrentUser() async {
    currentUser = await User().getCurrentUser();
  }

  getCurrentEnterprise() async {
    getCurrentUser();
    currentEnterprise = await currentUser?.getCurrentEnterprise();
  }

  getCurrentServicePoint() async {
    getCurrentUser();
    currentServicePoint = await currentUser?.getCurrentServicePoint();
  }

  getCurrentZyosGroup() async {
    getCurrentUser();
    currentZyosGroup = await currentUser?.getCurrentRole();
  }

  getPermissions() async {
    await getCurrentUser();
    await getCurrentEnterprise();
    await getCurrentZyosGroup();
    final prefs = await SharedPreferences.getInstance();
    PermissionsRequest body = PermissionsRequest.defaultValues();
    var response = await general.getPermissions(body);
    prefs.setString('permissions', jsonEncode(response));
    getPreferences();
  }

  /// If the current user is in the admin group, return true, otherwise return false
  ///
  /// Returns:
  ///   A boolean value.
  isAdminUser() {
    try {
      return currentZyosGroup?.id == idAdmin ? true : false;
    } catch (error) {
      return false;
    }
  }

  /// If the current user is in the security group, return true, otherwise return false
  ///
  /// Returns:
  ///   A boolean value.
  isSecurityUser() {
    try {
      return currentZyosGroup?.id == idSecurity ? true : false;
    } catch (error) {
      return false;
    }
  }

  /// Returns the a function to evaluate if the user has permission to a specific
  /// functionality, if the user doesn't have permissions in this module returns false
  ///
  /// The returned function accepts the id of the functionality to evaluate and returns a boolean
  // ignore: long-method
  hasPermissionsTo(int idFunctionality) {
    if (preferences == null) {
      getPreferences();
    }
    final List<Permission> userPermissions = List<Permission>.from(
      (preferences ?? []).map(
        (e) => Permission.fromJson(e),
      ),
    );
    return userPermissions.any((element) => element.id == idFunctionality);
  }
}
