import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';

class Constants {
  static const spanishLanguage = "1";
  static const englishLanguage = "2";
  static const mxIdCode = "156";
  static const coIdCode = "49";
  static const mxIntIdCode = 156;
  static const mxIntIdCodeTest = 246;
  static const coIntIdCode = 49;
  static const esCode = "es";
  static const appSource = 1;
  static const delaySplashDuration = 3;

  /// Production key, to use uncomment this one and comment bottom one.
  static const enviromentKey =
      "b7lWpPRnRUnfHhRHrDQWb21f1vjHdlpkeu3G7M7HBBZgDccwdI";

  /// Test key, to use uncomment this one and comment top one
  // static const enviromentKey =
  //     "8KGEHEChQbxWbHeFJVCgp1Pmc9qTatzhqP5vSg44o0IK0sxWSY";

  static const formAccess = "formAccess";
  static const validationCode = "validationCode";
  // ignore: prefer-correct-identifier-length
  static const youtubeAndVimeoRegexExpression =
      r"(http:\/\/|https:\/\/)(vimeo\.com|youtu\.be|www\.youtube\.com)\/([\w\/]+)([\?].*)";
  static const idImagePublicationType = 1;
  static const idVideoPublicationType = 6;
  static const idtTextPublicationType = 3;
  static final List<DropdownMenuItem<int>> sendMailOptions = [
    DropdownMenuItem(
      value: 0,
      child: Text(AppMessages().getCopy('news.select-one')),
    ),
    DropdownMenuItem(
      value: 1,
      child: Text(AppMessages().getCopy('news.do-not-send')),
    ),
    DropdownMenuItem(
      value: 2,
      child: Text(AppMessages().getCopy('news.sent-to-neighbords')),
    ),
  ];

  static final List<DropdownMenuItem<int>> categoryOptions = [
    DropdownMenuItem(
      value: 0,
      child: Text(AppMessages().getCopy('news.select-one')),
    ),
    DropdownMenuItem(
      value: 1,
      child: Text(AppMessages().getCopy('news.public-service-cut')),
    ),
    DropdownMenuItem(
      value: 2,
      child: Text(AppMessages().getCopy('news.repair')),
    ),
    DropdownMenuItem(
      value: 3,
      child: Text(AppMessages().getCopy('common.message')),
    ),
    DropdownMenuItem(
      value: 4,
      child: Text(AppMessages().getCopy('news.information')),
    ),
    DropdownMenuItem(
      value: 5,
      child: Text(AppMessages().getCopy('news.generic')),
    ),
    DropdownMenuItem(
      value: 6,
      child: Text(AppMessages().getCopy('news.advertising')),
    ),
  ];

  static final List<DropdownMenuItem<int>> typeNewsOptions = [
    DropdownMenuItem(
      value: 3,
      child: Text(AppMessages().getCopy('news.select-one')),
    ),
    DropdownMenuItem(
      value: 1,
      child: Text(AppMessages().getCopy('news.news-with-image')),
    ),
    DropdownMenuItem(
      value: 6,
      child: Text(AppMessages().getCopy('news.news-with-video')),
    ),
  ];
  static const manyDaysVisit = 2;
  static const singleDayVisit = 1;
  // Multiplication to get percentages.
  static const double tenPercent = 0.1;
  static const double twentyPercent = 0.2;
  static const double thirtyPercent = 0.3;
  static const double fourtyPercent = 0.4;
  static const double fiftyPercent = 0.5;
  static const double sixtyPercent = 0.6;
  static const double seventyPercent = 0.7;
  static const double eightyPercent = 0.8;
  static const double ninetyPercent = 0.9;
  // Visual common constants.
  static const double mediumBox = 32; // Used to set width or height.
  static const double bigBox = 64;
  static const int plateMexicoLenght = 9;
  static const int plateColombiaLenght = 7;
  static const String emailRegex =
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+";
  static const String plateRegex = r"^[A-Z-a-z]{1,3}-[0-9]{1,4}";
  static const int byteSize = 1024;
  // Margin left + margin right (16+16).
  static const int defaultMarginSum = 32;
  static const int defaultMargin = 16;
  static NumberFormat currencyFormatter =
      NumberFormat.currency(locale: "en_US", symbol: "\$ ");

  static const widthDialog = 150.0;
  static const heightDialog = 300.0;
  static const sizeImgLanguage = 35.0;

  static final List languageData = [
    {
      'idCodeLanguage': '1',
      'nameLanguage': 'Español',
      'imgLanguage': 'ds/icons/es_MX.svg',
    },
    {
      'idCodeLanguage': '2',
      'nameLanguage': 'Inglés',
      'imgLanguage': 'ds/icons/en_US.svg',
    },
  ];
  static const neivorWebPage = "https://www.neivor.com";
  // ignore: prefer-correct-identifier-length
  static const neivorWebPageWithouCertificate = "www.neivor.com";
  // States for id Notice Types.
  static const int publicServicecutState = 1;
  static const int messageState = 2;
  static const int repairState = 3;
  static const int informationState = 4;
  static const int genericState = 5;
  static const int advertisingState = 6;
  // Font Sizes.

  static const List<DropdownMenuItem<int>> months = [
    DropdownMenuItem(
      value: DateTime.january,
      child: Text("01"),
    ),
    DropdownMenuItem(
      value: DateTime.february,
      child: Text("02"),
    ),
    DropdownMenuItem(
      value: DateTime.march,
      child: Text("03"),
    ),
    DropdownMenuItem(
      value: DateTime.april,
      child: Text("04"),
    ),
    DropdownMenuItem(
      value: DateTime.may,
      child: Text("05"),
    ),
    DropdownMenuItem(
      value: DateTime.june,
      child: Text("06"),
    ),
    DropdownMenuItem(
      value: DateTime.july,
      child: Text("07"),
    ),
    DropdownMenuItem(
      value: DateTime.august,
      child: Text("08"),
    ),
    DropdownMenuItem(
      value: DateTime.september,
      child: Text("09"),
    ),
    DropdownMenuItem(
      value: DateTime.october,
      child: Text("10"),
    ),
    DropdownMenuItem(
      value: DateTime.november,
      child: Text("11"),
    ),
    DropdownMenuItem(
      value: DateTime.december,
      child: Text("12"),
    ),
  ];
  static const String onlyAlphaRegex = "[A-Za-zÀ-ÖØ-öø-ÿ ]";

  final List<DropdownMenuItem<String>> visitCategory = [
    DropdownMenuItem(
      value: "1",
      child: Text(
        //"Invitados de la reina Isabel ",
        AppMessages().getCopy('visitors.owners-guests'),
      ),
    ),
    DropdownMenuItem(
      value: "2",
      child: Text(
        //"Personal de servicios",
        AppMessages().getCopy('visitors.service-staff'),
      ),
    ),
    DropdownMenuItem(
      value: "3",
      child: Text(
        //"Funcionarios del condominio",
        AppMessages().getCopy('visitors.condominium-officers'),
      ),
    ),
    DropdownMenuItem(
      value: "4",
      child: Text(
        // "Obreros",
        AppMessages().getCopy('visitors.laborers'),
      ),
    ),
    DropdownMenuItem(
      value: "5",
      child: Text(
        //"Proveedores",
        AppMessages().getCopy('visitors.providers'),
      ),
    ),
    DropdownMenuItem(
      value: "6",
      child: Text(
        //"Administrador",
        AppMessages().getCopy('visitors.administrator'),
      ),
    ),
    DropdownMenuItem(
      value: "7",
      child: Text(
        //"Inquilino",
        AppMessages().getCopy('visitors.tenant'),
      ),
    ),
  ];
  static const List<DropdownMenuItem<int>> monthDaysAsDropdownItem = [
    DropdownMenuItem(
      value: 0,
      child: Text("Seleccione uno"),
    ),
    DropdownMenuItem(
      value: 1,
      child: Text("1"),
    ),
    DropdownMenuItem(
      value: 2,
      child: Text("2"),
    ),
    DropdownMenuItem(
      value: 3,
      child: Text("3"),
    ),
    DropdownMenuItem(
      value: 4,
      child: Text("4"),
    ),
    DropdownMenuItem(
      value: 5,
      child: Text("5"),
    ),
    DropdownMenuItem(
      value: 6,
      child: Text("6"),
    ),
    DropdownMenuItem(
      value: 7,
      child: Text("7"),
    ),
    DropdownMenuItem(
      value: 8,
      child: Text("8"),
    ),
    DropdownMenuItem(
      value: 9,
      child: Text("9"),
    ),
    DropdownMenuItem(
      value: 10,
      child: Text("10"),
    ),
    DropdownMenuItem(
      value: 11,
      child: Text("11"),
    ),
    DropdownMenuItem(
      value: 12,
      child: Text("12"),
    ),
    DropdownMenuItem(
      value: 13,
      child: Text("13"),
    ),
    DropdownMenuItem(
      value: 14,
      child: Text("14"),
    ),
    DropdownMenuItem(
      value: 15,
      child: Text("15"),
    ),
    DropdownMenuItem(
      value: 16,
      child: Text("16"),
    ),
    DropdownMenuItem(
      value: 17,
      child: Text("17"),
    ),
    DropdownMenuItem(
      value: 18,
      child: Text("18"),
    ),
    DropdownMenuItem(
      value: 19,
      child: Text("19"),
    ),
    DropdownMenuItem(
      value: 20,
      child: Text("20"),
    ),
    DropdownMenuItem(
      value: 21,
      child: Text("21"),
    ),
    DropdownMenuItem(
      value: 22,
      child: Text("22"),
    ),
    DropdownMenuItem(
      value: 23,
      child: Text("23"),
    ),
    DropdownMenuItem(
      value: 24,
      child: Text("24"),
    ),
    DropdownMenuItem(
      value: 25,
      child: Text("25"),
    ),
    DropdownMenuItem(
      value: 26,
      child: Text("26"),
    ),
    DropdownMenuItem(
      value: 27,
      child: Text("27"),
    ),
    DropdownMenuItem(
      value: 28,
      child: Text("28"),
    ),
    DropdownMenuItem(
      value: 29,
      child: Text("29"),
    ),
    DropdownMenuItem(
      value: 30,
      child: Text("30"),
    ),
  ];
  static const personalDataUrl =
      "https://cdn.neivor.com/cdn/colombia/static/docs/reglamento.pdf#page=9";
  static const tAndCUrl =
      "https://cdn.neivor.com/cdn/colombia/static/docs/reglamento.pdf#page=1";
}
