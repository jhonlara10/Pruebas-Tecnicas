//ignore_for_file: avoid-non-null-assertion
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/wall_notifications/wall_notifications_bloc.dart';
import 'package:neivor_flutter_app/domain/models/notification/notification_data.dart';
import 'package:neivor_flutter_app/main.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';

import '../../domain/models/payment/transactions/transaction.dart';

class NotificationUtils {
  ///
  /// Check if app has notifications received in background or
  /// resumed state and execute an action
  ///
  checkNotifications() async {
    /// Check if message exists
    RemoteMessage? initialMessage =
        await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      /// Case 1 Transaction notification
      if (initialMessage.data["route"].contains('transactions') &&
          initialMessage.messageId !=
              BlocProvider.of<WallNotificationsBloc>(
                navigatorKey.currentState!.context,
              ).state.messageId) {
        redirectToTransactions(initialMessage);
      }
    }
  }

  /// Navigate to movements view
  ///
  /// Params:
  ///   [RemoteMessage] message received from firebase.
  redirectToTransactions(RemoteMessage initialMessage) {
    saveMessageId(initialMessage.messageId ?? '');
    navigateToMovements(NotificationData.fromJson(initialMessage.data));
  }

  /// Stores messageId in bloc to avoid duplicate actions by cache fault.
  ///
  /// Params:
  ///   [String] messageId.
  saveMessageId(String messageId) {
    BlocProvider.of<WallNotificationsBloc>(
      navigatorKey.currentState!.context,
    ).add(NewMessageId(messageId: messageId));
  }

  /// check the required action to execute
  ///
  /// Params:
  ///   [NotificationData] data receiben in Firebase notification.
  navigateToMovements(NotificationData notificationData) {
    if (RegExp(r'\d').hasMatch(notificationData.route ?? '')) {
      Transaction? movement = Transaction(
        dpqTransaction: notificationData.route?.replaceAll(RegExp(r"\D"), ""),
      );
      Navigator.pushReplacementNamed(
        navigatorKey.currentState!.context,
        "invoice",
        arguments: {
          "fromMovements": {
            "movement": movement,
          },
        },
      );
    } else {
      Navigator.pushAndRemoveUntil(
        navigatorKey.currentState!.context,
        MaterialPageRoute(
          builder: (context) => const MainPayments(isComeFrom: "movements"),
        ),
        (Route<dynamic> route) => false,
      );
    }
  }

  processSpeiWallNotification(
    NotificationData data,
  ) {
    if (data.action == "SUCCESSFUL_PAYMENT") {
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(const NewShowSpeiNotification(showSpeiNotification: true));
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(const NewSuccessfulPayment(successfulPayment: true));
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(
        const NewPaymentPendingAssociate(paymentPendingAssociate: false),
      );
    } else if (data.action == "PAYMENT_PENDING_ASSOCIATE") {
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(const NewShowSpeiNotification(showSpeiNotification: true));
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(const NewSuccessfulPayment(successfulPayment: false));
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(
        const NewPaymentPendingAssociate(paymentPendingAssociate: true),
      );
    } else if (data.action == "LEGAL_CHARGE_DEACTIVATION") {
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(const NewCurrentLegalCharge(currentLegalCharge: 1));
    } else if (data.action == "LEGAL_CHARGE_ACTIVATION") {
      BlocProvider.of<WallNotificationsBloc>(navigatorKey.currentState!.context)
          .add(const NewCurrentLegalCharge(currentLegalCharge: 0));
    }
  }
}
