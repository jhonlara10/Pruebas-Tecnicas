import 'dart:io';
import 'dart:typed_data';

import 'package:android_path_provider/android_path_provider.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:file_saver/file_saver.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/presentation/util/app_api_constants.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:share_extend/share_extend.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'constants.dart';

class GlobalUtils {
  static String baseCdn = "";
  DeviceInfoPlugin deviceInfoInstance = DeviceInfoPlugin();
  static dynamic deviceInfo;
  static int? countryId;
  static String? currentLanguage;

  synqCurrentLanguage() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    currentLanguage = sharedPreferences.getString("selectedLang");
  }

  getBaseCdn() async {
    baseCdn = await AppUrls().getUrl(AppApiConstants.baseCdn);
    getCountryCode();
  }

  getCountryCode() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    countryId = sharedPreferences.get('countryId') as int;
  }

  getDeviceInfo() async {
    if (Platform.isAndroid) deviceInfo = await deviceInfoInstance.androidInfo;
    if (Platform.isIOS) deviceInfo = await deviceInfoInstance.iosInfo;
  }

  // ignore: long-method
  cdn(String? path) {
    if (path != null && path.length != 4) {
      if (path.contains("data:")) {
        return path;
      }
      if (path == "socialArea/socialArea.jpg") {
        return "$baseCdn/static/$path";
      }
      if (path.contains("graph.facebook") ||
          path.contains("googleusercontent")) {
        path = path.replaceAll(" ", "");
        return path;
      }
      return "$baseCdn/resources/mobile/$path";
    } else {
      return "$baseCdn/static/default/no_avatar.png";
    }
  }

  staticCdn(String path) {
    return "$baseCdn/static/$path";
  }

  /// Date formatter
  ///
  /// Arguments:
  /// date [double] as 1658510614.994
  /// format [String] as "dd MMMM yyyy" or others
  ///
  /// Return:
  /// String with date in passed format
  String parseDate(double? date, String format) {
    DateTime dateParsed = DateTime.fromMillisecondsSinceEpoch(
      date?.toInt() != null ? date!.toInt() * 1000 : 0 * 1000,
    );
    final formatter = DateFormat(format);
    return formatter.format(dateParsed);
  }

  String getCorrectDate(String? date) {
    return DateFormat("dd MMMM yyyy").format(DateTime.parse(date ?? ""));
  }

  String parseDoubleDate(double date) {
    DateTime dateParsed = DateTime.fromMillisecondsSinceEpoch(date.toInt());
    final formatter = DateFormat('dd/MM/yyyy');
    return formatter.format(dateParsed);
  }

  String getParsedTodayDate(String format) {
    DateTime dateParsed = DateTime.now();
    final formatter = DateFormat(format);
    return formatter.format(dateParsed);
  }

  /// Transform date format
  ///
  /// Args:
  ///   [stateId] is a integer with the value to the NewType
  /// Return:
  ///   string with the name to the state New.
  getNewType(int? stateId) {
    switch (stateId) {
      case Constants.publicServicecutState:
        return AppMessages().getCopy('news.public-service-cut');
      case Constants.messageState:
        return AppMessages().getCopy('common.message');
      case Constants.repairState:
        return AppMessages().getCopy('news.repair');
      case Constants.informationState:
        return AppMessages().getCopy('news.information');
      case Constants.genericState:
        return AppMessages().getCopy('news.generic');
      case Constants.advertisingState:
        return AppMessages().getCopy('news.advertising');
    }
  }

  /// Transform date format
  ///
  /// Args:
  ///   [stringDate] is a string like '2022/07/01 13:01:41' or '2022/07/01', etc
  ///   [initFormat] is the format of your date
  ///   [outputFormat] here you must put format would you want to get
  /// Return:
  ///   date with outputFormat format
  formatDateUtil(String stringDate, String initFormat, String outputFormat) {
    if (stringDate != '') {
      DateTime parseDate = DateFormat(initFormat).parse(stringDate);
      var inputDate = DateTime.parse(parseDate.toString());
      var output = DateFormat(outputFormat);
      return output.format(inputDate);
    } else {
      return '';
    }
  }

  /// Store image into Android filesystem.
  ///
  /// Params:
  ///   [Uint8List] bytes of file.
  /// Returns:
  ///   [String] Promise of file path.
  Future<String> storeAndroidFile(Uint8List? capturedImage) async {
    String androidPath = await AndroidPathProvider.downloadsPath;
    File imageFile = File(
      "$androidPath/Neivor/${DateTime.now().millisecondsSinceEpoch}.png",
    );
    imageFile.createSync(recursive: true);
    imageFile.writeAsBytesSync(capturedImage ?? []);
    return imageFile.path;
  }

  /// Store image into iOS filesystem.
  ///
  /// Params:
  ///   [Uint8List] bytes of file.
  /// Returns:
  ///   [String] Promise of file path.
  Future<String> storeiOSFile(Uint8List? capturedImage) {
    return FileSaver.instance.saveFile(
      "${DateTime.now().millisecondsSinceEpoch}.png",
      //ignore: avoid-non-null-assertion
      capturedImage!,
      "png",
      mimeType: MimeType.PNG,
    );
  }

  ///
  /// Share any byte image on iOS chooser.
  ///
  /// Params:
  ///   [Uint8List] captured image to store.
  Future<void> shareiOSFile(Uint8List? capturedImage) async {
    var filePath = await storeiOSFile(capturedImage);
    ShareExtend.share(filePath, "file");
  }

  ///
  /// Format clabe in format of home header.
  ///
  /// Params:
  ///   [String] clabe.
  /// Returns:
  /// Clabe in format XXXX XXXX XXXX XXXXX
  String formatClabe(String clabe) {
    try {
      return "${clabe.substring(0, 4)} ${clabe.substring(4, 8)} ${clabe.substring(8, 12)} ${clabe.substring(12, 18)}";
    } catch (error) {
      return "";
    }
  }
}
