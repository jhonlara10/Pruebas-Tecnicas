import 'dart:ui';

import 'package:libphonenumber/libphonenumber.dart';
import 'package:country_codes/country_codes.dart';

class CountriesUtils {
  getCountryISOToPhone(String phone) async {
    var phoneNumberRegionInfo =
        await PhoneNumberUtil.getRegionInfo(phoneNumber: phone, isoCode: '');
    if (phone.contains("+1")) {
      phoneNumberRegionInfo.isoCode = "+1";
    }
    return phoneNumberRegionInfo.isoCode ?? "";
  }

  gePhoneWithoutCode(String phone) async {
    var phoneNumberRegionInfo =
        await PhoneNumberUtil.getRegionInfo(phoneNumber: phone, isoCode: '');
    return phoneNumberRegionInfo.formattedPhoneNumber ?? "";
  }

  getLocaleCoutryISOcode() async {
    await CountryCodes
        .init(); // Optionally, you may provide a `Locale` to get countrie's localizadName.
    final Locale? deviceLocale = CountryCodes.getDeviceLocale();
    return deviceLocale?.countryCode;
  }
}
