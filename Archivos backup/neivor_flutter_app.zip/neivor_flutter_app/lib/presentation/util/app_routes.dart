import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/amenities/amenities.dart';
import 'package:neivor_flutter_app/presentation/documents/documents.dart';
import 'package:neivor_flutter_app/presentation/geolocation/geolocation.dart';
import 'package:neivor_flutter_app/presentation/home/home.dart';
import 'package:neivor_flutter_app/presentation/login/login.dart';
import 'package:neivor_flutter_app/presentation/login/select_login/select_login.dart';
import 'package:neivor_flutter_app/presentation/messages/add_message.dart';
import 'package:neivor_flutter_app/presentation/messages/main_messages.dart';
import 'package:neivor_flutter_app/presentation/news/edit/edit_new.dart';
import 'package:neivor_flutter_app/presentation/news/news.dart';
import 'package:neivor_flutter_app/presentation/packages/register/package_register.dart';
import 'package:neivor_flutter_app/presentation/packages/resident/package_resident.dart';
import 'package:neivor_flutter_app/presentation/payments/add_new_card.dart';
import 'package:neivor_flutter_app/presentation/payments/card_suscription.dart';
import 'package:neivor_flutter_app/presentation/payments/confirm_pay.dart';
import 'package:neivor_flutter_app/presentation/payments/disabled_payments.dart';
import 'package:neivor_flutter_app/presentation/payments/edit_schedule.dart';
import 'package:neivor_flutter_app/presentation/payments/invoice_view.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/presentation/payments/movements_view.dart';
import 'package:neivor_flutter_app/presentation/payments/my_cards.dart';
import 'package:neivor_flutter_app/presentation/payments/my_wallet.dart';
import 'package:neivor_flutter_app/presentation/payments/payment_methods.dart';
import 'package:neivor_flutter_app/presentation/payments/pending_payment_view.dart';
import 'package:neivor_flutter_app/presentation/payments/schedule_form.dart';
import 'package:neivor_flutter_app/presentation/profile/emergency_contacts/add_emergency.dart';
import 'package:neivor_flutter_app/presentation/profile/emergency_contacts/emergency_contact.dart';
import 'package:neivor_flutter_app/presentation/profile/pet/add_pet.dart';
import 'package:neivor_flutter_app/presentation/profile/profile.dart';
import 'package:neivor_flutter_app/presentation/profile/profile/edit_profile.dart';
import 'package:neivor_flutter_app/presentation/profile/vehicles/add_vehicle.dart';
import 'package:neivor_flutter_app/presentation/splash/splash.dart';
import 'package:neivor_flutter_app/presentation/themes/themes.dart'
    as themes_page;
import 'package:neivor_flutter_app/presentation/tickets/add_ticket.dart';
import 'package:neivor_flutter_app/presentation/tickets/edit_ticket.dart';
import 'package:neivor_flutter_app/presentation/tickets/ticket_detail.dart';
import 'package:neivor_flutter_app/presentation/chat/chat.dart';
import 'package:neivor_flutter_app/presentation/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visits_historic.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/qr_scanner.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visitor_name_sp.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visitors_security.dart';
import 'package:neivor_flutter_app/presentation/wish/wish.dart';
import 'package:neivor_flutter_app/presentation/wish/wish_success.dart';
import 'package:neivor_flutter_app/presentation/packages/packages.dart';

/// This class is a map of all the routes in the app.
class AppRoutes {
  static Map<String, Widget Function(BuildContext)> routes = {
    // Profile section.
    'profile': (BuildContext context) => const Profile(),
    'editProfile': (BuildContext context) => const EditProfile(),
    'emergency': (BuildContext context) => const EmergencyContact(),
    'addEmergency': (BuildContext context) => const AddEmergency(),
    'documents': (BuildContext context) => const Documents(),
    'addVehicle': (BuildContext context) => const AddVehicle(),
    // Login.
    'splash': (BuildContext context) => const Splash(),
    'geolocation': (BuildContext context) => const Geolocation(),
    'login': (BuildContext context) => const Login(),
    'selectLogin': (BuildContext context) => const SelectLogin(),
    // Home.
    'home': (BuildContext context) => const Home(),
    // News.
    'addNews': (BuildContext context) => const News(),
    'editNew': (BuildContext context) => const EditNew(),
    // Tickets.
    'tickets': (BuildContext context) => const Tickets(),
    'ticketDetail': (BuildContext context) => const TicketDetail(),
    'addTicket': (BuildContext context) => const AddTicket(),
    'editTicket': (BuildContext context) => const EditTicket(),
    // Neivor wish.
    'wish': (BuildContext context) => const Wish(),
    'wishSuccess': (BuildContext context) => const WishSuccess(),
    // Visitors.
    'visitsHistory': (BuildContext context) => const VisitsHistoric(),
    'visitors': (BuildContext context) => const Visitors(),
    'visitorsSecurity': (BuildContext context) => const VisitorsSecurity(),
    'visitorsScanner': (BuildContext context) => const QRScanner(),
    'visitorNameAndSp': (BuildContext context) => const VisitorNameAndSp(),
    // Amenities.
    'amenities': (BuildContext context) => const Amenities(),
    // Chat.
    // Messages.
    'messages': (BuildContext context) => const MainMessages(),
    'addMessage': (BuildContext context) => const AddMessage(),
    // For developement only.
    'packages': (BuildContext context) => const Packages(),
    'packagesResident': (BuildContext context) => const PackageResident(),

    'packagesRegister': (BuildContext context) => const PackageRegister(),
    'themes': (BuildContext context) => const themes_page.Themes(),
    'addPet': (BuildContext context) => const AddPet(),
    // Payments.
    'payments': (BuildContext context) => const MainPayments(),
    'pendingPaymentView': (BuildContext context) => const PendingPaymentView(),
    'paymentMethods': (BuildContext context) => const PaymentMethods(),
    'confirmPay': (BuildContext context) => const ConfirmPay(),
    'addNewCard': (BuildContext context) => const AddNewCard(),
    'movementsMain': (BuildContext context) => const MovementsMain(),
    'disabledPayments': (BuildContext context) => const DisabledPayments(),
    'wallet': (BuildContext context) => const MyWallet(),
    'myCards': (BuildContext context) => const MyCards(),
    'scheduleForm': (BuildContext context) => const ScheduleForm(),
    "cardSuscription": (BuildContext context) => const CardSuscription(),
    "editSchedule": (BuildContext context) => const EditSchedule(),
    //'associatePaymentMain': (BuildContext context) =>  const AssociatePaymentMain(),
    // Multi entry point routes.
    'chat': (BuildContext context) => const Chat(),
    'invoice': (BuildContext context) => const InvoiceView(),
  };
}
