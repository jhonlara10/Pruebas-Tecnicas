class AppApiConstants {
  static const authUrl = "api.auth.url";
  static const noticesUrl = "api.notice.url";
  static const filesUrl = "api.files.url";
  static const structureUrl = "api.structure.url";
  static const pqrUrl = "api.pqr.url";
  static const messageUrl = "api.chat.url";
  static const baseCdn = "cdn.http.url";
  static const visitUrl = "api.visit.url";
  static const packageUrl = "api.packages.url";
  static const paymentUrl = "api.payment.url";
  static const amenitiesUrl = 'api.social.url';
}
