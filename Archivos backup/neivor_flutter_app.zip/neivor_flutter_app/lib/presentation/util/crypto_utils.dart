import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:crypton/crypton.dart';

class CryptoUtils {
  RSAPublicKey? _receiverRsaPublicKey;
  final String publicKey =
      "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCax1rtbpOXX+N4jxZ8oT0o3oQxN0hpAcJnPYFdFo9nIrdrvLyJCH04NGnkTmjyzVhYli2PLQYEMkhXK41ztHJi5oPAKNVbhnhgwgDUXvPglN4VKEDdLMjl14g++OaNfomw4copRLZshvNGwatoUdxa6MmrAc85uYpnmWlgeNa1xQIDAQAB";
  final int md5PasswordLength = 32;

  /// Generates MD5 encrypted string from specific input.
  ///
  /// Param:
  /// [String] original input to be encrypted.
  ///
  /// Returns:
  /// [String] input encrypted by MD5 algoritm.
  ///
  String generateMd5(String input) {
    return md5.convert(utf8.encode(input)).toString();
  }

  /// Encrypt input using RSA public key algoritm.
  /// Param:
  /// [String] original input to be encrypted.
  ///
  /// Returns:
  /// [String] input encrypted by RSA public key algoritm.
  ///
  String? encrypt(String input) {
    try {
      _receiverRsaPublicKey = RSAPublicKey.fromString(publicKey);
      bool isMd5Password = input.length == md5PasswordLength;
      return _receiverRsaPublicKey
          ?.encrypt(!isMd5Password ? generateMd5(input) : input);
    } catch (error) {
      return null;
    }
  }

  /// Encrypt input using RSA public key algoritm.
  /// Param:
  /// [String] original input to be encrypted.
  ///
  /// Returns:
  /// [String] input encrypted by RSA public key algoritm.
  ///
  String? rsaEncrypt(String input) {
    try {
      _receiverRsaPublicKey = RSAPublicKey.fromString(publicKey);
      return _receiverRsaPublicKey?.encrypt(input);
    } catch (error) {
      return null;
    }
  }
}
