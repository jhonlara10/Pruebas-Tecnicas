import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/amenities/amenities_bloc.dart';
import 'package:neivor_flutter_app/bloc/emergency/emergency_bloc.dart';
import 'package:neivor_flutter_app/bloc/emergency/relationship_bloc.dart';
import 'package:neivor_flutter_app/bloc/login/login_bloc.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/bloc/wall_notifications/wall_notifications_bloc.dart';

/// This class is a list of all the Blocs that are used in the app.
class AppBlocs {
  static List<BlocProvider> providersList = [
    BlocProvider<EmergencyBloc>(
      create: (_) => EmergencyBloc(),
    ),
    BlocProvider<RelationshipBloc>(
      create: (_) => RelationshipBloc(),
    ),
    BlocProvider<MessagesBloc>(
      create: (_) => MessagesBloc(),
    ),
    BlocProvider<PaymentsBloc>(
      create: (_) => PaymentsBloc(),
    ),
    BlocProvider<LoginBloc>(
      create: (_) => LoginBloc(),
    ),
    BlocProvider<AmenitiesBloc>(
      create: (_) => AmenitiesBloc(),
    ),
    BlocProvider<WallNotificationsBloc>(
      create: (_) => WallNotificationsBloc(),
    ),
  ];
}
