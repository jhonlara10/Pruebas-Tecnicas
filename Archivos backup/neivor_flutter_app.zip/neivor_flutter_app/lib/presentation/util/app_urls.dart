import 'dart:convert';
import 'package:neivor_flutter_app/domain/models/settings/setting.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppUrls {
  static dynamic preferences;

  getPreferences() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    preferences = jsonDecode(sharedPreferences.getString("settings") ?? "");
  }

  /// Obtain url value from specific key on database.
  ///
  /// Returns [String] value of combination key/value from list.
  Future<String> getUrl(key) async {
    var sharedPreferences = await SharedPreferences.getInstance();
    var settingsJson =
        jsonDecode(sharedPreferences.getString("settings") ?? "");
    var filteredJson = settingsJson.where((val) => val["name"] == key).toList();
    return Setting.fromJson(filteredJson[0]).value ?? "";
  }

  String getProperty(key) {
    var filteredJson = preferences.where((val) => val["name"] == key).toList();
    return Setting.fromJson(filteredJson[0]).value ?? "";
  }

  String getPropertyById(key, int? id) {
    var filteredJson = jsonDecode(getProperty(key));
    var json = filteredJson.where((val) => val["id"] == id).toList();
    return Setting.fromJson(json.first).name ?? "";
  }
}
