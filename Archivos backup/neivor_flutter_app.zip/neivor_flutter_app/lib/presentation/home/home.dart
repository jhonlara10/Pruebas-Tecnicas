import 'dart:async';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/login/login_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/general/general_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/news/list_news_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/payment_methods_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/documents_container.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/home_header.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu_section_main.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/news_carousel.dart';
import 'package:neivor_flutter_app/presentation/news/show/show_new.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/main_admin_payments.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/notification_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const Home());
}

class Home extends StatefulWidget {
  const Home({
    Key? key,
  }) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  int selectedIndex = 0;
  int paymentsIndex = 1;
  int porterIndex = 2;
  int messagesIndex = 3;
  bool? isAdminRole = false;
  bool? isSecurityRole = false;
  bool isSeeMoreVisible = false;
  int pressed = 0;
  final copy = AppMessages().getCopy;
  bool isIOSChatButtonEnabled = false;

  @override
  // ignore: long-method
  void initState() {
    /// A function that is called immediately.
    /// to create a global object instances
    (() async {
      await AppUrls().getPreferences();
      await GlobalUtils().getBaseCdn();
      await UserUtils().getCurrentUser();
      await UserUtils().getCurrentEnterprise();
      await UserUtils().getCurrentZyosGroup();

      // Could be moved after select a country.
      await AppMessages().getPreferences();
      await AppUrls().getPreferences();
      if (!mounted) return;
      await getNeighbors(context);
      // ignore: use_build_context_synchronously
      if ((BlocProvider.of<LoginBloc>(context).state.firstLogin ?? false) &&
          GlobalUtils.countryId == Constants.mxIntIdCode &&
          !UserUtils().isAdminUser() &&
          await isSpeiActive()) {
        showClabePopup();
      }

      setState(() {
        isIOSChatButtonEnabled =
            AppUrls().getProperty("api.ios.showGoogleSocialButton") == "true"
                ? true
                : false;

        initRoles();
        NotificationUtils().checkNotifications();
      });
    })();

    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  // ignore: long-method
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.resumed:
        print("app in inactive");
        NotificationUtils().checkNotifications();
        break;
      case AppLifecycleState.inactive:
        print("app in inactive");
        break;
      case AppLifecycleState.paused:
        print("app in paused");
        break;
      case AppLifecycleState.detached:
        print("app in detached");
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  initRoles() async {
    isAdminRole = UserUtils().isAdminUser();
    isSecurityRole = UserUtils().isSecurityUser();
  }

  markAsLogoutUser() async {
    var sharePreferences = await SharedPreferences.getInstance();
    sharePreferences.remove("isLogged");
  }

  appCloser() {
    pressed += 1;
    Timer(const Duration(seconds: 4), () {
      pressed = 0;
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(copy('home.press-back-button-again-to-exit')),
    ));
    if (pressed == 2) {
      if (Platform.isAndroid) {
        SystemNavigator.pop();
      } else {
        exit(0);
      }
    }
    return Future.value(false);
  }

  isSpeiActive() async {
    PaymentMethodsResponse? enterprisePaymentMethod =
        await getActivePaymentMethods();
    return enterprisePaymentMethod.data?.any((element) => element.id == 11) ??
        false;
  }

  // ignore: long-method
  showClabePopup() async {
    ZyosUserClabe? clabeData;
    if (!(GlobalUtils.countryId == Constants.coIntIdCode)) {
      clabeData = await getZyosUserClabe();
    }
    // ignore: prefer-async-await
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
          titlePadding: const EdgeInsets.all(0),
          title: Container(
            color: const Color(0xFF7367E9).withOpacity(0.08),
            child: Row(
              children: [
                const NvImage(
                  imageUrl: "/ds/illustrations/clabe-descriptive.png",
                  width: 136,
                  height: 134,
                ),
                Column(
                  children: [
                    const SizedBox(
                      height: 43,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.44,
                      child: Text(
                        "Actualiza tu CLABE y paga tus cuotas pendientes",
                        style: AppThemeScope.of(context).typography.h5.semibold,
                        overflow: TextOverflow.clip,
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          content: RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              style: AppThemeScope.of(context).typography.bd1.light,
              children: [
                const TextSpan(
                  text: "Ahora con tu",
                ),
                TextSpan(
                  text: ' CLABE ÚNICA ',
                  style: AppThemeScope.of(context).typography.bd1.medium,
                ),
                const TextSpan(
                  text: 'de residente, paga rápido y seguro con SPEI',
                ),
              ],
            ),
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            ElevatedButton(
              style: ButtonStyle(
                minimumSize: MaterialStateProperty.all(
                  Size(MediaQuery.of(context).size.width * 0.7, 36),
                ),
              ),
              // ignore: prefer-extracting-callbacks
              onPressed: () {
                Clipboard.setData(ClipboardData(
                  text: clabeData?.entity?.referenceNumber ?? '',
                ));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text("Copiado al portapapeles."),
                ));
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(GlobalUtils().formatClabe(
                    clabeData?.entity?.referenceNumber ?? "",
                  )),
                  const SizedBox(
                    width: 10,
                  ),
                  const NvImage(
                    icon: "Interface, Essential/copy-paste-select-add-plus",
                    color: Colors.white,
                  ),
                ],
              ),
            ),
          ],
        );
      },
    ).then((_) => BlocProvider.of<LoginBloc>(context)
        .add(const NewFirstLogin(firstLogin: false)));
  }

  @override
  Widget build(BuildContext context) {
    const headerMinHeight = 120.0;
    final headerMaxHeight =
        UserUtils().isSecurityUser() ? headerMinHeight : 270.0;

    return WillPopScope(
      onWillPop: () => appCloser(),
      child: Scaffold(
        body: CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers: [
            NvSliverAppbar(
              expandedHeight: headerMaxHeight,
              toolbarHeight: headerMinHeight,
              flexibleSpace: HomeHeader(
                maxHeight: headerMaxHeight,
                minHeight: headerMinHeight,
              ),
            ),
            SliverList(
              delegate: SliverChildListDelegate(
                [
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 5,
                      bottom: 20,
                      right: 5,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        MenuSectionMain(
                          isSeeMoreVisible: isSeeMoreVisible,
                          hideSeeMoreSection: hideSeeMoreSection,
                        ),
                        if (UserUtils().hasPermissionsTo(19))
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 10,
                            ),
                            child: NewsCarousel(
                              goToNewsDetail: goToNewsDetail,
                            ),
                          ),
                        if (UserUtils().hasPermissionsTo(39))
                          Center(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                DocumentsContainer(copy: copy),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        bottomNavigationBar: isSecurityRole == false
            ? BottomNavigationBar(
                currentIndex: selectedIndex,
                onTap: onItemTapped,
                showSelectedLabels: true,
                type: BottomNavigationBarType.fixed,
                selectedItemColor: AppTheme.coral0Main,
                unselectedItemColor: AppTheme.black0Main,
                showUnselectedLabels: true,
                items: <BottomNavigationBarItem>[
                  BottomNavigationBarItem(
                    icon: Image.asset(
                      "assets/images/home.png",
                      height: 30,
                      width: 30,
                    ),
                    label: copy('home.start'),
                  ),
                  BottomNavigationBarItem(
                    icon: Image.asset(
                      "assets/images/pay.png",
                      height: 30,
                      width: 30,
                    ),
                    label: copy('charges.payments'),
                  ),
                  BottomNavigationBarItem(
                    icon: Image.asset(
                      "assets/images/security.png",
                      height: 30,
                      width: 30,
                    ),
                    label: copy('messages.security-guard'),
                  ),
                  if (Platform.isAndroid ||
                      (Platform.isIOS && isIOSChatButtonEnabled))
                    BottomNavigationBarItem(
                      icon: Image.asset(
                        "assets/images/chat.png",
                        height: 30,
                        width: 30,
                      ),
                      label: copy('common.chat'),
                    ),
                ],
              )
            : null,
      ),
    );
  }

  // ignore: long-method
  onItemTapped(int index) {
    setState(() {
      switch (index) {
        case 0:
          break;
        case 1:
          if (UserUtils().hasPermissionsTo(130) ||
              UserUtils().hasPermissionsTo(67)) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (BuildContext context) => MainAdminPayments(
                  balance: Constants.currencyFormatter
                      .format(BlocProvider.of<PaymentsBloc>(context)
                              .state
                              .balance
                              ?.totalValueIncome ??
                          0)
                      .toString(),
                ),
              ),
              (Route<dynamic> route) => false,
            );
          } else {
            if (UserUtils.currentEnterprise?.hidePay ?? false) {
              gotoSelectedPage('disabledPayments');
            } else {
              gotoSelectedPage('payments');
            }
          }
          break;
        case 2:
          gotoSelectedPage('visitors');
          break;
        case 3:
          gotoSelectedPage('messages');
          break;
        default:
          break;
      }
    });
  }

  gotoSelectedPage(String name) async {
    Navigator.pushNamed(context, name);
  }

  hideSeeMoreSection() {
    setState(() {
      isSeeMoreVisible = !isSeeMoreVisible;
    });
  }

  goToNewsDetail(ListNewsResponse newsObject) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => ShowNew(
          newSelected: newsObject,
        ),
      ),
    );
  }
}
