import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/carousel_card.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

import '../../../data/repository/news/news_repository_impl.dart';
import '../../../domain/models/login/enterprise.dart';
import '../../../domain/models/login/user.dart';
import '../../../domain/models/news/list_news_response.dart';

class NewsCarousel extends StatefulWidget {
  final Function goToNewsDetail;
  const NewsCarousel({Key? key, required this.goToNewsDetail})
      : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _NewsCarouselState createState() => _NewsCarouselState();
}

class _NewsCarouselState extends State<NewsCarousel> {
  PageController pageController = PageController(viewportFraction: 0.8);
  User? currentProfileUser;
  Enterprise? currentEnterprise;
  List<ListNewsResponse>? newsList;
  double pageOffset = 0;
  int newsListSize = 0;
  List<CarouselCard>? allSlideCards;

  @override
  void initState() {
    (() async {
      await getProfileCurrentUser();
      currentEnterprise = await currentProfileUser?.getCurrentEnterprise();
      if (!mounted) return;
      sendGetNews();
    })();
    super.initState();
    if (mounted) {
      pageController.addListener(() {
        pageOffset = pageController.page!;
      });
    }
  }

  sendGetNews() async {
    try {
      newsList = await getNews(currentEnterprise?.id ?? 1);
      newsListSize = newsList?.length ?? 0;
      allSlideCards = newsList?.map((newItem) {
        return CarouselCard(
          newItem: newItem,
          goToNewsDetail: widget.goToNewsDetail,
        );
      }).toList();
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      log(e.toString());
    }
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return newsListSize > 0
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: const EdgeInsets.only(left: 16.0),
                child: NvText(
                  copy: 'news.news',
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: colors.text.primary,
                ),
              ),
              const SizedBox(
                height: 8,
              ),
              SizedBox(
                height: 373,
                child: PageView(
                  controller: pageController,
                  children: [
                    ...?allSlideCards,
                  ],
                ),
              ),
            ],
          )
        : Row();
  }
}
