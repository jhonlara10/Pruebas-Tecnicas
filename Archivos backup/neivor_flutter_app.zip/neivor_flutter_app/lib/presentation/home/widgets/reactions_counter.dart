import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class ReactionsCounter extends StatelessWidget {
  const ReactionsCounter({
    Key? key,
    required this.totalLike,
    required this.totalLove,
    required this.totalWow,
    required this.totalReaction,
  }) : super(key: key);

  final int? totalLike;
  final int? totalLove;
  final int? totalWow;
  final int? totalReaction;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Row(
      children: [
        if (totalLike != 0)
          const NvImage(
            imageUrl: 'ds/icons/like-emoji.svg',
            width: 14,
          ),
        const SizedBox(
          width: 4,
        ),
        if (totalLove != 0)
          const NvImage(
            imageUrl: 'ds/icons/love-emoji.svg',
            width: 14,
          ),
        const SizedBox(
          width: 4,
        ),
        if (totalWow != 0)
          const NvImage(
            imageUrl: 'ds/icons/wow-emoji.svg',
            width: 14,
          ),
        const SizedBox(
          width: 4,
        ),
        if (totalReaction != 0)
          Container(
            alignment: Alignment.center,
            width: 14.0,
            height: 14.0,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: colors.primary.turquoise.v1,
            ),
            child: NvText(
              textHolder: totalReaction.toString(),
              fontFamily: "Jost",
              fontWeight: FontWeight.bold,
              fontSize: 12,
              color: colors.primary.turquoise.v4,
            ),
          ),
      ],
    );
  }
}
