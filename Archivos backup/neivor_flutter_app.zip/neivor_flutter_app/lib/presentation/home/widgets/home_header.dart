import 'dart:async';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/bloc/wall_notifications/wall_notifications_bloc.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/enterprise.dart';
import 'package:neivor_flutter_app/domain/models/login/service_point.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/notification/notification_data.dart';
import 'package:neivor_flutter_app/domain/models/payment/collections/header_admin_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/spei_wall_notification.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/row_enterprise.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/main_admin_payments.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeHeader extends StatefulWidget {
  final double maxHeight;
  final double minHeight;

  const HomeHeader({
    Key? key,
    this.maxHeight = NvSliverAppbar.defaultExpandeHeight,
    this.minHeight = NvSliverAppbar.defaultToolbarHeight,
  }) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _HomeHeader createState() => _HomeHeader();
}

class _HomeHeader extends State<HomeHeader> {
  bool isDebtVisible = true;
  int adminId = 2;
  int enterprisesSize = 1;
  List<Invoice>? invoices;
  ZyosUserClabe? clabeData;
  HeaderAdminResponse? headerAdminResponse;
  Enterprise? currentEnterprise;
  ServicePoint? currentServicePoint;
  User? currentProfileUser;
  bool? isAdminRole = false;
  bool? isSecurityRole = false;
  // ignore: prefer-correct-identifier-length
  bool changeEnterpriseButtonEnabled = true;
  final copy = AppMessages().getCopy;
  int? valueSelectedGroup;
  StreamSubscription? firebaseSuscription;
  NotificationData? data;
  int currentEnterpriseIndex = 0;
  int currentServicePointIndex = 0;
  int servicePointsSize = 1;

  @override
  // ignore: long-method
  void initState() {
    valueSelectedGroup = 0;
    (() async {
      await UserUtils().getCurrentUser();
      await UserUtils().getCurrentEnterprise();
      await UserUtils().getCurrentServicePoint();
      await UserUtils().getCurrentZyosGroup();
      await getProfileCurrentUser();
      await getCurrentEnterpriseUser();
      await getCurrentServicePointUser();
      await isAdminRoleLogic();
      await isSecurityRoleLogic();

      if (isAdminRole == false) {
        await callGetDebts();
      } else {
        await callAdminHeader();
      }
    })();
    super.initState();
    firebaseSuscription =
        FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      data = NotificationData.fromJson(message.data);
      activateSpeiNotification();
    });
  }

  @override
  void dispose() {
    firebaseSuscription?.cancel();
    super.dispose();
  }

  double _calculateExpandRatio(BoxConstraints constraints) {
    if (widget.maxHeight - widget.minHeight != 0) {
      return (constraints.maxHeight - widget.minHeight) /
          (widget.maxHeight - widget.minHeight);
    } else {
      return 0;
    }
  }

  // ignore: long-method
  Widget _buildPaymentsCard(Animation<double> animation) {
    final opacity = Tween<double>(begin: -1, end: 1).evaluate(animation);

    return Opacity(
      opacity: opacity < 0
          ? 0
          : opacity > 1
              ? 1
              : opacity,
      child: Tween<double>(begin: 0, end: 1).evaluate(animation) < 0.5
          ? null
          : Card(
              margin: EdgeInsets.only(
                top: Tween<double>(begin: 0, end: 100).evaluate(animation),
              ),
              elevation: 5,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
              child: ListView(
                padding: const EdgeInsets.only(top: 8),
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 20, top: 0),
                    child: ((UserUtils.currentEnterprise?.hidePay ?? false) &&
                            (!UserUtils().hasPermissionsTo(787) ||
                                !UserUtils().hasPermissionsTo(788)))
                        ? null
                        : NvText(
                            // ignore: avoid-nested-conditional-expressions
                            textHolder: UserUtils().hasPermissionsTo(787)
                                ? copy('collections.pending-payments')
                                : copy('payments.balance-of-the-month'),
                            fontFamily: "Jost",
                            fontWeight: FontWeight.w300,
                            fontSize: 14,
                            color: AppTheme.black0Main,
                          ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 20,
                          top: 16,
                          bottom: 20,
                        ),
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * 0.45,
                          child: Text(
                            totalDebt,
                            style: (UserUtils.currentEnterprise?.hidePay ??
                                        false) &&
                                    !UserUtils().isAdminUser()
                                ? AppThemeScope.of(context)
                                    .typography
                                    .st1
                                    .medium
                                    .copyWith(fontSize: 12)
                                : AppThemeScope.of(context)
                                    .typography
                                    .st1
                                    .medium,
                            maxLines: 2,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          bottom: 3,
                          left: 10,
                        ),
                        child:
                            (UserUtils.currentEnterprise?.hidePay ?? false) &&
                                    !UserUtils().isAdminUser()
                                ? null
                                : GestureDetector(
                                    onTap: () => changeDebtVisibility(),
                                    child: const Icon(
                                      Icons.visibility_outlined,
                                      color: AppTheme.black0Main,
                                    ),
                                  ),
                      ),
                      const Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: GestureDetector(
                          onTap: () => navigateToPaymentPage(),
                          child: Container(
                            width: 90,
                            height: 30,
                            margin: const EdgeInsets.only(left: 10.0),
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  AppTheme.coral0Main,
                                  AppTheme.coral0Main,
                                ],
                              ),
                              borderRadius: BorderRadius.all(
                                Radius.circular(10),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                NvText(
                                  textHolder: isAdminRole == false
                                      ? copy('charges.pay-button')
                                      : copy('common.see-more'),
                                  textAlign: TextAlign.center,
                                  fontFamily: 'Jost',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                  color: AppTheme.black1,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    right: 5,
                                    left: 5,
                                  ),
                                  child: GestureDetector(
                                    child: const Icon(
                                      Icons.chevron_right,
                                      size: 14,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (needsToShowFooter())
                    Container(
                      width: double.infinity,
                      height: 50,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(colors: [
                          AppTheme.cobaltoBlue,
                          AppTheme.cobaltoBlue,
                        ]),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                      ),
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 18),
                            child: NvText(
                              textHolder: isAdminRole == false
                                  ? "${copy('payment.transfer')} ${copy('common.spei')}"
                                  : copy('payments.payments-month'),
                              fontFamily: "Jost",
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                              color: AppTheme.black1,
                            ),
                          ),
                          const Spacer(),
                          // ignore: avoid-wrapping-in-padding
                          Padding(
                            padding: const EdgeInsets.only(
                              right: 10,
                              top: 12,
                              bottom: 12,
                            ),
                            child: Container(
                              width: 170,
                              height: 35,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  AppTheme.cobalto2Blue,
                                  AppTheme.cobalto2Blue,
                                ]),
                                borderRadius: BorderRadius.all(
                                  Radius.circular(10),
                                ),
                              ),
                              child: GestureDetector(
                                onTap: () => copyToclipboard(
                                  context,
                                  clabeData?.entity?.referenceNumber ?? "",
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(left: 10),
                                      child: NvText(
                                        textHolder: isAdminRole == false
                                            ? GlobalUtils().formatClabe(
                                                clabeData?.entity
                                                        ?.referenceNumber ??
                                                    "",
                                              )
                                            : obtainTotalAdminPaymentMonth(),
                                        fontFamily: "Jost",
                                        fontWeight: FontWeight.normal,
                                        fontSize: 12,
                                        textAlign: TextAlign.center,
                                        color: AppTheme.black1,
                                      ),
                                    ),
                                    if (isAdminRole == false)
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          right: 5,
                                          left: 5,
                                        ),
                                        child: Icon(
                                          Icons.copy,
                                          size: 10,
                                          color: Colors.white,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (!needsToShowFooter())
                    Container(
                      width: double.infinity,
                      height: 20,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(colors: [
                          AppTheme.cobaltoBlue,
                          AppTheme.cobaltoBlue,
                        ]),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  isAdminRoleLogic() async {
    isAdminRole = await currentProfileUser?.isAdmin();
    // ignore: no-empty-block
    setState(() {});
  }

  isSecurityRoleLogic() async {
    isSecurityRole = await currentProfileUser?.isSecurity();
    // ignore: no-empty-block
    setState(() {});
  }

  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    enterprisesSize = currentProfileUser?.enterpriseList?.length ?? 1;
  }

  getCurrentEnterpriseUser() async {
    currentEnterprise = await currentProfileUser?.getCurrentEnterprise();
    servicePointsSize = currentEnterprise?.servicePointList?.length ?? 1;
  }

  getCurrentServicePointUser() async {
    currentServicePoint = await currentProfileUser?.getCurrentServicePoint();
  }

  setEnterpriseChangeValues(
    int index,
    int servicePointIndex,
    StateSetter bottomSheetSetter,
    int valueSelectedG,
  ) async {
    bottomSheetSetter(() {
      changeEnterpriseButtonEnabled = false;
    });
    currentEnterpriseIndex = index;
    currentServicePointIndex = servicePointIndex - 1;

    setState(() {
      valueSelectedGroup = valueSelectedG;
    });
  }

  changeEnterprise() async {
    var sharePreferences = await SharedPreferences.getInstance();
    sharePreferences.setInt("currentEnterpriseIndex", currentEnterpriseIndex);
    // ignore: format-comment
    // Always -1 because this value is comming from index on servicePointList
    // of one particular enterprise
    sharePreferences.setInt(
      "currentServicePointIndex",
      currentServicePointIndex,
    );
    sharePreferences.setInt("currentZyosGroup", 0);
    await UserUtils().getPermissions();
    Navigator.of(context)
        .pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
  }

  // ignore: long-method
  buildingChange() async {
    if (enterprisesSize > 1 ||
        (enterprisesSize == 1 && servicePointsSize > 1)) {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return SingleChildScrollView(
            child: StatefulBuilder(
              builder: (BuildContext context, StateSetter bottomSheetSetter) {
                return Container(
                  height: 500,
                  color: Colors.white,
                  child: Center(
                    child: Stack(
                      children: [
                        ListView(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 20,
                                bottom: 5,
                              ),
                              child: NvText(
                                textHolder: copy('home.you-are-in'),
                                fontFamily: 'Jost',
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: AppTheme.turquoise4,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                bottom: 5,
                              ),
                              child: NvText(
                                textHolder: currentEnterprise?.name,
                                fontFamily: 'Jost',
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: AppTheme.black0Main,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                bottom: 10,
                              ),
                              child: NvText(
                                textHolder:
                                    copy('home.select-a-condo-you-want'),
                                fontFamily: 'Jost',
                                fontWeight: FontWeight.normal,
                                fontSize: 16,
                                color: AppTheme.black0Main,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            ListView.builder(
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              physics: const BouncingScrollPhysics(),
                              itemCount:
                                  currentProfileUser?.enterpriseList?.length ??
                                      0,
                              itemBuilder: (context, index) {
                                return RowEnterprise(
                                  //ignore: avoid-non-null-assertion
                                  enterprise: currentProfileUser?.enterpriseList
                                      ?.elementAt(index),
                                  setEnterpriseChangeValues:
                                      setEnterpriseChangeValues,
                                  index: index,
                                  bottomSheetSetter: bottomSheetSetter,
                                  valueSelectedGroup: valueSelectedGroup,
                                );
                              },
                            ),
                            const SizedBox(
                              height: 150,
                            ),
                          ],
                        ),
                        Align(
                          alignment: FractionalOffset.bottomCenter,
                          child: Padding(
                            padding: const EdgeInsets.only(
                              left: 16,
                              right: 16,
                            ),
                            child: BottomButton(
                              buttonText: copy('user-access.sign-in'),
                              action: changeEnterprise,
                              disabled: changeEnterpriseButtonEnabled,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      );
    }
  }

  /// It gets data of admin header.
  ///
  callAdminHeader() async {
    headerAdminResponse = await getHeaderAdminInfo(context);
    // ignore: no-empty-block
    setState(() {});
  }

  /// It gets a list of invoices, filters them by date, and then creates a list of controllers for each
  /// list
  callGetDebts() async {
    invoices = await getInvoices(false, UserUtils.currentServicePoint?.id);
    if (!(GlobalUtils.countryId == Constants.coIntIdCode)) {
      clabeData = await getZyosUserClabe();
    }
    // ignore: no-empty-block
    setState(() {});
  }

  needsToShowFooter() {
    if (isAdminRole == false) {
      if (clabeData?.entity != null) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  // ignore: long-method
  String get totalDebt {
    if ((UserUtils.currentEnterprise?.hidePay ?? false) &&
        !UserUtils().isAdminUser()) {
      //"Aquí encontrarás tus pagos pendientes. ¡Espéralo pronto!";
      return copy('home.payments-section-comming-soon');
    } else {
      if (isDebtVisible) {
        if (isAdminRole == false) {
          return getTotalDebt();
        }
        return obtainTotalIncomeValue();
      } else {
        if (isAdminRole == false) {
          return getTotalDebt().replaceAll(RegExp(r"."), "*");
        } else {
          return obtainTotalIncomeValue().replaceAll(RegExp(r"."), "*");
        }
      }
    }
  }

  // ignore: long-method
  activateSpeiNotification() {
    setState(() {
      if (data?.action == "SUCCESSFUL_PAYMENT") {
        BlocProvider.of<WallNotificationsBloc>(context)
            .add(const NewShowSpeiNotification(showSpeiNotification: true));
        BlocProvider.of<WallNotificationsBloc>(context)
            .add(const NewSuccessfulPayment(successfulPayment: true));
        BlocProvider.of<WallNotificationsBloc>(context).add(
          const NewPaymentPendingAssociate(paymentPendingAssociate: false),
        );
      } else if (data?.action == "PAYMENT_PENDING_ASSOCIATE") {
        BlocProvider.of<WallNotificationsBloc>(context)
            .add(const NewShowSpeiNotification(showSpeiNotification: true));
        BlocProvider.of<WallNotificationsBloc>(context)
            .add(const NewSuccessfulPayment(successfulPayment: false));
        BlocProvider.of<WallNotificationsBloc>(context).add(
          const NewPaymentPendingAssociate(paymentPendingAssociate: true),
        );
      } else if (data?.action == "LEGAL_CHARGE_DEACTIVATION") {
        BlocProvider.of<WallNotificationsBloc>(context)
            .add(const NewCurrentLegalCharge(currentLegalCharge: 1));
      } else if (data?.action == "LEGAL_CHARGE_ACTIVATION") {
        BlocProvider.of<WallNotificationsBloc>(context)
            .add(const NewCurrentLegalCharge(currentLegalCharge: 0));
      }
    });
  }

  goToMovements() {
    setState(() {
      BlocProvider.of<WallNotificationsBloc>(context)
          .add(const NewShowSpeiNotification(showSpeiNotification: false));
    });
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => const MainPayments(isComeFrom: "movements"),
      ),
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return LayoutBuilder(
      builder: (context, constraints) {
        final expandRatio = _calculateExpandRatio(constraints);
        final animation = AlwaysStoppedAnimation(expandRatio);

        return OverflowBox(
          alignment: Alignment.topCenter,
          maxHeight: 500,
          child: Column(
            children: [
              if (UserUtils().isSecurityUser())
                Container(
                  color: colors.primary.coral.main,
                  height: 20,
                ),
              Container(
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                      width: 0,
                      color: colors.primary.coral.main,
                    ),
                  ),
                  image: DecorationImage(
                    image: isSecurityRole == true
                        ? const AssetImage(
                            'assets/images/header_home_security.png',
                          )
                        : const AssetImage('assets/images/header_home.png'),
                    fit: BoxFit.cover,
                  ),
                ),
                height: isSecurityRole == true ? 185 : null,
                width: double.infinity,
                child: Stack(
                  children: [
                    Column(
                      children: [
                        if (BlocProvider.of<WallNotificationsBloc>(context)
                                .state
                                .showSpeiNotification ??
                            false) ...[
                          SpeiWallNotification(
                            succesFullPay:
                                (BlocProvider.of<WallNotificationsBloc>(context)
                                        .state
                                        .successfulPayment ??
                                    false),
                            goToMovements: goToMovements,
                          ),
                        ],
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(left: 20.0),
                                  constraints: BoxConstraints(
                                    maxHeight:
                                        MediaQuery.of(context).size.height *
                                            0.28,
                                  ),
                                  child: Row(
                                    children: [
                                      SafeArea(
                                        child: GestureDetector(
                                          onTap: (() => buildingChange()),
                                          child: Row(
                                            children: [
                                              Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .height *
                                                    0.18,
                                                child: NvText(
                                                  textHolder: isAdminRole ==
                                                          false
                                                      ? currentEnterprise !=
                                                              null
                                                          ? "${currentServicePoint?.operationZone?.name ?? ""} - ${currentServicePoint?.name ?? ""}"
                                                          : ""
                                                      : copy(
                                                          'visitors.administrator',
                                                        ),
                                                  fontFamily: 'Jost',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12,
                                                  textAlign: TextAlign.start,
                                                  color: AppTheme.black1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  maxLines: 2,
                                                ),
                                              ),
                                              if (enterprisesSize > 1 ||
                                                  (enterprisesSize == 1 &&
                                                      servicePointsSize > 1))
                                                const Padding(
                                                  padding: EdgeInsets.only(
                                                    top: 20,
                                                    left: 5,
                                                  ),
                                                  child: Icon(
                                                    Icons.keyboard_arrow_down,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 3,
                                    left: 20,
                                    bottom: 10,
                                  ),
                                  child: NvText(
                                    textHolder: currentProfileUser?.name,
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w500,
                                    textAlign: TextAlign.start,
                                    fontSize: 16,
                                    color: AppTheme.black1,
                                  ),
                                ),
                              ],
                            ),
                            const Spacer(),
                            Container(
                              margin: const EdgeInsets.only(top: 20, right: 20),
                              child: Align(
                                alignment: Alignment.topRight,
                                child: Row(
                                  children: [
                                    ClipOval(
                                      child: NvImage(
                                        enterpriseLogo: true,
                                        imageUrl: currentEnterprise?.nameLogo,
                                        width: 42,
                                        height: 42,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () => Navigator.pushNamed(
                                        context,
                                        "profile",
                                      ),
                                      child: ClipOval(
                                        child: NvImage(
                                          isUserImage: true,
                                          width: 42,
                                          height: 42,
                                          imageUrl:
                                              UserUtils.currentUser?.photo,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    if (isSecurityRole == false) ...[
                      Center(
                        child: Padding(
                          padding: EdgeInsets.only(
                            top: needsToShowFooter() ? 20 : 40,
                            left: 20,
                            right: 20,
                          ),
                          child: SizedBox(
                            width: double.infinity,
                            child: _buildPaymentsCard(animation),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String obtainTotalAdminPaymentMonth() {
    if (headerAdminResponse != null) {
      return Constants.currencyFormatter
          .format(headerAdminResponse?.totalAdminPaymentMonth)
          .toString();
    } else {
      return "";
    }
  }

  String obtainTotalIncomeValue() {
    if (headerAdminResponse != null) {
      return Constants.currencyFormatter
          .format(headerAdminResponse?.totalValueIncome)
          .toString();
    } else {
      return "";
    }
  }

  /// It takes a list of invoices, and returns the total debt of all invoices
  ///
  /// Returns:
  ///   A string.
  String getTotalDebt() {
    if (invoices != null) {
      DateFormat dateFormatter = DateFormat("dd/MM/yyyy");
      List<Invoice>? currentDebts = invoices
          ?.where((element) => dateFormatter
              .parse(element.initialDate ?? '')
              .isBefore(DateTime.now()))
          .toList();
      double total = 0;
      currentDebts?.forEach((element) {
        total = total + (element.debt ?? 0);
      });
      return Constants.currencyFormatter.format(total).toString();
    } else {
      return "";
    }
  }

  // ignore: long-method
  navigateToPaymentPage() async {
    if (isAdminRole == false) {
      if ((UserUtils.currentEnterprise?.hidePay ?? false) &&
          !UserUtils().isAdminUser()) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          "disabledPayments",
          (Route<dynamic> route) => false,
        );
      } else {
        PendingTransactionResponse pendingResponse =
            await getPendingTransaction(context);
        if (pendingResponse.list?.isNotEmpty ?? false) {
          if (!mounted) return;
          Navigator.pushReplacementNamed(context, "pendingPaymentView");
        } else {
          if (!mounted) return;
          Navigator.pushReplacementNamed(context, "payments");
        }
      }
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => MainAdminPayments(
            balance: obtainTotalIncomeValue(),
          ),
        ),
      );
    }
  }

  void changeDebtVisibility() {
    setState(() {
      isDebtVisible = !isDebtVisible;
    });
  }

  copyToclipboard(context, String? clabeData) {
    Clipboard.setData(ClipboardData(
      text: clabeData ?? "",
    ));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(copy('home.copied-to-clipboard')),
    ));
  }
}
