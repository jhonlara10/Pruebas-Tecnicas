import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/admin_menu.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/user_menu.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class TopOptionsMenu extends StatefulWidget {
  const TopOptionsMenu({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _TopOptionsMenu createState() => _TopOptionsMenu();
}

class _TopOptionsMenu extends State<TopOptionsMenu> {
  User? currentProfileUser;
  bool? isAdminRole = false;
  bool? isSecurityRole = false;

  @override
  void initState() {
    (() async {
      await UserUtils().getCurrentUser();
      await UserUtils().getCurrentEnterprise();
      await UserUtils().getCurrentZyosGroup();
      await getProfileCurrentUser();
      isAdminRole = await currentProfileUser?.isAdmin();
      isSecurityRole = await currentProfileUser?.isSecurity();
    })();
    super.initState();
  }

  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return isAdminRole == false
        ? UserMenu(isSecurityRole == true ? true : false)
        : const AdminMenu();
  }
}
