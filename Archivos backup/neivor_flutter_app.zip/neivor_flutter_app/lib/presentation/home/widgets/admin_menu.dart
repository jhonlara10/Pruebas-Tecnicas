import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class AdminMenu extends StatelessWidget {
  const AdminMenu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screnDividerInFour = (MediaQuery.of(context).size.width / 4) - 8;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: screnDividerInFour,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FloatingActionButton(
                  heroTag: "tickets",
                  backgroundColor: AppTheme.blueButtons,
                  onPressed: () {
                    Navigator.pushNamed(context, "tickets");
                  },
                  child: Image.asset(
                    "assets/images/question.png",
                    width: 25,
                    height: 25,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  child: SizedBox(
                    width: screnDividerInFour - 15,
                    child: const NvText(
                      color: AppTheme.black0Main,
                      copy: 'home.consultation-incidents',
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.normal,
                      fontSize: 12,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: screnDividerInFour,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FloatingActionButton(
                  heroTag: "visitors",
                  backgroundColor: AppTheme.blueButtons,
                  onPressed: () {
                    Navigator.pushNamed(context, "visitors");
                  },
                  child: Image.asset(
                    "assets/images/with_qr.png",
                    width: 25,
                    height: 25,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  child: SizedBox(
                    width: screnDividerInFour - 15,
                    child: const NvText(
                      color: AppTheme.black0Main,
                      copy: 'home.record-your-visits',
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.normal,
                      fontSize: 12,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (UserUtils().hasPermissionsTo(17))
            SizedBox(
              width: screnDividerInFour,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  FloatingActionButton(
                    heroTag: "news",
                    backgroundColor: AppTheme.blueButtons,
                    onPressed: () {
                      Navigator.pushNamed(context, "addNews");
                    },
                    child: Image.asset(
                      "assets/images/news.png",
                      width: 25,
                      height: 25,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: SizedBox(
                      width: screnDividerInFour - 25,
                      child: const NvText(
                        color: AppTheme.black0Main,
                        copy: 'home.create-a-news',
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.normal,
                        fontSize: 12,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          SizedBox(
            width: screnDividerInFour,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FloatingActionButton(
                  heroTag: "wish",
                  backgroundColor: AppTheme.blueButtons,
                  onPressed: () {
                    Navigator.pushNamed(context, "wish");
                  },
                  child: Image.asset(
                    "assets/images/wish.png",
                    width: 25,
                    height: 25,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  child: SizedBox(
                    width: screnDividerInFour - 35,
                    child: const NvText(
                      color: AppTheme.black0Main,
                      copy: 'home.make-a-wish',
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.normal,
                      fontSize: 12,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
