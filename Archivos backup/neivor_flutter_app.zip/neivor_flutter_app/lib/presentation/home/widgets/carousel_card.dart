import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_tag.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
// ignore: depend_on_referenced_packages
import 'package:html/parser.dart';
import 'package:neivor_flutter_app/helpers/string_helper.dart';

import '../../../../domain/models/news/list_news_response.dart';

import 'reactions_counter.dart';

class CarouselCard extends StatelessWidget {
  final Function goToNewsDetail;
  final ListNewsResponse? newItem;

  const CarouselCard({
    Key? key,
    required this.newItem,
    required this.goToNewsDetail,
  }) : super(key: key);

  String parseHtmlString(String? htmlString) {
    final document = parse(htmlString);
    return parse(document.body?.text).documentElement!.text;
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return Container(
      margin: const EdgeInsets.only(
        right: 16.0,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: colors.primary.black.v1,
          width: 1.0,
        ),
        borderRadius: const BorderRadius.all(
          Radius.circular(8.0),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: (() {
              if (UserUtils().hasPermissionsTo(810)) goToNewsDetail(newItem);
            }),
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 143,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(8.0),
                          topRight: Radius.circular(8.0),
                        ),
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: NetworkImage(
                            GlobalUtils().cdn(newItem?.image),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0, right: 4.0),
                      child: NvTag(
                        label: GlobalUtils().getNewType(newItem?.idNoticeType),
                        state: TagVariant.yellow,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 16.0,
                    right: 16.0,
                    top: 8,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      NvText(
                        textHolder: newItem?.name?.capitalize(),
                        fontFamily: "Jost",
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: colors.text.primary,
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      NvText(
                        textHolder: parseHtmlString(newItem?.description),
                        fontFamily: "Jost",
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: colors.text.primary,
                        maxLines: 2,
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      NvText(
                        textHolder: copy('common.see-more'),
                        fontFamily: "Jost",
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: colors.primary.turquoise.v4,
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      if (newItem?.reactionCountJson != null)
                        ReactionsCounter(
                          totalLike: newItem?.reactionCountJson?.totalLike,
                          totalLove: newItem?.reactionCountJson?.totalLove,
                          totalWow: newItem?.reactionCountJson?.totalWow,
                          totalReaction:
                              newItem?.reactionCountJson?.totalReaction,
                        ),
                      const SizedBox(
                        height: 8,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // ------------- ESTO AUN NO VA -------------
          // Padding(
          //   padding: const EdgeInsets.only(bottom: 12, left: 24, right: 16),
          //   child: Row(
          //     children: [
          //       const NvImage(
          //         imageUrl: 'ds/icons/like.svg',
          //         width: 14,
          //       ),
          //       const SizedBox(
          //         width: 8,
          //       ),
          //       NvText(
          //         textHolder: "Me Gusta",
          //         fontFamily: "Jost",
          //         fontWeight: FontWeight.bold,
          //         fontSize: 16,
          //         color: colors.primary.black.main,
          //       ),
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }
}
