import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/home/home.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class CircleButtonMenu extends StatelessWidget {
  final double screenDivider;
  final String nameButton;
  final String navigationTo;
  final String imageButton;
  final String copyLabelButton;
  final Widget? buildedRoute;

  const CircleButtonMenu({
    Key? key,
    required this.screenDivider,
    required this.nameButton,
    required this.navigationTo,
    required this.imageButton,
    required this.copyLabelButton,
    this.buildedRoute,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: screenDivider,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          FloatingActionButton(
            heroTag: nameButton,
            backgroundColor: AppTheme.blueButtons,
            // ignore: prefer-extracting-callbacks
            onPressed: () {
              buildedRoute != null
                  ? Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => buildedRoute ?? const Home(),
                      ),
                      (Route<dynamic> route) => false,
                    )
                  : Navigator.pushNamed(context, navigationTo);
            },
            child: Image.asset(
              imageButton,
              width: 25,
              height: 25,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 10),
            child: SizedBox(
              width: screenDivider - 25,
              child: NvText(
                color: AppTheme.black0Main,
                copy: copyLabelButton,
                fontFamily: 'Jost',
                fontWeight: FontWeight.normal,
                fontSize: 12,
                textAlign: TextAlign.center,
                maxLines: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
