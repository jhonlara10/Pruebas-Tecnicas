import 'dart:io';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu-widgets/row_menu.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class BottomOptionsMenu extends StatefulWidget {
  const BottomOptionsMenu({Key? key}) : super(key: key);

  @override
  State<BottomOptionsMenu> createState() => _BottomOptionsMenuState();
}

class _BottomOptionsMenuState extends State<BottomOptionsMenu> {
  User? currentProfileUser;
  bool? isAdminRole = false; //TODO: permissions here
  bool? isSecurityRole = false;
  bool? isOwnerRole = false;
  bool isIOSChatButtonEnabled = false;
  @override
  void initState() {
    (() async {
      await AppUrls().getPreferences();
      await UserUtils().getCurrentUser();
      await UserUtils().getCurrentEnterprise();
      await UserUtils().getCurrentZyosGroup();
      await getProfileCurrentUser();
      isIOSChatButtonEnabled =
          AppUrls().getProperty("api.ios.showGoogleSocialButton") == "true"
              ? true
              : false;
      isAdminRole = await currentProfileUser?.isAdmin();
      isSecurityRole = await currentProfileUser?.isSecurity();
      isOwnerRole = await currentProfileUser?.isOwner();
    })();
    super.initState();
  }

  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return RowMenu(
      isAdminRole ?? false,
      isSecurityRole ?? false,
      isOwnerRole ?? false,
      (Platform.isAndroid || (Platform.isIOS && isIOSChatButtonEnabled)),
    );
  }
}
