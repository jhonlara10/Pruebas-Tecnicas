import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu-widgets/circle_button_menu.dart';
import 'package:neivor_flutter_app/presentation/messages/add_message.dart';

class UserMenu extends StatelessWidget {
  final bool isSecurityRole;

  const UserMenu(this.isSecurityRole, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screnDividerInFour = (MediaQuery.of(context).size.width / 4) - 8;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        children: [
          if (!isSecurityRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //"Reporta incidencias",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "tickets",
                  navigationTo: "tickets",
                  imageButton: "assets/images/question.png",
                  copyLabelButton: 'home.report-incidents',
                ),

                //"Registra tus visitas",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "visitors",
                  navigationTo: "visitors",
                  imageButton: "assets/images/with_qr.png",
                  copyLabelButton: 'home.record-your-visits',
                ),

                //"Reserva amenidades",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "amenities",
                  navigationTo: "amenities",
                  imageButton: "assets/images/amenities.png",
                  copyLabelButton: 'home.reservation-menities',
                ),

                //"Recoge tus paquetes",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "packages",
                  navigationTo: "packagesResident",
                  imageButton: "assets/images/packages.png",
                  copyLabelButton: "packages.pick-up",
                ),
              ],
            ),
          if (isSecurityRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //"Registra tus visitas",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "visitors",
                  navigationTo: "visitorsSecurity",
                  imageButton: "assets/images/with_qr.png",
                  copyLabelButton: "home.record-your-visits",
                ),

                //"Registra paquetes",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "packages",
                  navigationTo: "packages",
                  imageButton: "assets/images/packages.png",
                  copyLabelButton: "home.register-packages",
                ),

                //"Accede al directorio",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "phone",
                  navigationTo: "",
                  imageButton: "assets/images/phone.png",
                  copyLabelButton: "home.access-directory",
                  buildedRoute: const AddMessage(fromWall: true),
                ),

                //"Reporta incidencias",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "tickets",
                  navigationTo: "tickets",
                  imageButton: "assets/images/question.png",
                  copyLabelButton: 'home.report-incidents',
                ),
              ],
            ),
        ],
      ),
    );
  }
}
