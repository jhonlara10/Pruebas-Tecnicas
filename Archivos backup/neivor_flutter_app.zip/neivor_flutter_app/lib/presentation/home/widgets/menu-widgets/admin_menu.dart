import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu-widgets/circle_button_menu.dart';

class AdminMenu extends StatelessWidget {
  const AdminMenu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screnDividerInFour = (MediaQuery.of(context).size.width / 4) - 8;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //"Reporta incidencias",
          CircleButtonMenu(
            screenDivider: screnDividerInFour,
            nameButton: "tickets",
            navigationTo: "tickets",
            imageButton: "assets/images/question.png",
            copyLabelButton: "home.consultation-incidents",
          ),

          //"Registra visitas",
          CircleButtonMenu(
            screenDivider: screnDividerInFour,
            nameButton: "visitors",
            navigationTo: "visitors",
            imageButton: "assets/images/with_qr.png",
            copyLabelButton: "home.record-your-visits",
          ),

          //"Crea un anuncio",
          CircleButtonMenu(
            screenDivider: screnDividerInFour,
            nameButton: "news",
            navigationTo: "addNews",
            imageButton: "assets/images/news.png",
            copyLabelButton: "home.create-a-news",
          ),

          //"Pide un deseo",
          CircleButtonMenu(
            screenDivider: screnDividerInFour,
            nameButton: "wish",
            navigationTo: "wish",
            imageButton: "assets/images/wish.png",
            copyLabelButton: "home.make-a-wish",
          ),
        ],
      ),
    );
  }
}
