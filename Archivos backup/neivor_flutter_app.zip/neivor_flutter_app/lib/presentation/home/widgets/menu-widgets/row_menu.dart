import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu-widgets/circle_button_menu.dart';
import 'package:neivor_flutter_app/presentation/messages/add_message.dart';
import 'package:neivor_flutter_app/presentation/payments/disabled_payments.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class RowMenu extends StatelessWidget {
  const RowMenu(
    this.isAdminRole,
    this.isSecurityRole,
    this.isOwnerRole,
    this.messagesButtonVisibility, {
    Key? key,
  }) : super(key: key);

  final bool isAdminRole;
  final bool isSecurityRole;
  final bool isOwnerRole;
  final bool messagesButtonVisibility;

  @override
  Widget build(BuildContext context) {
    var hidePay = UserUtils.currentEnterprise?.hidePay ?? false;
    final screnDividerInFour = (MediaQuery.of(context).size.width / 4) - 8;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        children: [
          if (isAdminRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //"Accede al directorio",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "phone",
                  navigationTo: "",
                  imageButton: "assets/images/phone.png",
                  copyLabelButton: "home.access-directory",
                  buildedRoute: const AddMessage(fromWall: true),
                ),

                //"Reserva amenidades",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "amenities",
                  navigationTo: "amenities",
                  imageButton: "assets/images/amenities.png",
                  copyLabelButton: 'home.reservation-menities',
                ),

                //"shop",
                // CircleButtonMenu(
                //   screenDivider: screnDividerInFour,
                //   nameButton: "shop",
                //   navigationTo: "",
                //   imageButton: "assets/images/shop.png",
                //   copyLabelButton: 'home.reservation-menities',
                // ),
              ],
            ),
          if (!isSecurityRole && !isAdminRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //"Llama al portero",
                if (UserUtils().hasPermissionsTo(700))
                  CircleButtonMenu(
                    screenDivider: screnDividerInFour,
                    nameButton: "phone",
                    navigationTo: "",
                    imageButton: "assets/images/phone.png",
                    copyLabelButton: "home.call-the-doorman",
                    buildedRoute: const AddMessage(fromWall: true),
                  ),

                //"Consulta los recibos",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "invoice",
                  navigationTo: "",
                  imageButton: "assets/images/invoice.png",
                  copyLabelButton: "home.check-the-receipts",
                  buildedRoute: hidePay
                      ? const DisabledPayments()
                      : const MainPayments(isComeFrom: "history"),
                ),
                if (messagesButtonVisibility)
                  //"Enviar mensajes",
                  CircleButtonMenu(
                    screenDivider: screnDividerInFour,
                    nameButton: "message",
                    navigationTo: "messages",
                    imageButton: "assets/images/message.png",
                    copyLabelButton: "home.shared-message",
                    //buildedRoute: const AddMessage(fromWall: true),
                  ),
              ],
            ),
          if (isSecurityRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //"Enviar mensajes",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "message",
                  navigationTo: "messages",
                  imageButton: "assets/images/message.png",
                  copyLabelButton: "home.shared-message",
                  //buildedRoute: const AddMessage(fromWall: true),
                ),

                //"Consulta el reglamento",
                CircleButtonMenu(
                  screenDivider: screnDividerInFour,
                  nameButton: "documents",
                  navigationTo: "documents",
                  imageButton: "assets/images/documents-icon.png",
                  copyLabelButton: "home.condominium-rules",
                ),
              ],
            ),
        ],
      ),
    );
  }
}
