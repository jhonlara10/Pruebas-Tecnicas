import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class RowMenu extends StatelessWidget {
  const RowMenu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 12, right: 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FloatingActionButton(
                heroTag: "invoice",
                backgroundColor: AppTheme.blueButtons,
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        const MainPayments(isComeFrom: "history"),
                  ),
                ),
                child: Image.asset(
                  "assets/images/invoice.png",
                  width: 25,
                  height: 25,
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child: NvText(
                  color: AppTheme.black0Main,
                  textHolder: "Consulta\nlos recibos",
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 12,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FloatingActionButton(
                heroTag: "message",
                backgroundColor: AppTheme.blueButtons,
                onPressed: () {
                  Navigator.pushNamed(context, "messages");
                },
                child: Image.asset(
                  "assets/images/message.png",
                  width: 25,
                  height: 25,
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child: NvText(
                  color: AppTheme.black0Main,
                  textHolder: "Enviar\nmensajes",
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 12,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
        /*Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FloatingActionButton(
                heroTag: "shop",
                backgroundColor: AppTheme.blueButtons,
                onPressed: () {},
                child: Image.asset(
                  "assets/images/shop.png",
                  width: 25,
                  height: 25,
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child: NvText(
                  color: AppTheme.black0Main,
                  textHolder: "Tienda\n",
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 12,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),*/
      ],
    );
  }
}
