import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class DocumentsContainer extends StatelessWidget {
  const DocumentsContainer({Key? key, this.copy}) : super(key: key);
  final copy;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: NvText(
            color: AppTheme.black0Main,
            fontFamily: 'Jost',
            textHolder: copy('home.condominium-regulation'),
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        GestureDetector(
          child: Padding(
            padding: const EdgeInsets.only(
              left: 16,
              right: 16,
              bottom: 20,
            ),
            child: Column(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    border: Border.fromBorderSide(
                      BorderSide(color: AppTheme.grayBorder),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                  ),
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 20,
                              left: 18,
                              bottom: 10,
                            ),
                            child: NvText(
                              color: AppTheme.black0Main,
                              fontFamily: 'Jost',
                              textHolder:
                                  copy('home.documents-and-regulations'),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 18,
                              bottom: 20,
                            ),
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width * 0.5,
                              child: NvText(
                                color: AppTheme.black0Main,
                                fontFamily: 'Jost',
                                textHolder: copy(
                                  'home.regulations-of-your-condominium',
                                ),
                                fontWeight: FontWeight.normal,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Image.asset(
                        "assets/images/documents.png",
                        width: 90,
                        height: 90,
                      ),
                      Image.asset("assets/images/chevron.png"),
                    ],
                  ),
                ),
              ],
            ),
          ),
          onTap: () => {
            Navigator.pushNamed(context, "documents"),
          },
        ),
      ],
    );
  }
}
