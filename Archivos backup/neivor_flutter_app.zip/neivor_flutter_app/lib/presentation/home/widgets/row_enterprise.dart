import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

import '../../../domain/models/login/enterprise.dart';

/// Widget class to populate ListView rows of enterprises to change enterprise.
///
/// This Widget have:
/// [Text] to put enterprise name.
///
/// Constructor params:
/// [Enterprise] object with info of enterprise.
/// [Function] callback of click listener of row to handle on UI.
///
class RowEnterprise extends StatefulWidget {
  final Enterprise? enterprise;
  // ignore: prefer-correct-identifier-length
  final Function setEnterpriseChangeValues;
  final int index;
  final StateSetter bottomSheetSetter;
  final int? valueSelectedGroup;

  const RowEnterprise({
    Key? key,
    required this.enterprise,
    required this.setEnterpriseChangeValues,
    required this.index,
    required this.bottomSheetSetter,
    required this.valueSelectedGroup,
  }) : super(key: key);

  @override
  State<RowEnterprise> createState() => RowEnterpriseState();
}

class RowEnterpriseState extends State<RowEnterprise> {
  int? selectedValue;

  @override
  void initState() {
    super.initState();
    selectedValue = 0;
  }

  @override
  Widget build(BuildContext context) {
    const size = 0.55;

    TextStyle advancedOptionsStyle = const TextStyle(
      color: AppTheme.black0Main,
      fontWeight: FontWeight.w400,
      fontFamily: 'Jost',
      fontSize: 16,
    );

    return Padding(
      padding: const EdgeInsets.only(right: 16, left: 16),
      child: ExpandablePanel(
        theme: const ExpandableThemeData(
          headerAlignment: ExpandablePanelHeaderAlignment.center,
        ),
        header: Row(
          children: [
            const Padding(
              padding: EdgeInsets.only(left: 10),
              child: Icon(
                Icons.apartment,
                color: AppTheme.black0Main,
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * size,
              padding: const EdgeInsets.only(left: 5),
              child: Text(
                widget.enterprise?.name ?? "",
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
                style: advancedOptionsStyle,
              ),
            ),
          ],
        ),
        collapsed: const SizedBox(),
        expanded: ListView.builder(
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          physics: const BouncingScrollPhysics(),
          itemCount: widget.enterprise?.servicePointList?.length ?? 0,
          itemBuilder: (context, indexServicePoint) {
            return ListTile(
              title: Padding(
                padding: const EdgeInsets.only(left: 23),
                child: NvText(
                  textHolder:
                      "${widget.enterprise?.servicePointList?.elementAt(indexServicePoint).operationZone?.name ?? ""} - ${widget.enterprise?.servicePointList?.elementAt(indexServicePoint).name ?? ""}",
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 16,
                  color: AppTheme.black3,
                ),
              ),
              trailing: Padding(
                padding: const EdgeInsets.only(left: 5),
                child: Radio(
                  value: (widget.enterprise?.servicePointList
                          ?.elementAt(indexServicePoint)
                          .id ??
                      0),
                  groupValue: widget.valueSelectedGroup,
                  // ignore: prefer-extracting-callbacks
                  onChanged: (int? value) {
                    widget.setEnterpriseChangeValues(
                      widget.index,
                      (indexServicePoint + 1),
                      widget.bottomSheetSetter,
                      value, //value is used for match with groupValue
                    );
                    setState(() {
                      selectedValue = value;
                    });
                  },
                  toggleable: true,
                  activeColor: Colors.green,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
