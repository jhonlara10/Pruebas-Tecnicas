import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu-widgets/bottom_options_menu.dart';
import 'package:neivor_flutter_app/presentation/home/widgets/menu-widgets/top_options_menu.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class MenuSectionMain extends StatefulWidget {
  final bool isSeeMoreVisible;
  final Function hideSeeMoreSection;

  const MenuSectionMain({
    Key? key,
    required this.isSeeMoreVisible,
    required this.hideSeeMoreSection,
  }) : super(key: key);

  @override
  State<MenuSectionMain> createState() => _MenuSectionMainState();
}

class _MenuSectionMainState extends State<MenuSectionMain> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(top: 10, right: 10, left: 16, bottom: 10),
          child: NvText(
            //"¿Que deseas hacer?",
            copy: 'home.what-do-you-want-to-do',
            fontFamily: 'Jost',
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: Colors.black,
          ),
        ),
        const TopOptionsMenu(),
        widget.isSeeMoreVisible ? const BottomOptionsMenu() : Container(),
        GestureDetector(
          onTap: () => widget.hideSeeMoreSection(),
          child: Center(
            child: Container(
              width: 160,
              height: 35,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [
                  AppTheme.cobalto3Blue,
                  AppTheme.cobalto3Blue,
                ]),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 7),
                    child: NvText(
                      copy: !widget.isSeeMoreVisible
                          ? 'common.see-more'
                          : 'common.see-less',
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.normal,
                      textAlign: TextAlign.center,
                      fontSize: 15,
                      color: AppTheme.black0Main,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 7),
                    child: Icon(
                      !widget.isSeeMoreVisible
                          ? Icons.expand_more
                          : Icons.expand_less,
                      size: 14,
                      color: AppTheme.black0Main,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
