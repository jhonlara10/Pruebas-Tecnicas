import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class SpeiWallNotification extends StatelessWidget {
  const SpeiWallNotification({
    Key? key,
    required this.succesFullPay,
    required this.goToMovements,
  }) : super(key: key);

  final bool succesFullPay;
  final Function goToMovements;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => goToMovements(),
      child: Container(
        margin: const EdgeInsets.only(top: 16),
        padding: const EdgeInsets.all(19),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          color: succesFullPay
              ? AppThemeScope.of(context).colors.secondary.harlequinGreen.v2
              : AppThemeScope.of(context).colors.secondary.indigoBlue.v2,
        ),
        width: MediaQuery.of(context).size.width - 32,
        child: Row(
          children: [
            NvImage(
              imageUrl: succesFullPay
                  ? "/ds/icons/check-success.svg"
                  : "/ds/icons/info-blue.svg",
              height: succesFullPay ? 18 : 25,
            ),
            const SizedBox(
              width: 13,
            ),
            Text(
              succesFullPay
                  ? "El pago ha sido exitoso"
                  : "Tienes un pago pendiente por asociar",
              style: AppThemeScope.of(context).typography.bd1.medium.copyWith(
                    color: succesFullPay
                        ? AppThemeScope.of(context)
                            .colors
                            .secondary
                            .harlequinGreen
                            .v4
                        : AppThemeScope.of(context)
                            .colors
                            .secondary
                            .indigoBlue
                            .v4,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
