import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/messages/add_message.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class UserMenu extends StatelessWidget {
  final bool isSecurityRole;

  const UserMenu(this.isSecurityRole, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screnDividerInFour = (MediaQuery.of(context).size.width / 4) - 8;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        children: [
          if (!isSecurityRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: screnDividerInFour,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        heroTag: "tickets",
                        backgroundColor: AppTheme.blueButtons,
                        onPressed: () {
                          Navigator.pushNamed(context, "tickets");
                        },
                        child: Image.asset(
                          "assets/images/question.png",
                          width: 25,
                          height: 25,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: SizedBox(
                          width: screnDividerInFour - 15,
                          child: const NvText(
                            color: AppTheme.black0Main,
                            //"Reporta incidencias",
                            copy: 'home.report-incidents',
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 12,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (UserUtils().hasPermissionsTo(606))
                  SizedBox(
                    width: screnDividerInFour,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        FloatingActionButton(
                          heroTag: "visitors",
                          backgroundColor: AppTheme.blueButtons,
                          // ignore: prefer-extracting-callbacks
                          onPressed: () {
                            Navigator.pushNamed(context, "visitors");
                          },
                          child: Image.asset(
                            "assets/images/with_qr.png",
                            width: 25,
                            height: 25,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10, bottom: 10),
                          child: SizedBox(
                            width: screnDividerInFour - 15,
                            child: const NvText(
                              color: AppTheme.black0Main,
                              //"Registra tus visitas",
                              copy: 'home.record-your-visits',
                              fontFamily: 'Jost',
                              fontWeight: FontWeight.normal,
                              fontSize: 12,
                              textAlign: TextAlign.center,
                              maxLines: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                SizedBox(
                  width: screnDividerInFour,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        heroTag: "amenities",
                        backgroundColor: AppTheme.blueButtons,
                        onPressed: () {
                          Navigator.pushNamed(context, "amenities");
                        },
                        child: Image.asset(
                          "assets/images/amenities.png",
                          width: 25,
                          height: 25,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: SizedBox(
                          width: screnDividerInFour - 15,
                          child: const NvText(
                            color: AppTheme.black0Main,
                            //"Reserva amenidades",
                            copy: 'home.reservation-menities',
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 12,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: screnDividerInFour,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        heroTag: "packages",
                        backgroundColor: AppTheme.blueButtons,
                        onPressed: () {
                          Navigator.pushNamed(context, "packagesResident");
                        },
                        child: Image.asset(
                          "assets/images/packages.png",
                          width: 25,
                          height: 25,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: SizedBox(
                          width: screnDividerInFour - 15,
                          child: const NvText(
                            color: AppTheme.black0Main,
                            //"Recoge tus paquetes",
                            copy: "packages.pick-up",
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 12,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          if (isSecurityRole)
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (UserUtils().hasPermissionsTo(606))
                  SizedBox(
                    width: screnDividerInFour,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        FloatingActionButton(
                          heroTag: "visitors",
                          backgroundColor: AppTheme.blueButtons,
                          // ignore: prefer-extracting-callbacks
                          onPressed: () {
                            Navigator.pushNamed(context, "visitorsSecurity");
                          },
                          child: Image.asset(
                            "assets/images/with_qr.png",
                            width: 25,
                            height: 25,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10, bottom: 10),
                          child: SizedBox(
                            width: screnDividerInFour - 15,
                            child: const NvText(
                              color: AppTheme.black0Main,
                              //"Registra tus visitas",
                              copy: 'home.record-your-visits',
                              fontFamily: 'Jost',
                              fontWeight: FontWeight.normal,
                              fontSize: 12,
                              textAlign: TextAlign.center,
                              maxLines: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                SizedBox(
                  width: screnDividerInFour,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        heroTag: "packages",
                        backgroundColor: AppTheme.blueButtons,
                        onPressed: () {
                          Navigator.pushNamed(context, "packages");
                        },
                        child: Image.asset(
                          "assets/images/packages.png",
                          width: 25,
                          height: 25,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: SizedBox(
                          width: screnDividerInFour - 15,
                          child: const NvText(
                            color: AppTheme.black0Main,
                            //"Registra paquetes",
                            copy: 'home.register-packages',
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 12,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: screnDividerInFour,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        heroTag: "phone",
                        backgroundColor: AppTheme.blueButtons,
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const AddMessage(fromWall: true),
                            ),
                            (Route<dynamic> route) => false,
                          );
                        },
                        child: Image.asset(
                          "assets/images/phone.png",
                          width: 25,
                          height: 25,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: SizedBox(
                          width: screnDividerInFour - 25,
                          child: const NvText(
                            color: AppTheme.black0Main,
                            //"Accede al directorio",
                            copy: 'home.access-directory',
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 12,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: screnDividerInFour,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        heroTag: "tickets",
                        backgroundColor: AppTheme.blueButtons,
                        onPressed: () {
                          Navigator.pushNamed(context, "tickets");
                        },
                        child: Image.asset(
                          "assets/images/question.png",
                          width: 25,
                          height: 25,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: SizedBox(
                          width: screnDividerInFour - 15,
                          child: const NvText(
                            color: AppTheme.black0Main,
                            //"Reporta incidencias",
                            copy: 'home.report-incidents',
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 12,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
