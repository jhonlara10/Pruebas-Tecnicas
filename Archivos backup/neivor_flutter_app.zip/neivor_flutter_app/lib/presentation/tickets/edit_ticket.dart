import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/tickets/tickets_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class EditTicket extends StatefulWidget {
  const EditTicket({Key? key}) : super(key: key);
  static const int _fixedDecimals = 2;
  static const double _calendarButtonSize = 40;
  static const int _messageLength = 250;
  static const int _messageMinLines = 5;
  static const int _messageMaxLines = 8;
  static const double _previewHeight = 93;
  static const double _previewWidth = 151;

  @override
  State<EditTicket> createState() => _EditTicketState();
}

class _EditTicketState extends State<EditTicket> {
  final copy = AppMessages().getCopy;
  TicketsRequestResponse? selectedTicket;
  // SelectedDate default value is tomorrow.
  DateTime selectedDate = DateTime.now().add(const Duration(days: 1));

  /// Creating a global key for the form.
  final editTicketsFormKey = GlobalKey<FormState>();

  /// Ticket state options.
  List<DropdownMenuItem<int>> states = [
    const DropdownMenuItem(value: 1, child: Text("En progreso")),
    const DropdownMenuItem(value: 0, child: Text("Finalizado")),
    const DropdownMenuItem(value: 2, child: Text("Nuevo")),
  ];

  Map<String, dynamic> updateFormValues = {};
  Map<String, dynamic> sendMessageFormValues = {};

  final ImagePicker _picker = ImagePicker();
  XFile? image;
  String? imgAsBase64;

  @override
  // ignore: long-method
  void initState() {
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        if (ModalRoute.of(context)?.settings.arguments != null) {
          /// Getting the arguments passed to the route.
          selectedTicket = ModalRoute.of(context)?.settings.arguments
              as TicketsRequestResponse;
          selectedDate = parseInitialDate;
          // Declaring jsons default values.
          updateFormValues = {
            "id": selectedTicket?.id,
            "dateCreation": selectedTicket?.dateCreation,
            "hourCreation": selectedTicket?.hourCreation,
            "state": selectedTicket?.state,
            "title": selectedTicket?.title,
            "description": selectedTicket?.description,
            "idZyosUser": selectedTicket?.idZyosUser,
            "idResponsible": selectedTicket?.idResponsible,
            "idServicePoint": selectedTicket?.idServicePoint,
            "idEnterprise": selectedTicket?.idEnterprise,
            "idConversation": selectedTicket?.idConversation,
            "nameServicePoint": selectedTicket?.nameServicePoint,
            "idComplaintDemandType": selectedTicket?.idComplaintDemandType,
            "idStateComplaintDemand": selectedTicket?.idStateComplaintDemand,
            "daysBetweenDeadLine": selectedTicket?.daysBetweenDeadLine,
            "deadLineLong": selectedTicket?.deadLineLong,
            "numberCD": selectedTicket?.numberCD,
            "nameUser": selectedTicket?.nameUser,
            "nameResponsible": selectedTicket?.nameResponsible,
            "email": selectedTicket?.email,
            "messageUnread": selectedTicket?.messageUnread,
            "adminUser": selectedTicket?.adminUser,
            "updateResponsible": selectedTicket?.updateResponsible,
            "deadLineUpdate": parseInitialDate,
            "userChange": UserUtils.currentUser?.id,
          };
          sendMessageFormValues = {
            "newMessage": false,
            "userCreation": UserUtils.currentUser?.id,
            "idZyosUserCreator": UserUtils.currentUser?.id,
            "recipients": null,
            "idEnterprise": UserUtils.currentEnterprise?.id,
            "messageBody": "",
            "idConversation": selectedTicket?.idConversation,
            "pqr": true,
            "adminUser": UserUtils().isAdminUser(),
          };
        }
      });
    });
  }

  /// It's a function that opens a date picker dialog, and when the user selects a date, it updates the
  /// state of the widget
  ///
  /// Args:
  ///   context (BuildContext): context,
  ///
  /// Returns:
  ///   A DateTime object
  // ignore: long-method
  selectDate(BuildContext context) async {
    final DateTime? selected = await showDatePicker(
      cancelText: AppMessages().getCopy('common.cancel'), //"Cancelar",
      confirmText: AppMessages().getCopy('common.accept'), //"Aceptar"
      //! the calendar is in english
      //? we need a deeper Locale config to modify it otherwise it will thrown an error
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2025),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppTheme.coral0Main,
              onPrimary: AppTheme.textPrimary,
              //ignore: no-equal-arguments
              onSurface: AppTheme.textPrimary,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                backgroundColor: AppTheme.coral0Main,
                primary: AppTheme.grayArtic5,
              ),
            ),
          ),
          child: child ?? const Text(''),
        );
      },
    );
    if (selected != null && selected != selectedDate) {
      setState(() {
        selectedDate = selected;
        updateFormValues["deadLineUpdate"] =
            selectedDate.millisecondsSinceEpoch;
      });
    }
  }

  /// It takes an image from the gallery and converts it to a base64 string
  ///
  /// Returns:
  ///   The image as a base64 string.
  // ignore: long-method
  pickImage() async {
    try {
      image = await _picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        imgAsBase64 = await imgToBase64();
        // ignore: no-empty-block
        setState(() {});
      } else {
        showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            Future.delayed(const Duration(seconds: 3), () {
              Navigator.of(context).pop();
            });
            return const NvAlert(
              type: "alert",
              content: "No se a seleccionado una imagen",
            );
          },
        );
      }
    } catch (e) {
      log(e.toString());
    }
  }

  /// It takes the image path, reads the bytes, encodes the bytes to base64, and returns the base64
  /// encoded string
  ///
  /// Returns:
  ///   A Future&lt;String&gt;
  imgToBase64() async {
    final Uint8List bytes;
    if (image != null) {
      //ignore: avoid-non-null-assertion
      bytes = await File(image!.path).readAsBytes();
      String base64Encoded = base64Encode(bytes);
      String prefix =
          //ignore: avoid-non-null-assertion
          "data:image/${image!.path.substring(image!.path.length - 3)};base64,";
      return prefix + base64Encoded;
    }
  }

  /// It takes a file, reads it as bytes, and returns the size of the file in kilobytes
  ///
  /// Args:
  ///   img (XFile): The image file
  ///
  /// Returns:
  ///   A string.
  String getImageSize(XFile img) {
    final size = File(img.path).readAsBytesSync().lengthInBytes;
    return (size / Constants.byteSize)
        .toStringAsFixed(EditTicket._fixedDecimals);
  }

  /// It sends a request to update a ticket, then sends a message to the ticket, then if there's an
  /// image it sends the image to the ticket
  ///
  /// Returns:
  ///   a Future&lt;void&gt;.
  // ignore: long-method
  sendData() async {
    try {
      //ignore: avoid-non-null-assertion
      if (editTicketsFormKey.currentState!.validate()) {
        context.loaderOverlay.show();

        if (updateFormValues["deadLineUpdate"].runtimeType == DateTime) {
          updateFormValues["deadLineUpdate"] =
              selectedDate.millisecondsSinceEpoch;
        }
        // ignore: prefer-async-await
        await updateTicket(updateFormValues).then((updateResponse) async {
          if (updateResponse.sucessRequestPqr ?? false) {
            // ignore: prefer-async-await
            await sendTicketMessage(sendMessageFormValues)
                .then((messageResponse) async {
              if (messageResponse.sucessRequestChat ?? false) {
                if (image != null) {
                  sendMessageFormValues["image"] = imgAsBase64;
                  // ignore: prefer-async-await
                  await sendTicketMessage(sendMessageFormValues)
                      .then((sendImageResponse) {
                    if (!(sendImageResponse.sucessRequestChat ?? true)) {
                      // ignore: prefer-async-await
                      showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (context) {
                          Future.delayed(const Duration(seconds: 3), () {
                            Navigator.of(context).pop();
                          });
                          return const AlertDialog(
                            content: Text(
                              "Error al adjuntar imagen",
                              textAlign: TextAlign.center,
                            ),
                            title: Icon(
                              Icons.warning_amber_rounded,
                              size: 88,
                              color: Colors.amber,
                            ),
                          );
                        },
                      ).then((value) {
                        context.loaderOverlay.hide();
                        Navigator.pushNamed(context, "tickets");
                      });
                    }
                  });
                }
                context.loaderOverlay.hide();
                showSuccessModal();
              }
            });
          }
        });
      }
    } catch (e) {
      context.loaderOverlay.hide();
      print(e);
    }
  }

  showSuccessModal() {
    // ignore: prefer-async-await
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          //"Se actualizo el Ticket con exito",
          content: copy('messages.edit-ticket-success'),
          type: "success",
        );
      },
    ).then((value) {
      Navigator.pushNamed(context, "tickets");
    });
  }

  get parseInitialDate {
    String date =
        GlobalUtils().parseDate(selectedTicket?.deadLineLong, "dd/MM/yyyy");
    DateFormat formatter = DateFormat("dd/MM/yyyy");
    return formatter.parse(date);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'ticketDetail',
          (Route<dynamic> route) => false,
          arguments: selectedTicket,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'ticketDetail',
            (Route<dynamic> route) => false,
            arguments: selectedTicket,
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 36),
            child: Form(
              key: editTicketsFormKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 32.0),
                    child: NvText(
                      textHolder: AppMessages().getCopy('messages.ticket') +
                          (selectedTicket?.numberCD ?? ''),
                      fontWeight: FontWeight.w500,
                      fontSize: 24,
                      color: AppTheme.black0Main,
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8.0),
                    child: NvText(
                      copy: "page.pqr.detail.deadLine2",
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: AppTheme.black0Main,
                    ),
                  ),
                  Container(
                    decoration: const BoxDecoration(
                      border: Border(
                        right: BorderSide(width: 1, color: AppTheme.black1),
                        left: BorderSide(width: 1, color: AppTheme.black1),
                        bottom: BorderSide(width: 1, color: AppTheme.black1),
                        top: BorderSide(
                          width: 1,
                          color: AppTheme.black1,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          decoration: const BoxDecoration(
                            border: Border(
                              right: BorderSide(
                                width: 0,
                                color: Colors.transparent,
                              ),
                            ),
                          ),
                          width: (MediaQuery.of(context).size.width *
                              Constants.eightyPercent),
                          child: TextFormField(
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                            ),
                            controller: TextEditingController(
                              text:
                                  "${selectedDate.day}/${selectedDate.month}/${selectedDate.year}",
                            ),
                            enabled: false,
                          ),
                        ),
                        Container(
                          decoration: const BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(6)),
                            //color: AppTheme.coral0Main,
                          ),
                          width: EditTicket._calendarButtonSize,
                          height: EditTicket._calendarButtonSize,
                          child: IconButton(
                            onPressed: () {
                              selectDate(context);
                            },
                            icon: const Icon(
                              Icons.calendar_month_outlined,
                              color: AppTheme.black3,
                              size: 25,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8.0),
                    child: NvText(
                      copy: "common.state",
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: AppTheme.black0Main,
                    ),
                  ),
                  DropdownButtonFormField(
                    value: updateFormValues['idStateComplaintDemand'] ??
                        states.first.value,
                    items: states,
                    onChanged: (value) {
                      setState(() {
                        updateFormValues['idStateComplaintDemand'] = value;
                      });
                    },
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  const Padding(
                    padding: EdgeInsets.only(bottom: 8.0),
                    child: NvText(
                      textHolder: "Mensaje",
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: AppTheme.black0Main,
                    ),
                  ),
                  TextFormField(
                    maxLength: EditTicket._messageLength,
                    // ignore: prefer-extracting-callbacks
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        //'Obligatorio';
                        return copy('common.validator-required');
                      }
                      return null;
                    },
                    onChanged: (value) {
                      sendMessageFormValues['messageBody'] = value;
                    },
                    keyboardType: TextInputType.multiline,
                    minLines: EditTicket._messageMinLines,
                    maxLines: EditTicket._messageMaxLines,
                    decoration: const InputDecoration(
                      isDense: false,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    ),
                  ),
                  NvButton(
                    label: copy("messages.labelAttachFile"),
                    action: () async {
                      await pickImage();
                    },
                    variant: ButtonVariant.tertiary,
                  ),
                  if (image != null)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.file(
                          //ignore: avoid-non-null-assertion
                          File(image!.path),
                          height: EditTicket._previewHeight,
                          width: EditTicket._previewWidth,
                          fit: BoxFit.cover,
                        ),
                        Text(
                          (image?.name ?? '').replaceFirst("image_picker", ""),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          //ignore: avoid-non-null-assertion
                          "${getImageSize(image!)} kb",
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ),
        bottomSheet: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: NvButton(
            variant: "primary",
            label: copy("common.ready"),
            action: () {
              if ((editTicketsFormKey.currentState?.validate() ?? false)) {
                sendData();
              }
            },
          ),
        ),
      ),
    );
  }
}
