import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/tickets/tickets_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/tickets/add_ticket.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:intl/intl.dart';

class Tickets extends StatefulWidget {
  const Tickets({Key? key}) : super(key: key);
  static const int _idNew = 2;
  static const int _idFinished = 0;
  static const int _idInProgress = 1;
  static const double _statusFontSize = 12;

  @override
  State<Tickets> createState() => _TicketsState();
}

class _TicketsState extends State<Tickets> {
  final copy = AppMessages().getCopy;
  final inProgress = AppMessages().getCopy('messages.inprogress');
  final finshed = AppMessages().getCopy('messages.finished');
  final newState = AppMessages().getCopy('messages.new-pqr');
  List<TicketsRequestResponse>? ticketsList;

  @override
  void initState() {
    getTicketList();
    super.initState();
  }

  /// It shows a loader overlay, gets a list of tickets, sets the state, and hides the loader overlay.
  getTicketList() async {
    context.loaderOverlay.show();
    ticketsList = await getTickets();
    if ((ticketsList?.isEmpty ?? true)) {
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => const AddTicket(fromEmptyTickets: true),
        ),
        (Route<dynamic> route) => false,
      );
    }

    // ignore: no-empty-block
    setState(() {});
    context.loaderOverlay.hide();
  }

  /// It takes state id and return the correct label
  ///
  /// Args:
  ///   id (int): The id state of the ticket
  ///
  /// Returns:
  ///   A string.
  String getTicketStatus(int id) {
    switch (id) {
      case Tickets._idInProgress:
        return inProgress; //"En progreso";
      case Tickets._idFinished:
        return finshed; // "Finalizado";
      case Tickets._idNew:
        return newState; //"Nuevo";
      default:
        print('default');
        return newState; //"Nuevo";

    }
  }

  /// It returns a color based on the id
  ///
  /// Args:
  ///   id (int): the id of the status
  ///
  /// Returns:
  ///   A Color object.
  Color getStatusColor(int id) {
    switch (id) {
      case Tickets._idInProgress:
        return AppTheme.yellow4;
      case Tickets._idFinished:
        return AppTheme.greenArlequin4;
      case Tickets._idNew:
        return AppTheme.blueIndigo4;
      default:
        {
          return AppTheme.blueIndigo4;
        }
    }
  }

  /// If the date is today, return the hour. If the date is yesterday, return "Ayer". If the date is
  /// anything else, return the date
  ///
  /// Args:
  ///   dateCreation (String): String
  ///   hourCreation (String): String
  ///
  /// Returns:
  ///   A string with the date or time.
  // ignore: long-method
  String getPqrTime(String dateCreation, String hourCreation) {
    if (dateCreation.isNotEmpty) {
      final formatter = DateFormat('dd/MM/yyyy');
      final today = formatter.format(DateTime.now());
      final parsedDate = DateFormat('yyyy/MM/dd').parse(dateCreation);
      final formatedDatecreation = formatter.format(parsedDate);
      final yesterday =
          formatter.format(DateTime.now().subtract(const Duration(days: 1)));
      if (formatedDatecreation.toString() == today.toString()) {
        return hourCreation.toString();
      } else if (formatedDatecreation.toString() == yesterday.toString()) {
        return "Ayer";
      } else {
        return yesterday.toString();
      }
    } else {
      return copy('common.invalid-date'); //"Fecha invalida";
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
          elevation: 0,
          actions: [
            if (UserUtils().hasPermissionsTo(587) ||
                UserUtils().hasPermissionsTo(581))
              Padding(
                padding: const EdgeInsets.only(right: 23),
                child: GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(context, "addTicket");
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: const [
                      NvImage(imageUrl: "/ds/icons/edit-new-version.svg"),
                    ],
                  ),
                ),
              ),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          scrollDirection: Axis.vertical,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 24, top: 24),
                child: Text(
                  //"Tickets",
                  copy('messages.pqr-title'),
                  style: const TextStyle(
                    color: AppTheme.black0Main,
                    fontWeight: FontWeight.w600,
                    fontSize: 24,
                  ),
                ),
              ),
              ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemCount: ticketsList?.length ?? 0,
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                    onTap: () => Navigator.pushNamed(
                      context,
                      "ticketDetail",
                      arguments: ticketsList?[index] ?? '',
                    ),
                    child: Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      elevation: 0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                        side: BorderSide(color: AppTheme.black1),
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 8.0),
                                      child: Text(
                                        (ticketsList?[index].dateCreation ??
                                            ""),
                                        style: const TextStyle(
                                          color: AppTheme.black3,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      AppMessages().getCopy('messages.ticket') +
                                          (ticketsList?[index].numberCD ?? ""),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16,
                                      ),
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          Constants.fiftyPercent,
                                      child: Text(
                                        (ticketsList?[index].title ?? ""),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: Tickets._idNew,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          color: AppTheme.black3,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Chip(
                                      backgroundColor: getStatusColor(
                                        (ticketsList?[index]
                                                .idStateComplaintDemand ??
                                            Tickets._idNew),
                                      ).withOpacity(Constants.twentyPercent),
                                      label: Text(
                                        getTicketStatus((ticketsList?[index]
                                                .idStateComplaintDemand ??
                                            Tickets._idNew)),
                                        style: TextStyle(
                                          color: getStatusColor(
                                            (ticketsList?[index]
                                                    .idStateComplaintDemand ??
                                                Tickets._idNew),
                                          ),
                                          fontSize: Tickets._statusFontSize,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                    Text(getPqrTime(
                                      (ticketsList?[index].dateCreation ?? ""),
                                      (ticketsList?[index].hourCreation ?? ""),
                                    )),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
