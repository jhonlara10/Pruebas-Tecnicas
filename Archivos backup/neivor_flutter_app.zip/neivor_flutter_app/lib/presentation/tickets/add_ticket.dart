import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/general/general_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/tickets/tickets_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/general/servicepoint_request.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets_add_response.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets_request_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

class AddTicket extends StatefulWidget {
  final bool? fromEmptyTickets;

  const AddTicket({Key? key, this.fromEmptyTickets}) : super(key: key);
  static const int _defaultTypeId = 3;
  static const int _idNew = 2;
  static const int _saturday = 6;
  static const int _sunday = 5;
  static const int _titleLenght = 50;
  static const double _dropdownHeight = 200;
  static const int _descriptionLength = 500;
  static const int _descriptionMinLines = 5;
  static const int _descriptionMaxLines = 8;
  static const double _filePreviewHeight = 93;
  static const double _filePreviewWidth = 151;

  @override
  State<AddTicket> createState() => _AddTicketState();
}

class _AddTicketState extends State<AddTicket> {
  final copy = AppMessages().getCopy;

  /// Creating a global key for the form.
  final ticketsFormKey = GlobalKey<FormState>();

  /// Creating an instance of the ImagePicker class.
  final ImagePicker _picker = ImagePicker();

  /// Declaring a XFile variable to store the selected image  .
  XFile? image;
  String? imgAsBase64;
  Map<String, dynamic> formValues = {};
  List<int>? adminIds;
  final TextEditingController textEditingController = TextEditingController();
  List<ServicepointRequest>? servicepointList;
  List<DropdownMenuItem<String>> dropdownItems = [];

  @override
  void initState() {
    (() async {
      if (!UserUtils().isAdminUser()) {
        await callGetAdminIds();
      } else {
        await callServicepoints();
        servicepointAsDropdownItems();
      }
      setDefaultFormValues();
    })();
    super.initState();
  }

  // Setting the default form value.
  // ignore: long-method
  setDefaultFormValues() {
    formValues = {
      'adminUser': UserUtils().isAdminUser(),
      'deadLineUpdate': getThreeWorkingDays(),
      'description': "",
      'email': UserUtils.currentUser?.email,
      'idComplaintDemandType': AddTicket._defaultTypeId,
      'idEnterprise': UserUtils.currentEnterprise?.id,
      'idResponsible': UserUtils().isAdminUser()
          ? UserUtils.currentUser?.id
          : adminIds?.first,
      'idServicePoint': UserUtils().isAdminUser()
          ? (UserUtils.currentServicePoint?.id ??
              UserUtils.currentServicePoint?.id)
          : UserUtils.currentServicePoint?.id,
      'idStateComplaintDemand': AddTicket._idNew,
      'idZyosUser': UserUtils.currentUser?.id ?? 0,
      'title': "",
      'userCreation': UserUtils.currentUser?.id,
    };
  }

  /// It picks an image from the gallery, converts it to base64.
  pickImage() async {
    try {
      image = await _picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        imgAsBase64 = await imgToBase64();
        // ignore: no-empty-block
        setState(() {});
      }
    } catch (e) {
      log(e.toString());
    }
  }

  /// It takes the image path, reads the bytes, encodes the bytes to base64, and returns the base64
  /// encoded string
  ///
  /// Returns:
  ///   A Future&lt;String&gt;
  imgToBase64() async {
    final Uint8List bytes;
    if (image != null) {
      //ignore: avoid-non-null-assertion
      bytes = await File(image!.path).readAsBytes();
      String base64Encoded = base64Encode(bytes);
      String prefix =
          //ignore: avoid-non-null-assertion
          "data:image/${image!.path.substring(image!.path.length - 3)};base64,";
      return prefix + base64Encoded;
    }
  }

  /// API call to get admin IDs
  /// sets the state of the widget
  callGetAdminIds() async {
    adminIds = await getAdminsIds();
    // ignore: no-empty-block
    setState(() {});
  }

  /// API call to get service point list
  /// sets the state of the widget
  callServicepoints() async {
    servicepointList = await getServicepoints();
    // ignore: no-empty-block
    setState(() {});
  }

  /// Transform the service point list in a dropdown items.
  servicepointAsDropdownItems() {
    setState(() {
      servicepointList?.forEach((element) {
        dropdownItems.add(DropdownMenuItem(
          key: Key(
            "${element.operationZone?.name ?? ''} - ${element.name ?? ''}",
          ),
          value: element.id.toString(),
          child: Text(
            "${element.operationZone?.name ?? ''} - ${element.name ?? ''}",
          ),
        ));
      });
    });
  }

  /// calculate 3 working days from now
  ///
  ///
  /// Returns:
  ///   The number of milliseconds since the epoch.
  int getThreeWorkingDays() {
    int duration = 0;
    DateTime today = DateTime.now().add(const Duration(days: 3));
    while (today.weekday == AddTicket._saturday ||
        today.weekday == AddTicket._sunday) {
      duration += 1;
      today = today.add(Duration(days: duration));
    }
    return today.millisecondsSinceEpoch;
  }

  /// It takes a file, reads it as bytes, and returns the size of the file in kilobytes
  ///
  /// Args:
  ///   img (XFile): The image file
  ///
  /// Returns:
  ///   A string.
  String getImageSize(XFile img) {
    final size = File(img.path).readAsBytesSync().lengthInBytes;
    return (size / Constants.byteSize).toStringAsFixed(AddTicket._idNew);
  }

  // ignore: long-method
  validateForm() async {
    FocusManager.instance.primaryFocus?.unfocus();
    if ((ticketsFormKey.currentState?.validate() ?? false)) {
      context.loaderOverlay.show();
      TicketsAddResponse creationResponse = await createTicket(formValues);
      if (imgAsBase64 != null && (imgAsBase64?.isNotEmpty ?? false)) {
        sendImage(creationResponse.idComplaintDemand);
      }
      if (creationResponse.sucessRequestPqr ?? false) {
        // ignore: prefer-async-await
        showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            Future.delayed(const Duration(seconds: 3), () {
              Navigator.of(context).pop();
            });
            return NvAlert(
              type: "success",
              //"Ticket creado con exito",
              content: copy('messages.new-tiket-success'),
            );
          },
        ).then((value) => Navigator.pushNamedAndRemoveUntil(
              context,
              'tickets',
              (Route<dynamic> route) => false,
            ));
      } else {
        showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            Future.delayed(const Duration(seconds: 3), () {
              Navigator.of(context).pop();
            });
            return NvAlert(
              type: "error",
              content: creationResponse.message ??
                  //'Ocurrio un error creando el Ticket',
                  copy('messages.new-tiket-error'),
            );
          },
        );
      }
    }
    context.loaderOverlay.hide();
  }

  sendImage(int? idComplaintDemand) async {
    List<TicketsRequestResponse>? ticketsList = await getTickets();
    TicketsRequestResponse createdConversation =
        ticketsList.firstWhere((element) => element.id == idComplaintDemand);
    Map<String, dynamic> imgJson = {
      "newMessage": false,
      "userCreation": UserUtils.currentUser?.id,
      "idZyosUserCreator": UserUtils.currentUser?.id,
      "recipients": null,
      "idEnterprise": UserUtils.currentEnterprise?.id,
      "idConversation": createdConversation.idConversation,
      "pqr": true,
      "adminUser": UserUtils().isAdminUser(),
      "image": imgAsBase64,
    };
    sendTicketMessage(imgJson);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          (widget.fromEmptyTickets ?? false) ? 'home' : 'tickets',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          elevation: 0,
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            (widget.fromEmptyTickets ?? false) ? 'home' : 'tickets',
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Form(
            key: ticketsFormKey,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    //"Nuevo ticket",
                    copy('messages.new-tiket'),
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 26,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(
                    height: 21,
                  ),
                  Row(
                    children: [
                      const Text(
                        "*",
                        style: TextStyle(
                          color: AppTheme.rosePonche0Main,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Text(
                        //"Asunto",
                        copy('messages.issue'),
                      ),
                    ],
                  ),
                  TextFormField(
                    maxLength: AddTicket._titleLenght,
                    // ignore: prefer-extracting-callbacks
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return copy(
                          'common.validator-required',
                        ); //'Obligatorio';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        formValues["title"] = value;
                      });
                    },
                    decoration: InputDecoration(
                      hintText:
                          //"Reparacion de ascensor",
                          copy('messages.pqr-title-placeholder'),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  if (UserUtils().isAdminUser()) ...[
                    Row(
                      children: const [
                        Text(
                          "*",
                          style: TextStyle(
                            color: AppTheme.rosePonche0Main,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          "Inmueble",
                        ),
                      ],
                    ),
                    DropdownButton2(
                      isExpanded: true,
                      value: formValues['idServicePoint'].toString(),
                      items: dropdownItems,
                      onChanged: (value) => setState(() {
                        formValues['idServicePoint'] =
                            int.parse(value as String);
                      }),
                      dropdownMaxHeight: AddTicket._dropdownHeight,
                      searchController: textEditingController,
                      searchInnerWidget: Padding(
                        padding: const EdgeInsets.only(
                          top: 8,
                          bottom: 4,
                          right: 8,
                          left: 8,
                        ),
                        child: TextFormField(
                          controller: textEditingController,
                        ),
                      ),
                      // ignore: prefer-extracting-callbacks
                      searchMatchFn: (item, searchValue) {
                        return (item.key
                            .toString()
                            .toLowerCase()
                            .contains(searchValue.toLowerCase()));
                      },
                      onMenuStateChange: (isOpen) {
                        if (!isOpen) {
                          textEditingController.clear();
                        }
                      },
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                  Row(
                    children: [
                      const Text(
                        "*",
                        style: TextStyle(
                          color: AppTheme.rosePonche0Main,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Text(
                        //"Cuéntanos tu situación"),
                        copy('messages.tell-us-your-situation'),
                      ),
                    ],
                  ),
                  TextFormField(
                    maxLength: AddTicket._descriptionLength,
                    // ignore: prefer-extracting-callbacks
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        copy('common.validator-required'); //'Obligatorio';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        formValues["description"] = value;
                      });
                    },

                    keyboardType: TextInputType.text,
                    minLines: AddTicket._descriptionMinLines,
                    maxLines: AddTicket._descriptionMaxLines,
                    decoration: const InputDecoration(
                      isDense: false,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    ),
                  ),
                  NvButton(
                    //"Adjuntar archivo",
                    label: copy('messages.labelAttachFile'),
                    action: () async {
                      await pickImage();
                    },
                    variant: ButtonVariant.tertiary,
                  ),
                  if (image != null)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.file(
                          //ignore: avoid-non-null-assertion
                          File(image!.path),
                          height: AddTicket._filePreviewHeight,
                          width: AddTicket._filePreviewWidth,
                          fit: BoxFit.cover,
                        ),
                        Text(
                          (image?.name ?? '').replaceFirst("image_picker", ""),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          //ignore: avoid-non-null-assertion
                          "${getImageSize(image!)} kb",
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: NvButton(
            variant: "primary",
            //"Listo",
            label: copy('common.ready'),
            action: () => validateForm(),
          ),
        ),
      ),
    );
  }
}
