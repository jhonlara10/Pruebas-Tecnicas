import 'package:flutter/material.dart';

class TicketMessageActions extends StatelessWidget {
  const TicketMessageActions({
    Key? key,
    required this.pickImage,
    required this.isGroupMember,
  }) : super(key: key);

  final Function(String source) pickImage;
  final bool isGroupMember;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 22),
          child: GestureDetector(
            onTap: () {
              pickImage('camera');
            },
            child: const Icon(Icons.camera_alt_outlined, size: 20),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(right: isGroupMember ? 0 : 22),
          child: GestureDetector(
            onTap: () {
              pickImage('gallery');
            },
            child: const Icon(Icons.attach_file_rounded, size: 20),
          ),
        ),
      ],
    );
  }
}
