import 'dart:io';

import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';

class BottomMessageSender extends StatelessWidget {
  const BottomMessageSender({
    Key? key,
    required this.changeEmojiVisibility,
    required this.isEmojiSelectionActive,
    required this.controller,
    required this.sendMessage,
  }) : super(key: key);

  final Function changeEmojiVisibility;
  final bool isEmojiSelectionActive;
  final TextEditingController controller;
  final Function sendMessage;
  static const double _iconAngle = 5.5;
  static const double _sendSize = 40;
  static const int _emojiColumn = 11;
  static const int _emojiSize = 20;
  static const double _emojiVariation = 1.3;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Divider(
          height: 1,
          thickness: 1,
        ),
        const SizedBox(
          height: 16,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16, bottom: 16),
          child: Row(
            children: [
              SizedBox(
                width:
                    MediaQuery.of(context).size.width * Constants.eightyPercent,
                child: TextFormField(
                  controller: controller,
                  // ignore: prefer-extracting-callbacks
                  onTap: () {
                    if (MediaQuery.of(context).viewInsets.bottom == 0 &&
                        isEmojiSelectionActive) {
                      changeEmojiVisibility();
                    }
                  },
                  decoration: InputDecoration(
                    hintText: "...",
                    border: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(100)),
                    ),
                    prefixIcon: GestureDetector(
                      onTap: () {
                        changeEmojiVisibility();
                      },
                      child: const Icon(
                        Icons.sentiment_satisfied_alt_outlined,
                        color: AppTheme.black0Main,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Transform.rotate(
                angle: _iconAngle,
                child: Container(
                  width: _sendSize,
                  height: _sendSize,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(100)),
                    color: AppTheme.turquoise4,
                  ),
                  child: IconButton(
                    onPressed: () {
                      sendMessage();
                    },
                    icon: const Icon(
                      Icons.send,
                      color: AppTheme.grayArtic0main,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        if (isEmojiSelectionActive)
          SizedBox(
            height:
                MediaQuery.of(context).size.height * Constants.twentyPercent,
            child: EmojiPicker(
              onEmojiSelected: (category, emoji) {
                controller.text = controller.text + emoji.emoji;
              },
              config: Config(
                columns: _emojiColumn,
                emojiSizeMax:
                    _emojiSize * (Platform.isIOS ? _emojiVariation : 1.0),
                verticalSpacing: 0,
                horizontalSpacing: 0,
                gridPadding: EdgeInsets.zero,
                initCategory: Category.SMILEYS,
                bgColor: AppTheme.grayArtic0main,
                indicatorColor: AppTheme.coral0Main,
                iconColor: AppTheme.coral0Main,
                iconColorSelected: AppTheme.coral0Main,
                //ignore: no-equal-arguments
                progressIndicatorColor: AppTheme.coral0Main,
                backspaceColor: AppTheme.coral0Main,
                //ignore: no-equal-arguments
                skinToneDialogBgColor: AppTheme.grayArtic0main,
                skinToneIndicatorColor: AppTheme.black3,
                enableSkinTones: true,
                showRecentsTab: false,
                tabIndicatorAnimDuration: kTabScrollDuration,
                categoryIcons: const CategoryIcons(),
                buttonMode: Platform.isAndroid
                    ? ButtonMode.MATERIAL
                    : ButtonMode.CUPERTINO,
              ),
            ),
          ),
      ],
    );
  }
}
