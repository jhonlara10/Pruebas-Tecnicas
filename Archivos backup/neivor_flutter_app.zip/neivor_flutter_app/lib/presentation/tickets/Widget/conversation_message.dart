import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:full_screen_image_null_safe/full_screen_image_null_safe.dart';
import 'package:lottie/lottie.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class ConversationMessage extends StatelessWidget {
  const ConversationMessage({
    Key? key,
    required this.conversation,
  }) : super(key: key);
  final TicketGetMsgResponse? conversation;
  static List<NeighborsResponse>? neighborsList;
  static const double _avatarSize = 40;
  static const double _imageMessageSize = 120;

  /// It checks if the url is an image by checking if the url ends with .jpg, .jpeg, .png, .gif, .JPG,
  /// .JPEG, .PNG, .GIF
  ///
  /// Args:
  ///   url (String): The URL of the image.
  ///
  /// Returns:
  ///   A boolean value.
  bool isAnUrlImage(String url) {
    return (RegExp("[^\\s]+(.*?)\\.(jpg|jpeg|png|gif|JPG|JPEG|PNG|GIF)\$")
        .hasMatch(url));
  }

  /// If the id of the user is the same as the id of the current user, return true
  ///
  /// Args:
  ///   id (int): The id of the user you want to check
  ///
  /// Returns:
  ///   A boolean value.
  bool isCurrentUser(int id) {
    return id == UserUtils.currentUser?.id;
  }

  /// If the id is the current user's id, return the current user. Otherwise, return the neighbor with
  /// the matching id
  ///
  /// Args:
  ///   id (int): The id of the user you want to search for.
  ///
  /// Returns:
  ///   A Future<List<Neighbor>>
  searchNeighborById(int id, BuildContext context) {
    neighborsList = BlocProvider.of<MessagesBloc>(context).state.neighborsList;
    if (neighborsList != null && conversation != null) {
      if (id == UserUtils.currentUser?.id) {
        return UserUtils.currentUser;
      } else {
        return neighborsList?.firstWhere((element) => element.id == id);
      }
    }
  }

  normalizeImageUrl(String imageUrl) {
    String withoutBackslash =
        imageUrl[0] == "/" ? imageUrl.substring(1) : imageUrl;
    // Datetime to prevent cached image.
    return GlobalUtils().cdn(
      "$withoutBackslash?${DateTime.now().millisecondsSinceEpoch.toString()}.jpg",
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: Row(
        mainAxisAlignment:
            !(isCurrentUser(conversation?.idZyosUserCreator ?? 0))
                ? MainAxisAlignment.start
                : MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isCurrentUser(conversation?.idZyosUserCreator ?? 0))
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: ClipOval(
                child: NvImage(
                  isUserImage: true,
                  width: _avatarSize,
                  height: _avatarSize,
                  imageUrl: conversation?.photoUserCreator,
                ),
              ),
            ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: const BoxDecoration(
                  color: AppTheme.grayArtic0main,
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                ),
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width *
                      Constants.seventyPercent,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: !isAnUrlImage((conversation?.messageBody ?? ''))
                      ? Text(
                          (conversation?.messageBody ?? ''),
                          overflow: TextOverflow.clip,
                        )
                      : FullScreenWidget(
                          backgroundIsTransparent: true,
                          child: Hero(
                            tag: conversation?.id ?? '',
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(16)),
                              child: Image.network(
                                normalizeImageUrl(
                                  (conversation?.messageBody ?? ''),
                                ),
                                height: _imageMessageSize,
                                fit: BoxFit.fitWidth,
                                errorBuilder: (context, error, stackTrace) {
                                  return Lottie.network(
                                    'https://assets10.lottiefiles.com/packages/lf20_rwq6ciql.json',
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                ),
              ),
            ],
          ),
          if (isCurrentUser(conversation?.idZyosUserCreator ?? 0))
            ClipOval(
              child: NvImage(
                isUserImage: true,
                width: _avatarSize,
                height: _avatarSize,
                imageUrl: UserUtils.currentUser?.photo,
              ),
            ),
        ],
      ),
    );
  }
}
