import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/domain/models/general/neighbors_response.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class TicketDetail extends StatefulWidget {
  const TicketDetail({Key? key}) : super(key: key);
  static const int _idInProgress = 1;
  static const int _idFinished = 0;
  static const int _idNew = 2;
  static const double _chipFontSize = 9;
  static const double _avatarSize = 40;

  @override
  State<TicketDetail> createState() => _TicketDetailState();
}

class _TicketDetailState extends State<TicketDetail> {
  Function copy = AppMessages().getCopy;
  TicketsRequestResponse? selectedTicket;
  List<NeighborsResponse>? neighborsList;

  @override
  void initState() {
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      neighborsList =
          BlocProvider.of<MessagesBloc>(context).state.neighborsList;
      setState(() {
        if (ModalRoute.of(context)?.settings.arguments != null) {
          selectedTicket = ModalRoute.of(context)?.settings.arguments
              as TicketsRequestResponse;
        }
      });
    });
  }

  /// It takes a date in the format of `yyyy/MM/dd` and returns a date in the format of `dd/MM/yyyy`
  ///
  /// Args:
  ///   date (String): The date to be formatted.
  ///
  /// Returns:
  ///   A String
  String formatDate(String date) {
    if (date.isNotEmpty) {
      final formatter = DateFormat('dd MMM yyyy');
      final parsedDate = DateFormat('yyyy/MM/dd').parse(date);
      final formatedDatecreation = formatter.format(parsedDate);
      return formatedDatecreation.toString();
    }
    return 'Fecha invalida';
  }

  /// It takes state id and return the correct label
  ///
  /// Args:
  ///   id (int): The id state of the ticket
  ///
  /// Returns:
  ///   A string.
  String getTicketStatus(int id) {
    switch (id) {
      case TicketDetail._idInProgress:
        return copy('messages.inprogress'); //"En progreso";
      case TicketDetail._idFinished:
        return copy('messages.finished'); //"Finalizado";
      case TicketDetail._idNew:
        return copy('messages.new-pqr'); //"Nuevo";
      default:
        {
          return copy('page.eq.labelNew'); //"Nuevo";
        }
    }
  }

  /// It returns a color based on the id
  ///
  /// Args:
  ///   id (int): the id of the status
  ///
  /// Returns:
  ///   A Color object.
  Color getStatusColor(int id) {
    switch (id) {
      case TicketDetail._idInProgress:
        return AppTheme.yellow4;
      case TicketDetail._idFinished:
        return AppTheme.greenArlequin4;
      case TicketDetail._idNew:
        return AppTheme.blueIndigo4;
      default:
        {
          return AppTheme.blueIndigo4;
        }
    }
  }

  /// If the neighborsList is not null, return the first element in the list where the id of the element
  /// is equal to the idResponsible of the selectedTicket, or null if no such element is found.
  ///
  /// Args:
  ///   id (int): the id of the neighbor
  ///
  /// Returns:
  ///   A Future<List<NeighborsResponse>>
  searchNeighborById(int id) {
    if (neighborsList != null) {
      return neighborsList?.firstWhere(
        (element) => element.id == id,
        orElse: () {
          return NeighborsResponse();
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'tickets',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          elevation: 0,
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'tickets',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              AppMessages().getCopy('messages.ticket') +
                  (selectedTicket?.numberCD ?? ''),
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
                fontSize: 26,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(formatDate(selectedTicket?.dateCreation.toString() ?? '')),
                Chip(
                  backgroundColor: getStatusColor(
                    (selectedTicket?.idStateComplaintDemand ??
                        TicketDetail._idNew),
                  ).withOpacity(Constants.thirtyPercent),
                  label: Text(
                    getTicketStatus(selectedTicket?.idStateComplaintDemand ??
                        TicketDetail._idNew),
                    style: TextStyle(
                      color: getStatusColor(
                        (selectedTicket?.idStateComplaintDemand ??
                            TicketDetail._idNew),
                      ),
                      fontSize: TicketDetail._chipFontSize,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 27,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6,
                  child: Text(
                    selectedTicket?.title ?? '',
                    style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                      color: AppTheme.black0Main,
                    ),
                  ),
                ),
                if (UserUtils().hasPermissionsTo(583) ||
                    UserUtils().hasPermissionsTo(869))
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(
                      context,
                      "editTicket",
                      arguments: selectedTicket,
                    ),
                    child: const NvText(
                      copy: "tickets.update-state",
                      color: AppTheme.turquoise4,
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      textDecoration: TextDecoration.underline,
                    ),
                  ),
              ],
            ),
            const SizedBox(
              height: 16,
            ),
            Text(
              //"REPORTADO POR",
              copy('messages.reported-by'),
              style: const TextStyle(
                fontWeight: FontWeight.w400,
                fontSize: 14,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(
              height: 8,
            ),
            Row(
              children: [
                ClipOval(
                  child: NvImage(
                    isUserImage: true,
                    width: TicketDetail._avatarSize,
                    height: TicketDetail._avatarSize,
                    imageUrl: (selectedTicket?.idZyosUser ?? 0) ==
                            UserUtils.currentUser?.id
                        ? UserUtils.currentUser?.photo
                        : (searchNeighborById(
                            (selectedTicket?.idZyosUser ?? 0),
                          )?.photo),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      (selectedTicket?.idZyosUser ?? 0) ==
                              UserUtils.currentUser?.id
                          ? UserUtils.currentUser?.name
                          : searchNeighborById(
                                (selectedTicket?.idZyosUser ?? 0),
                              )?.name ??
                              '',
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      (selectedTicket?.idZyosUser ?? 0) ==
                              UserUtils.currentUser?.id
                          ? '${UserUtils.currentServicePoint?.operationZone?.name ?? ''} - ${UserUtils.currentServicePoint?.name ?? ''}'
                          : searchNeighborById(
                                (selectedTicket?.idZyosUser ?? 0),
                              )?.servicePointName ??
                              '',
                      style: const TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        color: AppTheme.black0Main,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(
              height: 16,
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    //"Responsable: ",
                    copy('messages.responsable'),
                    style: const TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                      color: AppTheme.black3,
                    ),
                  ),
                  Text(
                    searchNeighborById((selectedTicket?.idResponsible ?? 0))
                            ?.name ??
                        '',
                    style: const TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                      color: AppTheme.black4,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              selectedTicket?.description ?? '',
              textAlign: TextAlign.justify,
            ),
            const Spacer(),
            if (UserUtils().hasPermissionsTo(588))
              Padding(
                padding: const EdgeInsets.only(bottom: 25),
                child: NvButton(
                  variant: "secondary",
                  label: copy('messages.messages-title'), //"Mensajes",
                  // ignore: prefer-extracting-callbacks
                  action: () {
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      'chat',
                      (Route<dynamic> route) => false,
                      arguments: selectedTicket,
                    );
                  },
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
