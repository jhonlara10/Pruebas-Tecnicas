import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/amenities/amenities.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

// ignore: prefer-correct-type-name
class CancellationDone extends StatelessWidget {
  static final _copy = AppMessages().getCopy;
  static const _iconWidth = 48.0;
  static const _bottomPadding = 100.0;

  const CancellationDone({Key? key}) : super(key: key);

  void goToAmenities(context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (BuildContext context) => const Amenities()),
      ModalRoute.withName('home'),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BackdropFilter(
        filter: DefaultValues.backdropBlur,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: colors.backgrounds.main,
                borderRadius: DefaultValues.borderRadius2,
              ),
              child: Container(
                padding:
                    DefaultValues.padding2.copyWith(bottom: _bottomPadding),
                width: double.infinity,
                child: Column(
                  children: [
                    NvImage(
                      icon: 'Interface, Essential/Done, Check',
                      width: _iconWidth,
                      color: colors.icons.success,
                    ),
                    Text(
                      _copy('social-areas.booking-cancelled'),
                      style: typo.h5.semibold,
                    ),
                    const SizedBox(height: 24),
                    Text(
                      _copy('social-areas.booking-successfully-cancelled'),
                      style: typo.bd1.light,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomSheet: BottomButton(
        direction: Axis.vertical,
        action: () => goToAmenities(context),
        buttonText: _copy('social-areas.go-back-to-bookings'),
        variant: ButtonVariant.secondary,
      ),
    );
  }
}
