import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/cancellation_flux/cancellation_confirmation.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_message.dart';

// ignore: must_be_immutable
class CancellationDetails extends StatefulWidget {
  Booking booking;
  Amenity? amenity;
  bool _isOpen = true;

  CancellationDetails({
    Key? key,
    required this.booking,
  }) : super(key: key);

  @override
  State<CancellationDetails> createState() => _CancellationDetailsState();
}

// ignore: prefer-correct-type-name
class _CancellationDetailsState extends State<CancellationDetails> {
  @override
  void initState() {
    (() async {
      var response = await AmenitiesRepository()
          .getAmenities('social-area=${widget.booking.idSocialArea}');

      if ((response.success ?? false) && widget._isOpen) {
        setState(() {
          widget.amenity = response.data?.list?.first;
        });
      }
    })();
    super.initState();
  }

  @override
  void dispose() {
    widget._isOpen = false;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    final typo = AppThemeScope.of(context).typography;
    final colors = AppThemeScope.of(context).colors;
    final startDate =
        Jiffy(widget.booking.eventStartString, 'yyyy/MM/dd HH:mm');
    final endDate = Jiffy(widget.booking.eventEndString, 'yyyy/MM/dd HH:mm');
    final isAbleToCancelUntil =
        startDate.subtract(hours: widget.amenity?.cancellationTime ?? 0);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BackdropFilter(
        filter: DefaultValues.backdropBlur,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: colors.backgrounds.main,
            borderRadius: DefaultValues.borderRadius2,
          ),
          child: ListView(
            padding: DefaultValues.padding2,
            children: [
              Text(
                widget.booking.title ?? '',
                style: typo.h2.semibold,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  getBookingTag(context, widget.booking),
                  const Spacer(),
                  if (widget.amenity != null)
                    Text(
                      //ignore: avoid-non-null-assertion
                      getBookingPrice(context, widget.amenity!),
                      style: typo.h5.semibold,
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const NvImage(icon: 'Holidays/calendar-31'),
                  const SizedBox(width: 10.5),
                  Text(
                    //TODO: remove replaceAll when date formats has been updated.
                    startDate.format(
                      copy('common.date-format-2')
                          .replaceAll('Do', 'do')
                          .replaceAll('dddd', 'EEEE')
                          .replaceAll('D', 'd'),
                    ),
                    style: typo.bd2.light,
                  ),
                ],
              ),
              const SizedBox(height: 13),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const NvImage(
                    icon: 'Interface, Essential/clock-time',
                  ),
                  const SizedBox(width: 10.5),
                  Text(
                    '${startDate.format('hh:mm a')} - ${endDate.format('hh:mm a')}',
                    style: typo.bd2.light,
                  ),
                ],
              ),
              const SizedBox(height: 13),
              Row(
                children: [
                  const NvImage(
                    icon: 'User/users-checkmark--square',
                  ),
                  const SizedBox(width: 10.5),
                  Text(
                    '${copy(
                      'social-areas.companion',
                    )}: ${widget.booking.companionsNumber}',
                    style: typo.bd2.light,
                  ),
                ],
              ),
              const SizedBox(height: 24),
              if (![BookingState.denied, BookingState.deleted]
                  .contains(widget.booking.idEventState))
                NvMessage(
                  child: Text(
                    '${copy('social-areas.you-are-able-to-cancel-until')} ${isAbleToCancelUntil.format(
                      copy('common.hour-date-format')
                          .replaceAll('Do', 'do')
                          .replaceAll('dddd', 'EEEE')
                          .replaceAll('D', 'd'),
                    )}',
                    style: typo.bd2.light,
                  ),
                ),
            ],
          ),
        ),
      ),
      bottomSheet: BottomButton(
        //TODO: absolutely make this function global
        action: () => showModalBottomSheet(
          context: context,
          shape: RoundedRectangleBorder(
            borderRadius: DefaultValues.borderRadius2,
          ),
          builder: (context) {
            return CancellationConfirmation(booking: widget.booking);
          },
        ),
        disabled: Jiffy().isSameOrAfter(startDate) ||
            ![BookingState.approved, BookingState.pending]
                .contains(widget.booking.idEventState),
        buttonText: copy('social-areas.cancel-booking'),
        secondaryVariant: ButtonVariant.secondary,
        secondaryText: copy('common.back'),
        secondaryAction: () => Navigator.pop(context),
      ),
    );
  }
}
