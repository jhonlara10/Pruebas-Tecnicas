import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/cancel_booking_body.dart';
import 'package:neivor_flutter_app/presentation/amenities/cancellation_flux/cancellation_done.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:loader_overlay/loader_overlay.dart';

// ignore: prefer-correct-type-name
class CancellationConfirmation extends StatefulWidget {
  final Booking booking;
  const CancellationConfirmation({
    Key? key,
    required this.booking,
  }) : super(key: key);

  @override
  State<CancellationConfirmation> createState() =>
      _CancellationConfirmationState();
}

// ignore: prefer-correct-type-name
class _CancellationConfirmationState extends State<CancellationConfirmation> {
  static final _bookingBody = CancelBookingBody.defaultValues();
  static final _copy = AppMessages().getCopy;
  static const _iconWidth = 48.0;
  static const _bottomPadding = 154.0;

  void _cancelBooking(BuildContext context) async {
    context.loaderOverlay.show();
    _setBookingValues();
    await AmenitiesRepository().cancelBooking(_bookingBody);
    context.loaderOverlay.hide();
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: DefaultValues.borderRadius2,
      ),
      builder: (context) {
        return const CancellationDone();
      },
    );
  }

  _setBookingValues() {
    _bookingBody.eventStartString = widget.booking.eventStartString;
    _bookingBody.id = widget.booking.id;
    _bookingBody.idSocialArea = widget.booking.idSocialArea;
    _bookingBody.title = widget.booking.title;
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BackdropFilter(
        filter: DefaultValues.backdropBlur,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: colors.backgrounds.main,
                borderRadius: DefaultValues.borderRadius2,
              ),
              child: Container(
                padding:
                    DefaultValues.padding2.copyWith(bottom: _bottomPadding),
                width: double.infinity,
                child: Column(
                  children: [
                    NvImage(
                      icon: 'Interface, Essential/Warning',
                      width: _iconWidth,
                      color: colors.icons.warning,
                    ),
                    const SizedBox(height: 24),
                    Text(
                      _copy('social-areas.are-you-sure-to-cancel-the-booking'),
                      style: typo.h5.semibold,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomSheet: BottomButton(
        direction: Axis.vertical,
        action: () => _cancelBooking(context),
        buttonText: _copy('common.confirm'),
        secondaryAction: () => Navigator.pop(context),
        secondaryText: _copy('common.back'),
        secondaryVariant: ButtonVariant.secondaryText,
      ),
    );
  }
}
