import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';

class Header extends StatelessWidget {
  final double maxHeight;
  final double minHeight;
  final Widget title;
  final List<Widget>? children;
  final void Function()? onGoBack;

  const Header({
    Key? key,
    this.maxHeight = NvSliverAppbar.defaultExpandeHeight,
    this.minHeight = NvSliverAppbar.defaultToolbarHeight,
    required this.title,
    this.children,
    this.onGoBack,
  }) : super(key: key);

  double _calculateExpandRatio(BoxConstraints constraints) {
    return (constraints.maxHeight - minHeight) / (maxHeight - minHeight);
  }

  // ignore: long-method
  Widget _buildTitle(Animation<double> animation) {
    return Align(
      alignment: Alignment.bottomLeft,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 72),
        child: Opacity(
          opacity: Tween<double>(begin: 0, end: 1).evaluate(animation),
          child: title,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final expandRatio = _calculateExpandRatio(constraints);
        final animation = AlwaysStoppedAnimation(expandRatio);
        final colors = AppThemeScope.of(context).colors;
        const arrowBackContainerSize = 32.0;

        return DecoratedBox(
          decoration: BoxDecoration(
            color: colors.backgrounds.main,
          ),
          child: Padding(
            padding: DefaultValues.padding,
            child: Stack(
              fit: StackFit.expand,
              children: [
                _buildTitle(animation),
                Align(
                  alignment: Alignment.topLeft,
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: onGoBack ??
                            () =>
                                Navigator.pushReplacementNamed(context, "home"),
                        child: Container(
                          width: arrowBackContainerSize,
                          height: arrowBackContainerSize,
                          decoration: BoxDecoration(
                            color: colors.primary.arcticGray.main,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.arrow_back),
                        ),
                      ),
                    ],
                  ),
                ),
                if (children != null)
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: children!, //ignore: avoid-non-null-assertion
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
