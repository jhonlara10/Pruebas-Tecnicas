import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_blocks_model.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class AvailabilityBlock extends StatelessWidget {
  final Block block;
  final Amenity amenity;
  final bool selected;
  final void Function()? onClick;

  const AvailabilityBlock(
    this.block,
    this.amenity, {
    Key? key,
    this.selected = false,
    required this.onClick,
  }) : super(key: key);

  String _getAvailability(BuildContext context) {
    final copy = AppMessages().getCopy;
    final availableSpaces =
        (amenity.capacity ?? 0) - (block.occupiedCapacity ?? 0);

    if (block.available == false || availableSpaces == 0) {
      return copy('social-areas.not-available');
    }

    return '$availableSpaces ${availableSpaces > 1 ? copy('social-areas.persons') : copy('social-areas.person')}';
  }

  bool _isAvailable() {
    bool response = false;
    final availableSpaces =
        (amenity.capacity ?? 0) - (block.occupiedCapacity ?? 0);

    //ignore: avoid-non-null-assertion
    response = block.available != null ? block.available! : false;
    response = response && availableSpaces > 0;

    return response;
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final colors = AppThemeScope.of(context).colors;
    final startHour = Jiffy(block.startHour, 'HH:mm').format('hh:mm a');
    final endHour = Jiffy(block.endHour, 'HH:mm').format('hh:mm a');
    const availableOpacity = 1.0;
    const unavailableOpacity = 0.5;
    const iconSize = 15.0;

    return Opacity(
      opacity: _isAvailable() ? availableOpacity : unavailableOpacity,
      child: ElevatedButton(
        onPressed: _isAvailable() ? onClick : () {},
        style: ElevatedButton.styleFrom(
          primary: selected ? colors.primary.turquoise.v2 : Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: DefaultValues.borderRadius,
            side: BorderSide(
              color: selected
                  ? colors.primary.turquoise.v4
                  : colors.primary.black.v2,
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  NvImage(
                    icon: 'Interface, Essential/clock-time',
                    width: iconSize,
                    color: selected ? colors.primary.turquoise.v4 : null,
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      '$startHour - $endHour',
                      style: typo.bd2.light.copyWith(
                        color: selected
                            ? colors.primary.turquoise.v4
                            : typo.bd2.light.color,
                      ),
                      overflow: TextOverflow.clip,
                    ),
                  ),
                ],
              ),
              Text(
                _getAvailability(context),
                style: typo.caption.xxsLight.copyWith(
                  color: selected
                      ? colors.primary.turquoise.v4
                      : typo.bd2.light.color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
