import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class Counter extends StatefulWidget {
  final void Function(int currentValue) onChange;
  final int? lowerLimit;
  final int? upperLimit;
  final int initValue;

  const Counter({
    Key? key,
    required this.onChange,
    this.lowerLimit,
    this.upperLimit,
    this.initValue = 0,
  }) : super(key: key);

  @override
  State<Counter> createState() => _CounterState();
}

class _CounterState extends State<Counter> {
  int _value = 0;

  @override
  void initState() {
    _value = widget.initValue;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    const borderWidth = 1.5;
    const boxSize = 18.0;
    const iconSize = 16.0;
    const borderRadius = BorderRadius.all(Radius.circular(600));

    _getButtonStyle() {
      return ElevatedButton.styleFrom(
        primary: Colors.transparent,
        padding: EdgeInsets.zero,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: borderRadius,
          //ignore: avoid-non-null-assertion
          side: BorderSide(color: typo.bd1.medium.color!, width: borderWidth),
        ),
      );
    }

    _changeValue(Operator operation) {
      if (operation == Operator.subtract &&
          _value > (widget.lowerLimit ?? double.negativeInfinity)) {
        setState(() {
          _value--;
        });
      } else if (operation == Operator.add &&
          _value < (widget.upperLimit ?? double.infinity)) {
        setState(() {
          _value++;
        });
      }
      widget.onChange(_value);
    }

    _getButton(Operator operation) {
      return SizedBox(
        width: boxSize,
        height: boxSize,
        child: ElevatedButton(
          onPressed: () => _changeValue(operation),
          style: _getButtonStyle(),
          child: Icon(
            operation == Operator.add ? Icons.add : Icons.remove,
            size: iconSize,
            color: typo.bd1.italicLight.color,
          ),
        ),
      );
    }

    return Row(
      children: [
        _getButton(Operator.subtract),
        const SizedBox(width: 11),
        Text('$_value', style: typo.bd1.medium),
        const SizedBox(width: 11),
        _getButton(Operator.add),
      ],
    );
  }
}

enum Operator { add, subtract }
