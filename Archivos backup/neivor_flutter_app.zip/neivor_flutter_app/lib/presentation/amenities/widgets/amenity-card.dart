import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:skeletons/skeletons.dart';

class AmenityCard extends StatelessWidget {
  final String? image;
  final double? imageWidth;
  final double? imageHeight;
  final Widget child;

  const AmenityCard({
    Key? key,
    this.image,
    this.imageHeight = 52, //ignore: no-magic-number
    this.imageWidth = 70, //ignore: no-magic-number
    this.child = const SizedBox(),
  }) : super(key: key);

  // ignore: long-method
  static Widget skeleton({Widget child = const Text('')}) {
    const skeletonHeight = 84.0;
    return SkeletonItem(
      child: SizedBox(
        height: skeletonHeight,
        width: double.infinity,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(width: 12),
            const SkeletonAvatar(
              style: SkeletonAvatarStyle(
                shape: BoxShape.rectangle,
                width: 70,
                height: 52,
              ),
            ),
            const SizedBox(width: 8),
            child,
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final shadows = AppThemeScope.of(context).shadows;

    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 16,
        horizontal: 12,
      ),
      decoration: BoxDecoration(
        boxShadow: shadows.medium,
        color: colors.backgrounds.main,
        borderRadius: DefaultValues.borderRadius2,
      ),
      child: Row(
        children: [
          if (image != null)
            Row(
              children: [
                ClipRRect(
                  borderRadius: DefaultValues.borderRadius2,
                  child: NvImage(
                    //ignore: avoid-non-null-assertion
                    imageUrl: image!,
                    height: imageHeight,
                    width: imageWidth,
                    isUserImage: true,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(width: 8),
              ],
            ),
          child,
          const Spacer(),
          const Align(
            alignment: Alignment.centerRight,
            child: Icon(Icons.chevron_right),
          ),
          const SizedBox(width: 12),
        ],
      ),
    );
  }
}
