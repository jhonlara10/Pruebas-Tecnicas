import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/amenities/amenities_bloc.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/amenities/partials/available_tab_view.dart';
import 'package:neivor_flutter_app/presentation/amenities/partials/booked_tab_view.dart';
import 'package:neivor_flutter_app/presentation/amenities/partials/requests_tab_view.dart';
import 'package:neivor_flutter_app/presentation/amenities/widgets/header.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_service_point_finder.dart';
import 'package:neivor_flutter_app/widgets/nv_tab_bar.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class Amenities extends StatefulWidget {
  const Amenities({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _AmenitiesState();
}

class _AmenitiesState extends State<Amenities> {
  static const _tabsNumber = 2;
  ServicePointObject? _currentServicePoint;

  _setServicePoint(ServicePointObject servicePoint) {
    BlocProvider.of<AmenitiesBloc>(context)
        .add(NewSelectedServicePoint(selectedServicePoint: servicePoint));
    setState(() {
      _currentServicePoint =
          BlocProvider.of<AmenitiesBloc>(context).state.selectedServicePoint;
    });
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final copy = AppMessages().getCopy;

    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "home");
        return Future.value(false);
      },
      child: Scaffold(
        body: SafeArea(
          child: DefaultTabController(
            length: _tabsNumber,
            child: NestedScrollView(
              scrollDirection: Axis.vertical,
              floatHeaderSlivers: true,
              // ignore: prefer-extracting-callbacks
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return [
                  NvSliverAppbar(
                    flexibleSpace: Header(
                      onGoBack: _currentServicePoint != null
                          ? () {
                              _currentServicePoint = null;
                              setState(() {});
                            }
                          : null,
                      title: Text(
                        copy('social-areas.social-areas'),
                        style: typo.h2.semibold,
                      ),
                      children: [
                        const SizedBox(height: 24),
                        NvTabBar(
                          tabs: [
                            Tab(text: copy('social-areas.available')),
                            if (UserUtils().isAdminUser())
                              Tab(text: copy('social-areas.requests'))
                            else
                              Tab(text: copy('social-areas.booked')),
                          ],
                        ),
                      ],
                    ),
                  ),
                ];
              },
              body: TabBarView(
                children: [
                  if (UserUtils().isAdminUser()) ...[
                    if (_currentServicePoint == null)
                      NvServicePointFinder(
                        padding: DefaultValues.padding,
                        onSearch: _setServicePoint,
                      )
                    else
                      const AvailableTabView(),
                    const RequestsTabView(),
                  ] else ...[
                    const AvailableTabView(),
                    const BookedTabView(),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
