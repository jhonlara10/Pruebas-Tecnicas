import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/amenities.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/dashed_divider.dart';
import 'package:neivor_flutter_app/widgets/nv_carousel.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_receipt.dart';

class RequestApproved extends StatefulWidget {
  final Booking booking;
  final Amenity amenity;

  const RequestApproved({
    Key? key,
    required this.booking,
    required this.amenity,
  }) : super(key: key);

  @override
  State<RequestApproved> createState() => _RequestApprovedState();
}

class _RequestApprovedState extends State<RequestApproved> {
  final _copy = AppMessages().getCopy;
  static const _dividerThickness = 0.1;

  void _goToAmenities(context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (BuildContext context) => const Amenities()),
      ModalRoute.withName('home'),
    );
  }

  String getTotalTime(String time) {
    List<String> timeArray = time.split(':');
    return '${timeArray.first}H ${timeArray[1] != '0' ? '${timeArray[1]}M' : ''}';
  }

  String _getHourlyRate(Amenity amenity) {
    if (amenity.isPerHour ?? false) {
      return formatPrice(amenity.rentCost);
    }
    const minutes = 60;
    List<String> timeArray = amenity.blockPeriod?.split(':') ?? ['0', '0'];
    double timeInMinutes = (double.tryParse(timeArray.first) ?? 0) * minutes +
        (double.tryParse(timeArray[1]) ?? 0);
    return formatPrice(
      //ignore: avoid-non-null-assertion
      (amenity.rentCost != null ? amenity.rentCost! / timeInMinutes : 0) *
          minutes,
    );
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final colors = AppThemeScope.of(context).colors;
    final Jiffy startDate = Jiffy(
      widget.booking.eventStartString,
      'yyyy/MM/dd HH:mm',
    );

    return NvReceipt(
      title: _copy('social-areas.booking-approved'),
      onGoBack: () => _goToAmenities(context),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NvCarousel(
            images: widget.amenity.imageList,
          ),
          const SizedBox(height: 24),
          Text(
            widget.booking.title ?? '',
            style: typo.h4.semibold,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Text(_copy('common.date'), style: typo.bd2.light),
              const Spacer(),
              Text(
                startDate.format(
                  _copy('common.full-date-format')
                      .replaceAll('Do', 'do')
                      .replaceAll('dddd', 'EEEE')
                      .replaceAll('D', 'd')
                      .replaceAll('YYYY', 'yyyy'),
                ),
                style: typo.bd2.medium,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(_copy('social-areas.companion'), style: typo.bd2.light),
              const Spacer(),
              Text(
                widget.booking.companionsNumber.toString(),
                style: typo.bd2.medium,
              ),
            ],
          ),
          const SizedBox(height: 24),
          DashedDivider(
            thickness: _dividerThickness,
            color: colors.primary.arcticGray.v4,
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Text(_copy('social-areas.hourly-rate'), style: typo.bd2.light),
              const Spacer(),
              Text(
                _getHourlyRate(widget.amenity).toString(),
                style: typo.bd2.medium,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(_copy('social-areas.total-time'), style: typo.bd2.light),
              const Spacer(),
              Text(
                //TODO: ask to the backend to return this value
                getTotalTime(widget.amenity.blockPeriod ?? '0:0'),
                style: typo.bd2.medium,
              ),
            ],
          ),
          const SizedBox(height: 24),
          DashedDivider(
            thickness: _dividerThickness,
            color: colors.primary.arcticGray.v4,
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Text(_copy('social-areas.total-paid'), style: typo.bd2.light),
              const Spacer(),
              Text(
                getBookingPrice(context, widget.amenity),
                style: typo.bd2.medium,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
