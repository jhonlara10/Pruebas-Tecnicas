import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/approve_booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/presentation/amenities/requests_flux/success_modal.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_carousel.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:loader_overlay/loader_overlay.dart';

class RequestDetails extends StatefulWidget {
  final Booking booking;

  const RequestDetails({
    Key? key,
    required this.booking,
  }) : super(key: key);

  @override
  State<RequestDetails> createState() => _RequestDetailsState();
}

class _RequestDetailsState extends State<RequestDetails> {
  final _copy = AppMessages().getCopy;
  final ApproveBookingBody body = ApproveBookingBody.defaultValues();
  Amenity? amenity;

  @override
  void initState() {
    (() async {
      var response = await AmenitiesRepository()
          .getAmenities('social-area=${widget.booking.idSocialArea}');

      if ((response.success ?? false)) {
        setState(() {
          amenity = response.data?.list?.first;
        });
      }
    })();
    super.initState();
  }

  // ignore: long-method
  _approveRequest() async {
    _setBodyParameters();
    await AmenitiesRepository().approveBooking(body);
    context.loaderOverlay.hide();

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: DefaultValues.borderRadius2,
      ),
      builder: (context) {
        return SuccessModal(
          booking: widget.booking,
          //ignore: avoid-non-null-assertion
          amenity: amenity!,
          isApproved: true,
        );
      },
    );
  }

  _rejectRequest() async {
    _setBodyParameters();
    await AmenitiesRepository().rejectBooking(body);
    context.loaderOverlay.hide();
  }

  _setBodyParameters() {
    var cost = double.tryParse(
          //ignore: avoid-non-null-assertion
          getBookingPrice(context, amenity!)
              .replaceFirst("\$ ", '')
              .replaceAll(',', ''),
        ) ??
        0;
    body.id = widget.booking.id;
    body.title = widget.booking.title;
    body.idUserRequest = widget.booking.idUserRequest;
    body.eventEndString = widget.booking.eventEndString;
    body.eventStartString = widget.booking.eventStartString;
    body.costEvent = cost.toString();
    context.loaderOverlay.show();
  }

  rejectBookingController() {
    _rejectRequest();
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: DefaultValues.borderRadius2,
      ),
      builder: (context) {
        return SuccessModal(
          booking: widget.booking,
          //ignore: avoid-non-null-assertion
          amenity: amenity!,
          isApproved: false,
        );
      },
    );
  }

  // ignore: long-method
  showModalAreYouSure() {
    const height = 300.0;
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return NvBottomSheet(
          bottomSheetHeight: height,
          iconRoute: "assets/images/warning.png",
          //"¿Estas seguro de rechazar la reserva?",
          title: _copy('social-areas.booking-rejected-sure'),
          subtitle: '',
          //"Rechazar",
          primaryButtonText: _copy('common.deny'),
          //"Cancelar"
          secondaryButtonText: _copy('common.cancel'),
          primaryButtonVariant: "nv-bottom-sheet-primary",
          secondaryButtonVariant: "nv-bottom-sheet-secondary",
          primaryButtonAction: rejectBookingController,
          secondaryButtonAction: () => Navigator.pop(context),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final startDate =
        Jiffy(widget.booking.eventStartString, 'yyyy/MM/dd HH:mm');
    final endDate = Jiffy(widget.booking.eventEndString, 'yyyy/MM/dd HH:mm');
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            const NvSliverAppbar(),
            SliverPadding(
              padding: const EdgeInsets.only(bottom: 100),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  Padding(
                    padding: DefaultValues.padding,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.booking.title ?? '',
                          style: typo.h2.semibold,
                        ),
                        const SizedBox(height: 24),
                        NvCarousel(
                          images: widget.booking.imageList,
                        ),
                        const SizedBox(height: 24),
                        Text(
                          _copy('social-areas.booking-data'),
                          style: typo.h5.semibold,
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            const NvImage(
                              icon:
                                  'Building, Construction/skyscraper-modern-tree',
                            ),
                            const SizedBox(width: 10.5),
                            Text(
                              '${widget.booking.nameOperationZone} - ${widget.booking.nameServicePoint}',
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                        const SizedBox(height: 13),
                        Row(
                          children: [
                            const NvImage(icon: 'Holidays/calendar-31'),
                            const SizedBox(width: 10.5),
                            Text(
                              //TODO: remove replaceAll when date formats has been updated.
                              startDate.format(
                                _copy('common.date-format-2')
                                    .replaceAll('Do', 'do')
                                    .replaceAll('dddd', 'EEEE')
                                    .replaceAll('D', 'd'),
                              ),
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                        const SizedBox(height: 13),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const NvImage(
                              icon: 'Interface, Essential/clock-time',
                            ),
                            const SizedBox(width: 10.5),
                            Text(
                              '${startDate.format('hh:mm a')} - ${endDate.format('hh:mm a')}',
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                        const SizedBox(height: 13),
                        Row(
                          children: [
                            const NvImage(
                              icon: 'User/users-checkmark--square',
                            ),
                            const SizedBox(width: 10.5),
                            Text(
                              '${_copy('social-areas.companion')}: ${widget.booking.companionsNumber}',
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
      extendBody: true,
      bottomNavigationBar: BottomButton(
        buttonText: _copy('social-areas.approve'),
        action: () => _approveRequest(),
        secondaryText: _copy('social-areas.reject'),
        secondaryAction: () => showModalAreYouSure(),
      ),
    );
  }
}
