import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/requests_flux/request_approved.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

// ignore: prefer-correct-type-name
class SuccessModal extends StatelessWidget {
  final Booking booking;
  final Amenity amenity;
  final bool isApproved;
  static final _copy = AppMessages().getCopy;
  static const _iconWidth = 48.0;
  static const _bottomPadding = 100.0;

  const SuccessModal({
    Key? key,
    required this.booking,
    required this.amenity,
    required this.isApproved,
  }) : super(key: key);

  void _goToApprovedReceipt(context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => RequestApproved(
          booking: booking,
          amenity: amenity,
        ),
      ),
    );
  }

  void _goToAmenitiesList(context) {
    Navigator.pushReplacementNamed(context, "amenities");
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BackdropFilter(
        filter: DefaultValues.backdropBlur,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: colors.backgrounds.main,
                borderRadius: DefaultValues.borderRadius2,
              ),
              child: Container(
                padding:
                    DefaultValues.padding2.copyWith(bottom: _bottomPadding),
                width: double.infinity,
                child: Column(
                  children: [
                    NvImage(
                      icon: 'Interface, Essential/Done, Check',
                      width: _iconWidth,
                      color: colors.icons.success,
                    ),
                    const SizedBox(height: 30),
                    Text(
                      isApproved
                          ? _copy('social-areas.booking-approved')
                          : 'Reserva rechazada',
                      style: typo.h5.semibold,
                    ),
                    const SizedBox(height: 24),
                    Text(
                      isApproved
                          ? _copy(
                              'social-areas.booking-approved-successfully',
                              [
                                booking.title ?? '',
                                booking.nameOperationZone ?? '',
                                booking.nameServicePoint ?? '',
                              ],
                            )
                          : _copy(
                              'social-areas.booking-rejected-successfully',
                              [
                                booking.title ?? '',
                                booking.nameOperationZone ?? '',
                                booking.nameServicePoint ?? '',
                              ],
                            ),
                      style: typo.bd1.light,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomSheet: BottomButton(
        action: () => isApproved
            ? _goToApprovedReceipt(context)
            : _goToAmenitiesList(context),
        buttonText:
            isApproved ? _copy('common.continue') : _copy('common.back'),
        variant: ButtonVariant.secondary,
      ),
    );
  }
}
