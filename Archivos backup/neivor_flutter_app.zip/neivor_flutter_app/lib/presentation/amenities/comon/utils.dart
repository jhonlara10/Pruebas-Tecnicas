import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_tag.dart';

Widget getAmenityTag(BuildContext context, Amenity amenity) {
  final copy = AppMessages().getCopy;
  TagVariant variant;
  String text;

  if (amenity.inMaintenance == true) {
    variant = TagVariant.ponchePink;
    text = copy('social-areas.in-maintenance');
  } else {
    variant = TagVariant.harlequinGreen;
    text = copy('social-areas.avaliable');
  }
  return NvTag(
    label: text,
    state: variant,
  );
}

String _getBookingTagText(BuildContext context, Booking booking) {
  final copy = AppMessages().getCopy;

  switch (booking.idEventState) {
    case BookingState.approved:
      return copy('social-areas.approved');
    case BookingState.pending:
      return copy('social-areas.pending');
    case BookingState.deleted:
      return copy('social-areas.cancelled');
    default:
      return copy('social-areas.cancelled');
  }
}

TagVariant _getBookingTagVariant(Booking booking) {
  switch (booking.idEventState) {
    case BookingState.approved:
      return TagVariant.harlequinGreen;
    case BookingState.pending:
      return TagVariant.yellow;
    default:
      return TagVariant.black;
  }
}

Widget getBookingTag(BuildContext context, Booking booking) {
  return NvTag(
    label: _getBookingTagText(context, booking),
    state: _getBookingTagVariant(booking),
  );
}

//ignore: prefer-match-file-name
abstract class BookingState {
  static const pending = 1;
  static const approved = 2;
  static const denied = 3;
  static const deleted = 4;
}

String getBookingPrice(BuildContext context, Amenity amenity) {
  final copy = AppMessages().getCopy;
  num? finalPrice = amenity.rentCost ?? 0;
  List<String> duration;

  if (amenity.isPerHour ?? false) {
    duration = amenity.blockPeriod?.split(':') ?? [''];
    finalPrice = ((num.tryParse(duration.first) ?? 0) +
            (num.tryParse(duration[1]) ?? 0) / 60) * //ignore: no-magic-number
        (amenity.rentCost ?? 0);
  }
  return finalPrice > 0 ? formatPrice(finalPrice) : copy('social-areas.free');
}

// TODO: put this in global utils.
String formatPrice(price) {
  var formatter = NumberFormat.currency(locale: "en_US", symbol: "\$ ");
  return formatter.format(price);
}

/// Returns an array of numbers that represents the available days
/// been 1 = Monday and 7 = Sunday
List<int> getAvailability(Amenity amenity) {
  List<String> availableDays = [];
  List<int> availabelDaysNum = [];

  for (var days in (amenity.availabilityList ?? [])) {
    availableDays = [...availableDays, ...days.weekDayList.split(',')];
  }
  availabelDaysNum = availableDays.map((e) => int.tryParse(e) ?? 0).toList();

  List<int> response = availabelDaysNum.toSet().toList();
  response.sort((a, b) => a.compareTo(b));

  return response;
}
