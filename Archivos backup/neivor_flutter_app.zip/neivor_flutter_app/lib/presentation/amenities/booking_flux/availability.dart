import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_days_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/booking_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/available_blocks_model.dart'
    as blocks;
import 'package:neivor_flutter_app/presentation/amenities/booking_flux/summary.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/presentation/amenities/widgets/availability_block.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/amenities/widgets/counter.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:skeletons/skeletons.dart';

class Availability extends StatefulWidget {
  final Amenity amenity;

  const Availability({
    Key? key,
    required this.amenity,
  }) : super(key: key);

  @override
  State<Availability> createState() => _AvailabilityState();
}

class _AvailabilityState extends State<Availability> {
  List<blocks.Block>? _blocksList;
  DateTime _date = DateTime.now();
  int? _selectedBlock;
  final BookingBody _booking = BookingBody.defaultValues();
  bool _isLoading = true;
  List<String> _availableDates = [];
  final AvailableDaysBody _body = AvailableDaysBody.defaultValues();
  final String _datesFrom = Jiffy().format('yyyy-MM-dd');
  final String _datesTo = Jiffy().add(days: 90).format('yyyy-MM-dd');

  @override
  // ignore: long-method
  void initState() {
    _booking.idSocialArea = widget.amenity.id;
    _booking.title = widget.amenity.name;
    (() async {
      context.loaderOverlay.show();
      _body.socialArea = widget.amenity.id;
      _body.startDate = _datesFrom;
      _body.endDate = _datesTo;
      var availableDaysResponse = await AmenitiesRepository().getAvailableDates(
        _body,
      );
      if (availableDaysResponse.success ?? false) {
        setState(() {
          _availableDates = availableDaysResponse.data?.list ?? [];
          _date = Jiffy(_availableDates.first, 'yyyy-MM-dd').dateTime;
        });
      }
      context.loaderOverlay.hide();
      await _bringAvailableBlocks(_date);
      setState(() {
        _isLoading = false;
      });
    })();
    super.initState();
  }

// #region Methods.
  _bringAvailableBlocks(DateTime date) async {
    var response = await AmenitiesRepository().getAvailableBlocks(
      'social-area=${widget.amenity.id}&day-number=${date.weekday}&date=${DateFormat('yyyy/MM/dd').format(date)}',
    );
    if (response.success == true) {
      setState(() {
        _blocksList = response.data?.list;
      });
    }
  }

  bool _isAvailableDay(DateTime date) {
    return _availableDates.contains(DateFormat('yyyy-MM-dd').format(date));
  }

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    final typo = AppThemeScope.of(context).typography;
    final colors = AppThemeScope.of(context).colors;
    const columns = 2;
    const verticalSpacing = 8.0;
    const horizontalSpacing = 10.0;
    const textAreaMaxLines = 6;
    const textAreaOpacity = 0.5;
    const skeletonHeight = 240.0;

    // #region Methods.
    // ignore: long-method
    _showCalendar() async {
      _selectedBlock = null;
      _date = await showDatePicker(
            context: context,
            initialDate: _date,
            firstDate: DateTime.now(),
            lastDate: DateTime.now().add(const Duration(days: 365)),
            selectableDayPredicate: _isAvailableDay,
            initialEntryMode: DatePickerEntryMode.calendarOnly,
            builder: (context, child) {
              return Theme(
                data: Theme.of(context).copyWith(),
                //ignore: avoid-non-null-assertion
                child: child!,
              );
            },
          ) ??
          _date;
      setState(() {
        _isLoading = true;
      });
      await _bringAvailableBlocks(_date);
      setState(() {
        _isLoading = false;
      });
    }

    _selectBlock(index) {
      final startHour = _blocksList?[index].startHour ?? '';
      final endHour = _blocksList?[index].endHour ?? '';
      _booking.eventStartString =
          '${DateFormat('yyyy/MM/dd').format(_date)} ${Jiffy(startHour, 'HH:mm').format('HH:mm')}';
      _booking.eventEndString =
          '${DateFormat('yyyy/MM/dd').format(_date)} ${Jiffy(endHour, 'HH:mm').format('HH:mm')}';
      setState(() {
        _selectedBlock = index;
      });
    }

    _setComment(comment) {
      _booking.description = comment;
    }

    _setCompanions(int companionsNumber) {
      _booking.companionsNumber = companionsNumber;
    }

    _getAvailabilityBlock(context, index) {
      if (_blocksList?[index] != null) {
        return AvailabilityBlock(
          //ignore: avoid-non-null-assertion
          _blocksList![index],
          widget.amenity,
          onClick: () => _selectBlock(index),
          selected: _selectedBlock == index,
        );
      }
      return const SizedBox();
    }

    void _goToSummary() {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) =>
              Summary(booking: _booking, amenity: widget.amenity),
        ),
      );
    }

    int _getCompanions() {
      if (_selectedBlock == null) return 0;
      int capacity = (widget.amenity.capacity ?? 0) -
          //ignore: avoid-non-null-assertion
          (_blocksList![_selectedBlock!].occupiedCapacity ?? 0) -
          1;
      int maxCompanions = widget.amenity.maxCompanionsNumber ?? 0;
      return maxCompanions > capacity ? capacity : maxCompanions;
    }
    // #endregion.

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
      },
      child: Scaffold(
        body: SafeArea(
          bottom: false,
          child: CustomScrollView(
            slivers: [
              const NvSliverAppbar(),
              SliverPadding(
                padding: DefaultValues.padding,
                sliver: SliverList(
                  delegate: SliverChildListDelegate(
                    [
                      Text(
                        copy('social-areas.complete-the-data-to-continue'),
                        style: typo.h5.semibold,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        copy('common.select-a-date'),
                        style: typo.bd1.light,
                      ),
                      TextButton(
                        onPressed: _showCalendar,
                        style: TextButton.styleFrom(
                          primary: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: DefaultValues.borderRadius,
                            side: BorderSide(color: colors.primary.black.v2),
                          ),
                        ),
                        child: Row(children: [
                          Text(
                            DateFormat('dd / MM / yyyy').format(_date),
                            style: typo.bd1.light,
                          ),
                          const Spacer(),
                          const NvImage(icon: 'Emails/Calendar,Schedule'),
                        ]),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        copy('common.select-a-hour'),
                        style: typo.bd1.medium,
                      ),
                      Text(
                        copy("social-areas.we'll-show-you-the-available-hours"),
                        style: typo.bd2.light,
                      ),
                      const SizedBox(height: 16),
                      if (_isLoading)
                        SizedBox(
                          height: skeletonHeight,
                          child: SkeletonListView(
                            padding: EdgeInsets.zero,
                            spacing: verticalSpacing,
                            item: Column(
                              children: [
                                Row(
                                  children: const [
                                    Expanded(
                                      child: SkeletonLine(
                                        style: SkeletonLineStyle(
                                          height: 72,
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: horizontalSpacing),
                                    Expanded(
                                      child: SkeletonLine(
                                        style: SkeletonLineStyle(
                                          height: 72,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: verticalSpacing),
                              ],
                            ),
                          ),
                        )
                      else
                        AlignedGridView.count(
                          crossAxisCount: columns,
                          padding: EdgeInsets.zero,
                          itemCount: _blocksList?.length ?? 0,
                          shrinkWrap: true,
                          mainAxisSpacing: verticalSpacing,
                          crossAxisSpacing: horizontalSpacing,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: _getAvailabilityBlock,
                        ),
                      if (widget.amenity.maxCompanionsNumber != null &&
                          //ignore: avoid-non-null-assertion
                          _selectedBlock != null &&
                          _getCompanions() > 0)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 16),
                            Text(
                              copy('social-areas.companion'),
                              style: typo.bd1.medium,
                            ),
                            Row(
                              children: [
                                Text(
                                  '${copy('social-areas.allowed-by-booking')}: ',
                                  style: typo.bd2.light,
                                ),
                                Text(
                                  '${_getCompanions()}',
                                  style: typo.bd2.light,
                                ),
                                const Spacer(),
                                Counter(
                                  onChange: _setCompanions,
                                  lowerLimit: 0,
                                  upperLimit: _getCompanions(),
                                  initValue: ((_booking.companionsNumber ?? 0) <
                                              _getCompanions()
                                          ? _booking.companionsNumber
                                          : _getCompanions()) ??
                                      0,
                                ),
                              ],
                            ),
                          ],
                        ),
                      const SizedBox(height: 16),
                      Text(
                        copy('social-areas.leave-us-a-message'),
                        style: typo.bd1.medium,
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        maxLines: textAreaMaxLines,
                        style: typo.bd1.light,
                        onChanged: _setComment,
                        decoration: InputDecoration(
                          hintStyle: typo.bd1.light.copyWith(
                            //ignore: avoid-non-null-assertion
                            color: typo.bd1.light.color!
                                .withOpacity(textAreaOpacity),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                        ),
                      ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        extendBody: true,
        bottomNavigationBar: BottomButton(
          buttonText: copy('common.continue'),
          action: _goToSummary,
          disabled: _selectedBlock == null,
        ),
      ),
    );
  }
}
