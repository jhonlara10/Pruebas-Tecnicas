import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/amenities/amenities_bloc.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/service_point_info_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/booking_flux/availability.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/widgets/nv_carousel.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/nv_message.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class AmenityDetails extends StatefulWidget {
  final Amenity amenity;

  const AmenityDetails({
    Key? key,
    required this.amenity,
  }) : super(key: key);

  @override
  State<AmenityDetails> createState() => _AmenityDetailsState();
}

class _AmenityDetailsState extends State<AmenityDetails> {
  static ServicePointInfoModel? _servicePoint;
  final _copy = AppMessages().getCopy;
  List<String> _days = [];
  String? _errorMessage;
  bool _isLoading = true;
  int? _currentServicePoint;

  @override
  // ignore: long-method
  void initState() {
    (() async {
      _currentServicePoint = BlocProvider.of<AmenitiesBloc>(context)
          .state
          .selectedServicePoint
          ?.id;
      _servicePoint = await AmenitiesRepository()
          // ignore: avoid-non-null-assertion
          .getServicePointInfo(_currentServicePoint, widget.amenity.id!);
      setState(() {
        _errorMessage = validateServicePoint();
        _isLoading = false;
      });
    })();
    _days = [
      '',
      _copy('common.monday'),
      _copy('common.tuesday'),
      _copy('common.wednesday'),
      _copy('common.thursday'),
      _copy('common.friday'),
      _copy('common.saturday'),
      _copy('common.sunday'),
    ];
    super.initState();
  }

// #region Methods.
  /// Groups consecutive _days.
  List<List<int>> groupDays(List<int> avilableDays) {
    List<List<int>> groupedDays = [];
    List<int> consecutiveDays = [];
    for (var day in avilableDays) {
      if (consecutiveDays.isEmpty) {
        consecutiveDays.add(day);
      } else if (consecutiveDays.last + 1 == day) {
        consecutiveDays.add(day);
      } else {
        groupedDays.add(consecutiveDays);
        consecutiveDays = [day];
      }
    }
    groupedDays.add(consecutiveDays);
    return groupedDays;
  }

  /// Returns the grouped _days in an "easy-to-read" form.
  ///
  /// example:
  /// ```dart
  /// [[1, 4], [6]]  // ['From Monday to thursady', 'Saturday']
  /// ```
  List<String> humanizeGroypedDays(List<List<int>> groupedDays) {
    List<String> response = [];
    const pairOfDays = 2;

    for (var group in groupedDays) {
      if (group.length > pairOfDays) {
        response.add(
          '${_copy('common.from-alt')} ${_days[group.first]} ${_copy('common.to')} ${_days[group.last]}',
        );
      } else {
        for (var day in group) {
          //ignore: avoid-non-null-assertion
          response.add(_days[day]);
        }
      }
    }

    return response;
  }

  /// Returns the availability in a "easy-to-read" form
  /// example:
  /// ```dart
  /// "From Monday to Wednesday, Friday and Sunday"
  /// ```
  String humanizeAvailability() {
    List<int> availableDays = getAvailability(widget.amenity);
    List<String> groupedDays;
    String lastDay = '';
    const everyDay = 7;
    const pairOfDays = 2;

    if (availableDays.length == everyDay) {
      return _copy('social-areas.every-day');
    }
    if (availableDays.isEmpty) return _copy('social-areas.not-available');
    groupedDays = humanizeGroypedDays(groupDays(availableDays));

    if (groupedDays.length >= pairOfDays) {
      lastDay = groupedDays.removeLast();
      return '${groupedDays.join(', ')} ${_copy('common.and').toLowerCase()} $lastDay';
    }

    return groupedDays.join('');
  }

  String getBookingDuration() {
    List<String> duration = widget.amenity.blockPeriod?.split(':') ?? [''];
    String hours = '';
    String minutes = '';

    if ((num.tryParse(duration.first) ?? 0) > 0) {
      hours =
          '${duration.first} ${(int.tryParse(duration.first) ?? 0) > 1 ? _copy('common.hours').toLowerCase() : _copy('common.hour').toLowerCase()}';
    }
    if ((num.tryParse(duration[1]) ?? 0) > 0) {
      minutes =
          '${duration[1]} ${(int.tryParse(duration[1]) ?? 0) > 1 ? _copy('common.minutes').toLowerCase() : _copy('common.minute').toLowerCase()}';
    }

    return '$hours ${(hours != '' && minutes != '') ? _copy('common.and').toLowerCase() : ''} $minutes';
  }

  void goToAvailability() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) =>
            Availability(amenity: widget.amenity),
      ),
    );
  }

  String? validateServicePoint() {
    if (_servicePoint?.hasPendingPayments == true) {
      return _copy('social-areas.has-a-debt');
    }
    if ((_servicePoint?.eventReservationCapacityMonthly ?? double.infinity) <=
        (_servicePoint?.monthlyEventCount ?? double.negativeInfinity)) {
      return _copy('social-areas.you-reached-your-booking-limit-per-month');
    }
    if ((_servicePoint?.eventReservationCapacityWeekly ?? double.infinity) <=
        (_servicePoint?.weeklyEventCount ?? double.negativeInfinity)) {
      return _copy('social-areas.you-reached-your-booking-limit-per-week');
    }
    if (_servicePoint?.hasActiveReserve ?? false) {
      return _copy('social-areas.has-an-active-booking');
    }
    return null;
  }
  // #endregion.

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            const NvSliverAppbar(),
            SliverPadding(
              padding: const EdgeInsets.only(bottom: 100),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  Padding(
                    padding: DefaultValues.padding,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.amenity.name ?? '',
                          style: typo.h2.semibold,
                        ),
                        const SizedBox(height: 24),
                        NvCarousel(
                          images: widget.amenity.imageList,
                        ),
                        const SizedBox(height: 24),
                        Row(
                          children: [
                            //ignore: avoid-non-null-assertion
                            getAmenityTag(context, widget.amenity),
                            const Spacer(flex: 1),
                            Text(
                              //ignore: avoid-non-null-assertion
                              getBookingPrice(context, widget.amenity),
                              style: typo.h5.semibold,
                            ),
                            const SizedBox(height: 16),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            const NvImage(icon: 'Holidays/calendar-31'),
                            const SizedBox(width: 10.5),
                            Text(
                              humanizeAvailability(),
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                        const SizedBox(height: 13),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const NvImage(
                              icon: 'Interface, Essential/clock-time',
                            ),
                            const SizedBox(width: 10.5),
                            Text(
                              '${_copy('social-areas.max-duration')}: ${getBookingDuration()}',
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                        const SizedBox(height: 13),
                        Row(
                          children: [
                            const NvImage(
                              icon: 'User/users-checkmark--square',
                            ),
                            const SizedBox(width: 10.5),
                            Text(
                              _copy(
                                'social-areas.maximun-capacity',
                                //ignore: avoid-non-null-assertion
                                [widget.amenity.capacity.toString()],
                              ),
                              style: typo.bd2.light,
                            ),
                          ],
                        ),
                        if (widget.amenity.socialAreaConfigurationObj?.rules !=
                            null)
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 18.5),
                              Text(
                                '${_copy('social-areas.note')}:',
                                style: typo.bd1.medium,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                widget.amenity.socialAreaConfigurationObj
                                        ?.rules ??
                                    '',
                                style: typo.bd2.light,
                              ),
                            ],
                          ),
                        if (_errorMessage != null)
                          Column(
                            children: [
                              const SizedBox(height: 16),
                              NvMessage(
                                child: Text(
                                  '${_copy("social-areas.you-can't-book-because")} ${_errorMessage?.toLowerCase()}',
                                  style: typo.bd2.light,
                                ),
                              ),
                            ],
                          ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
      extendBody: true,
      bottomNavigationBar: BottomButton(
        buttonText: _copy('social-areas.book'),
        disabled: _errorMessage != null || _isLoading,
        action: widget.amenity.inMaintenance ?? false ? null : goToAvailability,
      ),
    );
  }
}
