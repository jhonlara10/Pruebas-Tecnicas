import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/amenities/amenities_bloc.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/booking_body.dart';
import 'package:neivor_flutter_app/presentation/amenities/amenities.dart';
import 'package:neivor_flutter_app/presentation/amenities/partials/summary_info.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_receipt.dart';

class Confirmation extends StatelessWidget {
  final BookingBody booking;
  final Amenity amenity;

  const Confirmation({
    Key? key,
    required this.booking,
    required this.amenity,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;

    void _goToAmenities(context) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (BuildContext context) => const Amenities()),
        ModalRoute.withName('home'),
      );
    }

    return NvReceipt(
      title: copy('social-areas.booked-successfully'),
      subtitle: copy('social-areas.check-the-data'),
      onGoBack: () => _goToAmenities(context),
      body: Column(
        children: [
          const SizedBox(height: 24),
          SummaryInfo(
            booking: booking,
            amenity: amenity,
            servicePoint: BlocProvider.of<AmenitiesBloc>(context)
                .state
                .selectedServicePoint,
            isConfirmationPage: true,
          ),
        ],
      ),
    );
  }
}
