import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/amenities/amenities_bloc.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/booking_body.dart';
import 'package:neivor_flutter_app/presentation/amenities/booking_flux/cancel_booking.dart';
import 'package:neivor_flutter_app/presentation/amenities/booking_flux/confirmation.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/presentation/amenities/partials/summary_info.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';

class Summary extends StatefulWidget {
  final BookingBody booking;
  final Amenity amenity;

  const Summary({
    Key? key,
    required this.booking,
    required this.amenity,
  }) : super(key: key);

  @override
  State<Summary> createState() => _SummaryState();
}

class _SummaryState extends State<Summary> {
  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    void goToConfirmation() {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) =>
              Confirmation(booking: widget.booking, amenity: widget.amenity),
        ),
      );
    }

    void book() async {
      context.loaderOverlay.show();
      if (UserUtils().isAdminUser()) {
        final servicePoint =
            BlocProvider.of<AmenitiesBloc>(context).state.selectedServicePoint;
        widget.booking.idServicePointRequest = servicePoint?.id;
        widget.booking.idOperationZone = servicePoint?.idOperationZone;
      }
      var cost = double.tryParse(getBookingPrice(context, widget.amenity)
              .replaceFirst("\$ ", '')
              .replaceAll(',', '')) ??
          0;
      widget.booking.costEvent = cost.toString();
      await AmenitiesRepository().bookAmenity(widget.booking);
      goToConfirmation();
      context.loaderOverlay.hide();
    }

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            const NvSliverAppbar(),
            SliverPadding(
              padding: DefaultValues.padding,
              sliver: SliverList(
                delegate: SliverChildListDelegate(
                  [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          copy('social-areas.booking-data'),
                          style: typo.h2.semibold,
                        ),
                        const SizedBox(height: 24),
                        Text(
                          copy('social-areas.check-the-data'),
                          style: typo.bd2.light,
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    SummaryInfo(
                      booking: widget.booking,
                      amenity: widget.amenity,
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: colors.opacityBackgrounds.turquoise,
                        borderRadius: DefaultValues.borderRadius2,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            copy('social-areas.total-to-pay'),
                            style: typo.bd2.light.copyWith(
                              color: colors.text.primary,
                            ),
                          ),
                          Text(
                            getBookingPrice(context, widget.amenity),
                            style: typo.h1.semibold
                                .copyWith(color: colors.text.primary),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomButton(
        buttonText: copy('social-areas.book'),
        action: book,
        secondaryText: copy('common.cancel'),
        secondaryAction: () => showModalBottomSheet(
          context: context,
          shape: RoundedRectangleBorder(
            borderRadius: DefaultValues.borderRadius2,
          ),
          builder: (context) {
            return const CancelBooking();
          },
        ),
      ),
    );
  }
}
