import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

// ignore: prefer-correct-type-name
class CancelBooking extends StatefulWidget {
  const CancelBooking({
    Key? key,
  }) : super(key: key);

  @override
  State<CancelBooking> createState() => _CancelBookingState();
}

// ignore: prefer-correct-type-name
class _CancelBookingState extends State<CancelBooking> {
  static final _copy = AppMessages().getCopy;
  static const _iconWidth = 48.0;
  static const _bottomPadding = 154.0;

  void _goToAmenities(BuildContext context) {
    Navigator.of(context).popUntil(ModalRoute.withName("amenities"));
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BackdropFilter(
        filter: DefaultValues.backdropBlur,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: colors.backgrounds.main,
                borderRadius: DefaultValues.borderRadius2,
              ),
              child: Container(
                padding:
                    DefaultValues.padding2.copyWith(bottom: _bottomPadding),
                width: double.infinity,
                child: Column(
                  children: [
                    NvImage(
                      icon: 'Interface, Essential/Warning',
                      width: _iconWidth,
                      color: colors.icons.warning,
                    ),
                    const SizedBox(height: 24),
                    Text(
                      _copy('social-areas.are-you-sure-to-cancel-the-booking'),
                      style: typo.h5.semibold,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomSheet: BottomButton(
        direction: Axis.vertical,
        action: () => _goToAmenities(context),
        buttonText: _copy('common.confirm'),
        secondaryAction: () => Navigator.pop(context),
        secondaryText: _copy('common.back'),
        secondaryVariant: ButtonVariant.secondaryText,
      ),
    );
  }
}
