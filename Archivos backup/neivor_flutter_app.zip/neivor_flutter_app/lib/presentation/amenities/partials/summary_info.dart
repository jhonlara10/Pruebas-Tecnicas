import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/domain/models/amenities/booking_body.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class SummaryInfo extends StatelessWidget {
  final BookingBody booking;
  final Amenity amenity;
  final bool isConfirmationPage;
  final ServicePointObject? servicePoint;

  const SummaryInfo({
    Key? key,
    required this.booking,
    required this.amenity,
    this.servicePoint,
    this.isConfirmationPage = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    final typo = AppThemeScope.of(context).typography;
    final colors = AppThemeScope.of(context).colors;
    final startDate = Jiffy(
      booking.eventStartString,
      'yyyy/MM/dd HH:mm',
    );
    final endDate = Jiffy(
      booking.eventEndString,
      'yyyy/MM/dd HH:mm',
    );
    const imageWidth = 78.21;
    const imageHeight = 58.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            ClipRRect(
              borderRadius: DefaultValues.borderRadius2,
              child: NvImage(
                fit: BoxFit.fill,
                isStatic: true,
                width: imageWidth,
                height: imageHeight,
                imageUrl: amenity.imageList?.first,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    amenity.name ?? '',
                    style: typo.bd1.medium,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Text(
                        '${copy('social-areas.price')}:',
                        style: typo.bd2.light,
                      ),
                      const Spacer(),
                      Text(
                        getBookingPrice(context, amenity),
                        style: typo.bd1.medium,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          children: [
            Text(
              copy('social-areas.booking-data'),
              style: typo.st1.medium,
            ),
            const Spacer(),
            if (!isConfirmationPage)
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Text(
                  copy('common.edit'),
                  style: typo.bd1.mediumUnderLine.copyWith(
                    color: colors.button.turquoise.main,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 16),
        if (servicePoint != null)
          Row(
            children: [
              Text(
                '${copy('social-areas.tower-and-unity')}:',
                style: typo.bd1.light,
              ),
              const Spacer(),
              Text(
                '${servicePoint?.operationZone?.name} - ${servicePoint?.name}',
                style: typo.bd2.medium,
              ),
            ],
          ),
        Row(
          children: [
            Text('${copy('common.date')}:', style: typo.bd1.light),
            const Spacer(),
            Text(
              //TODO: remove replaceAll when date formats has been updated.
              startDate.format(
                copy('common.date-format')
                    .replaceAll('Do', 'do')
                    .replaceAll('D', 'd'),
              ),
              style: typo.bd2.medium,
            ),
          ],
        ),
        Row(
          children: [
            Text('${copy('common.hour')}:', style: typo.bd1.light),
            const Spacer(),
            Text(
              '${startDate.format('hh:mm a')} - ${endDate.format('hh:mm a')}',
              style: typo.bd2.medium,
            ),
          ],
        ),
        Row(
          children: [
            Text(
              '${copy('social-areas.companion')}:',
              style: typo.bd1.light,
            ),
            const Spacer(),
            Text(
              '${booking.companionsNumber}',
              style: typo.bd2.medium,
            ),
          ],
        ),
        if (booking.description?.isNotEmpty ?? false)
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 24),
              Text(
                copy('social-areas.message'),
                style: typo.bd1.medium,
              ),
              const SizedBox(height: 4),
              Text(
                booking.description ?? '',
                style: typo.bd2.light,
              ),
            ],
          ),
      ],
    );
  }
}
