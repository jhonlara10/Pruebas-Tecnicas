import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_body.dart';
import 'package:neivor_flutter_app/domain/models/amenities/bookings_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/presentation/amenities/requests_flux/request_details.dart';
import 'package:neivor_flutter_app/presentation/amenities/widgets/amenity-card.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:skeletons/skeletons.dart';

class RequestsTabView extends StatefulWidget {
  const RequestsTabView({Key? key}) : super(key: key);

  @override
  State<RequestsTabView> createState() => _RequestsTabViewState();
}

class _RequestsTabViewState extends State<RequestsTabView>
    with AutomaticKeepAliveClientMixin {
  final BookingsBody _body = BookingsBody.defaultValues();
  final PagingController<int, Booking> _pagingController =
      PagingController(firstPageKey: 0);
  bool _areThereBookings = false;
  bool _isLoading = true;
  static const _listTopPadding = 24.0;
  static const _skeletonListSize = 800.0;
  static const _skeletonListSizeSm = 200.0;

// #region Life cycle.
  @override
  void initState() {
    (() async {
      _pagingController.addPageRequestListener((pageKey) {
        _fetchPage(pageKey);
      });
      _body.servicePoint = null;
      _body.eventStart = Jiffy().format('yyyy-MM-dd HH:mm:ss');
      _body.eventState = [BookingState.pending];
      print(_body.toJson());
    })();
    super.initState();
  }

  @override
  void dispose() {
    _pagingController.dispose();
    super.dispose();
  }
// #endregion.

// #region Methods
  bool scrollEffect(OverscrollIndicatorNotification overScroll) {
    if (!_areThereBookings && !_isLoading) {
      overScroll.disallowIndicator();
    }
    return false;
  }

  // ignore: long-method
  Future<void> _fetchPage(int pageKey) async {
    _body.page = pageKey;
    var response = await AmenitiesRepository().getBookings(_body);
    try {
      if (response.success == true) {
        final list = response.data;
        final isLastPage = (list?.isEmpty ?? true);
        //ignore: avoid-non-null-assertion
        if (isLastPage) {
          _pagingController.appendLastPage(list ?? []);
        } else {
          _pagingController.appendPage(list ?? [], pageKey + 1);
        }
        if (_pagingController.itemList?.isNotEmpty ?? false) {
          _areThereBookings = true;
        }
      }
      setState(() {
        _isLoading = false;
      });
    } catch (error) {
      _pagingController.error = error;
    }
  }

  // ignore: long-method
  Widget getSkeleton(BuildContext context, double listSize) {
    final typo = AppThemeScope.of(context).typography;

    return SizedBox(
      height: listSize,
      child: SkeletonListView(
        padding: EdgeInsets.only(
          top: _listTopPadding + (typo.h5.semibold.height?.toDouble() ?? 0),
        ),
        item: AmenityCard.skeleton(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              // TODO: get the sizes from widget.
              SkeletonLine(
                style: SkeletonLineStyle(
                  width: 90,
                ),
              ),
              SizedBox(height: 4),
              SkeletonLine(
                style: SkeletonLineStyle(
                  width: 52,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _goToDetails(Booking booking) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => RequestDetails(booking: booking),
      ),
    );
  }

// #endregion.

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final copy = AppMessages().getCopy;
    const size = 0.55;

    super.build(context);

    return Align(
      alignment: !_areThereBookings && !_isLoading
          ? Alignment.center
          : Alignment.topLeft,
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: scrollEffect,
        child: PagedListView<int, Booking>(
          padding: DefaultValues.padding.copyWith(top: _listTopPadding),
          shrinkWrap: true,
          pagingController: _pagingController,
          builderDelegate: PagedChildBuilderDelegate<Booking>(
            firstPageProgressIndicatorBuilder: (_) =>
                getSkeleton(context, _skeletonListSize),
            newPageProgressIndicatorBuilder: (_) =>
                getSkeleton(context, _skeletonListSizeSm),
            itemBuilder: (context, booking, index) {
              return Column(
                children: [
                  GestureDetector(
                    onTap: () => _goToDetails(booking),
                    child: AmenityCard(
                      image: booking.imageList?.first,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width * size,
                            child: Text(
                              booking.title ?? '',
                              style: typo.bd1.medium,
                              overflow: TextOverflow.fade,
                              maxLines: 1,
                              softWrap: false,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const NvImage(
                                icon:
                                    'Building, Construction/skyscraper-modern-tree',
                                width: 16,
                              ),
                              const SizedBox(width: 4),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * size,
                                child: Text(
                                  '${booking.nameOperationZone} - ${booking.nameServicePoint}',
                                  style: typo.bd2.light,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              );
            },
            noItemsFoundIndicatorBuilder: (_) => Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const NvImage(
                  imageUrl: 'ds/illustrations/calendar.png',
                  width: 174.67,
                ),
                const SizedBox(height: 16),
                Text(
                  //'Aun no tienes solicitudes',
                  copy('social-areas.booking-empty'),
                  style: typo.h5.semibold,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  //'Los residentes aún no han solicitado reservar una amenidad disponible',
                  copy('social-areas.booking-empty-description'),
                  style: typo.bd1.light,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
