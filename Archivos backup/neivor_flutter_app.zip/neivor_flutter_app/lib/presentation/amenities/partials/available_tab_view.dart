// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:neivor_flutter_app/data/repository/amenities/amenities_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/amenities/amenities_model.dart';
import 'package:neivor_flutter_app/presentation/amenities/booking_flux/amenity_details.dart';
import 'package:neivor_flutter_app/presentation/amenities/comon/utils.dart';
import 'package:neivor_flutter_app/presentation/amenities/widgets/amenity-card.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/constants/default_values.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:skeletons/skeletons.dart';

class AvailableTabView extends StatefulWidget {
  const AvailableTabView({Key? key}) : super(key: key);

  @override
  State<AvailableTabView> createState() => _AvailableTabViewState();
}

class _AvailableTabViewState extends State<AvailableTabView> {
  final int _pageSize = 6;
  final PagingController<int, Amenity> _pagingController =
      PagingController(firstPageKey: 0);
  bool _areThereAmenities = false;
  bool _isLoading = true;

  @override
  initState() {
    (() async {
      _pagingController.addPageRequestListener((pageKey) {
        _fetchPage(pageKey);
      });
    })();
    super.initState();
  }

  @override
  void dispose() {
    _pagingController.dispose();
    super.dispose();
  }

  // ignore: long-method
  Future<void> _fetchPage(int pageKey) async {
    try {
      var response = await AmenitiesRepository()
          .getAmenities('page-size=$_pageSize&page=$pageKey');
      if (response.success == true) {
        final data = response.data;
        final list = data?.list;
        final isLastPage =
            (data?.totalRow ?? 1) <= (_pagingController.itemList?.length ?? 0);
        //ignore: avoid-non-null-assertion
        if (_pagingController.itemList?.isNotEmpty ?? false) {
          _areThereAmenities = true;
        }
        if (isLastPage) {
          _pagingController.appendLastPage(list ?? []);
        } else {
          _pagingController.appendPage(list ?? [], pageKey + 1);
        }
      }
      setState(() {
        _isLoading = false;
      });
    } catch (error) {
      _pagingController.error = error;
    }
  }

  void _goToDetails(BuildContext context, Amenity amenity) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => AmenityDetails(amenity: amenity),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;
    final copy = AppMessages().getCopy;
    const listTopPadding = 24.0;
    const skeletonListSize = 800.0;
    const skeletonListSizeSm = 200.0;
    const maxLines = 2;
    const size = 0.55;

    bool scrollEffect(OverscrollIndicatorNotification overScroll) {
      if (!_areThereAmenities && !_isLoading) {
        overScroll.disallowIndicator();
      }
      return false;
    }

// ignore: long-method
    Widget getSkeleton(double listSize) {
      return SizedBox(
        height: listSize,
        child: SkeletonListView(
          padding: EdgeInsets.only(
            top: listTopPadding + (typo.h5.semibold.height?.toDouble() ?? 0),
          ),
          item: AmenityCard.skeleton(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                // TODO: get the sizes from widget.
                SkeletonLine(
                  style: SkeletonLineStyle(
                    width: 90,
                  ),
                ),
                SizedBox(height: 4),
                SkeletonLine(
                  style: SkeletonLineStyle(
                    width: 52,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Align(
      alignment: !_areThereAmenities && !_isLoading
          ? Alignment.center
          : Alignment.topLeft,
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: scrollEffect,
        child: PagedListView<int, Amenity>(
          padding: DefaultValues.padding.copyWith(top: listTopPadding),
          shrinkWrap: true,
          pagingController: _pagingController,
          builderDelegate: PagedChildBuilderDelegate<Amenity>(
            firstPageProgressIndicatorBuilder: (_) =>
                getSkeleton(skeletonListSize),
            newPageProgressIndicatorBuilder: (_) =>
                getSkeleton(skeletonListSizeSm),
            itemBuilder: (context, amenity, index) {
              return Column(
                children: [
                  GestureDetector(
                    child: AmenityCard(
                      image: amenity.imageList?.first,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width * size,
                            child: Text(
                              amenity.name ?? '',
                              style: typo.bd1.medium.copyWith(
                                overflow: TextOverflow.fade,
                              ),
                              softWrap: false,
                              maxLines: maxLines,
                            ),
                          ),
                          if (amenity.inMaintenance ?? false)
                            Column(
                              children: [
                                const SizedBox(height: 4),
                                getAmenityTag(context, amenity),
                              ],
                            ),
                        ],
                      ),
                    ),
                    onTap: () => _goToDetails(
                      context,
                      amenity,
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              );
            },
            noItemsFoundIndicatorBuilder: (_) => Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const NvImage(
                  imageUrl: 'ds/illustrations/buildings.png',
                  width: 174.67,
                ),
                const SizedBox(height: 16),
                Text(
                  copy('social-areas.not-available-social-areas'),
                  style: typo.h5.semibold,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  copy('social-areas.contact-admin'),
                  style: typo.bd1.light,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
