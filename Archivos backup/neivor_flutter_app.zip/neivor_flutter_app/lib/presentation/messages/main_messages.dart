import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/data/repository/chat_messages/chat_msgs_repository_impl.dart';
import 'package:neivor_flutter_app/domain/groups/groups_response.dart';
import 'package:neivor_flutter_app/domain/models/chat_messages/get_chat_msgs_response.dart';
import 'package:neivor_flutter_app/presentation/chat/chat.dart';
import 'package:neivor_flutter_app/presentation/messages/widgets/groups.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:skeletons/skeletons.dart';

import 'widgets/widgets.dart';

class MainMessages extends StatefulWidget {
  static const double _divisionHeight = 16;
  static const double _emptyImageHeight = 120;
  static const int _loadingDummyQuantity = 10;
  const MainMessages({Key? key}) : super(key: key);

  @override
  State<MainMessages> createState() => _MainMessagesState();
}

class _MainMessagesState extends State<MainMessages> {
  List<GetChatMsgsResponse>? conversations;
  TextEditingController searchController = TextEditingController();
  List<GetChatMsgsResponse>? listToShow;
  bool isLoading = true;
  GroupsResponse? groupList;

  @override
  void initState() {
    callGetInboxMsgs();
    super.initState();
  }

  callGetInboxMsgs() async {
    await getInboxMsgs(context);
    groupList = await getGroups();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        conversations =
            BlocProvider.of<MessagesBloc>(context).state.messagesList;
        conversations = conversations
            ?.where((element) => element.idComplaintDemand == null)
            .toList();
        listToShow = conversations;
      });
    });
    isLoading = false;
  }

  void searchChat(input) {
    listToShow = conversations;
    setState(() {
      if (input == null || input.isNotEmpty) {
        listToShow = listToShow?.where((element) {
          return element.nameConversation
                  ?.toLowerCase()
                  .contains(input.toLowerCase()) ??
              false;
        }).toList();
      }
    });
  }

  previewGroup(Data? selectedGroup) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => Chat(
          selectedGroup: selectedGroup,
          isGroupMember: false,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "home");
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacementNamed(context, "home"),
        ),
        body: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    AppMessages().getCopy("messages.messages-title"),
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 26,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  if (UserUtils().hasPermissionsTo(46) &&
                      UserUtils().hasPermissionsTo(50))
                    GestureDetector(
                      onTap: () => Navigator.pushNamed(context, 'addMessage'),
                      child: const NvImage(
                        imageUrl: "/ds/icons/edit-new-version.svg",
                      ),
                    ),
                ],
              ),
              const SizedBox(
                height: MainMessages._divisionHeight,
              ),
              if ((conversations?.isNotEmpty ?? false) && !isLoading)
                TextField(
                  controller: searchController,
                  onChanged: (value) => searchChat(value),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText:
                        AppMessages().getCopy("messages.search-placeholder"),
                  ),
                ),
              const SizedBox(
                height: 16,
              ),
              if (groupList?.data?.isNotEmpty ?? false)
                 Groups(
                   groupList: groupList ?? GroupsResponse(),
                   previewGroup: previewGroup,
                 ),
              if ((conversations?.isEmpty ?? true) && !isLoading) ...[
                const Spacer(),
                const EmptyMsgList(
                  emptyImageHeight: MainMessages._emptyImageHeight,
                ),
                const Spacer(),
              ],
              const SizedBox(
                height: 24,
              ),
              isLoading
                  ? Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: MainMessages._loadingDummyQuantity,
                        itemBuilder: (context, index) {
                          return SkeletonListTile(
                            hasSubtitle: true,
                            leadingStyle: const SkeletonAvatarStyle(
                              height: 50,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(100)),
                            ),
                          );
                        },
                      ),
                    )
                  : ConversationCard(conversations: listToShow),
            ],
          ),
        ),
      ),
    );
  }
}
