import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/domain/models/chat_messages/get_chat_msgs_response.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/presentation/chat/chat.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';
import 'dart:convert';
import 'package:neivor_flutter_app/domain/models/general/neighbors_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:url_launcher/url_launcher.dart';

import 'widgets/widgets.dart';

class AddMessage extends StatefulWidget {
  const AddMessage({Key? key, this.fromWall}) : super(key: key);
  static const double _titleSize = 26;
  static const double _divisionHeight = 16;
  final bool? fromWall;

  @override
  State<AddMessage> createState() => _AddMessageState();
}

class _AddMessageState extends State<AddMessage> {
  List<NeighborsResponse>? securityList;
  List<NeighborsResponse>? neighborsList;
  List<NeighborsResponse>? neighborsToShow;
  List<NeighborsResponse>? securityToShow;
  String chatApiUrl = "";

  @override
  void initState() {
    super.initState();
    chatApiUrl = AppUrls().getProperty("api.chat.url");
    FocusManager.instance.primaryFocus?.unfocus();
    filterSecurity();
    filterNeighbors();
  }

  Map<String, dynamic> getCallParams(NeighborsResponse? neigbor) {
    return {
      "phone": neigbor?.mobilePhone ?? neigbor?.phone ?? "",
      "userImage": GlobalUtils().cdn(neigbor?.photo),
      "userName": neigbor?.alias,
      "idEnterprise": UserUtils.currentEnterprise?.id,
      "idCallerZyosUser": neigbor?.id,
      "idCalledZyosUser": UserUtils.currentUser?.id,
      "idZyosGroup": UserUtils.currentZyosGroup?.id,
      "enterpriseName": UserUtils.currentEnterprise?.name,
      "servicePointName":
          '${UserUtils.currentServicePoint?.operationZone?.name ?? ''} - ${UserUtils.currentServicePoint?.name ?? ''}',
      "apiUrl": "$chatApiUrl/private/v1/chats/call-history",
    };
  }

  makeCall(NeighborsResponse? neigbor) {
    var params = getCallParams(neigbor);
    Codec<String, String> stringToBase64 = utf8.fuse(base64);
    String encoded = stringToBase64.encode(json.encode(params));
    if (Platform.isAndroid) {
      launch("https://fitnesswellnessschool.com/twilio-calls/?params=$encoded");
    } else {
      launch(
        "https://fitnesswellnessschool.com/twilio-calls/?params=$encoded",
        forceSafariVC: true,
      );
    }
  }

  void filterSecurity() {
    securityList = BlocProvider.of<MessagesBloc>(context)
        .state
        .neighborsList
        ?.where((element) {
      List<ZyosUserGroup>? securityRole = element.zyosUserGroup
          ?.where((zyosUserGroupId) => zyosUserGroupId.idGroup == 8)
          .toList();
      return (securityRole != null && securityRole.isNotEmpty);
    }).toList();
    securityList?.removeWhere((value) => value.id == UserUtils.currentUser?.id);
    securityToShow = securityList;
  }

  void filterNeighbors() {
    neighborsList = BlocProvider.of<MessagesBloc>(context)
        .state
        .neighborsList
        ?.where((element) {
      List<ZyosUserGroup>? nonSecurityRole = element.zyosUserGroup
          ?.where((zyosUserGroupId) => zyosUserGroupId.idGroup != 8)
          .toList();
      return (nonSecurityRole != null && nonSecurityRole.isNotEmpty);
    }).toList();
    neighborsList
        ?.removeWhere((value) => value.id == UserUtils.currentUser?.id);
    neighborsToShow = neighborsList;
  }

  void searchPeople(String input) {
    securityToShow = securityList;
    neighborsToShow = neighborsList;
    setState(() {
      searchSecurity(input);
      searchNeighbor(input);
    });
  }

  void searchNeighbor(String input) {
    if (input.isNotEmpty) {
      neighborsToShow = neighborsToShow?.where((element) {
        return (element.alias?.toLowerCase().contains(input.toLowerCase()) ??
                false) ||
            (element.name?.toLowerCase().contains(input.toLowerCase()) ??
                false);
      }).toList();
    }
  }

  void searchSecurity(String input) {
    securityToShow = securityToShow?.where((element) {
      return (element.alias?.toLowerCase().contains(input.toLowerCase()) ??
              false) ||
          (element.name?.toLowerCase().contains(input.toLowerCase()) ?? false);
    }).toList();
  }

  // ignore: long-method
  void goToConversation(int index, bool isNeighbor) {
    List<GetChatMsgsResponse>? conversation =
        BlocProvider.of<MessagesBloc>(context).state.messagesList;
    GetChatMsgsResponse? result;
    if (neighborsToShow != null && securityToShow != null) {
      result = conversation?.firstWhere(
        (element) {
          return element.idZyosUserDestiny ==
              (isNeighbor
                  // ignore: avoid-non-null-assertion
                  ? neighborsToShow![index].id
                  // ignore: avoid-non-null-assertion
                  : securityToShow![index].id);
        },
        orElse: () => GetChatMsgsResponse(idConversation: null),
      );
    }
    if (isNeighbor) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => Chat(
            selectedNeighbor: neighborsToShow?[index],
            chatConversation: result?.idConversation == null ? null : result,
            fromNeighborList: true,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => Chat(
            selectedNeighbor: securityToShow?[index],
            chatConversation: result?.idConversation == null ? null : result,
            fromNeighborList: true,
          ),
        ),
      );
    }
  }

  final int idSecurity = 8;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          (widget.fromWall ?? false) ? 'home' : 'messages',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacementNamed(
            context,
            (widget.fromWall ?? false) ? 'home' : 'messages',
          ),
        ),
        body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppMessages().getCopy('messages.new-group'),
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: AddMessage._titleSize,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(
                  height: AddMessage._divisionHeight,
                ),
                TextField(
                  onChanged: (value) {
                    searchPeople(value);
                  },
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText:
                        AppMessages().getCopy("messages.search-placeholder"),
                  ),
                ),
                const SizedBox(
                  height: AddMessage._divisionHeight,
                ),
                if (!UserUtils().hasPermissionsTo(736)) ...[
                  Text(
                    AppMessages().getCopy('messages.security'),
                    style: const TextStyle(
                      fontSize: AddMessage._divisionHeight,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(
                    height: AddMessage._divisionHeight,
                  ),
                  NeighborsList(
                    neighborsList: securityToShow,
                    goToConversation: goToConversation,
                    makeCall: makeCall,
                    isSecurityList: true,
                  ),
                ],
                const SizedBox(
                  height: AddMessage._divisionHeight,
                ),
                Text(
                  AppMessages().getCopy('messages.neighbors'),
                  style: const TextStyle(
                    fontSize: AddMessage._divisionHeight,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(
                  height: AddMessage._divisionHeight,
                ),
                NeighborsList(
                  neighborsList: neighborsToShow,
                  goToConversation: goToConversation,
                  makeCall: makeCall,
                  isSecurityList: false,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
