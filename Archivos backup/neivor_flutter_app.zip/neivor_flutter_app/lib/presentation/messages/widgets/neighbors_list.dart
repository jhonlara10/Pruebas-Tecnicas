import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class NeighborsList extends StatelessWidget {
  static const double _userImageSize = 32;
  static const double _divisionHorizontal = 8;
  static const double _fontsizeName = 14;
  const NeighborsList({
    Key? key,
    required this.neighborsList,
    required this.goToConversation,
    required this.makeCall,
    required this.isSecurityList,
  }) : super(key: key);

  final List<NeighborsResponse>? neighborsList;
  final Function goToConversation;
  final Function makeCall;
  final bool isSecurityList;

  final int idSecurity = 8;
  final int idAdmin = 2;

  showCallOption() {
    if (isSecurityList) {
      return UserUtils().hasPermissionsTo(700);
    }

    if (!isSecurityList) {
      return UserUtils().hasPermissionsTo(703);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: neighborsList?.length ?? 0,
      separatorBuilder: (BuildContext context, int index) {
        return const Divider(
          thickness: 1,
        );
      },
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: () => goToConversation(index, !isSecurityList),
          child: Card(
            elevation: 0,
            shape: const RoundedRectangleBorder(
              side: BorderSide(color: Colors.transparent),
            ),
            child: Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipOval(
                        child: NvImage(
                          isUserImage: true,
                          width: _userImageSize,
                          height: _userImageSize,
                          imageUrl: neighborsList?[index].photo,
                        ),
                      ),
                      const SizedBox(
                        width: _divisionHorizontal,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (neighborsList?[index].name ?? ''),
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: _fontsizeName,
                            ),
                          ),
                          if (isSecurityList)
                            const Text(
                              "vigilante",
                              style: TextStyle(
                                fontWeight: FontWeight.w300,
                              ),
                            )
                          else
                            Text(
                              (neighborsList?[index].servicePointName ?? ''),
                              style: const TextStyle(
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                  if (showCallOption())
                    FloatingActionButton(
                      backgroundColor: AppThemeScope.of(context)
                          .colors
                          .primary
                          .arcticGray
                          .main,
                      elevation: 0,
                      mini: true,
                      heroTag: "$index$isSecurityList",
                      onPressed: () => makeCall(neighborsList?[index]),
                      child: const Icon(
                        Icons.phone,
                        color: AppTheme.greenArlequin4,
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
