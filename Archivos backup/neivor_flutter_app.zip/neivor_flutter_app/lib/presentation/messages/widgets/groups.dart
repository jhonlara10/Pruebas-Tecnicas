import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/groups/groups_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class Groups extends StatefulWidget {
  const Groups({Key? key, required this.groupList, required this.previewGroup})
      : super(key: key);

  final GroupsResponse groupList;
  final Function previewGroup;

  @override
  State<Groups> createState() => _GroupsState();
}

class _GroupsState extends State<Groups> {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // TODO this option is not available yet.
        // Container(
        //   height: 115,
        //   padding: const EdgeInsets.all(10),
        //   color:
        //       AppThemeScope.of(context).colors.opacityBackgrounds.turquoise,
        //   child: Column(
        //     children: [
        //       const CircleAvatar(
        //         backgroundColor: Colors.white,
        //         child: NvImage(
        //           imageUrl: "/ds/icons/user-add-plus.svg",
        //         ),
        //       ),
        //       Text(
        //         "Sugerir\ngrupo",
        //         style: AppThemeScope.of(context).typography.bd2.medium,
        //         textAlign: TextAlign.center,
        //       ),
        //     ],
        //   ),
        // ),
        Expanded(
          child: Container(
            height: 115,
            padding: const EdgeInsets.fromLTRB(0, 10, 10, 10),
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: widget.groupList.data?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Colors.white,
                      child: Icon(Icons.group_outlined),
                    ),
                    SizedBox(
                      width: 80,
                      child: Text(
                        widget.groupList.data?[index].name ?? '',
                        style: AppThemeScope.of(context).typography.bd2.medium,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                    GestureDetector(
                      onTap: () => widget.previewGroup(
                        widget.groupList.data?[index],
                      ),
                      child: Text(
                        AppMessages().getCopy('groups.join'),
                        style: AppThemeScope.of(context)
                            .typography
                            .bd2
                            .medium
                            .copyWith(
                              color: AppThemeScope.of(context)
                                  .colors
                                  .button
                                  .turquoise
                                  .main,
                            ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
