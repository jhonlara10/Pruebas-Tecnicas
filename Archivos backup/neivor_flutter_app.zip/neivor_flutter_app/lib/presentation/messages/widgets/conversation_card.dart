import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/chat_messages/get_chat_msgs_response.dart';
import 'package:neivor_flutter_app/presentation/chat/chat.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class ConversationCard extends StatelessWidget {
  static const double _userImageHeight = 32;
  static const double _titleSeparation = 8;
  const ConversationCard({
    Key? key,
    required this.conversations,
  }) : super(key: key);

  final List<GetChatMsgsResponse>? conversations;
  final String regex =
      "[^\\s]+(.*?)\\.(jpg|jpeg|png|gif|JPG|JPEG|PNG|GIF|svg|SVG)\$";

  String parseDate(double date) {
    DateTime dateParsed =
        DateTime.fromMillisecondsSinceEpoch(date.toInt() * 1000);
    final formatter = DateFormat('dd/MM/yyyy');
    return formatter.format(dateParsed);
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.separated(
        physics: const BouncingScrollPhysics(),
        shrinkWrap: true,
        itemCount: conversations?.length ?? 0,
        separatorBuilder: (BuildContext context, int index) {
          return const Divider(
            thickness: 1,
          );
        },
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (BuildContext context) =>
                    Chat(chatConversation: conversations?[index]),
              ),
            ),
            child: Card(
              margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
              shape: const RoundedRectangleBorder(
                side: BorderSide(color: Colors.transparent),
              ),
              elevation: 0,
              child: Row(children: [
                ClipOval(
                  child: NvImage(
                    isUserImage: true,
                    width: _userImageHeight,
                    height: _userImageHeight,
                    imageUrl: conversations?[index].photoUserDestiny,
                  ),
                ),
                const SizedBox(
                  width: _titleSeparation,
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width *
                          Constants.eightyPercent,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width *
                                Constants.fiftyPercent,
                            child: Text(
                              conversations?[index].nameConversation ?? '',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Text(
                            parseDate(
                              conversations?[index].dateCreation ?? 0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width *
                          Constants.eightyPercent,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width *
                                Constants.sixtyPercent,
                            child: !RegExp(regex).hasMatch(
                              conversations?[index].messageBody ?? '',
                            )
                                ? Text(
                                    conversations?[index].messageBody ?? '',
                                    overflow: TextOverflow.ellipsis,
                                  )
                                : Row(
                                    children: const [
                                      Icon(
                                        Icons.photo_camera_rounded,
                                        color: AppTheme.black3,
                                      ),
                                    ],
                                  ),
                          ),
                          if (!(conversations?[index].read ?? true))
                            const Chip(
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              label: Text(
                                "1",
                                style: TextStyle(
                                  color: AppTheme.grayArtic0main,
                                ),
                              ),
                              backgroundColor: AppTheme.coral0Main,
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ]),
            ),
          );
        },
      ),
    );
  }
}
