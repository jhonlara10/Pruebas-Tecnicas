import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class NeighborsView extends StatelessWidget {
  static const double _userImageSize = 32;
  static const double _divisionHorizontal = 8;
  static const double _fontsizeName = 14;
  const NeighborsView({
    Key? key,
    required this.neighborsList,
    required this.goToConversation,
  }) : super(key: key);

  final List<NeighborsResponse>? neighborsList;
  final Function goToConversation;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: neighborsList?.length ?? 0,
      separatorBuilder: (BuildContext context, int index) {
        return const Divider(
          thickness: 1,
        );
      },
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: () => goToConversation(index, true),
          child: Card(
            elevation: 0,
            shape: const RoundedRectangleBorder(
              side: BorderSide(color: Colors.transparent),
            ),
            child: Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipOval(
                        child: NvImage(
                          isUserImage: true,
                          width: _userImageSize,
                          height: _userImageSize,
                          imageUrl: neighborsList?[index].photo,
                        ),
                      ),
                      const SizedBox(
                        width: _divisionHorizontal,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (neighborsList?[index].alias ?? ''),
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: _fontsizeName,
                            ),
                          ),
                          Text(
                            neighborsList?[index].servicePointName ?? '',
                            style: const TextStyle(
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
