import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class SecurityView extends StatelessWidget {
  static const double _userImageSize = 32;
  static const double _divisionHorizontal = 8;
  static const double _fontsizeName = 14;
  const SecurityView({
    Key? key,
    required this.securityList,
    required this.goToConversation,
  }) : super(key: key);

  final List<NeighborsResponse>? securityList;
  final Function goToConversation;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: securityList?.length ?? 0,
      separatorBuilder: (BuildContext context, int index) {
        return const Divider(
          thickness: 1,
        );
      },
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: () => goToConversation(index, false),
          child: Card(
            elevation: 0,
            shape: const RoundedRectangleBorder(
              side: BorderSide(color: Colors.transparent),
            ),
            child: Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ClipOval(
                        child: NvImage(
                          isUserImage: true,
                          width: _userImageSize,
                          height: _userImageSize,
                          imageUrl: securityList?[index].photo,
                        ),
                      ),
                      const SizedBox(
                        width: _divisionHorizontal,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (securityList?[index].name ?? ''),
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: _fontsizeName,
                            ),
                          ),
                          const Text(
                            "vigilante",
                            style: TextStyle(
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const IconButton(
                    onPressed: null, // TODO call.
                    icon: Icon(
                      Icons.phone,
                      color: AppTheme.greenArlequin4,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
