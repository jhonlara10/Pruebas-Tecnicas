import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class EmptyMsgList extends StatelessWidget {
  const EmptyMsgList({
    Key? key,
    required double emptyImageHeight,
  })  : _emptyImageHeight = emptyImageHeight,
        super(key: key);

  final double _emptyImageHeight;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          NvImage(
            width: MediaQuery.of(context).size.width * Constants.fiftyPercent,
            height: _emptyImageHeight,
            imageUrl: 'ds/illustrations/dove.png',
          ),
          const SizedBox(
            height: 44,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                //"Todavía no tienes conversaciones.",
                AppMessages().getCopy('messages.new-msg'),
              ),
              Container(
                padding: const EdgeInsets.only(top: 16),
                width:
                    MediaQuery.of(context).size.width * Constants.fourtyPercent,
                child: NvButton(
                  //"Nuevo mensaje",
                  label: AppMessages().getCopy('messages.new-msg'),
                  action: () => Navigator.pushNamed(context, 'addMessage'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
