import 'package:flutter/material.dart';

import '../../../domain/models/settings/country.dart';

/// Widget class to populate ListView rows of country.
///
/// This Widget have:
/// [Text] to put country name.
/// [Image] to display country image.
///
/// Constructor params:
/// [Country] object with info of country name and code.
/// [Function] callback of click listener of row to handle on UI.
///
class RowCountry extends StatelessWidget {
  final Country country;
  final Function getSettingsByCountry;

  const RowCountry({
    Key? key,
    required this.country,
    required this.getSettingsByCountry,
  }) : super(key: key);

  /// Obtain correct flag to display on Row.
  ///
  /// Param
  /// [String] country name.
  ///
  /// Returns:
  /// [String] asset name of country flag.
  getCorrectImageByCountry(String country) {
    if (country.toLowerCase().contains("col")) {
      return 'assets/images/co.png';
    } else {
      return 'assets/images/mx.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => getSettingsByCountry(country.code ?? "", country.id),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          elevation: 5,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: Image.asset(
                getCorrectImageByCountry(country.name ?? ""),
                height: 30,
                width: 30,
              ),
              title: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  //ignore: avoid-non-null-assertion
                  country.name!,
                  style: const TextStyle(
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.normal,
                    color: Colors.black,
                  ),
                ),
              ),
              trailing: Image.asset("assets/images/chevron.png"),
            ),
          ),
        ),
      ),
    );
  }
}
