import 'dart:async';
import 'dart:ffi';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:neivor_flutter_app/domain/models/settings/setting.dart';
import 'package:neivor_flutter_app/presentation/geolocation/widgets/row_country.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/repository/country/countries_repository_impl.dart';
import '../../domain/models/settings/country.dart';

void main() {
  runApp(const Geolocation());
}

class Geolocation extends StatefulWidget {
  const Geolocation({
    Key? key,
  }) : super(key: key);

  @override
  State<Geolocation> createState() => _GeolocationState();
}

class _GeolocationState extends State<Geolocation> {
  final repository = CountryRepository();

  List<Country>? countryList;
  List<Setting>? settingsList;
  bool? isTest = false;
  var header = "";
  int pressed = 0;

  @override
  void initState() {
    getCountries();
    getCopies();
    if (kDebugMode) {
      getCurrentEnviroment();
    }
    super.initState();
  }

  getCurrentEnviroment() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      isTest = sharedPreferences.getBool("isTest");
    });
  }

  /// Method to call API repository and obtain country list, after the list is
  /// fetched will be displayed on ListView when setState is called.
  getCountries() async {
    countryList = await repository.getCountries();
    // ignore: no-empty-block
    setState(() {});
  }

  /// Get copy of screen by key, the message will be obtained of AppMessages factory.
  getCopies() async {
    header = await AppMessages().getMessage("index.geolocation-activation");
    // ignore: no-empty-block
    setState(() {});
  }

  /// Method to call API repository and obtain settings list, after the list is
  /// fetched will be stored on database and then will navigate to login screen.
  ///
  /// Param:
  /// [String] countryCode to be appended on URL.
  ///
  getSettingsByCountry(String countryCode, int countryId) async {
    await repository.getSettingsByCountry(
      countryCode,
      countryId,
    );
    await GlobalUtils().getBaseCdn();
    // ignore: use_build_context_synchronously
    Navigator.pushNamed(context, 'selectLogin');
  }

  appCloser() {
    pressed += 1;
    Timer(const Duration(seconds: 4), () {
      pressed = 0;
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Press Back button again to Exit"),
    ));
    if (pressed == 2) {
      if (Platform.isAndroid) {
        SystemNavigator.pop();
      } else {
        exit(0);
      }
    }
    return Future.value(false);
  }

  changeEnviroment(bool isTestEnviroment) async {
    var sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setBool("isTest", isTestEnviroment);
    // ignore: use_build_context_synchronously
    Navigator.of(context).pushNamedAndRemoveUntil(
      'geolocation',
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => appCloser(),
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 20,
                  bottom: 20,
                  right: 20,
                  top: 120,
                ),
                child: NvText(
                  textHolder: header,
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  color: Colors.black,
                ),
              ),
            ),
            ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: countryList?.length ?? 0,
              itemBuilder: (context, index) {
                return RowCountry(
                  //ignore: avoid-non-null-assertion
                  country: countryList![index],
                  getSettingsByCountry: getSettingsByCountry,
                );
              },
            ),
            if (kDebugMode) ...[
              GestureDetector(
                onTap: () => changeEnviroment(
                  isTest == true ? false : true,
                ),
                child: Padding(
                  padding: const EdgeInsets.only(top: 20, bottom: 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.published_with_changes,
                        size: 40,
                        color: Colors.black,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          isTest == false || isTest == null
                              ? "Cambiar a Test"
                              : "Cambiar a producción",
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ]),
        ),
      ),
    );
  }
}
