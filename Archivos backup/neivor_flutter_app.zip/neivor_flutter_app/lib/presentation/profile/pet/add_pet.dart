import 'dart:async';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/pets/pets.dart';
import 'package:neivor_flutter_app/data/repository/pets/pets_repository_impl.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/pet_selector.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class AddPet extends StatefulWidget {
  const AddPet({
    Key? key,
  }) : super(key: key);

  @override
  State<AddPet> createState() => _AddPetState();
}

class _AddPetState extends State<AddPet> {
  Function copy = AppMessages().getCopy;
  final petFormKey = GlobalKey<FormState>();
  Map<String, dynamic> formValues = {};
  PetsResponse? args;
  bool isDogSelected = false;
  bool isCatSelected = false;
  bool isBirdSelected = false;

  User? currentProfileUser = UserUtils.currentUser;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      // ignore: no-empty-block
      setState(() {});
      defineFormValues();
    });
  }

  // This funcion set values to form, if de accion is edit a pet,
  // if the accion is add Pet de form dosent have values.
  // ignore: long-method
  defineFormValues() {
    if (ModalRoute.of(context)?.settings.arguments != null) {
      args = ModalRoute.of(context)?.settings.arguments as PetsResponse;
      formValues = {
        'name': args?.name,
        'idServicePoint': UserUtils.currentServicePoint?.id,
        'idPetType': args?.idPetType,
        'userCreation': UserUtils.currentEnterprise?.id,
      };
      setTypePet(args?.idPetType);
    } else {
      formValues = {
        'name': "",
        'idServicePoint': UserUtils.currentServicePoint?.id,
        'idPetType': "",
        'userCreation': UserUtils.currentEnterprise?.id,
      };
    }
  }

  // This function selects the type of pet in the interface
  // when the action is to edit.
  setTypePet(int? id) {
    if (id == 1) {
      selectCat();
    } else if (id == 2) {
      selectDog();
    } else if (id == 3) {
      selectBird();
    }
  }

  /// If the dog is selected, then the formValues['idPetType']
  /// is set to 2, otherwise it is set to null
  selectDog() {
    setState(() {
      isDogSelected = !isDogSelected;
      isCatSelected = false;
      isBirdSelected = false;
      isDogSelected
          ? formValues['idPetType'] = 2
          : formValues['idPetType'] = null;
    });
  }

  /// If the cat is selected, then the formValues['idPetType']
  /// is set to 1, otherwise it is set to null
  selectCat() {
    setState(() {
      isCatSelected = !isCatSelected;
      isDogSelected = false;
      isBirdSelected = false;
      isCatSelected
          ? formValues['idPetType'] = 1
          : formValues['idPetType'] = null;
    });
  }

  /// If the bird is selected, then the formValues['idPetType']
  /// is set to 3, otherwise it is set to null
  selectBird() {
    setState(() {
      isBirdSelected = !isBirdSelected;
      isDogSelected = false;
      isCatSelected = false;
      isBirdSelected
          ? formValues['idPetType'] = 3
          : formValues['idPetType'] = null;
    });
  }

  /// It makes update the of pet and add values [id, userChange] to data of pet
  /// for send in the argument
  ///
  ///Returns: A Future
  setUpdatePet() async {
    formValues.addAll({
      "id": args?.id,
      "userChange": currentProfileUser?.id,
    });
    context.loaderOverlay.show();
    await updatePet(formValues).then((value) => {
          context.loaderOverlay.hide(),
          showDialog(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              Timer(const Duration(seconds: 2), () {
                Navigator.of(context).pop();
              });
              return AlertDialog(
                content: (value.sucessRequest ?? false)
                    ? Text(
                        copy(
                          'profile.pet-updated-success',
                        ), //"Se actualizo la mascota con exito",
                        textAlign: TextAlign.center,
                      )
                    : Text(
                        (value.message ??
                            copy(
                              'profile.error-updating-pet',
                            )), //"Ocurrio un error al actualizar la mascota",
                        textAlign: TextAlign.center,
                      ),
                title: const Icon(
                  Icons.check_circle_outline_rounded,
                  size: 88,
                  color: Colors.green,
                ),
              );
            },
          ).then(
            (value) => Navigator.pushNamed(context, 'profile'),
          ),
        });
  }

  /// It makes insert the of pet, takes data of form
  /// for send in the argument
  ///
  ///Returns: A Future
  setInsertPet() async {
    context.loaderOverlay.show();
    await addPet(formValues).then((value) => {
          context.loaderOverlay.hide(),
          showDialog(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              Timer(const Duration(seconds: 2), () {
                Navigator.of(context).pop();
              });
              return AlertDialog(
                content: (value.sucessRequest ?? false)
                    ? Text(
                        //"Se registró la mascota con exito",
                        copy('profile.pet-registered-successfully'),
                        textAlign: TextAlign.center,
                      )
                    : Text(
                        (value.message ??
                            //"Ocurrio un error al registrar la mascota"),
                            copy('profile.pet-registered-error')),
                        textAlign: TextAlign.center,
                      ),
                title: const Icon(
                  Icons.check_circle_outline_rounded,
                  size: 88,
                  color: Colors.green,
                ),
              );
            },
          ).then((value) => Navigator.pushNamed(context, 'profile')),
        });
  }

  /// If the form is valid, and the user has selected a pet type,
  /// then send the data to the server, depending on the action
  /// to do (update pet or register pet)
  ///
  /// Args: [typeOfRequest] type int 1: for update pet 2: fot insert pet
  // ignore: long-method
  sendDataPet(typeOfRequest) {
    if ((petFormKey.currentState?.validate() ?? false)) {
      if (!isBirdSelected && !isDogSelected && !isCatSelected) {
        showDialog(
          barrierDismissible: false,
          //ignore: avoid-non-null-assertion
          context: petFormKey.currentContext!,
          builder: (context) {
            Timer(const Duration(seconds: 3), () {
              Navigator.of(context).pop();
            });
            return AlertDialog(
              content: Text(
                //"Debe Seleccionar el tipo de mascota",
                copy('profile.pet-type-select'),
                textAlign: TextAlign.center,
              ),
              title: const Icon(
                Icons.warning,
                size: 88,
                color: Colors.amber,
              ),
            );
          },
        );
      } else {
        typeOfRequest == 2 ? setInsertPet() : setUpdatePet();
      }
    }
  }

  /// It Makes Delete request, delete a register of pet
  /// Args: data (Map<String, dynamic>): data of pet [id,userChange].
  ///
  ///Returns: A Future
  callDeletePet() async {
    Map<String, dynamic> request = {
      "id": args?.id,
      "userChange": currentProfileUser?.id,
    };

    await deletePet(request).then((value) {
      Navigator.pop(context);
      Navigator.pushReplacementNamed(context, "profile");
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    TextEditingController controller = TextEditingController();

    controller.text = formValues['name'] ?? '';
    controller.selection = TextSelection.fromPosition(
      TextPosition(offset: controller.text.length),
    );

    TextEditingController petNameInput = TextEditingController();
    petNameInput.text = formValues['name'] ?? '';
    petNameInput.selection = TextSelection.fromPosition(
      TextPosition(offset: petNameInput.text.length),
    );

    TextStyle labelStyle = TextStyle(
      color: colors.primary.black.v4,
      fontWeight: FontWeight.w400,
      fontSize: 12,
    );
    return Scaffold(
      appBar: NvAppBar(
        title: null,
        elevation: 0,
        backAction: () => Navigator.pushReplacementNamed(context, "profile"),
        actions: args != null
            ? [
                GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return NvAlert(
                          //"¿Estás seguro de eliminar esta mascota?",
                          content: copy('profile.pet-confirm-delete'),
                          cancelFn: () {
                            Navigator.pop(context);
                          },
                          acceptFn: () {
                            callDeletePet();
                          },
                          type: "warning",
                        );
                      },
                    );
                  },
                  child: const Padding(
                    padding: EdgeInsets.only(right: 16),
                    child: NvImage(
                      imageUrl: 'ds/icons/delete-trash-green.svg',
                    ),
                  ),
                ),
              ]
            : null,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 16, right: 16),
          child: Form(
            key: petFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          //"Cuéntanos más sobre tu mascota",
                          copy('profile.tell-more-about-pet'),
                          style: TextStyle(
                            color: colors.primary.black.main,
                            fontWeight: FontWeight.w600,
                            fontSize: 18,
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.8,
                          child: Text(
                            //'Esta información es valiosa para que podamos mejorar los espacios para animales',
                            copy('profile.tell-more-description'),
                            style: TextStyle(
                              color: colors.primary.black.v4,
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                            ),
                            overflow: TextOverflow.clip,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 34),
                  child: Row(
                    children: [
                      Text(
                        //"ANIMAL",
                        copy('profile.animal'),
                        style: labelStyle,
                      ),
                    ],
                  ),
                ),
                PetSelector(
                  dogSelector: selectDog,
                  isDogSelected: isDogSelected,
                  isCatSelected: isCatSelected,
                  catSelector: selectCat,
                  birdSelector: selectBird,
                  isBirdSelected: isBirdSelected,
                ),
                Text(
                  //"NOMBRE",
                  copy('profile.name').toUpperCase(),
                  style: labelStyle,
                ),
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 50.0),
                      child: TextFormField(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return copy('common.validator-required');
                          }
                          return null;
                        },
                        controller: petNameInput,
                        onChanged: (value) {
                          formValues['name'] = value;
                        },
                      ),
                    ),
                    NvButton(
                      label: args != null
                          ? copy('profile.edit-pet-label') //"Modificar mascota"
                          : copy('profile.add-pet-label'), //"Agregar mascota",
                      action: () {
                        args != null ? sendDataPet(1) : sendDataPet(2);
                      },
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
