import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/emergency/emergency_bloc.dart';
import 'package:neivor_flutter_app/bloc/emergency/relationship_bloc.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/widgets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/data/repository/emergency/emergency_repository_impl.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:url_launcher/url_launcher.dart';

class EmergencyContact extends StatefulWidget {
  const EmergencyContact({Key? key}) : super(key: key);

  @override
  State<EmergencyContact> createState() => _EmergencyContactState();
}

class _EmergencyContactState extends State<EmergencyContact> {
  Function copy = AppMessages().getCopy;
  List<EmergencyData>? contacts;
  List<Relationship>? relationships;
  User? currentProfileUser = UserUtils.currentUser;
  @override
  void initState() {
    (() async {
      context.loaderOverlay.show();
      await getContactData();
      context.loaderOverlay.hide();
    })();
    super.initState();
  }

  /// Get emergency contact data and relationship data.
  getContactData() async {
    await getEmergency(
      (UserUtils.currentServicePoint?.id ?? 0),
      context,
    );
    if (!mounted) return;
    await getRelationship(context);
    if (!mounted) return;
    contacts = BlocProvider.of<EmergencyBloc>(context).state.emergencyData;
    // ignore: no-empty-block
    setState(() {});
  }

  /// It takes an id and returns the name of the relationship that has that id
  ///
  /// Args:
  ///   id: The id of the relationship
  ///
  /// Returns:
  ///   A string.
  String? getRelationshipName(id) {
    for (var element
        in BlocProvider.of<RelationshipBloc>(context).state.relationsList ??
            []) {
      if (element.id == id) {
        return element.name;
      }
    }
    return '';
  }

  /// It takes a phone number as a parameter, formats it, and then launches whatsapp
  ///
  /// Args:
  ///   phoneNumber (String): The phone number of the person you want to send the message to.
  void sendWhatsapp(String phoneNumber) async {
    final String url =
        "https://api.whatsapp.com/send?phone=${phoneNumber.replaceFirst("+", "")}";
    // ignore: deprecated_member_use
    if (!await launch(url)) throw 'Could not launch $url';
  }

  /// It takes a contact object and navigates to the addEmergency page, passing the contact object as an
  /// argument
  ///
  /// Args:
  ///   contact (EmergencyData): The contact object that is passed to the edit screen.
  goToEdit(EmergencyData contact) {
    Navigator.pushNamed(context, 'addEmergency', arguments: contact);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pushReplacementNamed(context, "profile"),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                //"Contactos de emergencia",
                copy('profile.emergency-contact'),
                style: AppThemeScope.of(context).typography.h2.semibold,
              ),
              const SizedBox(
                height: 24,
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Row(
                  children: [
                    Text(
                      "${contacts?.length.toString() ?? "0"} ${copy('profile.emergency-contact')}",
                      style: AppThemeScope.of(context).typography.bd1.light,
                    ),
                  ],
                ),
              ),
              EmergencyCards(
                contacts: contacts,
                sendWhatsapp: sendWhatsapp,
                getRelationshipName: getRelationshipName,
                goToEdit: goToEdit,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar:
          (contacts?.length != 4) && UserUtils().hasPermissionsTo(846)
              ? Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
                  child: NvButton(
                    label: copy('profile.add-contact'), //"Agregar contacto",
                    action: () {
                      Navigator.pushNamed(context, 'addEmergency');
                    },
                  ),
                )
              : null,
    );
  }
}
