import 'dart:async';
import 'dart:developer';

import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/emergency/relationship_bloc.dart';
import 'package:neivor_flutter_app/data/repository/emergency/emergency_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/widgets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/countries_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class AddEmergency extends StatefulWidget {
  const AddEmergency({Key? key}) : super(key: key);

  @override
  State<AddEmergency> createState() => _AddEmergencyState();
}

class _AddEmergencyState extends State<AddEmergency> {
  Function copy = AppMessages().getCopy;
  String? countryCode = "+57";
  Map<String, dynamic>? formValues;
  User? currentProfileUser = UserUtils.currentUser;

  /// A key that is used to identify the Form widget and allow us to interact with it.
  final profileFormKey = GlobalKey<FormState>();

  /// Creating a list of DropdownMenuItem objects.
  List<DropdownMenuItem<String>> relationshipItems = [];
  EmergencyData? args;
  TextEditingController phoneController = TextEditingController();

  @override
  // ignore: long-method
  void initState() {
    if (BlocProvider.of<RelationshipBloc>(
              context,
            ).state.relationsList !=
            null &&
        (BlocProvider.of<RelationshipBloc>(
              context,
            ).state.relationsList?.isNotEmpty ??
            false)) {
      getRelationshipItems();
    }
    super.initState();

    setDefaultFormValues();

    /// Waiting for the widget to be built and then use the context to get the arguments.
    //ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        if (ModalRoute.of(context)?.settings.arguments != null) {
          args = ModalRoute.of(context)?.settings.arguments as EmergencyData;
          formValues?['name'] = args?.name;
          formValues?['email'] = args?.email;
          formValues?['idRelationship'] = args?.idRelationship;
          formValues?['id'] = args?.id;
          setPhoneNumber();
          setIsoCode();
        } else {
          phoneController.text = formValues?['phoneOne'];
        }
      });
    });
  }

  setPhoneNumber() async {
    try {
      phoneController.text =
          await CountriesUtils().gePhoneWithoutCode(args?.phoneOne ?? '');
    } catch (e) {
      phoneController.text = "";
    }
  }

  setIsoCode() async {
    try {
      formValues?['isoCode'] =
          await CountriesUtils().getCountryISOToPhone(args?.phoneOne ?? '');
    } catch (e) {
      formValues?['isoCode'] = "";
    }
  }

  setDefaultFormValues() {
    formValues = {
      'userCreation': currentProfileUser?.id,
      'name': '',
      'idRelationship': '',
      'phoneOne': '',
      'idServicePoint': UserUtils.currentServicePoint?.id,
      'idEnterprise': UserUtils.currentEnterprise?.id,
      'email': '',
      'isoCode': '',
    };
  }

  /// It takes the list of relationships from the bloc and adds them to a list of dropdown menu items.
  getRelationshipItems() {
    BlocProvider.of<RelationshipBloc>(
      context,
    ).state.relationsList?.forEach((element) {
      relationshipItems.add(DropdownMenuItem(
        value: element.id.toString(),
        child: Text(element.name ?? ''),
      ));
    });

    // ignore: no-empty-block
    setState(() {});
  }

  /// Shows a warning dialog with 3 sec autoclose.
  emptyCountryDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "warning",
          //"Debe ingresar un codigo de pais",
          content: copy('profile.type-country-code'),
        );
      },
    );
  }

  /// validate the form and try to create a contact and if the contact is created successfully, show a dialog
  /// and then navigate to profile view
  // ignore: long-method
  submitData() async {
    if ((profileFormKey.currentState?.validate() ?? false)) {
      if (countryCode == null || (countryCode?.isEmpty ?? true)) {
        emptyCountryDialog();
      } else {
        formValues?['phoneOne'] =
            (countryCode ?? '') + phoneController.text.replaceAll(" ", "");
        if (args != null) {
          var edit = await editEmergencyContact((formValues ?? {}));
          if (edit.sucessRequest ?? false) {
            showSuccessDialog();
          }
        } else {
          var creation = await createEmergencyContact((formValues ?? {}));
          log(creation.toJson().toString());
          if (creation.sucessRequest ?? false) {
            showSuccessDialog();
          }
        }
      }
    }
  }

  /// Shows a success dialog with 3 sec autoclose.
  // ignore: long-method
  showSuccessDialog() {
    Timer? timer;
    // ignore: prefer-async-await
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        timer = Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        String param =
            args != null ? copy('profile.edited') : copy('profile.created');
        return NvAlert(
          type: "success",
          //"Contacto {0} con exito",
          content: copy('profile.contact-x-successfully', [param]),
        );
      },
    ).then((value) {
      timer?.cancel();
      Navigator.pushReplacementNamed(context, 'emergency');
    });
  }

  /// It takes an id and a userChange value, and then deletes the emergency contact with the given id.
  deleteEmergencyContact() async {
    Map<String, dynamic> request = {
      "id": args?.id,
      "userChange": currentProfileUser?.id,
    };
    await deleteEmergency(request);
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, "emergency");
  }

  /// It shows a dialog with a "acept" and "cancel" option
  /// if accept is clicked then deletes the current emergency contact
  /// otherwise the dialog is closed
  confirmDelete() {
    showDialog(
      context: context,
      builder: (context) {
        return NvAlert(
          type: "warning",
          cancelFn: () => Navigator.pop(context),
          acceptFn: () {
            Navigator.pop(context);
            deleteEmergencyContact();
          },
          //"¿Estás seguro de eliminar este contacto?",
          content: copy('profile.sure-delete-contact'),
        );
      },
    );
  }

  get getInitialValue {
    if (args != null) {
      int receibedRelation = relationshipItems.indexWhere(
        (element) => element.value == args?.idRelationship.toString(),
      );
      return relationshipItems[receibedRelation].value;
    }
  }

  @override
  Widget build(BuildContext context) {
    TextEditingController mailInput = TextEditingController();
    mailInput.text = formValues?['email'];
    mailInput.selection = TextSelection.fromPosition(
      TextPosition(offset: mailInput.text.length),
    );

    return Scaffold(
      appBar: NvAppBar(
        elevation: 0,
        backAction: () => Navigator.pushReplacementNamed(context, 'emergency'),
        actions: args != null
            ? [
                GestureDetector(
                  onTap: () {
                    confirmDelete();
                  },
                  child: const Padding(
                    padding: EdgeInsets.only(right: 16),
                    child: NvImage(
                      imageUrl: 'ds/icons/delete-trash-green.svg',
                      color: AppTheme.black4,
                    ),
                  ),
                ),
              ]
            : null,
      ),
      body: CustomScrollView(
        slivers: [
          SliverFillRemaining(
            hasScrollBody: false,
            child: Form(
              key: profileFormKey,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 31, 16, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      //"Agrega un nuevo contacto de emergencia",
                      copy('profile.add-new-contact'),
                      style: AppThemeScope.of(context).typography.h2.semibold,
                    ),
                    Text(
                      //"Lo usaremos en caso de que ocurra una emergencia y no te podamos contactar",
                      copy('profile.add-new-contact-description'),
                      style: AppThemeScope.of(context).typography.bd1.light,
                    ),
                    EmergencyCustomInput(
                      obligatory: true,
                      formValues: (formValues ?? {}),
                      optionName: "name",
                      controller: TextEditingController(
                        text: formValues?['name'],
                      ),
                      //'Nombre',
                      label: copy('profile.name'),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          "*",
                          style: AppThemeScope.of(context)
                              .typography
                              .bd1
                              .medium
                              .copyWith(
                                color: AppThemeScope.of(context)
                                    .colors
                                    .primary
                                    .coral
                                    .main,
                              ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 16, bottom: 0),
                          child: Text(
                            //"Parentesco",
                            copy('profile.relationship2'),
                            style:
                                AppThemeScope.of(context).typography.bd1.medium,
                          ),
                        ),
                      ],
                    ),
                    DropdownButtonFormField(
                      value: getInitialValue,
                      // ignore: prefer-extracting-callbacks
                      validator: (value) {
                        if (value == null) {
                          //'Obligatorio';
                          return copy('visitors.validator-required');
                        }
                        return null;
                      },
                      isDense: true,
                      decoration: const InputDecoration(
                        contentPadding: EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 5,
                        ),
                      ),
                      menuMaxHeight: MediaQuery.of(context).size.height *
                          Constants.thirtyPercent,
                      isExpanded: true,
                      items: relationshipItems,
                      onChanged: (value) {
                        formValues?['idRelationship'] = value;
                      },
                    ),
                    Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "*",
                              style: AppThemeScope.of(context)
                                  .typography
                                  .bd1
                                  .medium
                                  .copyWith(
                                    color: AppThemeScope.of(context)
                                        .colors
                                        .primary
                                        .coral
                                        .main,
                                  ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 16),
                              child: Text(
                                //"Celular",
                                copy('profile.cellphone'),
                                style: AppThemeScope.of(context)
                                    .typography
                                    .bd1
                                    .medium,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            CountryCodePicker(
                              onChanged: (value) {
                                countryCode = value.dialCode;
                              },
                              countryFilter: const [
                                'CO',
                                'MX',
                                'US',
                                'EC',
                                'BOL',
                              ],
                              initialSelection: formValues?['isoCode'],
                              showCountryOnly: false,
                              showOnlyCountryWhenClosed: false,
                              alignLeft: false,
                              showDropDownButton: true,
                              enabled: true,
                              hideSearch: true,
                              dialogSize: Size(
                                (MediaQuery.of(context).size.width *
                                    Constants.fiftyPercent),
                                //ignore: no-equal-arguments
                                (MediaQuery.of(context).size.width *
                                    Constants.fiftyPercent),
                              ),
                            ),
                            Expanded(
                              child: TextFormField(
                                inputFormatters: [
                                  FilteringTextInputFormatter.digitsOnly,
                                ],
                                maxLength: 11,
                                // ignore: prefer-extracting-callbacks
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    //'Obligatorio';
                                    return copy('visitors.validator-required');
                                  }
                                  return null;
                                },
                                onChanged: (value) {
                                  formValues?['phoneOne'] = value;
                                },
                                controller: phoneController,
                                keyboardType: TextInputType.phone,
                                decoration: const InputDecoration(
                                  counter: SizedBox(),
                                  isDense: true,
                                  contentPadding: EdgeInsets.symmetric(
                                    vertical: 7,
                                    horizontal: 5,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const SizedBox(
                          width: 6,
                        ),
                        Text(
                          //"Correo",
                          copy('profile.email'),
                          style:
                              AppThemeScope.of(context).typography.bd1.medium,
                        ),
                      ],
                    ),
                    TextFormField(
                      // ignore: prefer-extracting-callbacks
                      validator: (value) {
                        if ((value?.isNotEmpty ?? false)) {
                          return !RegExp(Constants.emailRegex)
                                  .hasMatch(value ?? '')
                              ? copy(
                                  //"El email no es válido"
                                  'profile.invalid-mail',
                                )
                              : null;
                        }
                        return null;
                      },
                      onChanged: (value) {
                        formValues?['email'] = value;
                      },
                      controller: mailInput,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        isDense: true,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 7, horizontal: 5),
                      ),
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(0, 16, 0, 16),
                          child: NvButton(
                            label: args != null
                                ? copy(
                                    'profile.edit-contact',
                                  ) //"Editar contacto"
                                : copy(
                                    'profile.add-contact',
                                  ), //'Agregar contacto',
                            action: submitData,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
