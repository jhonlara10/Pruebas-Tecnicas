import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/pets/pets_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/profile/profile_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/vehicles/vehicles_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/parking/parking_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/pets/pets.dart';
import 'package:neivor_flutter_app/domain/models/profile/profile.dart';
import 'package:neivor_flutter_app/domain/models/vehicles/vehicles.dart';
import 'package:neivor_flutter_app/domain/models/parking/parking.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/settings_wg.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/parkings_wg.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/pets_wg.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'widgets/widgets.dart';

class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  List<VehiclesResponse>? vehiclesList;
  List<ParkingResponse>? parkingsList;
  List<PetsResponse>? petsList;
  ProfileData? profileData;
  User? currentProfileUser = UserUtils.currentUser;

  @override
  void initState() {
    loadProfileData();
    getPetsList();
    getVehiclesList();
    getParkingsList();

    super.initState();
  }

  /// "Load the profile data from the server and update the UI when it's done."
  ///
  /// The function is called from the `initState()` function
  loadProfileData() async {
    try {
      context.loaderOverlay.show();
      profileData = await getProfile(
        (UserUtils.currentUser?.id ?? 0),
        (UserUtils.currentEnterprise?.id ?? 0),
        (UserUtils.currentServicePoint?.id ?? 0),
      );
      // ignore: no-empty-block
      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  /// It gets list if pets from database and sets state of the widget.
  getPetsList() async {
    try {
      petsList = await getPets(
        UserUtils.currentServicePoint?.id ?? 0,
      );
    } catch (e) {
      log(e.toString());
    }
    // ignore: no-empty-block
    setState(() {});
  }

  /// It gets the list of vehicles from the database and sets the state of the widget.
  getVehiclesList() async {
    try {
      vehiclesList = await getVehicles(
        UserUtils.currentServicePoint?.id ?? 0,
      );
    } catch (e) {
      log(e.toString());
    }
    // ignore: no-empty-block
    setState(() {});
  }

  /// It gets list if pakings from database and sets state of the widget.
  getParkingsList() async {
    try {
      parkingsList = await getParkings(
        UserUtils.currentServicePoint?.id ?? 0,
      );
      context.loaderOverlay.hide();
    } catch (e) {
      log(e.toString());
    }
    // ignore: no-empty-block
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          elevation: 0,
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 16, right: 16),
            child: Column(
              children: [
                CustomCircleAvatar(
                  currentProfileName: profileData?.name,
                ),
                UserNameContainer(
                  name: profileData?.alias ?? profileData?.name,
                  email: profileData?.email,
                ),
                const SizedBox(
                  height: 8,
                ),
                const AccountWG(),
                PetsWG(
                  petsList: petsList ?? [],
                ),
                VehiclesWG(
                  vehiclesList: vehiclesList ?? [],
                ),
                ParkingsWG(
                  parkingList: parkingsList ?? [],
                ),
                const SettingsWG(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
