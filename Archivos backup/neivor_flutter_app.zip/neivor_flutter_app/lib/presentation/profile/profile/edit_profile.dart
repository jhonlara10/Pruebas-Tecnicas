import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:typed_data';

import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/profile/profile_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/profile/profile.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/widgets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/countries_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);
  static const int _countryCodeLong2 = 2;
  static const int _countryCodeLong3 = 3;
  static const int _countryCodeLong4 = 4;
  static const int _phoneTotalLong12 = 12;
  static const int _phoneTotalLong13 = 13;
  static const int _phoneTotalLong14 = 14;
  static const int _nameLenght = 30;
  static const int _phoneLenght = 20;
  static const int _ocupationLenght = 50;
  static const double _backgroundOpacity = 0.2;

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  Function copy = AppMessages().getCopy;

  /// Creating an instance of the ImagePicker class.
  final ImagePicker _picker = ImagePicker();
  ProfileData? profileData;
  XFile? image;
  String? imgAsBase64;
  bool isEditActive = false;
  String? countryCode;
  final profileFormKey = GlobalKey<FormState>();
  bool isPhoneInvalid = false;
  Map<String, dynamic> formValues = {
    'alias': '',
    'name': '',
    'mobilePhone': '',
    'email': '',
    'ocupation': '',
    'role': "",
    'documentNumber': '',
    'id': "",
    'userChange': '',
    'isoCode': '',
  };
  TextEditingController phoneController = TextEditingController();

  @override
  void initState() {
    (() async {
      context.loaderOverlay.show();
      await loadProfileData();
      context.loaderOverlay.hide();
    })();
    super.initState();
  }

  @override
  void dispose() {
    phoneController.dispose();
    super.dispose();
  }

  /// It loads profile data from an API and then sets the form values to the data retrieved from the API.
  // ignore: long-method
  loadProfileData() async {
    try {
      profileData = await getProfile(
        (UserUtils.currentUser?.id ?? 0),
        (UserUtils.currentEnterprise?.id ?? 0),
        (UserUtils.currentServicePoint?.id ?? 0),
      );
      formValues = {
        'alias': profileData?.alias ?? '',
        'name': profileData?.name ?? '',
        'mobilePhone': profileData?.mobilePhone ?? '',
        'email': profileData?.email ?? '',
        'ocupation': profileData?.ocupation ?? '',
        'role': UserUtils.currentZyosGroup?.name ?? '',
        'documentNumber': profileData?.documentNumber ?? '',
        'id': UserUtils.currentUser?.id,
        'userChange': UserUtils.currentUser?.id,
        'isoCode': await isoCode,
      };
      setState(() {
        phoneController.text = formatMobilePhone(
          formValues['mobilePhone'],
        );
      });
    } catch (e) {
      log(e.toString());
    }
  }

  get isoCode async {
    dynamic isoCode;
    try {
      isoCode = await CountriesUtils()
          .getCountryISOToPhone(UserUtils.currentUser?.mobilePhone ?? '');
      return isoCode;
    } catch (e) {
      return "";
    }
  }

  changeValidPhone() {
    isPhoneInvalid = !isPhoneInvalid;
    // ignore: no-empty-block
    setState(() {});
  }

  /// It picks an image from the gallery, converts it to base64, and uploads it to the server.
  // ignore: long-method
  pickImage() async {
    try {
      image = await _picker.pickImage(source: ImageSource.gallery);
      String base64img;
      if (image != null) {
        base64img = await imgToBase64();
        UpdatePhotoRequest data = UpdatePhotoRequest(
          id: UserUtils.currentUser?.id,
          idEnterprise: UserUtils.currentUser?.currentEnterprise?.id,
          photo: base64img,
          //ignore: no-equal-arguments
          userChange: UserUtils.currentUser?.id,
        );
        UpdatePhotoResponse updateResponse = await uploadPhoto(data);
        await updateCurrentUser(updateResponse.photo);
        await loadProfileData();
        // ignore: no-empty-block
        setState(() {});
      } else {
        missingPhotoAlert();
      }
    } catch (e) {
      log(e.toString());
    }
  }

  missingPhotoAlert() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "warning",
          //"No se a seleccionado una imagen",
          content: copy('profile.not-selected-image'),
        );
      },
    );
  }

  /// It takes the image path, reads the bytes, encodes the bytes to base64, and returns the base64
  /// encoded string
  ///
  /// Returns:
  ///   A Future&lt;String&gt;
  imgToBase64() async {
    final Uint8List bytes;
    if (image != null) {
      //ignore: avoid-non-null-assertion
      bytes = await File(image!.path).readAsBytes();
      String base64Encoded = base64Encode(bytes);
      String prefix =
          //ignore: avoid-non-null-assertion
          "data:image/${image!.path.substring(image!.path.length - 3)};base64,";
      return prefix + base64Encoded;
    }
  }

  /// The function is called when the user clicks on the edit button. It sets the isEditActive variable
  /// to true to allow for edition
  activateOptions() {
    isEditActive = true;
    // ignore: no-empty-block
    setState(() {});
  }

  wrongPhoneAlert() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "warning",
          content:
              //"El numero de telefono es incorrecto\ndebe contener 10 numeros",
              copy('profile.phone-number-must-10-caracteres'),
        );
      },
    );
  }

  /// concatenate the country code and phonenumber
  /// if country code is null shows a dialog
  /// validate the form and if is valid save profile data
  ///
  /// Returns:
  ///   a Future<void>
  // ignore: long-method
  saveData() async {
    try {
      FocusManager.instance.primaryFocus?.unfocus();
      if (profileFormKey.currentState?.validate() ?? false) {
        if (!isValidMobilePhone()) {
          wrongPhoneAlert();
        } else {
          UpdateProfileResponse response = await uploadProfile(formValues);
          if (response.successEditUser ?? false) {
            await updateCurrentUser(null);
          }
          showDialog(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              // ignore: prefer-extracting-callbacks
              Timer(const Duration(seconds: 3), () {
                Navigator.of(context).pop();
                if (response.successEditUser ?? false) {
                  Navigator.pushReplacementNamed(context, 'profile');
                }
              });
              return NvAlert(
                type: (response.successEditUser ?? false) ? "success" : "error",
                content: (response.successEditUser ?? false)
                    ? copy(
                        'profile.saved-successfully',
                      ) // "Datos guardados con éxito"
                    : response.message ??
                        copy(
                          'profile.error-saving-data',
                        ), //"Error al guardar los datos",
              );
            },
          );
        }
      }
    } catch (e) {
      log(e.toString());
    }
  }

  String formatMobilePhone(String number) {
    if (number.contains("+1")) {
      return number.substring(EditProfile._countryCodeLong2, number.length);
    } else if (number.contains("+57") || number.contains("+52")) {
      return number.substring(EditProfile._countryCodeLong3, number.length);
    } else if (number.contains("+593") || number.contains("+591")) {
      return number.substring(EditProfile._countryCodeLong4, number.length);
    } else {
      return "";
    }
  }

  // ignore: long-method
  bool isValidMobilePhone() {
    if (formValues['mobilePhone'].contains('+1')) {
      formValues['mobilePhone'] = formValues['mobilePhone'].substring(
        EditProfile._countryCodeLong2,
        formValues['mobilePhone'].length,
      );
      formValues['mobilePhone'] =
          (countryCode ?? '') + formValues['mobilePhone'];
    } else if (formValues['mobilePhone'].contains('+57') ||
        formValues['mobilePhone'].contains("+52")) {
      formValues['mobilePhone'] = formValues['mobilePhone'].substring(
        EditProfile._countryCodeLong3,
        formValues['mobilePhone'].length,
      );
      formValues['mobilePhone'] =
          (countryCode ?? '') + formValues['mobilePhone'];
    } else if (formValues['mobilePhone'].contains("+593") ||
        formValues['mobilePhone'].contains("+591")) {
      formValues['mobilePhone'] = formValues['mobilePhone'].substring(
        EditProfile._countryCodeLong4,
        formValues['mobilePhone'].length,
      );
      formValues['mobilePhone'] =
          (countryCode ?? '') + formValues['mobilePhone'];
    } else {
      formValues['mobilePhone'] =
          (countryCode ?? '') + formValues['mobilePhone'];
    }
    if (countryCode == "+57" || countryCode == "+52") {
      return formValues['mobilePhone'].length == EditProfile._phoneTotalLong13;
    } else if (countryCode == "+1") {
      return formValues['mobilePhone'].length == EditProfile._phoneTotalLong12;
    } else {
      return formValues['mobilePhone'].length == EditProfile._phoneTotalLong14;
    }
  }

  // ignore: long-method
  updateCurrentUser(String? photo) async {
    var sharePreferences = await SharedPreferences.getInstance();
    User newUser = User.fromJson(
      jsonDecode(sharePreferences.getString("currentUser") ?? ""),
    );
    newUser.alias = formValues["alias"];
    newUser.name = formValues["name"];
    newUser.mobilePhone = formValues["mobilePhone"];
    newUser.ocupation = formValues["ocupation"];
    newUser.documentNumber = formValues["documentNumber"];
    if (photo != null) {
      newUser.photo = photo;
    }
    await sharePreferences.setString(
      "currentUser",
      jsonEncode(newUser.toJson()),
    );
    await UserUtils().getCurrentUser();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'profile',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          title: copy('profile.personal-data2'), //"Datos personales",
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'profile',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(
                  children: [
                    PhotoContainer(
                      imagePicker: pickImage,
                      pickedImage: image,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
                      child: Form(
                        key: profileFormKey,
                        child: Column(
                          children: [
                            CustomTextInput(
                              activateOption: activateOptions,
                              editIcon: true,
                              labelName: copy('profile.alias')
                                  .toUpperCase(), //'ALIAS',
                              isNumeric: false,
                              isOptionActive: isEditActive,
                              profileData: profileData,
                              formValues: formValues,
                              controller: TextEditingController(
                                text: formValues['alias'],
                              ),
                              optionName: 'alias',
                              maxLength: EditProfile._nameLenght,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            CustomTextInput(
                              activateOption: activateOptions,
                              editIcon: false,
                              labelName: copy('profile.name')
                                  .toUpperCase(), //'NOMBRE',
                              isOptionActive: isEditActive,
                              profileData: profileData,
                              formValues: formValues,
                              controller: TextEditingController(
                                text: formValues['name'],
                              ),
                              isNumeric: false,
                              optionName: 'name',
                              maxLength: EditProfile._nameLenght,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 2),
                                  child: Text(
                                    copy('profile.cellphone')
                                        .toUpperCase(), //"CELULAR",
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: AppTheme.black4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CountryCodePicker(
                                  onInit: (value) {
                                    countryCode = value?.dialCode;
                                  },
                                  onChanged: (value) {
                                    countryCode = value.dialCode;
                                  },
                                  countryFilter: const [
                                    'CO',
                                    'MX',
                                    'US',
                                    'EC',
                                    'BO',
                                  ],
                                  initialSelection: formValues['isoCode'],
                                  showCountryOnly: false,
                                  showOnlyCountryWhenClosed: false,
                                  alignLeft: false,
                                  showDropDownButton: isEditActive,
                                  enabled: isEditActive,
                                  dialogSize: Size(
                                    (MediaQuery.of(context).size.width *
                                        Constants.eightyPercent),
                                    //ignore: no-equal-arguments
                                    (MediaQuery.of(context).size.width *
                                        Constants.eightyPercent),
                                  ),
                                ),
                                Expanded(
                                  child: CustomTextInput(
                                    isPhoneInvalid: isPhoneInvalid,
                                    changeValidPhone: changeValidPhone,
                                    activateOption: activateOptions,
                                    editIcon: false,
                                    labelName: null,
                                    isOptionActive: isEditActive,
                                    profileData: profileData,
                                    formValues: formValues,
                                    controller: phoneController,
                                    isNumeric: true,
                                    optionName: 'mobilePhone',
                                    maxLength: EditProfile._phoneLenght,
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 1),
                                  child: Text(
                                    copy('profile.email')
                                        .toUpperCase(), //"CORREO",
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: AppTheme.black4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 20, 16, 20),
                                  child: Text(profileData?.email ?? ''),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            CustomTextInput(
                              activateOption: activateOptions,
                              editIcon: false,
                              labelName: copy('profile.ocupation')
                                  .toUpperCase(), //'OCUPACIÓN',
                              isOptionActive: isEditActive,
                              profileData: profileData,
                              formValues: formValues,
                              controller: TextEditingController(
                                text: formValues['ocupation'],
                              ),
                              isNumeric: false,
                              optionName: 'ocupation',
                              maxLength: EditProfile._ocupationLenght,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 1),
                                  child: Text(
                                    copy('profile.role').toUpperCase(), //"ROL",
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: AppTheme.black4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Chip(
                                  backgroundColor:
                                      AppTheme.greenArlequin0main.withOpacity(
                                    EditProfile._backgroundOpacity,
                                  ),
                                  label: Text(
                                    (formValues['role'].toString()),
                                    style: const TextStyle(
                                      color: AppTheme.greenArlequin0main,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            CustomTextInput(
                              activateOption: activateOptions,
                              editIcon: false,
                              labelName: copy('profile.document')
                                  .toUpperCase(), //'DOCUMENTO',
                              isNumeric: true,
                              isOptionActive: isEditActive,
                              profileData: profileData,
                              formValues: formValues,
                              controller: TextEditingController(
                                text: formValues['documentNumber'],
                              ),
                              optionName: 'documentNumber',
                              maxLength: EditProfile._phoneLenght,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 24),
                              child: Divider(
                                color: isEditActive
                                    ? Colors.transparent
                                    : AppTheme.black2,
                                height: 1,
                              ),
                            ),
                            NvButton(
                              label: copy('profile.save'), //"Guardar",
                              action: () {
                                saveData();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
