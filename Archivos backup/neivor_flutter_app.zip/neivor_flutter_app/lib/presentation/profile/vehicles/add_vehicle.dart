import 'dart:async';

import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/data/repository/vehicles/vehicles_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/vehicles/vehicles.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/widgets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';

class AddVehicle extends StatefulWidget {
  const AddVehicle({Key? key}) : super(key: key);
  static const int _idMoto = 11;
  static const int _idBike = 10;
  static const int _idCar = 2;
  static const double _bikePadding = 16;
  static const TextStyle _labelStyle = TextStyle(
    color: AppTheme.black0Main,
    fontWeight: FontWeight.w400,
    fontSize: 14,
  );

  @override
  State<AddVehicle> createState() => _AddVehicleState();
}

class _AddVehicleState extends State<AddVehicle> {
  Function copy = AppMessages().getCopy;
  final vehiclesFormKey = GlobalKey<FormState>();
  Map<String, dynamic> formValues = {};
  VehiclesResponse? args;
  bool isCarSelected = false;
  bool isBikeSelected = false;
  bool isMotoSelected = false;
  bool accordionOpen = true;
  TextEditingController plateController = TextEditingController();
  TextEditingController brandController = TextEditingController();
  TextEditingController modelController = TextEditingController();
  TextEditingController colorController = TextEditingController();

  User? currentProfileUser = UserUtils.currentUser;

  @override
  // ignore: long-method
  void initState() {
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        if (ModalRoute.of(context)?.settings.arguments != null) {
          args = ModalRoute.of(context)?.settings.arguments as VehiclesResponse;
          formValues = {
            'brand': args?.brand,
            'color': args?.color,
            'idServicePoint': UserUtils.currentServicePoint?.id,
            'idVehicleType': args?.idVehicleType,
            'numberPlate': args?.numberPlate,
            'userCreation': UserUtils.currentEnterprise?.id,
            'vehicleModel': args?.vehicleModel,
            'id': args?.id,
          };
          if (args?.idVehicleType == AddVehicle._idCar) {
            selectCar();
          } else if (args?.idVehicleType == AddVehicle._idMoto) {
            selectMoto();
          } else {
            selectBike();
          }
        } else {
          formValues = {
            'brand': "",
            'color': "",
            'idServicePoint': UserUtils.currentServicePoint?.id,
            'idVehicleType': "",
            'numberPlate': "",
            'userCreation': UserUtils.currentEnterprise?.id,
            'vehicleModel': "",
          };
        }
        plateController = TextEditingController(
          text: formValues['numberPlate'],
        );
        brandController = TextEditingController(
          text: formValues['brand'],
        );
        modelController = TextEditingController(
          text: formValues['vehicleModel'],
        );
        colorController = TextEditingController(
          text: formValues['color'],
        );
      });
    });
  }

  /// If the car is selected, then the formValues['idVehicleType'] is set to 1, otherwise it is set to
  /// null
  selectCar() {
    setState(() {
      isCarSelected = !isCarSelected;
      isMotoSelected = false;
      isBikeSelected = false;
      isCarSelected
          ? formValues['idVehicleType'] = AddVehicle._idCar
          : formValues['idVehicleType'] = null;
    });
  }

  /// If the user selects the moto button, the formValues['idVehicleType'] is set to 11, otherwise it is
  /// set to null
  selectMoto() {
    setState(() {
      isMotoSelected = !isMotoSelected;
      isCarSelected = false;
      isBikeSelected = false;
      isMotoSelected
          ? formValues['idVehicleType'] = AddVehicle._idMoto
          : formValues['idVehicleType'] = null;
    });
  }

  /// If the user clicks on the bike icon, the bike icon will be selected and the other icons will be
  /// unselected
  selectBike() {
    setState(() {
      isBikeSelected = !isBikeSelected;
      isCarSelected = false;
      isMotoSelected = false;
      isBikeSelected
          ? formValues['idVehicleType'] = AddVehicle._idBike
          : formValues['idVehicleType'] = null;
    });
  }

  /// If the form is valid, and the user has selected a vehicle type, then send the data to the server,
  /// and show a success dialog
  ///
  /// Returns:
  ///   A Future<void>;
  // ignore: long-method
  sendData() async {
    if ((vehiclesFormKey.currentState?.validate() ?? false)) {
      if (!isBikeSelected && !isCarSelected && !isMotoSelected) {
        showDialog(
          barrierDismissible: false,
          //ignore: avoid-non-null-assertion
          context: vehiclesFormKey.currentContext!,
          builder: (context) {
            Timer(const Duration(seconds: 3), () {
              Navigator.of(context).pop();
            });
            return NvAlert(
              type: "warning",
              //"Debe Seleccionar el tipo de vehiculo",
              content: copy('profile.select-type-vehicle'),
            );
          },
        );
      } else {
        if (ModalRoute.of(context)?.settings.arguments != null) {
          callUpdateVehicle();
        } else {
          // ignore: prefer-async-await
          await addVehicle(formValues).then((value) => showDialog(
                barrierDismissible: false,
                context: context,
                builder: (context) {
                  Timer(const Duration(seconds: 2), () {
                    Navigator.pushReplacementNamed(context, 'profile');
                  });
                  return NvAlert(
                    type: (value.sucessRequest ?? false) ? "success" : "error",
                    content: (value.sucessRequest ?? false)
                        ? copy(
                            'profile.vehicle-created-successfully',
                          ) //"Vehículo creado con éxito"
                        : (value.message ??
                            copy(
                              'profile.error-creating-vehicle',
                            )), //"Ocurrio un error creando el vehiculo"),
                  );
                },
              ));
        }
      }
    }
  }

  // ignore: long-method
  callUpdateVehicle() async {
    // ignore: prefer-async-await
    await updateVehicle(formValues).then((value) => showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            Timer(const Duration(seconds: 2), () {
              Navigator.pushReplacementNamed(context, 'profile');
            });
            return NvAlert(
              type: (value.sucessRequest ?? false) ? "success" : "error",
              content: (value.sucessRequest ?? false)
                  ? copy(
                      'profile.success-edited-vehicle',
                    ) //"Vehículo editado con éxito"
                  : (value.message ??
                      copy(
                        'profile.error-edited-vehicle',
                      )), //"Ocurrio un error editando el vehiculo"),
            );
          },
        ));
  }

  /// It takes a request object, sends it to the server, and then navigates to the profile page.
  callDeleteVehicle() async {
    Map<String, dynamic> request = {
      "id": args?.id,
      "userChange": currentProfileUser?.id,
    };
    await deleteVehicle(request);
    if (!mounted) return;
    Navigator.pushNamed(context, "profile");
  }

  showDeleteDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return NvAlert(
          //"¿Estás seguro de eliminar este vehiculo?",
          content: copy('profile.confirm-msg'),
          cancelFn: () {
            Navigator.pop(context);
          },
          acceptFn: () {
            callDeleteVehicle();
          },
          type: "warning",
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pushReplacementNamed(context, "profile"),
        title: null,
        elevation: 0,
        actions: args != null
            ? [
                GestureDetector(
                  onTap: () => showDeleteDialog(),
                  child: const Padding(
                    padding: EdgeInsets.only(right: 16),
                    child: NvImage(
                      imageUrl: 'ds/icons/delete-trash-green.svg',
                    ),
                  ),
                ),
              ]
            : null,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 16, right: 16),
          child: Form(
            key: vehiclesFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width -
                          Constants.defaultMarginSum,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            //"Agrega un nuevo vehículo",
                            copy('profile.add-new-vehicle'),
                            style: TextStyle(
                              color: colors.primary.black.main,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                            overflow: TextOverflow.clip,
                          ),
                          Text(
                            //'Usaremos esta información para mejorar los espacios\npara vehículos',
                            copy('profile.info-vehicle-use-msj'),
                            style: TextStyle(
                              color: colors.primary.black.v4,
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                            ),
                            overflow: TextOverflow.clip,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 34),
                  child: Row(
                    children: [
                      Text(
                        //"TIPO DE VEHÍCULO",
                        copy('profile.vehicle-type').toUpperCase(),
                        style: AddVehicle._labelStyle,
                      ),
                    ],
                  ),
                ),
                VehicleSelector(
                  carSelector: selectCar,
                  isCarSelected: isCarSelected,
                  isMotoSelected: isMotoSelected,
                  motoSelector: selectMoto,
                  bikeSelector: selectBike,
                  isBikeSelected: isBikeSelected,
                ),
                Text(
                  !isBikeSelected
                      ? copy('profile.plate') //"MATRÍCULA"
                      : copy(
                          'profile.plate-optional',
                        ), //"MATRÍCULA (OPCIONAL)",
                  style: AddVehicle._labelStyle,
                ),
                Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        bottom: isBikeSelected ? AddVehicle._bikePadding : 0,
                      ),
                      child: TextFormField(
                        maxLength:
                            GlobalUtils.countryId == Constants.coIntIdCode
                                ? Constants.plateColombiaLenght
                                : Constants.plateMexicoLenght,
                        // ignore: prefer-extracting-callbacks
                        validator: (value) {
                          if (isBikeSelected) return null;
                          if (value == null || value.isEmpty) {
                            //'Obligatorio';
                            return copy('visitors.validator-required');
                          }
                          return null;
                        },
                        controller: plateController,
                        onChanged: (value) {
                          formValues['numberPlate'] = value;
                        },
                      ),
                    ),
                    if (!isBikeSelected)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 24, 0, 36),
                        child: ExpandablePanel(
                          theme: const ExpandableThemeData(
                            headerAlignment:
                                ExpandablePanelHeaderAlignment.center,
                          ),
                          header: Text(
                            //'Opciones avanzadas',
                            copy('profile.advanced-options'),
                            style: AddVehicle._labelStyle,
                          ),
                          collapsed: const SizedBox(),
                          expanded: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                //"MARCA (OPCIONAL)",
                                copy('profile.brand-optional'),
                                style: AddVehicle._labelStyle,
                              ),
                              TextFormField(
                                controller: brandController,
                                onChanged: (value) {
                                  formValues['brand'] = value;
                                },
                              ),
                              const SizedBox(
                                height: 24,
                              ),
                              Text(
                                //"MODELO (OPCIONAL)",
                                copy('profile.model-optional'),
                                style: AddVehicle._labelStyle,
                              ),
                              TextFormField(
                                controller: modelController,
                                onChanged: (value) {
                                  formValues['vehicleModel'] = value;
                                },
                              ),
                              const SizedBox(
                                height: 24,
                              ),
                              Text(
                                // "COLOR (OPCIONAL)",
                                copy('profile.color-optional'),
                                style: AddVehicle._labelStyle,
                              ),
                              TextFormField(
                                controller: colorController,
                                onChanged: (value) {
                                  formValues['color'] = value;
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
                NvButton(
                  label: copy('profile.save'), //"Guardar",
                  action: () {
                    sendData();
                  },
                ),
                const SizedBox(
                  height: 8,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
