import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/vehicles/vehicles.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class VehiclesWG extends StatelessWidget {
  const VehiclesWG({
    Key? key,
    required this.vehiclesList,
  }) : super(key: key);
  final List<VehiclesResponse> vehiclesList;
  static const int _idCar = 1;
  static const int _idMoto = 11;
  static const int _idBike = 10;
  static const double _iconSize = 20;

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;

    /// gets an idVhicleType and returns the name of vehicle
    ///
    /// Args:
    ///   id (int): The id of the vehicle type.
    ///
    /// Returns:
    ///   A string.
    String getVehicleType(int? id) {
      switch (id) {
        case _idCar:
          return copy('profile.automobile'); //"Automóvil";
        case _idMoto:
          return copy('profile.motorcycle'); //"Motocicleta";
        case _idBike:
          return copy('profile.bicycle'); //"Bicicleta";
        default:
          {
            return copy('profile.automobile'); //"Vehículo";
          }
      }
    }

    /// Uses the vehicle data to show the vehicle name
    ///
    /// Args:
    ///   vehicle (VehiclesResponse): VehiclesResponse?
    ///
    /// Returns:
    ///   A string.
    String vehicleName(VehiclesResponse? vehicle) {
      if (vehicle?.brand != null && (vehicle?.brand?.isNotEmpty ?? true)) {
        //ignore: avoid-non-null-assertion
        return vehicle!.brand!;
        //ignore: avoid-non-null-assertion
      } else if (vehicle?.vehicleModel != null &&
          (vehicle?.vehicleModel?.isNotEmpty ?? true)) {
        //ignore: avoid-non-null-assertion
        return vehicle?.vehicleModel ?? '';
      } else {
        return getVehicleType(vehicle?.idVehicleType);
      }
    }

    /// gets an idVhicleType and returns the icon of vehicle
    ///
    /// Args:
    ///   id (int): The id of the vehicle type.
    ///
    /// Returns:
    ///   A string.
    String getVehicleIcon(int? id) {
      switch (id) {
        case _idCar:
          return 'ds/icons/car.svg';
        case _idMoto:
          return 'ds/icons/moto-profile.svg';
        case _idBike:
          return 'ds/icons/bike.svg';
        default:
          {
            return 'ds/icons/car.svg';
          }
      }
    }

    return Padding(
      padding: const EdgeInsets.only(top: 32),
      child: Card(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
          side: BorderSide(color: AppTheme.black1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8, left: 8),
              child: Text(
                //"VEHICULOS (${vehiclesList.length})",
                "${copy('profile.vehicles').toUpperCase()} ${vehiclesList.length.toString()}",
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Jost',
                ),
              ),
            ),
            ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: vehiclesList.length,
              itemBuilder: (BuildContext context, int index) {
                return GestureDetector(
                  onTap: () => Navigator.pushReplacementNamed(
                    context,
                    "addVehicle",
                    arguments: vehiclesList[index],
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        dense: true,
                        horizontalTitleGap: 0,
                        leading: NvImage(
                          width: _iconSize,
                          height: _iconSize,
                          color: AppTheme.turquoise0Main,
                          imageUrl: getVehicleIcon(
                            vehiclesList[index].idVehicleType,
                          ),
                        ),
                        title: Text(vehicleName(vehiclesList[index])),
                        trailing: Text(vehiclesList[index].numberPlate ?? ''),
                      ),
                      const Divider(
                        endIndent: 16,
                        indent: 17,
                        thickness: 1,
                        height: 0,
                      ),
                    ],
                  ),
                );
              },
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushReplacementNamed(context, "addVehicle");
              },
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: Row(
                  children: [
                    const Icon(
                      Icons.add,
                      color: AppTheme.turquoise0Main,
                      size: 15,
                    ),
                    Text(
                      //" Agregar vehiculo",
                      ' ${copy('profile.add-vehicle')}',
                      style: const TextStyle(color: AppTheme.turquoise0Main),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
