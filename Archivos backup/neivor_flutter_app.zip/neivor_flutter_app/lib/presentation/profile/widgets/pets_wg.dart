import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/pets/pets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class PetsWG extends StatelessWidget {
  const PetsWG({
    Key? key,
    required this.petsList,
  }) : super(key: key);

  final List<PetsResponse> petsList;
  static const int idCat = 1;
  static const int idDog = 2;
  static const int idBird = 3;
  final double iconSize = 20;

  @override
  Widget build(BuildContext context) {
    showScreenAddPet(objPet) {
      Navigator.pushReplacementNamed(
        context,
        "addPet",
        arguments: objPet,
      );
    }

    /// gets an idPetType and returns the name of pet image
    ///
    /// Args:
    ///   id (int): The id of the pet type.
    ///
    /// Returns:
    ///   A string.
    String getPetIcon(int? id) {
      switch (id) {
        case idCat:
          return 'ds/icons/icon_cat.svg';
        case idDog:
          return 'ds/icons/icon_dog.svg';
        case idBird:
          return 'ds/icons/icon_bird.svg';
        default:
          {
            return 'ds/icons/icon_dog.svg';
          }
      }
    }

    return Padding(
      padding: const EdgeInsets.only(top: 32),
      child: Card(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
          side: BorderSide(color: Color(0xFFEDEDED)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8, left: 8),
              child: Text(
                //"MASCOTAS ${petsList.length}",
                "${AppMessages().getCopy('profile.pets').toUpperCase()} ${petsList.length.toString()}",
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w400,
                  fontFamily: 'Jost',
                ),
              ),
            ),
            petsList.isNotEmpty
                ? ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    physics: const BouncingScrollPhysics(),
                    itemCount: petsList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        child: Column(
                          children: [
                            ListTile(
                              onTap: UserUtils().hasPermissionsTo(187)
                                  ? () {
                                      showScreenAddPet(petsList[index]);
                                    }
                                  : null,
                              dense: true,
                              horizontalTitleGap: 0,
                              leading: NvImage(
                                width: iconSize,
                                height: iconSize,
                                color: AppTheme.turquoise0Main,
                                imageUrl: getPetIcon(petsList[index].idPetType),
                              ),
                              title: Text(petsList[index].name.toString()),
                            ),
                            const Divider(
                              endIndent: 16,
                              indent: 17,
                              thickness: 1,
                              height: 0,
                            ),
                          ],
                        ),
                      );
                    },
                  )
                : Padding(
                    padding: const EdgeInsets.fromLTRB(5, 25, 5, 25),
                    child: Center(
                      child: Text(
                        //"Aún no tienes mascotas",
                        AppMessages().getCopy('profile.no-pets'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.black3,
                        ),
                      ),
                    ),
                  ),
            if (!petsList.isNotEmpty)
              const Divider(
                endIndent: 16,
                indent: 17,
                thickness: 1,
                height: 0,
              ),
            if (UserUtils().hasPermissionsTo(165))
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacementNamed(context, "addPet");
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 50, 16),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.add,
                        color: AppTheme.turquoise0Main,
                        size: 15,
                      ),
                      Text(
                        //"Agregar Mascota",
                        AppMessages().getCopy('profile.add-pet-label'),
                        style: const TextStyle(color: AppTheme.turquoise0Main),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
