import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class AccountWG extends StatelessWidget {
  const AccountWG({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 8, left: 8),
            child: Text(
              // "Mi cuenta",
              AppMessages().getCopy('profile.my-account'),
              style: const TextStyle(
                color: AppTheme.black2,
                fontSize: 14,
                fontWeight: FontWeight.w400,
                fontFamily: 'Jost',
              ),
            ),
          ),
          ListTile(
            horizontalTitleGap: 0.0,
            leading: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                NvImage(
                  imageUrl: 'ds/icons/user-icon-unfilled.svg',
                ),
              ],
            ),
            title: Text(
              //'Datos personales',
              AppMessages().getCopy('profile.personal-data2'),
              style: const TextStyle(
                color: AppTheme.black0Main,
                fontSize: 14,
                fontWeight: FontWeight.w400,
                fontFamily: 'Jost',
              ),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.pushNamed(context, 'editProfile'),
          ),
          const Divider(
            endIndent: 16,
            indent: 17,
            thickness: 1,
            height: 0,
          ),
          ListTile(
            horizontalTitleGap: 0.0,
            leading: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                NvImage(imageUrl: 'ds/icons/phone-green.svg'),
              ],
            ),
            title: Text(
              //'Contactos de emergencia',
              AppMessages().getCopy('profile.emergency-contact'),
              style: const TextStyle(
                color: AppTheme.black0Main,
                fontSize: 14,
                fontWeight: FontWeight.w400,
                fontFamily: 'Jost',
              ),
              textAlign: TextAlign.start,
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pushNamed(context, 'emergency');
            },
          ),
        ],
      ),
    );
  }
}
