import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class VehicleSelector extends StatelessWidget {
  const VehicleSelector({
    Key? key,
    required this.carSelector,
    required this.isCarSelected,
    required this.motoSelector,
    required this.isMotoSelected,
    required this.bikeSelector,
    required this.isBikeSelected,
  }) : super(key: key);

  final Function carSelector;
  final Function motoSelector;
  final Function bikeSelector;
  final bool isCarSelected;
  final bool isMotoSelected;
  final bool isBikeSelected;
  static const double _selectorHeight = 102;
  static const int _pageMargin = 32;
  static const double _vehicleSize = 64;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 4, 0, 34),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () {
              carSelector();
            },
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          AppTheme.black2.withOpacity(Constants.twentyPercent),
                    ),
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    color: isCarSelected
                        ? AppTheme.turquoise0Main
                            .withOpacity(Constants.tenPercent)
                        : null,
                  ),
                  height: _selectorHeight,
                  width: (MediaQuery.of(context).size.width *
                          Constants.thirtyPercent) -
                      _pageMargin,
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: 'ds/icons/car.svg',
                      color: isCarSelected
                          ? AppTheme.turquoise0Main
                          : AppTheme.black2,
                      width: _vehicleSize,
                      height: _vehicleSize,
                    ),
                  ),
                ),
                Text(
                  //"Auto",
                  AppMessages().getCopy('profile.car'),
                ),
              ],
            ),
          ),
          const SizedBox(
            width: 11,
          ),
          GestureDetector(
            onTap: () {
              motoSelector();
            },
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          AppTheme.black2.withOpacity(Constants.twentyPercent),
                    ),
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    color: isMotoSelected
                        ? AppTheme.turquoise0Main
                            .withOpacity(Constants.tenPercent)
                        : null,
                  ),
                  height: _selectorHeight,
                  width: (MediaQuery.of(context).size.width *
                          Constants.thirtyPercent) -
                      _pageMargin,
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: 'ds/icons/moto.svg',
                      color: isMotoSelected
                          ? AppTheme.turquoise0Main
                          : AppTheme.black2,
                      width: _vehicleSize,
                      height: _vehicleSize,
                    ),
                  ),
                ),
                Text(
                  //"Moto",
                  AppMessages().getCopy('profile.moto'),
                ),
              ],
            ),
          ),
          const SizedBox(
            width: 11,
          ),
          GestureDetector(
            onTap: () {
              bikeSelector();
            },
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          AppTheme.black2.withOpacity(Constants.twentyPercent),
                    ),
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    color: isBikeSelected
                        ? AppTheme.turquoise0Main
                            .withOpacity(Constants.tenPercent)
                        : null,
                  ),
                  height: _selectorHeight,
                  width: (MediaQuery.of(context).size.width *
                      Constants.thirtyPercent),
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: 'ds/icons/bike.svg',
                      shadow: false,
                      color: isBikeSelected
                          ? AppTheme.turquoise0Main
                          : AppTheme.black2,
                      width: _vehicleSize,
                      height: _vehicleSize,
                    ),
                  ),
                ),
                Text(
                  // "Bicicleta",
                  AppMessages().getCopy('profile.bicycle'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
