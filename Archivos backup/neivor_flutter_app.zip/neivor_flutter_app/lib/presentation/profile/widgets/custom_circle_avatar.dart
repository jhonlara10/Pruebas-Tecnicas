import 'dart:math';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class CustomCircleAvatar extends StatelessWidget {
  static const double _avatarSize = 80;
  const CustomCircleAvatar({
    Key? key,
    //required this.currentProfilePhoto,
    this.currentProfileName,
  }) : super(key: key);

  //final String? currentProfilePhoto;
  final String? currentProfileName;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: CustomCircleAvatar._avatarSize,
      height: CustomCircleAvatar._avatarSize,
      child: AspectRatio(
        aspectRatio: 1 / 1,
        child: ClipOval(
          child: UserUtils.currentUser?.photo != null &&
                  (UserUtils.currentUser?.photo?.isNotEmpty ?? false)
              ? ClipOval(
                  child: NvImage(
                    isUserImage: true,
                    width: CustomCircleAvatar._avatarSize,
                    height: CustomCircleAvatar._avatarSize,
                    imageUrl: UserUtils.currentUser?.photo?[0] == "/"
                        ? ("${UserUtils.currentUser?.photo?.substring(
                              1,
                            ) ?? ''}?${DateTime.now().millisecondsSinceEpoch.toString()}.jpg")
                        : UserUtils.currentUser?.photo,
                  ),
                )
              : CircleAvatar(
                  backgroundColor: Colors
                      .primaries[Random().nextInt(Colors.primaries.length)],
                  child: Text(
                    currentProfileName != null &&
                            (currentProfileName?.isNotEmpty ?? false)
                        ? (currentProfileName?[0] ?? '')
                        : "",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 40),
                  ),
                ),
        ),
      ),
    );
  }
}
