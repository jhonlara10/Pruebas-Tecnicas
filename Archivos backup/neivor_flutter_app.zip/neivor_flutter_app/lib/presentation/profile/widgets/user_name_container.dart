import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/themes/themes.dart';

class UserNameContainer extends StatelessWidget {
  final String? name;
  final String? email;
  const UserNameContainer({
    Key? key,
    this.name,
    this.email,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 8, 0, 42),
          child: Column(
            children: [
              Text(
                name ?? '',
                style: const TextStyle(
                  color: AppTheme.black0Main,
                  fontFamily: 'Jost',
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              Text(email ?? ''),
            ],
          ),
        ),
      ],
    );
  }
}
