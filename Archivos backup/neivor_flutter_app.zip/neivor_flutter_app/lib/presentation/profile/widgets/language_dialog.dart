import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';

class LanguageDialog extends StatefulWidget {
  final Function changeLanguage;

  const LanguageDialog({Key? key, required this.changeLanguage})
      : super(key: key);

  @override
  State<LanguageDialog> createState() => _LanguageDialogState();
}

class _LanguageDialogState extends State<LanguageDialog> {
  final txtSpanish = AppMessages().getCopy('common.spanish');
  final txtEnglish = AppMessages().getCopy('common.english-en');

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: Constants.widthDialog,
      width: Constants.heightDialog,
      child: ListView.builder(
        itemBuilder: (buildContext, index) {
          return Card(
            shape: const RoundedRectangleBorder(
              side: BorderSide(color: Colors.white70, width: 1),
              borderRadius: BorderRadius.all(Radius.circular(30)),
            ),
            child: ListTile(
              onTap: () => widget.changeLanguage(
                Constants.languageData[index]['idCodeLanguage'],
              ),
              leading: SvgPicture.network(
                GlobalUtils()
                    .staticCdn(Constants.languageData[index]['imgLanguage']),
                width: Constants.sizeImgLanguage,
                height: Constants.sizeImgLanguage,
              ),
              title: Text(Constants.languageData[index]['idCodeLanguage'] == "2"
                  ? txtEnglish
                  : txtSpanish),
            ),
          );
        },
        itemCount: Constants.languageData.length,
        shrinkWrap: true,
        padding: const EdgeInsets.all(5),
        scrollDirection: Axis.vertical,
      ),
    );
  }
}
