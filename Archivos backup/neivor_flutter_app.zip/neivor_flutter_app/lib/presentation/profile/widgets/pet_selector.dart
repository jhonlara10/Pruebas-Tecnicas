import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class PetSelector extends StatelessWidget {
  const PetSelector({
    Key? key,
    required this.dogSelector,
    required this.isDogSelected,
    required this.catSelector,
    required this.isCatSelected,
    required this.birdSelector,
    required this.isBirdSelected,
  }) : super(key: key);

  final Function dogSelector;
  final Function catSelector;
  final Function birdSelector;
  final bool isDogSelected;
  final bool isCatSelected;
  final bool isBirdSelected;

  @override
  Widget build(BuildContext context) {
    double imgSizePets = 64.0;
    double heightCarPets = 102.0;

    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 4, 0, 34),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () {
              dogSelector();
            },
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppTheme.black2.withOpacity(0.2)),
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    color: isDogSelected
                        ? AppTheme.turquoise0Main.withOpacity(0.1)
                        : null,
                  ),
                  height: heightCarPets,
                  width: (MediaQuery.of(context).size.width / 3) - 32,
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: 'ds/icons/icon_dog.svg',
                      color: isDogSelected
                          ? AppTheme.turquoise0Main
                          : AppTheme.black2,
                      width: imgSizePets,
                      height: imgSizePets,
                    ),
                  ),
                ),
                Text(
                  //"Perro",
                  AppMessages().getCopy('profile.dog'),
                ),
              ],
            ),
          ),
          const SizedBox(
            width: 11,
          ),
          GestureDetector(
            onTap: () {
              catSelector();
            },
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: AppTheme.black2.withOpacity(0.2)),
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    color: isCatSelected
                        ? AppTheme.turquoise0Main.withOpacity(0.1)
                        : null,
                  ),
                  height: heightCarPets,
                  width: (MediaQuery.of(context).size.width / 3) - 32,
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: 'ds/icons/icon_cat.svg',
                      color: isCatSelected
                          ? AppTheme.turquoise0Main
                          : AppTheme.black2,
                      width: imgSizePets,
                      height: imgSizePets,
                    ),
                  ),
                ),
                Text(
                  //"Gato",
                  AppMessages().getCopy('profile.cat'),
                ),
              ],
            ),
          ),
          const SizedBox(
            width: 11,
          ),
          GestureDetector(
            onTap: () {
              birdSelector();
            },
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: AppTheme.black2.withOpacity(0.2),
                    ),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(8),
                    ),
                    color: isBirdSelected
                        ? AppTheme.turquoise0Main.withOpacity(0.1)
                        : null,
                  ),
                  height: heightCarPets,
                  width: (MediaQuery.of(context).size.width * 0.3),
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: 'ds/icons/icon_bird.svg',
                      shadow: false,
                      color: isBirdSelected
                          ? AppTheme.turquoise0Main
                          : AppTheme.black2,
                      width: imgSizePets,
                      height: imgSizePets,
                    ),
                  ),
                ),
                Text(
                  //"Ave",
                  AppMessages().getCopy('profile.bird'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
