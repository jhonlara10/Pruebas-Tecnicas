import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/data/repository/general/general_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/messages/messages_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/profile/profile_repository_impl.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/domain/models/profile/profile.dart';
import 'package:neivor_flutter_app/domain/models/settings/messages_request.dart';
import 'package:neivor_flutter_app/presentation/profile/widgets/language_dialog.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsWG extends StatefulWidget {
  const SettingsWG({Key? key}) : super(key: key);

  @override
  State<SettingsWG> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<SettingsWG> {
  final copy = AppMessages().getCopy;
  User? currentProfileUser = UserUtils.currentUser;
  ProfileData? profileData;
  Map<String, dynamic> changeLanguageBody = {
    "appLanguage": "",
    "userChange": "",
  };

  final visibilityTitle = AppMessages().getCopy('profile.configurations');
  final visibilityMsg = AppMessages().getCopy('profile.be-visible');
  final txtChanceLanguage = AppMessages().getCopy('sidebar.change-language');
  final txtSpanish = AppMessages().getCopy('common.spanish');
  final txtEnglish = AppMessages().getCopy('common.english-en');
  final txtDeleteAccount = AppMessages().getCopy('profile.delete-account');

  final double iconSize = 20;
  final double borderRadius = 15.0;
  final double bottomSheetHeight = 300.0;
  final int stateDeleteAccount = 2;
  int? languageId;

  Map<String, dynamic> dataUpdateVisibility = {
    'alias': '',
    'documentNumber': '',
    'hideUserFromNeighbors': '',
    'id': "",
    'mobilePhone': '',
    'name': '',
    'ocupation': '',
    'userChange': "",
  };

  Map<String, dynamic> dataDeleteAccount = {
    'stae': "",
    'userChange': "",
  };

  @override
  void initState() {
    (() async {
      await loadProfileData();
      await AppMessages().getPreferences();
      var sharedPreferences = await SharedPreferences.getInstance();
      languageId = sharedPreferences.getInt("language");
    })();
    super.initState();
  }

  /// This funcion gets user data, and call function [assignProfileData] for tu assing
  /// user's data into list
  loadProfileData() async {
    try {
      profileData = await getProfile(
        (currentProfileUser?.id ?? 0),
        (UserUtils.currentEnterprise?.id ?? 0),
        (UserUtils.currentServicePoint?.id ?? 0),
      );
      assignProfileData();
      // ignore: no-empty-block
      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  /// This function fills the list of data that will be sent to consume
  /// the service (change visibility to neighbors) with the user's information
  assignProfileData() {
    dataUpdateVisibility = {
      'alias': profileData?.alias ?? '',
      'documentNumber': profileData?.documentNumber ?? '',
      'hideUserFromNeighbors': profileData?.hideUserFromNeighbors ?? '',
      'id': currentProfileUser?.id,
      'mobilePhone': profileData?.mobilePhone ?? '',
      'name': profileData?.name ?? '',
      'ocupation': profileData?.ocupation ?? '',
      'userChange': currentProfileUser?.id,
    };
  }

  /// This function calls the service that changes visibility to neighbors.
  changeVisibility() async {
    await updateVisibility(dataUpdateVisibility).then(
      (value) => context.loaderOverlay.hide(),
    );
  }

  /// This function is called from the widget to make the call to the service
  /// that updates the visibility to neighbors, and updates the state of the widget
  onChangedVisibility(value) {
    setState(() {
      value
          ? dataUpdateVisibility['hideUserFromNeighbors'] = 0
          : dataUpdateVisibility['hideUserFromNeighbors'] = 1;
    });
    context.loaderOverlay.show();
    changeVisibility();
  }

  /// This function is executed from the widget and calls the function that consumes the service to fetch the copies.
  changeLanguage(idCodeLanguage) {
    try {
      Navigator.of(context, rootNavigator: true).pop();
      context.loaderOverlay.show();
      callToChangeLanguage(idCodeLanguage);
      Jiffy.locale(
        idCodeLanguage.toString() == Constants.spanishLanguage ? 'es' : 'en',
      );
      changeLanguageBody['appLanguage'] =
          idCodeLanguage.toString() == Constants.spanishLanguage ? 'ES' : 'EN';
      changeLanguageBody['userChange'] = UserUtils.currentEnterprise?.id;
    } catch (e) {
      log(e.toString());
    }
  }

  /// This function brings the new copies of the selected language and sends to home.
  // ignore: long-method
  callToChangeLanguage(idCodeLanguage) async {
    var sharedPreferences = await SharedPreferences.getInstance();
    var countryId = sharedPreferences.getInt("countryId");
    sharedPreferences.setString("selectedLang", idCodeLanguage.toString());

    await changeLenguage(changeLanguageBody);
    await GlobalUtils().synqCurrentLanguage();
    // ignore: prefer-async-await
    await MessagesRepository().getMessages(MessagesRequest(
      idCodeLanguage,
      Constants.appSource,
      countryId.toString(),
      true,
    ));
    await AppMessages().getPreferences();
    context.loaderOverlay.hide();
    Navigator.pushReplacementNamed(context, 'home');
  }

  /// This function displays the modal with the list of available languages.
  showDialogLanguage() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            AppMessages().getCopy('common.select-your-language'),
            textAlign: TextAlign.center,
          ),
          content: LanguageDialog(
            changeLanguage: changeLanguage,
          ),
          elevation: 0,
        );
      },
    );
  }

  /// This function builds the modal, to confirm the account deletion.
  showDeleteAccountBottomSheet() async {
    var borderRadius2 = borderRadius;
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(borderRadius),
          topRight: Radius.circular(borderRadius2),
        ),
      ),
      context: context,
      builder: (BuildContext context) {
        return modalConfirmDeleteAccount();
      },
    );
  }

  // ignore: long-method
  Padding modalConfirmDeleteAccount() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: NvBottomSheet(
        bottomSheetHeight: bottomSheetHeight,
        iconRoute: "assets/images/warning.png",
        //"¿Estás seguro que quieres eliminar tu cuenta?",
        title: copy('profile.you-want-to-delete-your-account'),
        //"Si la eliminas, todos tus registros seran borrados del sistema de Neivor.",
        subtitle: copy('profile.all-your-records-will-be-deleted'),
        primaryButtonText: copy('common.confirm'), //"Confirmar",
        secondaryButtonText: copy('profile.back'), //"Regresar",
        primaryButtonVariant: "nv-bottom-sheet-primary",
        secondaryButtonVariant: "nv-bottom-sheet-secondary",
        primaryButtonAction: deleteAccount,
        secondaryButtonAction: cancelDeleteAccount,
      ),
    );
  }

  /// This function sends the data and makes the call to the function that
  ///  executes the service to delete account.
  deleteAccount() async {
    context.loaderOverlay.show();
    dataUpdateVisibility = {
      'state': stateDeleteAccount,
      'userChange': UserUtils.currentUser?.id,
    };
    callDeleteUserAccount(dataUpdateVisibility);
  }

  /// This function receives the data to consume the service to delete the account.
  // ignore: long-method
  callDeleteUserAccount(data) async {
    // ignore: prefer-async-await
    await deleteUserAccount(
      (UserUtils.currentUser?.id ?? 0),
      data,
    ).then((value) => {
          context.loaderOverlay.hide(),
          if (value.success == true)
            {
              markAsLogoutUser(),
              Navigator.pushNamedAndRemoveUntil(
                context,
                "selectLogin",
                (Route<dynamic> route) => false,
              ),
            }
          else
            {
              Navigator.pop(context),
              errorModalDeleteAccount(),
            },
        });
  }

  /// This function displays a modal, if there was an error deleting the account.
  // ignore: long-method
  errorModalDeleteAccount() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return AlertDialog(
          content: Text(
            //"Ocurrio un error al eliminar la cuenta",
            copy('account.error-deleting-account'),
            textAlign: TextAlign.center,
          ),
          title: const Icon(
            Icons.error,
            size: 88,
            color: Colors.red,
          ),
        );
      },
    );
  }

  // This function removes the user's session.
  markAsLogoutUser() async {
    var sharePreferences = await SharedPreferences.getInstance();
    sharePreferences.remove("isLogged");
    sharePreferences.remove("currentEnterpriseIndex");
    sharePreferences.remove("currentServicePointIndex");
    sharePreferences.remove("currentZyosGroup");
  }

  cancelDeleteAccount() {
    Navigator.pop(context);
  }

  logout() async {
    await deleteTokens();
    await markAsLogoutUser();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil(
      'selectLogin',
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 32, bottom: 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                const EdgeInsets.only(top: 5, bottom: 5, left: 10, right: 10),
            child: Text(
              visibilityTitle.toUpperCase(),
              style: const TextStyle(
                color: Colors.black,
                fontSize: 10,
                fontWeight: FontWeight.w400,
                fontFamily: 'Jost',
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8, left: 0),
            child: Column(
              children: [
                if (UserUtils().hasPermissionsTo(875))
                  ListTile(
                    dense: true,
                    horizontalTitleGap: 0,
                    title: Text(visibilityMsg),
                    trailing: Switch(
                      activeColor: AppTheme.turquoise0Main,
                      value: dataUpdateVisibility['hideUserFromNeighbors'] == 0
                          ? true
                          : false,
                      onChanged: (value) {
                        onChangedVisibility(value);
                      },
                    ),
                  ),
                const Divider(
                  endIndent: 16,
                  indent: 17,
                  thickness: 1,
                  height: 0,
                ),
                if (UserUtils().hasPermissionsTo(842))
                  ListTile(
                    onTap: () {
                      showDialogLanguage();
                    },
                    dense: true,
                    horizontalTitleGap: 0,
                    leading: NvImage(
                      width: iconSize,
                      height: iconSize,
                      imageUrl: 'ds/icons/icon_translate.svg',
                    ),
                    title: Text(txtChanceLanguage),
                    trailing: Text(languageId == 1 ? txtSpanish : txtEnglish),
                  ),
                const Divider(
                  endIndent: 16,
                  indent: 17,
                  thickness: 1,
                  height: 0,
                ),
                ListTile(
                  onTap: () {
                    showDeleteAccountBottomSheet();
                  },
                  dense: true,
                  horizontalTitleGap: 0,
                  leading: NvImage(
                    width: iconSize,
                    height: iconSize,
                    imageUrl: 'ds/icons/delete_account.svg',
                  ),
                  title: Text(
                    //"Eliminar cuenta",
                    copy('profile.delete-account'),
                  ),
                  trailing: Image.asset("assets/images/chevron.png"),
                ),
                const Divider(
                  endIndent: 16,
                  indent: 17,
                  thickness: 1,
                  height: 0,
                ),
                ListTile(
                  onTap: () {
                    logout();
                  },
                  dense: true,
                  horizontalTitleGap: 0,
                  leading: Icon(
                    Icons.output,
                    size: iconSize,
                    color: AppTheme.black0Main,
                  ),
                  title: Text(
                    //"Cerrar sesión",
                    copy('sidebar.sing-off'),
                    style: const TextStyle(
                      color: Colors.black,
                    ),
                  ),
                  trailing: Image.asset("assets/images/chevron.png"),
                ),
                const SizedBox(
                  height: 16.0,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
