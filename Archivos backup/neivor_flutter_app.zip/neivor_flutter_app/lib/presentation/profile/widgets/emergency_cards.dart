import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/emergency/emergency.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class EmergencyCards extends StatelessWidget {
  const EmergencyCards({
    Key? key,
    this.contacts,
    required this.sendWhatsapp,
    required this.getRelationshipName,
    required this.goToEdit,
  }) : super(key: key);
  final List<EmergencyData>? contacts;
  final Function sendWhatsapp;
  final Function getRelationshipName;
  final Function goToEdit;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      scrollDirection: Axis.vertical,
      shrinkWrap: true,
      itemCount: contacts?.length ?? 0,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: GestureDetector(
            onTap: UserUtils().hasPermissionsTo(847)
                ? () {
                    goToEdit(contacts?[index]);
                  }
                : null,
            child: Card(
              elevation: 0,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
                side: BorderSide(color: AppTheme.black1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Text(
                            contacts?[index].name ?? '',
                            style:
                                AppThemeScope.of(context).typography.bd1.medium,
                          ),
                        ),
                        Text(
                          getRelationshipName(
                                contacts?[index].idRelationship,
                              ) ??
                              '',
                          style: AppThemeScope.of(context).typography.bd2.light,
                        ),
                      ],
                    ),
                  ),
                  Stack(
                    children: [
                      GestureDetector(
                        onTap: () {
                          sendWhatsapp(contacts?[index].phoneOne ?? '');
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(16),
                          child: NvImage(imageUrl: 'profile/whatsapp.svg'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
