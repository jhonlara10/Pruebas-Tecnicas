import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

import '../../../domain/models/profile/profile.dart';

class CustomTextInput extends StatelessWidget {
  const CustomTextInput({
    this.changeValidPhone,
    Key? key,
    required this.isOptionActive,
    this.isPhoneInvalid,
    required this.profileData,
    required this.formValues,
    required this.activateOption,
    this.labelName,
    required this.controller,
    required this.isNumeric,
    required this.optionName,
    required this.maxLength,
    required this.editIcon,
  }) : super(key: key);

  final bool isOptionActive;
  final bool isNumeric;
  final ProfileData? profileData;
  final Function activateOption;
  final String? labelName;
  final Map<String, dynamic> formValues;
  final String optionName;
  final TextEditingController controller;
  final int maxLength;
  final bool editIcon;
  final Function? changeValidPhone;
  final bool? isPhoneInvalid;
  static const double _phoneSize1 = 60;
  static const double _phoneSize2 = 40;
  static const double _phoneWidth1 = 0.48;

  double getPhonesize() {
    if (optionName == 'mobilePhone') {
      return isPhoneInvalid ?? false ? _phoneSize1 : _phoneSize2;
    }
    return _phoneSize2;
  }

  @override
  Widget build(BuildContext context) {
    controller.selection = TextSelection.fromPosition(
      TextPosition(offset: controller.text.length),
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (labelName != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 5, left: 2),
            child: Text(
              labelName ?? '',
              style: const TextStyle(fontSize: 10, color: AppTheme.black4),
            ),
          ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextFormField(
              // ignore: prefer-extracting-callbacks
              validator: (value) {
                if (value == null || value.isEmpty) {
                  //ignore: avoid-non-null-assertion
                  optionName == 'mobilePhone' ? changeValidPhone!() : null;
                  return AppMessages()
                      .getCopy('visitors.validator-required'); //"Obligatorio";
                }
                return null;
              },
              maxLength: maxLength,
              enabled: isOptionActive,
              controller: controller,
              onChanged: (value) {
                formValues[optionName] = value;
              },
              textCapitalization: TextCapitalization.words,
              keyboardType:
                  isNumeric ? TextInputType.number : TextInputType.name,
              decoration: InputDecoration(
                counterText: "",
                constraints: BoxConstraints.expand(
                  width: optionName == 'mobilePhone'
                      ? (MediaQuery.of(context).size.width * _phoneWidth1)
                      : (MediaQuery.of(context).size.width *
                          Constants.eightyPercent),
                  height: optionName == 'mobilePhone' ? getPhonesize() : 60,
                ),
                contentPadding: const EdgeInsets.all(8),
                hintText: formValues[labelName?.toLowerCase()],
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: AppTheme.black1),
                ),
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.zero,
                  borderSide: BorderSide(color: AppTheme.black1),
                ),
                disabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.transparent),
                ),
              ),
            ),
            if (UserUtils().hasPermissionsTo(845)) ...[
              if (!isOptionActive && editIcon)
                GestureDetector(
                  onTap: (() {
                    activateOption();
                  }),
                  child: const NvImage(imageUrl: 'profile/pencil-icon.svg'),
                ),
            ],
          ],
        ),
      ],
    );
  }
}
