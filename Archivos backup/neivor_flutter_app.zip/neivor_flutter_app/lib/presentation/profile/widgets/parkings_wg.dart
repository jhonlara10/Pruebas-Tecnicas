import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/parking/parking_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class ParkingsWG extends StatelessWidget {
  const ParkingsWG({
    Key? key,
    required this.parkingList,
  }) : super(key: key);

  final List<ParkingResponse> parkingList;
  final double iconSize = 20;
  

  formatterCost(cost) {
    var formatter = NumberFormat.currency(locale: "en_US", symbol: "\$ ");
    return formatter.format(cost);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 32),
      child: Card(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
          side: BorderSide(color: Color(0xFFEDEDED)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8, left: 8),
              child: Text(
                //"ESTACIONAMIENTOS (${parkingList.length})",
                "${AppMessages().getCopy('profile.parking').toUpperCase()}S ${parkingList.length}" ,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 10,
                  fontWeight: FontWeight.w400,
                  fontFamily: 'Jost',
                ),
              ),
            ),
            parkingList.isNotEmpty
                ? ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    physics: const BouncingScrollPhysics(),
                    itemCount: parkingList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        child: Column(
                          children: [
                            ListTile(
                              dense: true,
                              horizontalTitleGap: 0,
                              leading: NvImage(
                                width: iconSize,
                                height: iconSize,
                                color: AppTheme.turquoise0Main,
                                imageUrl: "ds/icons/icon_parking.svg",
                              ),
                              title: Text(parkingList[index].name.toString()),
                              trailing: Text(
                                formatterCost(parkingList[index].cost),
                                overflow: TextOverflow.fade,
                                maxLines: 1,
                                softWrap: false,
                              ),
                            ),
                            const Divider(
                              endIndent: 16,
                              indent: 17,
                              thickness: 1,
                              height: 0,
                            ),
                          ],
                        ),
                      );
                    },
                  )
                :  Padding(
                    padding: const EdgeInsets.fromLTRB(5, 25, 5, 25),
                    child: Center(
                      child: Text(
                        //"No tienes estacionamientos",
                        AppMessages().getCopy('profile.no-parking'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.black3,
                        ),
                      ),
                    ),
                  ),
            if (!parkingList.isNotEmpty)
              const Divider(
                endIndent: 16,
                indent: 17,
                thickness: 1,
                height: 0,
              ),
          ],
        ),
      ),
    );
  }
}
