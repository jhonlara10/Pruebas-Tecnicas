import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class PhotoContainer extends StatelessWidget {
  final Function imagePicker;
  final XFile? pickedImage;
  const PhotoContainer({
    Key? key,
    required this.imagePicker,
    this.pickedImage,
  }) : super(key: key);
  static const double _containerHeight = 170;
  static const double _padding1 = 40;
  static const double _padding2 = 10;
  static const double _imageHeight = 120;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (() {
        imagePicker();
      }),
      child: Container(
        height: _containerHeight,
        color: AppTheme.black2.withOpacity(Constants.fiftyPercent),
        child: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(
                  top: UserUtils.currentUser?.photo == null ||
                          (UserUtils.currentUser?.photo?.isEmpty ?? true)
                      ? _padding1
                      : _padding2,
                ),
                child: Column(
                  children: [
                    if (pickedImage == null) ...[
                      UserUtils.currentUser?.photo != null &&
                              (UserUtils.currentUser?.photo?.length ?? 0) > 0
                          ? SizedBox(
                              width: MediaQuery.of(context).size.width,
                              height: _imageHeight,
                              child: NvImage(
                                isUserImage: true,
                                imageUrl: UserUtils.currentUser?.photo?[0] ==
                                        "/"
                                    ? ("${UserUtils.currentUser?.photo?.substring(
                                          1,
                                        ) ?? ''}?${DateTime.now().millisecondsSinceEpoch.toString()}.jpg")
                                    : UserUtils.currentUser
                                        ?.photo, // Ugly solution !to delete double backslashes and avoid caching image.
                              ),
                            )
                          : const NvImage(imageUrl: 'profile/camera-icon.svg'),
                    ],
                    if (pickedImage != null)
                      SizedBox(
                        width: MediaQuery.of(context).size.width,
                        height: _imageHeight,
                        child: Image.file(File(pickedImage!.path)),
                      ),
                    if (UserUtils.currentUser?.photo == null ||
                        (UserUtils.currentUser?.photo?.isEmpty ?? true))
                      Text(
                        //'Agregar foto de perfil',
                        AppMessages().getCopy('profile.add-profile-photo'),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
