import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class EmergencyCustomInput extends StatelessWidget {
  const EmergencyCustomInput({
    Key? key,
    this.label,
    required this.controller,
    required this.formValues,
    required this.optionName,
    this.obligatory,
  }) : super(key: key);

  final String? label;
  final TextEditingController controller;
  final Map<String, dynamic> formValues;
  final String optionName;
  final bool? obligatory;

  @override
  Widget build(BuildContext context) {
    controller.selection = TextSelection.fromPosition(
      TextPosition(offset: controller.text.length),
    );

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 16, bottom: 0),
              child: Text(
                "*",
                style: AppThemeScope.of(context).typography.bd1.medium.copyWith(
                      color:
                          AppThemeScope.of(context).colors.primary.coral.main,
                    ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16, bottom: 0),
              child: Text(
                label ?? '',
                style: AppThemeScope.of(context).typography.bd1.medium,
              ),
            ),
          ],
        ),
        TextFormField(
          validator: (obligatory ?? false)
              ? (value) {
                  if (value == null || value.isEmpty) {
                    //'Obligdatorio';
                    return AppMessages().getCopy('visitors.validator-required');
                  }
                  return null;
                }
              : null,
          onChanged: (value) {
            formValues[optionName] = value;
          },
          controller: controller,
          keyboardType: TextInputType.name,
          decoration: const InputDecoration(
            isDense: true,
            contentPadding: EdgeInsets.symmetric(vertical: 7, horizontal: 5),
          ),
        ),
      ],
    );
  }
}
