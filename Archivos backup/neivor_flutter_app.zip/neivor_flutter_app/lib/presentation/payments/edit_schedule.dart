import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/get_schedules_response.dart'
    show Data;
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/update_schedule_response.dart'
    hide Data;
import 'package:neivor_flutter_app/presentation/payments/my_cards.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/input_label.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

class EditSchedule extends StatefulWidget {
  final Data? selectedSchedule;
  final UserPaymentMethodResponse? paymentMethod;
  const EditSchedule({Key? key, this.selectedSchedule, this.paymentMethod})
      : super(key: key);

  @override
  State<EditSchedule> createState() => _EditScheduleState();
}

class _EditScheduleState extends State<EditSchedule> {
  GlobalKey<FormState> editScheduleFormKey = GlobalKey<FormState>();
  List<UserPaymentMethodResponse>? paymentMethodsList;
  List<DropdownMenuItem<int>> methodsDropdown = [
    const DropdownMenuItem(
      value: 0,
      child: Text("Seleccione uno"),
    ),
  ];
  final copy = AppMessages().getCopy;
  Map<String, dynamic> reqObject = {
    "userChange": UserUtils.currentUser?.id ?? 0,
    "paymentDay": 0,
    "idPaymentMethod": 0,
  };

  @override
  void initState() {
    callGetUserPaymentMethods();
    super.initState();
  }

  callGetUserPaymentMethods() async {
    context.loaderOverlay.show();
    paymentMethodsList = await getUserPaymentMethods();
    buildDropdownOptions();
    // ignore: no-empty-block
    setState(() {});
  }

  buildDropdownOptions() {
    reqObject['paymentDay'] = widget.selectedSchedule?.paymentDay;
    reqObject['idPaymentMethod'] = widget.selectedSchedule?.idPaymentMethod;
    setState(() {
      paymentMethodsList?.forEach((element) {
        methodsDropdown.add(DropdownMenuItem(
          value: element.id,
          child: Text("${element.name}"),
        ));
      });
      context.loaderOverlay.hide();
    });
  }

  callDeleteSchedulePay() async {
    context.loaderOverlay.show();
    await deleteSchedulePay(widget.selectedSchedule?.id ?? 0);
    context.loaderOverlay.hide();
    Navigator.pushNamedAndRemoveUntil(context, "wallet", (route) => false);
  }

  // ignore: long-method
  callUpdateSchedule() async {
    if (editScheduleFormKey.currentState?.validate() ?? false) {
      context.loaderOverlay.show();
      UpdateScheduleResponse response =
          await updateSchedule(widget.selectedSchedule?.id ?? 0, reqObject);
      context.loaderOverlay.hide();
      if (response.success ?? false) {
        // ignore: prefer-async-await
        showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            Future.delayed(const Duration(seconds: 3), () {
              Navigator.of(context).pop();
            });
            return NvAlert(
              hasTitle: true,
              titleText: copy('schedule.pay-updated'),
              content:
                  "${copy('schedule.update-info')} ${reqObject['paymentDay']}",
              type: "success",
            );
          },
        ).then((value) {
          Navigator.pushReplacementNamed(context, "wallet");
        });
      }
    }
  }

  // ignore: long-method
  showDeleteModal() {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      context: context,
      builder: (BuildContext context) {
        return NvBottomSheet(
          bottomSheetHeight: 300,
          iconRoute: "assets/images/warning.png",
          title: "¿Quieres dejar de domiciliar el pago?",
          subtitle: "",
          primaryButtonText: copy('common.confirm'),
          secondaryButtonText: copy('common.cancel'),
          primaryButtonVariant: "nv-bottom-sheet-primary",
          secondaryButtonVariant: "nv-bottom-sheet-secondary",
          primaryButtonAction: callDeleteSchedulePay,
          secondaryButtonAction: () => Navigator.pop(context),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => MyCards(paymentMethod: widget.paymentMethod),
          ),
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  MyCards(paymentMethod: widget.paymentMethod),
            ),
          ),
        ),
        body: Form(
          key: editScheduleFormKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Domiciliar pago",
                  style: AppThemeScope.of(context).typography.h2.semibold,
                ),
                const SizedBox(height: 40),
                const InputLabel(label: "Método de pago"),
                DropdownButtonFormField(
                  //ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value == 0) {
                      return copy('common.default-text-validation');
                    } else {
                      return null;
                    }
                  },
                  value: methodsDropdown.firstWhere(
                    (element) {
                      if (element.value ==
                          widget.selectedSchedule?.idPaymentMethod) {
                        return true;
                      }
                      return false;
                    },
                    orElse: () => methodsDropdown.first,
                  ).value,
                  menuMaxHeight: MediaQuery.of(context).size.height *
                      Constants.fiftyPercent,
                  items: methodsDropdown,
                  onChanged: (value) => reqObject["idPaymentMethod"] = value,
                ),
                const InputLabel(label: "Día de pago"),
                DropdownButtonFormField(
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value == 0) {
                      return copy('common.default-text-validation');
                    } else {
                      return null;
                    }
                  },
                  value: widget.selectedSchedule?.paymentDay ?? 0,
                  menuMaxHeight: MediaQuery.of(context).size.height *
                      Constants.fiftyPercent,
                  items: Constants.monthDaysAsDropdownItem,
                  onChanged: (value) => reqObject["paymentDay"] = value,
                ),
              ],
            ),
          ),
        ),
        bottomSheet: Container(
          decoration: const BoxDecoration(
            border: Border(
              top: BorderSide(color: AppTheme.black1),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                NvButton(label: "Actualizar", action: callUpdateSchedule),
                NvButton(
                  variant: ButtonVariant.tertiary,
                  label: "Eliminar",
                  action: showDeleteModal,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
