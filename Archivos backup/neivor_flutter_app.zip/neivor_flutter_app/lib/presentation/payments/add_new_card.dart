import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/general/general_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/kushki/kushki_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/general/document_types_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/payment_token_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/payment_methods_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

import 'widgets/widgets.dart';

class AddNewCard extends StatefulWidget {
  const AddNewCard({Key? key, this.commision}) : super(key: key);
  final PaymentCommission? commision;
  static List<DropdownMenuItem<int>> years = [
    DropdownMenuItem(
      value: DateTime.now().year,
      child: Text((DateTime.now().year).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 1,
      child: Text((DateTime.now().year + 1).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 2,
      child: Text((DateTime.now().year + 2).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 3,
      child: Text((DateTime.now().year + 3).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 4,
      child: Text((DateTime.now().year + 4).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 5,
      child: Text((DateTime.now().year + 5).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 6,
      child: Text((DateTime.now().year + 6).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 7,
      child: Text((DateTime.now().year + 7).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 8,
      child: Text((DateTime.now().year + 8).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 9,
      child: Text((DateTime.now().year + 9).toString().substring(2, 4)),
    ),
    DropdownMenuItem(
      value: DateTime.now().year + 10,
      child: Text((DateTime.now().year + 10).toString().substring(2, 4)),
    ),
  ];
  static const int _cvvMaxLength = 4;
  static const int _cvvMinLength = 3;

  @override
  State<AddNewCard> createState() => _AddNewCardState();
}

class _AddNewCardState extends State<AddNewCard> {
  String name = '';
  String lastName = '';
  bool saveCard = false;
  final GlobalKey<FormState> addCardFormKey = GlobalKey<FormState>();
  Map<String, dynamic> formValues = {};
  final MaskedTextController cardController = MaskedTextController(
    mask: "0000 0000 0000 0000",
  );
  List<Invoice>? selectedDebts;
  static const int _cardNumberLength = 16;
  ScrollController viewController = ScrollController();
  List<DocumentTypesResponse>? documentTypes;
  List<DropdownMenuItem<String>>? documentDropdown = [];
  String documentType = "";
  String documentNumber = "";
  final copy = AppMessages().getCopy;

  @override
  void initState() {
    callGetKushkiSettings();
    selectedDebts = BlocProvider.of<PaymentsBloc>(context).state.selectedDebts;
    setInitFormValues();
    if (GlobalUtils.countryId == Constants.coIntIdCode) callGetDocuments();
    super.initState();
  }

  callGetDocuments() async {
    documentTypes = await getDocumentTypes();
    setState(() {
      documentTypes?.forEach((element) {
        documentDropdown?.add(DropdownMenuItem(
          value: element.code ?? "",
          child: Text(
            element.code ?? '',
          ),
        ));
      });
    });
  }

  setInitFormValues() {
    formValues = {
      "card": {
        "cvv": "",
        "expiryMonth": "",
        "expiryYear": "",
        "name": "",
        "number": "",
      },
      "currency": "MXN",
      "isDeferred": false,
      "sessionId": "",
      "totalAmount": getTotalToPay(),
      "userId": "",
    };
  }

  callGetKushkiSettings() async {
    await getKushkiSettings();
  }

  Future<String> userId() async {
    String publicMerchantId = await isTest()
        ? "833d039e085242aa8d84497993226b90" // For test.
        : "b8c9b3bd12f940418fb825644f66a763"; // For develop.

    String firstCardNumbers = formValues['card']['number'].substring(0, 6);
    String lastCardNumbers = formValues['card']['number'].substring(12);

    return "$publicMerchantId$firstCardNumbers$lastCardNumbers";
  }

  // ignore: long-method
  callGetPaymentToken() async {
    context.loaderOverlay.show();
    formValues['card']['name'] = '$name $lastName';
    formValues['userId'] = await userId();
    PaymentTokenResponse? paymentToken = await getPaymentToken(
      formValues,
    );
    if (paymentToken != null) {
      callPayCard(paymentToken.token ?? '');
    } else {
      context.loaderOverlay.hide();
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Future.delayed(const Duration(seconds: 2), () {
            Navigator.of(context).pop();
          });
          return const NvAlert(
            type: "error",
            content: "Número de tarjeta no válido, verifique los datos.",
          );
        },
      );
    }
  }

  List<Map<String, dynamic>> selectedAsJson() {
    List<Map<String, dynamic>> result = [];
    selectedDebts?.forEach((element) {
      result.add({
        "idInvoice": element.id,
        "value": element.valueToPay,
      });
    });
    return result;
  }

  // ignore: long-method
  double getTotalToPay() {
    double totalValue = 0;
    selectedDebts?.forEach((element) {
      totalValue = totalValue + (element.valueToPay ?? 0);
    });
    if (widget.commision != null) {
      widget.commision?.paymentCommissionList?.forEach((commisionItem) {
        if (commisionItem.idCommissionCriteria == 1 &&
            commisionItem.state == 1) {
          totalValue =
              totalValue + (totalValue * (commisionItem.value ?? 0) / 100);
        } else if (commisionItem.idCommissionCriteria == 1 &&
            commisionItem.state == 1) {
          totalValue = (totalValue + (commisionItem.value ?? 0));
        }
      });
    }
    return double.parse(totalValue.toStringAsFixed(2));
  }

  // ignore: long-method
  callPayCard(String paymentToken) async {
    Map<String, dynamic> requestObj = {
      "userInvoicePaymentList": selectedAsJson(),
      "paymentMethodType": {"id": 7},
      "paymentMethod": {
        "payer": {
          "name": name,
          "lastname": lastName,
          "email": UserUtils.currentUser?.email,
          "documentNumber": UserUtils.currentUser?.documentNumber,
          "contactPhone": UserUtils.currentUser?.mobilePhone,
        },
        "creditCard": {
          "cardNumber": formValues['card']['number'],
          "tokenize": saveCard,
          "dynamicCvv": true,
        },
      },
      "enterprise": {
        "id": UserUtils.currentEnterprise?.id,
      },
      "servicePoint": {
        "id": UserUtils.currentServicePoint?.id,
      },
      "userAgent": GlobalUtils.deviceInfo.model,
      "zyosUser": {
        "id": UserUtils.currentUser?.id,
      },
      "paymentToken": paymentToken,
    };
    context.loaderOverlay.hide();
    if (!mounted) return;
    Navigator.pushNamed(
      context,
      "confirmPay",
      arguments: {
        "commision": widget.commision,
        "requestObj": requestObj,
        "suscriptionData": formValues,
      },
    );
  }

  bool isCardExpired() {
    if ((formValues['card']['expiryMonth'] != null &&
            formValues['card']['expiryMonth'].isNotEmpty) &&
        (formValues['card']['expiryMonth'] != null &&
            formValues['card']['expiryYear'].isNotEmpty)) {
      String date = formValues['card']['expiryMonth'] +
          "/" +
          formValues['card']['expiryYear'];
      DateFormat dateFormatter = DateFormat("MM/yy");
      DateTime formDate = dateFormatter.parse(date);
      return formDate.isBefore(DateTime.now());
    }
    return false;
  }

  // ignore: long-method
  generateJsonPay() {
    Map<String, dynamic> requestObj = {
      "userInvoicePaymentList": selectedAsJson(),
      "paymentMethodType": {
        "id": 3,
      },
      "paymentMethod": {
        "payer": {
          "name": name,
          "lastname": lastName,
          "documentType": documentType,
          "documentNumber": documentNumber,
          "email": UserUtils.currentUser?.email,
        },
        "creditCard": {
          "cardNumber": formValues['card']['number'],
          "expirationDate": formValues['card']['expiryMonth'] +
              "/" +
              formValues['card']['expiryYear'],
          "cvv": formValues['card']['cvv'],
          "installment": 1,
          "tokenize": saveCard,
        },
      },
      "enterprise": {
        "id": UserUtils.currentEnterprise?.id,
      },
      "servicePoint": {
        "id": UserUtils.currentServicePoint?.id,
      },
      "userAgent": GlobalUtils.deviceInfo.model,
      "zyosUser": {
        "id": UserUtils.currentUser?.id,
      },
    };
    if (!mounted) return;
    Navigator.pushNamed(
      context,
      "confirmPay",
      arguments: {
        "notRegisteredCard": null,
        "requestObj": requestObj,
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'paymentMethods',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'paymentMethods',
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          controller: viewController,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Form(
            key: addCardFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  copy('payments-scheduler.credit-debit'),
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(
                  height: 24,
                ),
                InputLabel(label: copy('payments.card number')),
                TextFormField(
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return copy('common.default-text-validation');
                    } else if (value.length < _cardNumberLength) {
                      return copy('payments.must-contain-16-digits');
                    }
                    return null;
                  },
                  keyboardType: TextInputType.number,
                  controller: cardController,
                  decoration: InputDecoration(
                    hintText: "4444 0000 6666 1211",
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width -
                          Constants.defaultMarginSum,
                    ),
                  ),
                  onChanged: (value) => setState(() {
                    formValues["card"]['number'] = value.replaceAll(" ", "");
                  }),
                ),
                InputLabel(label: copy('messages.name')),
                TextFormField(
                  onChanged: (value) => name = value,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(
                      RegExp(Constants.onlyAlphaRegex),
                    ),
                  ],
                  keyboardType: TextInputType.name,
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return copy('common.default-text-validation');
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    hintText: copy('payments-scheduler.like-card'),
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width -
                          Constants.defaultMarginSum,
                    ),
                  ),
                ),
                InputLabel(label: copy('payments.surname')),
                TextFormField(
                  onChanged: (value) => lastName = value,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(
                      RegExp(Constants.onlyAlphaRegex),
                    ),
                  ],
                  keyboardType: TextInputType.name,
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return copy('common.default-text-validation');
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    hintText: copy('payments-scheduler.like-card'),
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width -
                          Constants.defaultMarginSum,
                    ),
                  ),
                ),
                if (GlobalUtils.countryId == Constants.coIntIdCode) ...[
                  InputLabel(
                    label: copy('common.document'),
                  ),
                  Row(
                    children: [
                      DropdownButtonFormField(
                        isExpanded: true,
                        decoration: InputDecoration(
                          isCollapsed: true,
                          hintText: copy('common.type'),
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width *
                                    Constants.thirtyPercent -
                                Constants.defaultMarginSum,
                          ),
                        ),
                        items: documentDropdown,
                        onChanged: (value) => setState(() {
                          documentType = value as String;
                        }),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      TextFormField(
                        onChanged: (value) => setState(() {
                          documentNumber = value;
                        }),
                        keyboardType: TextInputType.number,
                        maxLength: 10,
                        // ignore: prefer-extracting-callbacks
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return copy('common.default-text-validation');
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          counter: const SizedBox(),
                          hintText: 'Ej. 123456798542',
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width *
                                    Constants.seventyPercent -
                                Constants.defaultMargin,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
                InputLabel(
                  label: copy('payments.expiration-date'),
                ),
                Row(
                  children: [
                    DropdownButtonFormField(
                      // ignore: prefer-extracting-callbacks
                      validator: (value) {
                        if (value == null) {
                          return copy('common.default-text-validation');
                        } else {
                          return null;
                        }
                      },
                      decoration: InputDecoration(
                        hintText: copy('charges.month'),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width *
                                  Constants.fiftyPercent -
                              Constants.defaultMarginSum,
                        ),
                      ),
                      items: Constants.months,
                      onChanged: (value) => setState(() {
                        formValues["card"]['expiryMonth'] =
                            value?.toString().length == 1
                                ? "0$value"
                                : value.toString();
                      }),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    DropdownButtonFormField(
                      onChanged: (value) => setState(() {
                        formValues["card"]['expiryYear'] =
                            value.toString().substring(2, 4);
                      }),
                      validator: (value) => value == null
                          ? copy('common.default-text-validation')
                          : null,
                      decoration: InputDecoration(
                        hintText: copy('charges.year'),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width *
                                  Constants.fiftyPercent -
                              Constants.defaultMargin,
                        ),
                      ),
                      items: AddNewCard.years,
                    ),
                  ],
                ),
                if (isCardExpired())
                  Text(
                    copy('payments.the-card-is-expired'),
                    style: const TextStyle(color: AppTheme.coral0Main),
                  ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const InputLabel(label: "CVV"),
                    const SizedBox(width: 6),
                    Tooltip(
                      margin: EdgeInsets.fromLTRB(
                        MediaQuery.of(context).size.width *
                            Constants.tenPercent,
                        0,
                        MediaQuery.of(context).size.width *
                            Constants.twentyPercent,
                        0,
                      ),
                      waitDuration: const Duration(seconds: 3),
                      decoration: BoxDecoration(
                        color: AppTheme.blueIndigo0Main
                            .withOpacity(Constants.eightyPercent),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(4)),
                      ),
                      triggerMode: TooltipTriggerMode.tap,
                      message: copy('payments.cvv-explain'),
                      child: const Icon(
                        Icons.info_outline,
                        size: 13,
                      ),
                    ),
                  ],
                ),
                TextFormField(
                  obscureText: true,
                  maxLength: AddNewCard._cvvMaxLength,
                  keyboardType: TextInputType.number,
                  onChanged: (value) => setState(() {
                    formValues["card"]['cvv'] = value;
                  }),
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return copy('common.default-text-validation');
                    } else if (value.length < AddNewCard._cvvMinLength) {
                      return copy('payments.minimum-3-digits');
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    counter: const SizedBox(height: 0),
                    hintText: "123",
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width *
                              Constants.fiftyPercent -
                          Constants.defaultMarginSum,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      copy('payments.save card'),
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                      ),
                    ),
                    Switch(
                      activeColor: AppTheme.turquoise4,
                      value: saveCard,
                      onChanged: (value) => setState(() {
                        saveCard = value;
                      }),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 32),
                  child: NvButton(
                    variant: "primary",
                    label: copy('common.continue'),
                    // ignore: prefer-extracting-callbacks
                    action: () {
                      if ((addCardFormKey.currentState?.validate() ?? false) &&
                          !isCardExpired()) {
                        GlobalUtils.countryId == Constants.coIntIdCode
                            ? generateJsonPay()
                            : callGetPaymentToken();
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
