import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/delete_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/get_schedules_response.dart';
import 'package:neivor_flutter_app/helpers/string_helper.dart';
import 'package:neivor_flutter_app/presentation/payments/edit_schedule.dart';
import 'package:neivor_flutter_app/presentation/payments/schedule_form.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class MyCards extends StatefulWidget {
  final UserPaymentMethodResponse? paymentMethod;
  const MyCards({Key? key, this.paymentMethod}) : super(key: key);

  @override
  State<MyCards> createState() => _MyCardsState();
}

class _MyCardsState extends State<MyCards> {
  GetSchedulesResponse? schedulesPayments;
  // ignore: prefer-correct-identifier-length
  List<Data>? filteredSchedulesPayments;
  final copy = AppMessages().getCopy;
  @override
  void initState() {
    callGetSchedulePayment();
    super.initState();
  }

  callGetSchedulePayment() async {
    context.loaderOverlay.show();
    schedulesPayments = await getSchedulePayment();
    setState(() {
      filteredSchedulesPayments = schedulesPayments?.data
          ?.where(
            (element) =>
                (element.idPaymentMethod == widget.paymentMethod?.id) &&
                (element.idServicePoint == UserUtils.currentServicePoint?.id),
          )
          .toList();
    });
    context.loaderOverlay.hide();
  }

  // ignore: long-method
  getCardLogo(String string) {
    String newString = string.replaceAllMapped(RegExp(r"[0-9]*\** *"), (_) {
      return '';
    });
    switch (newString.toUpperCase()) {
      case 'MASTERCARD':
      case 'MASTER':
        return "payment/cc-brand/logo-mastercard.png";
      case 'VISA':
        return "payment/cc-brand/logo-visa.png";
      case 'DISCOVER':
        return "payment/cc-brand/logo-discover.png";
      case 'DINERS':
      case 'DINERSCLUB':
        return "payment/cc-brand/logo-diners.png";
      default:
        {
          "payment/cc-brand/credit-card.png";
        }
    }
  }

  // ignore: long-method
  callDeletePaymentMethod() async {
    context.loaderOverlay.show();
    Map<String, dynamic> req = {
      "enterprise": {
        "id": UserUtils.currentEnterprise?.id ?? 0,
      },
      "paymentMethod": {
        "id": widget.paymentMethod?.id ?? 0,
      },
      "zyosUser": {
        "id": UserUtils.currentUser?.id ?? 0,
      },
    };
    DeletePaymentMethodResponse response = await deletePaymetMethod(req);
    context.loaderOverlay.hide();
    if (response.success ?? false) {
      Navigator.pushReplacementNamed(context, "wallet");
    }
  }

  String get lastNumbers {
    return widget.paymentMethod?.name?.replaceAll(RegExp(r"\D"), "") ?? '';
  }

  String get cardBrand {
    return (widget.paymentMethod?.name?.replaceAllMapped(
              RegExp(r"[0-9]*\** *"),
              (_) {
                return '';
              },
            ) ??
            '')
        .toLowerCase()
        .capitalize();
  }

  // ignore: long-method
  showDeleteModal() {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      context: context,
      builder: (BuildContext context) {
        return NvBottomSheet(
          bottomSheetHeight: 300,
          iconRoute: "assets/images/trash-delete.png",
          title: AppMessages()
              .getCopy('schedule.delete-msg', [cardBrand, lastNumbers]),
          subtitle: "",
          primaryButtonText: copy('unionrequest.delete-label'),
          secondaryButtonText: copy('profile.cancel'),
          primaryButtonVariant: "nv-bottom-sheet-primary",
          secondaryButtonVariant: "nv-bottom-sheet-secondary",
          primaryButtonAction: () => callDeletePaymentMethod(),
          secondaryButtonAction: () => Navigator.pop(context),
        );
      },
    );
  }

  // ignore: long-method
  showwarningModal() {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 32, 16, 0),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16.0),
              topRight: Radius.circular(16.0),
            ),
          ),
          height: MediaQuery.of(context).size.height * Constants.fourtyPercent,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              NvImage(
                icon: 'Interface, Essential/Warning',
                color:
                    AppThemeScope.of(context).colors.secondary.indigoBlue.main,
                width: 40,
              ),
              const SizedBox(
                height: 16,
              ),
              Text(
                "Importante",
                style: AppThemeScope.of(context).typography.h3.medium,
              ),
              const SizedBox(
                height: 16,
              ),
              Text(
                copy('schedule.existing-info'),
                style: AppThemeScope.of(context).typography.bd1.light,
                textAlign: TextAlign.center,
              ),
              const SizedBox(
                height: 16,
              ),
              NvButton(
                label: copy('schedule.understand'),
                action: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      },
    );
  }

  goToSchedule() {
    bool? filtered = schedulesPayments?.data?.any((element) =>
        (element.idServicePoint == UserUtils.currentServicePoint?.id));
    if (filtered ?? false) {
      showwarningModal();
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              ScheduleForm(paymentMethod: widget.paymentMethod),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "wallet");
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacementNamed(context, "wallet"),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                copy("schedule.my-cards"),
                style: AppThemeScope.of(context).typography.h2.semibold,
              ),
              const SizedBox(
                height: 40,
              ),
              Card(
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  side: BorderSide(color: AppTheme.black2),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              NvImage(
                                width: 35,
                                height: 24,
                                imageUrl: getCardLogo(
                                  widget.paymentMethod?.name ?? '',
                                ),
                              ),
                              const SizedBox(
                                width: 16,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.paymentMethod?.name ?? '',
                                    style: AppThemeScope.of(context)
                                        .typography
                                        .bd1
                                        .medium,
                                  ),
                                  Text(
                                    "${widget.paymentMethod?.payer?.name} ${widget.paymentMethod?.payer?.lastname}",
                                    style: AppThemeScope.of(context)
                                        .typography
                                        .caption
                                        .xxxsLight,
                                  ),
                                ],
                              ),
                            ],
                          ),
                          GestureDetector(
                            onTap: showDeleteModal,
                            child: const NvImage(
                              icon: "Emails/Trash, Delete, Bin",
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      const Divider(
                        thickness: 1,
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      if (!(filteredSchedulesPayments?.isEmpty ?? true)) ...[
                        Text(
                          copy("schedule.scheduled-payments"),
                          style:
                              AppThemeScope.of(context).typography.st1.medium,
                        ),
                        const SizedBox(
                          height: 32,
                        ),
                        ListView.builder(
                          shrinkWrap: true,
                          itemCount: filteredSchedulesPayments?.length ?? 0,
                          itemBuilder: (BuildContext context, int index) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      filteredSchedulesPayments?[index]
                                              .paymentProductType
                                              ?.name ??
                                          '',
                                      style: AppThemeScope.of(context)
                                          .typography
                                          .bd1
                                          .medium,
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          Constants.twentyPercent,
                                      child: NvButton(
                                        variant: ButtonVariant.tertiaryLink,
                                        label: copy("schedule.edit"),
                                        action: () => Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => EditSchedule(
                                              selectedSchedule:
                                                  filteredSchedulesPayments?[
                                                      index],
                                              paymentMethod:
                                                  widget.paymentMethod,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Text(
                                  "${copy('schedule.amount')} ${Constants.currencyFormatter.format(filteredSchedulesPayments?[index].limitAmount)}",
                                  style: AppThemeScope.of(context)
                                      .typography
                                      .bd2
                                      .light,
                                ),
                                Text(
                                  "${copy('schedule.period')} ${copy('schedule.monthly')}",
                                  style: AppThemeScope.of(context)
                                      .typography
                                      .bd2
                                      .light,
                                ),
                                Text(
                                  "${copy('schedule.day')} ${filteredSchedulesPayments?[index].paymentDay}",
                                  style: AppThemeScope.of(context)
                                      .typography
                                      .bd2
                                      .light,
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomSheet: Padding(
          padding: const EdgeInsets.all(16),
          child: NvButton(
            variant: ButtonVariant.secondary,
            label: copy("schedule.add-scheduled"),
            action: () => goToSchedule(),
          ),
        ),
      ),
    );
  }
}
