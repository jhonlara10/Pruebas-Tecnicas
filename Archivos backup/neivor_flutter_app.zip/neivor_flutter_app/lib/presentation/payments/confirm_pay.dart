import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:lottie/lottie.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/kushki/kushki_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/kushki/kushki_suscriptions_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/pay_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/kushki/suscription_token_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/pay_response_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/payment_methods_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:url_launcher/url_launcher.dart';

class ConfirmPay extends StatefulWidget {
  const ConfirmPay({Key? key}) : super(key: key);

  @override
  State<ConfirmPay> createState() => _ConfirmPayState();
}

class _ConfirmPayState extends State<ConfirmPay> {
  UserPaymentMethodResponse? selectedPaymentMethod;
  List<Invoice>? selectedDebts;
  Map<String, dynamic>? payRequestObj;
  PaymentMethodResponse? notRegisteredCard;
  bool tAndC = false;
  PaymentCommission? commision;
  static const double _cardLogoWidth = 35;
  static const double _cardLogoHeight = 24;
  Map<String, dynamic>? suscriptionData;
  final copy = AppMessages().getCopy;

  @override
  void initState() {
    super.initState();
    selectedDebts = BlocProvider.of<PaymentsBloc>(context).state.selectedDebts;
    Future.delayed(Duration.zero, () {
      getArguments();
    });
  }

  getArguments() {
    setState(() {
      if (ModalRoute.of(context)?.settings.arguments != null) {
        Map<String, dynamic> args =
            ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>;
        selectedPaymentMethod = args['registeredCard'];
        payRequestObj = args['requestObj'];
        notRegisteredCard = args['notRegisteredCard'];
        commision = args['commision'];
        suscriptionData = args['suscriptionData'];
      }
    });
  }

  // ignore: long-method
  getCardLogo(String string) {
    String newString = string.replaceAllMapped(RegExp(r"[0-9]*\** *"), (_) {
      return '';
    });
    switch (newString.toUpperCase()) {
      case 'MASTERCARD':
      case 'MASTER':
        return "payment/cc-brand/logo-mastercard.png";
      case 'VISA':
        return "payment/cc-brand/logo-visa.png";
      case 'DISCOVER':
        return "payment/cc-brand/logo-discover.png";
      case 'DINERS':
      case 'DINERSCLUB':
        return "payment/cc-brand/logo-diners.png";
      default:
        {
          "payment/cc-brand/credit-card.png";
        }
    }
  }

  List<Map<String, dynamic>> selectedAsJson() {
    List<Map<String, dynamic>> result = [];
    selectedDebts?.forEach((element) {
      result.add({
        "idInvoice": element.id,
        "value": element.valueToPay,
      });
    });
    return result;
  }

  // ignore: long-method
  suscribeCard(PayResponseResponse invoiceData) async {
    context.loaderOverlay.show();
    SuscriptionTokenResponse suscriptionToken = await getSuscriptionToken(
      suscriptionData ?? {},
    );
    payRequestObj?['subscriptionToken'] = suscriptionToken.token;
    getPostPaymentMethod(payRequestObj ?? {});
    if (!mounted) return;
    context.loaderOverlay.hide();
    Navigator.pushReplacementNamed(
      context,
      "invoice",
      arguments: {
        "fromCardPay": {
          "invoice": invoiceData,
          "selectedPaymentMethod": selectedPaymentMethod,
        },
      },
    );
  }

  void tAndCAlert() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "warning",
          content: copy('payments.accept-terms'),
        );
      },
    );
  }

  // ignore: long-method
  buildRequestObject(SuscriptionTokenResponse kushkiCardSuscription) {
    payRequestObj ??= {
      "userInvoicePaymentList": selectedAsJson(),
      "paymentMethodType": {"id": 7},
      "paymentMethod": {
        "id": selectedPaymentMethod?.id,
        "idZyosUser": UserUtils.currentUser?.id,
        "idEnterprise": UserUtils.currentEnterprise?.id,
        "payer": {
          "name": selectedPaymentMethod?.payer?.name,
          "lastname": selectedPaymentMethod?.payer?.lastname,
          "email": UserUtils.currentUser?.email,
          "documentNumber": UserUtils.currentUser?.documentNumber,
          "contactPhone": UserUtils.currentUser?.mobilePhone,
        },
        "subscriptionId": selectedPaymentMethod?.subscriptionId,
        "creditCard": {
          "installment": 1,
        },
      },
      "enterprise": {
        "id": UserUtils.currentEnterprise?.id,
      },
      "servicePoint": {
        "id": UserUtils.currentServicePoint?.id,
      },
      "userAgent": GlobalUtils.deviceInfo.model,
      "zyosUser": {"id": UserUtils.currentUser?.id},
      "subscriptionToken": kushkiCardSuscription.token,
    };
    payRequestObj?['subscriptionId'] =
        selectedPaymentMethod?.subscriptionId ?? '';
    payRequestObj?['paymentToken'] = kushkiCardSuscription.token;
  }

  // ignore: long-method
  payProcessWNotSavedCard() async {
    showpayingAnimation(true);
    payRequestObj?['totalToPay'] =
        double.parse((getComissionCost + getTotalValue).toStringAsFixed(2));
    if (payRequestObj == null) {
      KushkiSuscriptionsResponse kushkiUserId = await getKushkiSuscriptions(
        selectedPaymentMethod?.subscriptionId ?? '',
      );
      Map<String, dynamic> cardSuscriptionReq = {
        "subscriptionId": selectedPaymentMethod?.subscriptionId ?? '',
        "userId": kushkiUserId.userId,
      };
      SuscriptionTokenResponse kushkiCardSuscription =
          await getKushkiCardSuscription(
        (selectedPaymentMethod?.subscriptionId ?? ''),
        cardSuscriptionReq,
      );
      buildRequestObject(kushkiCardSuscription);
    }
    PayResponse? response = await pay(payRequestObj ?? {});
    showpayingAnimation(false);
    if (response != null && (response.success ?? false)) {
      PayResponseResponse invoiceData = await getInvoiceResponseInfo(
        response.paymentOperation?.codRespuesta ?? '',
      );
      if (!mounted) return;
      context.loaderOverlay.hide();
      if (payRequestObj?['paymentMethod']['creditCard']['tokenize'] ?? false) {
        await suscribeCard(invoiceData);
      }
      Navigator.pushReplacementNamed(
        context,
        "invoice",
        arguments: {
          "fromCardPay": {
            "invoice": invoiceData,
            "selectedPaymentMethod": selectedPaymentMethod,
          },
        },
      );
    } else {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Timer(const Duration(seconds: 3), () {
            Navigator.of(context).pop();
          });
          return NvAlert(
            type: "error",
            content:
                response?.error?.message ?? copy('payments.payment-failed'),
          );
        },
      );
    }
  }

  String replaceCardNumber(String cardNumber) {
    if (cardNumber.isNotEmpty) {
      String cutedNumber =
          cardNumber.substring(cardNumber.length - 4, cardNumber.length);
      return "****$cutedNumber";
    } else {
      return "";
    }
  }

  selectPayMethod() async {
    if (GlobalUtils.countryId == Constants.coIntIdCode) {
      coPayProcess();
    } else {
      payProcessWNotSavedCard(); // This Apply only for MX.
    }
  }

  // ignore: long-method
  coPayProcess() async {
    showpayingAnimation(true);
    PayResponse? response = await pay(payRequestObj ?? {});
    showpayingAnimation(false);
    if (response != null && (response.success ?? false)) {
      PayResponseResponse invoiceData = await getInvoiceResponseInfo(
        response.paymentOperation?.codRespuesta ?? '',
      );
      if (!mounted) return;
      context.loaderOverlay.hide();
      if (payRequestObj?['paymentMethod']['creditCard']['tokenize'] ?? false) {
        suscribeCard(invoiceData);
      } else {
        Navigator.pushReplacementNamed(
          context,
          "invoice",
          arguments: {
            "fromCardPay": {
              "invoice": invoiceData,
              "selectedPaymentMethod": selectedPaymentMethod,
            },
          },
        );
      }
    } else {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Timer(const Duration(seconds: 3), () {
            Navigator.of(context).pop();
          });
          return NvAlert(
            type: "error",
            content:
                response?.error?.message ?? copy('payments.payment-failed'),
          );
        },
      );
    }
  }

  // ignore: long-method
  showpayingAnimation(bool show) {
    if (show) {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            alignment: Alignment.center,
            title: Column(
              children: [
                Lottie.asset(
                  'assets/images/paying-animation.zip',
                ),
                const Text(
                  'Tomará un momento, estamos procesando tu pago...',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );
    } else {
      Navigator.pop(context);
    }
  }

  double get getComissionCost {
    double totalComission = 0;
    if (commision == null) {
      return 0;
    } else {
      commision?.paymentCommissionList?.forEach((commisionItem) {
        if (commisionItem.idCommissionCriteria == 1 &&
            commisionItem.state == 1) {
          totalComission = getTotalValue * (commisionItem.value ?? 0) / 100;
        } else if (commisionItem.state == 1) {
          totalComission = getTotalValue + (commisionItem.value ?? 0);
        }
      });
    }
    return double.parse(totalComission.toStringAsFixed(2));
  }

  double get getTotalValue {
    double totalValue = 0;
    selectedDebts?.forEach((element) {
      totalValue = totalValue + (element.valueToPay ?? 0);
    });
    return totalValue;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              copy('payments.confirm-payment'),
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 26,
              ),
            ),
            const SizedBox(
              height: 24,
            ),
            Card(
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
                side: BorderSide(color: AppTheme.black2),
              ),
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(copy('charges.payment-method')),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Text(
                            copy('common.edit'),
                            style: const TextStyle(
                              color: AppTheme.turquoise4,
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    Row(
                      children: [
                        NvImage(
                          width: _cardLogoWidth,
                          height: _cardLogoHeight,
                          imageUrl: selectedPaymentMethod == null
                              ? '/payment/cc-brand/credit-card.png'
                              : getCardLogo(
                                  selectedPaymentMethod?.name ?? '',
                                ),
                        ),
                        const SizedBox(
                          width: 16,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              selectedPaymentMethod == null
                                  ? replaceCardNumber(
                                      payRequestObj?['paymentMethod']
                                              ['creditCard']['cardNumber'] ??
                                          '',
                                    )
                                  : selectedPaymentMethod?.name ?? '',
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              selectedPaymentMethod == null
                                  ? (payRequestObj?['paymentMethod']['payer']
                                              ['name'] ??
                                          '') +
                                      " " +
                                      (payRequestObj?['paymentMethod']['payer']
                                              ['lastname'] ??
                                          '')
                                  : selectedPaymentMethod?.payer?.name ?? '',
                              style: const TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              copy('payments.payment-single-installment.'),
                              style: const TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 12,
                                color: AppTheme.black3,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            Card(
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(8)),
                side: BorderSide(color: AppTheme.black2),
              ),
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(copy('charges.payment-resume')),
                        GestureDetector(
                          onTap: () => Navigator.pushReplacementNamed(
                            context,
                            "payments",
                          ),
                          child: Text(
                            copy('common.edit'),
                            style: const TextStyle(
                              color: AppTheme.turquoise4,
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    ListView.builder(
                      shrinkWrap: true,
                      itemCount: selectedDebts?.length ?? 0,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width *
                                    Constants.fiftyPercent,
                                child: Text(
                                  selectedDebts?[index].descriptionService ??
                                      '',
                                  overflow: TextOverflow.clip,
                                ),
                              ),
                              Text(
                                Constants.currencyFormatter
                                    .format(selectedDebts?[index].valueToPay),
                                overflow: TextOverflow.clip,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(AppMessages().getCopy('charges.transaction-cost')),
                        Text(Constants.currencyFormatter
                            .format(getComissionCost)),
                      ],
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          AppMessages().getCopy('charges.total-to-pay-label'),
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 18,
                          ),
                        ),
                        Text(
                          Constants.currencyFormatter
                              .format(getComissionCost + getTotalValue),
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            CheckboxListTile(
              contentPadding: const EdgeInsets.all(0),
              tristate: false,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(6),
                ),
              ),
              activeColor: AppTheme.turquoise4,
              controlAffinity: ListTileControlAffinity.leading,
              value: tAndC,
              onChanged: (value) {
                setState(() {
                  tAndC = value ?? false;
                });
              }, // Acept TYC.
              title: Transform.translate(
                offset: const Offset(-16, 0),
                child: RichText(
                  text: TextSpan(
                    style: const TextStyle(
                      height: 2,
                      fontSize: 10,
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w300,
                    ),
                    children: [
                      TextSpan(
                        text: copy('payments.i-accept-the'),
                      ),
                      TextSpan(
                        text: ' ${copy('payments.terms-and-conditions')}',
                        style: const TextStyle(
                          decoration: TextDecoration.underline,
                          fontWeight: FontWeight.w500,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () async {
                            const url =
                                'https://cdn.neivor.com/cdn/colombia/static/docs/reglamento.pdf#page=1';
                            // ignore: deprecated_member_use
                            if (await canLaunch(url)) {
                              // ignore: deprecated_member_use
                              await launch(
                                url,
                                forceSafariVC: false,
                              );
                            }
                          },
                      ),
                      TextSpan(
                        text: ' ${copy('payments.and-i-authorize-the')} ',
                      ),
                      TextSpan(
                        text: copy('payments.processing-of-personal-data'),
                        style: const TextStyle(
                          decoration: TextDecoration.underline,
                          fontWeight: FontWeight.w500,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () async {
                            const url =
                                'https://cdn.neivor.com/cdn/colombia/static/docs/reglamento.pdf#page=9';
                            // ignore: deprecated_member_use
                            if (await canLaunch(url)) {
                              // ignore: deprecated_member_use
                              await launch(url);
                            }
                          },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomSheet: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(width: 1, color: AppTheme.black2)),
        ),
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  copy('charges.secure-payment-with'),
                  style: const TextStyle(
                    fontWeight: FontWeight.w300,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                NvImage(
                  imageUrl: (GlobalUtils.countryId == Constants.coIntIdCode)
                      ? 'ds/icons/payvalida.svg'
                      : 'ds/icons/kushki-logo.png',
                  height: 18.5,
                  color: (GlobalUtils.countryId == Constants.coIntIdCode)
                      ? const Color(0xFF6630FF)
                      : null,
                ),
              ],
            ),
            ElevatedButton(
              onPressed: () => tAndC ? selectPayMethod() : tAndCAlert(),
              child: Text(
                "${copy('charges.pay-button')} ${Constants.currencyFormatter.format(getTotalValue + getComissionCost)}",
              ),
            ),
          ],
        ),
      ),
    );
  }
}
