import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/empty_view.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/movements_widgets/transaction_card.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class MovementsMain extends StatefulWidget {
  const MovementsMain({
    Key? key,
    this.servicePointId,
  }) : super(key: key);
  final int? servicePointId;

  @override
  State<MovementsMain> createState() => _MovementsMainState();
}

class _MovementsMainState extends State<MovementsMain> {
  List<Transaction>? transactionList;
  int count = 0;
  Function copy = AppMessages().getCopy;
  ListQueue<Transaction> orderedList = ListQueue<Transaction>();

  @override
  void initState() {
    callGetTransactions();
    super.initState();
  }

  // Trae las transacciones del servicio.
  callGetTransactions() async {
    context.loaderOverlay.show();
    var responseInvoices = await getTransactions(
      widget.servicePointId ?? UserUtils.currentServicePoint?.id,
    );
    transactionList = responseInvoices.data?.transactionList;
    orderPayToAsociateOnTopList();
    setState(() {});
    context.loaderOverlay.hide();
  }

  transactionObjectToCard(int index) {
    return transactionList?[index];
  }

  orderPayToAsociateOnTopList() {
    for (var element in transactionList ?? []) {
      _isToAssociatePayment(element)
          ? orderedList.addFirst(element)
          : orderedList.addLast(element);
    }
    transactionList = orderedList.toList();
  }

  bool _isToAssociatePayment(Transaction payment) {
    if (payment.state == 0 && payment.positiveBalance != null) {
      count++;
      return true;
    }
    return false;
  }

  _associatePaymentMessageForAdminUser() {
    return count == 1
        ? copy('payments.associate-pay')
        : copy('payments.associate-x-pays', ['$count']);
  }

  _associatePaymentMessageForUser() {
    return count == 1
        ? copy('charges.have-one-payment-to-asociate')
        : copy('charges.have-x-payments-to-asociate', ['$count']);
  }

  String get associationText {
    return UserUtils().isAdminUser()
        ? _associatePaymentMessageForAdminUser()
        : _associatePaymentMessageForUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: (transactionList?.isEmpty == true)
          ? EmptyView(fromTo: 'movements')
          : SingleChildScrollView(
              child: Column(
                children: [
                  const SizedBox(
                    height: 16,
                  ),
                  if (count > 0)
                    Container(
                      height: 45,
                      width: 350,
                      decoration: const BoxDecoration(
                        color:
                            Color.fromARGB(255, 216, 235, 243), //TODO: apptheme
                        border: Border(
                          left: BorderSide(
                            color: Colors.blue,
                            width: 10,
                          ), //TODO: apptheme
                        ),
                      ),
                      child: Center(
                        child: Text(
                          associationText,
                          style: const TextStyle(fontSize: 16),
                        ),
                      ),
                    ),

                  // Transaction list.
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: ListView.separated(
                      physics: const NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemCount: transactionList?.length ?? 0,
                      separatorBuilder: (context, index) {
                        return const SizedBox(
                          height: 16,
                        );
                      },
                      itemBuilder: ((context, index) {
                        return TransactionCard(
                          transaction: transactionObjectToCard(index),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
