import 'dart:async';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/discount_data_log_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/payment_schedule_response.dart';
import 'package:neivor_flutter_app/presentation/payments/my_cards.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/input_label.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_message.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';

class ScheduleForm extends StatefulWidget {
  final UserPaymentMethodResponse? paymentMethod;
  const ScheduleForm({Key? key, this.paymentMethod}) : super(key: key);

  @override
  State<ScheduleForm> createState() => _ScheduleFormState();
}

class _ScheduleFormState extends State<ScheduleForm> {
  final copy = AppMessages().getCopy;
  final Map<String, dynamic> formValues = {
    "idPaymentProductType": 1,
    "idPaymentPeriod": 1,
    "idServicePoint": UserUtils.currentServicePoint?.id ?? 0,
    "paymentDay": 0,
    "userCreation": UserUtils.currentUser?.id ?? 0,
  };
  GlobalKey<FormState> scheduleFormKey = GlobalKey<FormState>();
  DiscountDataLogResponse? discountResponse;
  @override
  void initState() {
    callDiscountDataLog();
    super.initState();
  }

  callDiscountDataLog() async {
    discountResponse = await getDiscountsDataLog();
    setState(() {});
  }

  // ignore: long-method
  getCardLogo(String string) {
    String newString = string.replaceAllMapped(RegExp(r"[0-9]*\** *"), (_) {
      return '';
    });
    switch (newString.toUpperCase()) {
      case 'MASTERCARD':
      case 'MASTER':
        return "payment/cc-brand/logo-mastercard.png";
      case 'VISA':
        return "payment/cc-brand/logo-visa.png";
      case 'DISCOVER':
        return "payment/cc-brand/logo-discover.png";
      case 'DINERS':
      case 'DINERSCLUB':
        return "payment/cc-brand/logo-diners.png";
      default:
        {
          "payment/cc-brand/credit-card.png";
        }
    }
  }

  // ignore: long-method
  processForm() async {
    if (scheduleFormKey.currentState?.validate() ?? false) {
      context.loaderOverlay.show();
      formValues["idPaymentMethod"] = widget.paymentMethod?.id ?? 0;
      PaymentScheduleResponse response = await schedulePayment(formValues);
      context.loaderOverlay.hide();
      if (response.success ?? false) {
        showModalBottomSheet(
          enableDrag: false,
          isDismissible: false,
          context: context,
          builder: (BuildContext context) {
            Timer(const Duration(seconds: 3), () async {
              Navigator.pushReplacementNamed(context, "wallet");
            });
            return Container(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16.0),
                  topRight: Radius.circular(16.0),
                ),
              ),
              height:
                  MediaQuery.of(context).size.height * Constants.thirtyPercent,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  NvImage(
                    imageUrl: "/ds/icons/check-success.svg",
                    width: MediaQuery.of(context).size.width *
                        Constants.twentyPercent,
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  Text(
                    copy("schedule.saved"),
                    style: AppThemeScope.of(context).typography.h5.semibold,
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Text(
                    "${copy('schedule.saved-scheduled')} ${UserUtils.currentServicePoint?.operationZone?.name} - ${UserUtils.currentServicePoint?.name}",
                    style: AppThemeScope.of(context).typography.bd1.medium,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );
          },
        );
      } else {
        showModalBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return Container(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16.0),
                  topRight: Radius.circular(16.0),
                ),
              ),
              height:
                  MediaQuery.of(context).size.height * Constants.twentyPercent,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  NvImage(
                    imageUrl: "/ds/icons/error-icon.svg",
                    width: MediaQuery.of(context).size.width *
                        Constants.twentyPercent,
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  Text(
                    copy('schedule.error'),
                    style: AppThemeScope.of(context).typography.h5.semibold,
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Text(
                    copy('schedule.error-msg'),
                    style: AppThemeScope.of(context).typography.bd1.medium,
                  ),
                ],
              ),
            );
          },
        );
      }
    }
  }

  String getDiscount(DiscountDataList discountObj) {
    if (discountObj.idCriteriaDiscount == 2) {
      return Constants.currencyFormatter.format(discountObj.discount);
    } else {
      return "${discountObj.discount} %";
    }
  }

  String get getDiscountString {
    List<String> newString = ['Plazo máximo para pagar con descuento'];
    discountResponse?.data?.discountDataList?.asMap().forEach((index, element) {
      newString.add(
        " de ${getDiscount(element)} hasta el día ${element.maxDateOfDiscount} ${(index != (discountResponse?.data?.discountDataList?.length ?? 0) - 1) ? 'y' : ''}",
      );
    });
    return newString.join();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => MyCards(paymentMethod: widget.paymentMethod),
          ),
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  MyCards(paymentMethod: widget.paymentMethod),
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                copy('schedule.schedule-pay'),
                style: AppThemeScope.of(context).typography.h2.semibold,
              ),
              Card(
                margin: const EdgeInsets.only(top: 16),
                elevation: 0,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  side: BorderSide(color: AppTheme.black2),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            copy('schedule.payment-method'),
                            style:
                                AppThemeScope.of(context).typography.bd1.medium,
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width *
                                Constants.thirtyPercent,
                            child: NvButton(
                              variant: ButtonVariant.tertiaryLink,
                              label: copy('schedule.edit'),
                              action: () => Navigator.pushReplacementNamed(
                                context,
                                "wallet",
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          NvImage(
                            height: 35,
                            imageUrl: getCardLogo(
                              widget.paymentMethod?.name ?? '',
                            ),
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.paymentMethod?.name ?? '',
                                style: AppThemeScope.of(context)
                                    .typography
                                    .bd2
                                    .medium,
                              ),
                              Text(
                                "${widget.paymentMethod?.payer?.name} ${widget.paymentMethod?.payer?.lastname}",
                                style: AppThemeScope.of(context)
                                    .typography
                                    .bd2
                                    .light,
                              ),
                              Text(
                                copy('schedule.pay-info'),
                                style: AppThemeScope.of(context)
                                    .typography
                                    .caption
                                    .xxsLight,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              NvMessage(
                child: Text(
                  copy('schedule.only-maintenance'),
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              InputLabel(label: copy('schedule.payment-day')),
              Form(
                key: scheduleFormKey,
                child: DropdownButtonFormField(
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (value == null || value == 0) {
                      return copy('common.default-text-validation');
                    } else {
                      return null;
                    }
                  },
                  value: Constants.monthDaysAsDropdownItem.first.value,
                  menuMaxHeight: MediaQuery.of(context).size.height *
                      Constants.fiftyPercent,
                  items: Constants.monthDaysAsDropdownItem,
                  onChanged: (value) => formValues["paymentDay"] = value,
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              if (discountResponse?.data?.discountDataList?.isNotEmpty ?? false)
                NvMessage(
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width - 32,
                    child: Text(
                      getDiscountString,
                      overflow: TextOverflow.clip,
                    ),
                  ),
                ),
            ],
          ),
        ),
        bottomSheet: BottomButton(
          action: processForm,
          buttonText: copy('common.confirm'),
        ),
      ),
    );
  }
}
