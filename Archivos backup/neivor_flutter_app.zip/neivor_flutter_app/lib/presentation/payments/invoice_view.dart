import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/associate/associate_payment_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/download_balance_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/pay_response_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/payment_schedule/get_schedules_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_invoice_response.dart';
import 'package:neivor_flutter_app/presentation/payments/history_detail_view.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/presentation/payments/schedule_form.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/dashed_divider.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:url_launcher/url_launcher.dart';

import 'widgets/custom_background.dart';

class InvoiceView extends StatefulWidget {
  const InvoiceView({Key? key}) : super(key: key);

  @override
  State<InvoiceView> createState() => _InvoiceViewState();
}

class _InvoiceViewState extends State<InvoiceView> {
  TransactionList? transaction;
  Invoice? invoice;
  PayResponseResponse? cardInvoice;
  Transaction? movement;
  AssociatePaymentResponse? associatedPay;
  int? associatedPayIdBalance;
  final copy = AppMessages().getCopy;
  bool fromHistory = false;
  bool fromCardPay = false;
  bool fromMovements = false;
  bool fromAssociation = false;
  static const approvedId = 0;
  static const pendingIdSPEI = 4;
  UserPaymentMethodResponse? selectedPaymentMethod;
  bool? hasSchedulePay;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      extractHistoryArgs();
    });
  }

  // ignore: long-method
  extractHistoryArgs() {
    setState(() {
      if (ModalRoute.of(context)?.settings.arguments != null) {
        Map<String, dynamic> args =
            ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>;
        fromHistory = args.containsKey("fromHistory");
        fromCardPay = args.containsKey("fromCardPay");
        fromMovements = args.containsKey("fromMovements");
        fromAssociation = args.containsKey("fromAssociation");
        if (fromHistory) {
          transaction = args['fromHistory']['transaction'];
          invoice = args['fromHistory']['invoice'];
        } else if (fromCardPay) {
          cardInvoice = args['fromCardPay']['invoice'];
          selectedPaymentMethod = args['fromCardPay']['selectedPaymentMethod'];
          hasSchedulePays();
        } else if (fromMovements) {
          movement = args['fromMovements']['movement'];
          if (movement?.dpqTransaction != null &&
              (movement?.dpqTransaction?.isNotEmpty ?? false)) {
            getPayResponse(movement?.dpqTransaction ?? '');
          }
        } else if (fromAssociation) {
          associatedPay = args['fromAssociation']['associatedPay'];
          associatedPayIdBalance =
              args['fromAssociation']['associatedPayIdBalance'];
        }
      }
    });
  }

  getPayResponse(dpqTransaction) async {
    context.loaderOverlay.show();
    cardInvoice = await getInvoiceResponseInfo(dpqTransaction);
    if (cardInvoice?.paymentError != null) {
      cardInvoice = null;
    }
    setState(() {
      context.loaderOverlay.hide();
    });
  }

  hasSchedulePays() async {
    context.loaderOverlay.show();
    GetSchedulesResponse? schedulesPayments = await getSchedulePayment();
    setState(() {
      hasSchedulePay = schedulesPayments.data?.any((element) =>
          (element.idServicePoint == UserUtils.currentServicePoint?.id));
    });
    context.loaderOverlay.hide();
  }

  // ignore: long-method
  String get getPaymentMethodName {
    if (!fromAssociation) {
      switch (transaction?.paymentType ??
          cardInvoice?.idPaymentType ??
          movement?.idPaymentType ??
          40) {
        case 0:
          return copy('payment.bonus-discount');
        case 1:
          return copy('payment.cash');
        case 2:
          return copy('payment.check');
        case 3:
          return copy('payment.bank-deposit');
        case 5:
          return copy('common.other');
        case 6:
          return copy('charges.positive-balance');
        case 8:
          return copy('payment.balance-association');
        case 9:
          return copy('payment.electronic payment');
        case 10:
          return copy('payment.face-to-face-payment-with-card');
        case 25:
          return copy('payments-scheduler.credit-card');
        case 34:
          return copy('payment.transfer');
        case 36:
          return copy('payment.new-spei');
        default:
          return copy('common.other');
      }
    } else {
      return associatedPay?.data?.paymentTypeName ?? '';
    }
  }

  double calculateTotalPay() {
    double totalPaymentList = 0;
    cardInvoice?.paymentList?.forEach((element) {
      totalPaymentList += (element.value ?? 0);
    });

    return totalPaymentList + (cardInvoice?.transactionCost ?? 0);
  }

  String get getInvoiceNumber {
    if (fromHistory) {
      return invoice?.reference ?? '';
    } else if (fromCardPay) {
      return cardInvoice?.invoice?.reference ?? '';
    } else if (fromMovements) {
      return movement?.balanceNumber.toString() ?? '';
    } else if (fromAssociation) {
      return associatedPay?.data?.paymentInvoiceValueList?.last.idInvoice
              .toString() ??
          '';
    }
    return "";
  }

  // ignore: long-method
  String get getInvoiceDate {
    if (fromHistory) {
      return GlobalUtils().formatDateUtil(
        (transaction?.date ?? ''),
        "yyyy/MM/dd HH:mm:ss",
        "dd/MM/yyyy",
      );
    } else if (fromCardPay) {
      return GlobalUtils().formatDateUtil(
        (cardInvoice?.date ?? ''),
        "yyyy/MM/dd HH:mm:ss",
        "dd/MM/yyyy",
      );
    } else if (fromMovements) {
      return GlobalUtils().formatDateUtil(
        (movement?.date ?? cardInvoice?.date ?? ''),
        "yyyy/MM/dd HH:mm:ss",
        "dd/MM/yyyy",
      );
    } else if (fromAssociation) {
      return GlobalUtils().formatDateUtil(
        (associatedPay?.data?.dateChange ?? ''),
        "yyyy/MM/dd",
        "dd/MM/yyyy",
      );
    }
    return "";
  }

  // ignore: long-method
  String get getStatusName {
    // TODO check if diferent payment types has diferent status id.
    // ! history is already checked need to verify
    // ! from card pay only comes to here when is approved
    // ! from association always approved
    // ! from movements need to be verifyed
    if (fromHistory) {
      switch (invoice?.idInvoiceState) {
        case 1:
          return copy('common.pending');
        case 2:
          return copy('charges.paid');
        case 3:
          return copy('payment.overdue');
        case 4:
          return copy('charges.partial-payment');
        case 5:
          return copy('payment.proccess');
      }
    } else if (fromCardPay) {
      return copy('common.approved');
    } else if (fromMovements) {
      switch (movement?.state ?? cardInvoice?.state) {
        case 0:
          return copy('common.approved');
        case 1:
          return copy('common.pending');
        case 2:
          return copy('payment.reject');
        case 4:
          return copy('messages.inprogress');
        case 5:
          return copy('payment.pending-cash-payment');
      }
    } else if (fromAssociation) {
      return copy('common.approved');
    }
    return "";
  }

  // ignore: long-method
  String get getStateImage {
    if (fromHistory) {
      switch (invoice?.idInvoiceState) {
        case 1:
          return 'ds/icons/triangle-yellow-alert.svg';
        case 2:
          return 'ds/icons/check-success.svg';
        case 3:
          return 'ds/icons/error-icon.svg';
        case 4:
          return 'ds/icons/check-success.svg';
        case 5:
          return 'ds/icons/triangle-yellow-alert.svg';
      }
    }
    switch (movement?.state) {
      case approvedId:
        return 'ds/icons/check-success.svg';
      case 5:
      case 1:
      case pendingIdSPEI:
        return 'ds/icons/triangle-yellow-alert.svg';
      case 2:
        return 'ds/icons/error-icon.svg';
      default:
        return 'ds/icons/check-success.svg';
    }
  }

  // ignore: long-method
  backAction() {
    if (fromCardPay) {
      return Navigator.pushReplacementNamed(context, "payments");
    } else if (fromHistory) {
      return Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (context) => HistoryPaymentDetail(
            idInvoice: invoice?.id.toString(),
            invoice: invoice,
          ),
        ),
        (Route<dynamic> route) => false,
      );
    } else if (fromMovements || fromAssociation) {
      return Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const MainPayments(isComeFrom: "movements"),
        ),
      );
    }
  }

  String get getAuthorization {
    if (fromHistory && transaction?.dpqTransaction != null) {
      return transaction?.dpqTransaction ?? '';
    } else if (fromCardPay) {
      return cardInvoice?.dpqTransaction ?? '';
    } else if (fromMovements && movement?.dpqTransaction != null) {
      return movement?.dpqTransaction ?? '';
    } else if (fromAssociation && associatedPay?.data?.payReference != null) {
      return associatedPay?.data?.payReference ?? '';
    }
    return "";
  }

  int get getItemCount {
    if ((fromHistory && invoice != null) || fromAssociation) {
      return 1;
    } else if (fromCardPay) {
      return cardInvoice?.paymentList?.length ?? 0;
    } else if (fromMovements) {
      if (movement?.dpqTransaction != null &&
          (movement?.dpqTransaction?.isNotEmpty ?? false) &&
          cardInvoice != null) {
        return cardInvoice?.paymentList?.length ?? 1;
      } else {
        return 1;
      }
    }
    return 0;
  }

  // ignore: long-method
  String getDescriptionService(index) {
    if (fromHistory) {
      return invoice?.descriptionService ?? '';
    } else if (fromCardPay) {
      return (cardInvoice?.paymentList?[index].invoice?.descriptionService ??
          'Pago anticipado');
    } else if (fromMovements) {
      if (movement?.dpqTransaction != null &&
          (movement?.dpqTransaction?.isNotEmpty ?? false) &&
          cardInvoice != null &&
          cardInvoice?.paymentList != null) {
        return cardInvoice?.paymentList?[index].invoice?.descriptionService ??
            '';
      }
      return movement?.invoice?.descriptionService ?? copy('prepay-button');
    } else if (fromAssociation) {
      return copy('payment.balance-association');
    }
    return "";
  }

  // ignore: long-method
  String getItemValue(index) {
    if (fromHistory) {
      return Constants.currencyFormatter.format((transaction?.payedValue ?? 0));
    } else if (fromCardPay) {
      return Constants.currencyFormatter
          .format(cardInvoice?.paymentList?[index].value);
    } else if (fromMovements) {
      if (fromMovements &&
          movement?.dpqTransaction != null &&
          (movement?.dpqTransaction?.isNotEmpty ?? false) &&
          cardInvoice != null &&
          cardInvoice?.paymentList != null) {
        return Constants.currencyFormatter
            .format(cardInvoice?.paymentList?[index].value ?? 0);
      }
      return Constants.currencyFormatter.format(movement?.payedValue ?? 0);
    } else if (fromAssociation) {
      return Constants.currencyFormatter.format(
        associatedPay?.data?.paymentInvoiceValueList?.last.payedValue ?? 0,
      );
    }
    return "0";
  }

  double get getTransactionCost {
    if (fromHistory) {
      return transaction?.transactionCost ?? 0;
    } else if (fromCardPay) {
      return cardInvoice?.transactionCost ?? 0;
    } else if (fromAssociation) {
      return 0;
    } else if (fromMovements) {
      return movement?.transactionCost ?? 0;
    }
    return 0;
  }

  // ignore: long-method
  String get getTotalPayed {
    if (fromHistory) {
      return Constants.currencyFormatter.format(
        (transaction?.payedValue ?? 0) + (getTransactionCost),
      );
    } else if (fromCardPay) {
      return Constants.currencyFormatter.format(
        (cardInvoice?.payedValue ?? 0) + (getTransactionCost),
      );
    } else if (fromMovements) {
      if (fromMovements &&
          movement?.dpqTransaction != null &&
          (movement?.dpqTransaction?.isNotEmpty ?? false) &&
          cardInvoice != null &&
          cardInvoice?.paymentList != null) {
        double total = 0;
        cardInvoice?.paymentList?.forEach((element) {
          total += element.value ?? 0;
        });
        return Constants.currencyFormatter.format(
          (total) + (getTransactionCost),
        );
      } else {
        return Constants.currencyFormatter.format(
          (movement?.payedValue ?? 0) + (getTransactionCost),
        );
      }
    } else if (fromAssociation) {
      return Constants.currencyFormatter.format(
        (associatedPay?.data?.paymentInvoiceValueList?.last.payedValue ?? 0) +
            getTransactionCost,
      );
    }
    return "";
  }

  bool get showThanks {
    return getStatusName == copy('common.approved') ? true : false;
  }

  // ignore: long-method
  downloadUrl() async {
    try {
      context.loaderOverlay.show();
      Map<String, dynamic> json = {
        "idBalance": 0,
        "idZyosUser": UserUtils.currentUser?.id,
      };
      if ((movement?.idBalance != null) ||
          (transaction?.idBalance != null) ||
          ((cardInvoice?.idBalance != null)) ||
          associatedPayIdBalance != null) {
        json["idBalance"] = movement?.idBalance ??
            transaction?.idBalance ??
            cardInvoice?.idBalance ??
            associatedPayIdBalance;
      }
      DownloadBalanceResponse response = await downloadBalance(json);
      if (response.success ?? false) {
        Timer(
          Duration(milliseconds: response.data?.millisDelay ?? 3),
          // ignore: prefer-extracting-callbacks
          () async {
            if (Platform.isAndroid) {
              // ignore: deprecated_member_use
              launch(response.data?.url ?? '');
            } else {
              // ignore: deprecated_member_use
              launch(response.data?.url ?? '', forceSafariVC: false);
            }
            context.loaderOverlay.hide();
          },
        );
      }
    } catch (e) {
      context.loaderOverlay.hide();
      log(e.toString());
    }
  }

  goToSchedule() {
    if (selectedPaymentMethod != null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) =>
              ScheduleForm(paymentMethod: selectedPaymentMethod),
        ),
      );
    } else {
      Navigator.pushReplacementNamed(context, "wallet");
    }
  }

  bool get isForRecurrent {
    bool hasMaintenanceDebt = BlocProvider.of<PaymentsBloc>(context)
            .state
            .selectedDebts
            ?.any((element) => element.idInvoiceType == 1) ??
        false;
    return fromCardPay && hasMaintenanceDebt && !(hasSchedulePay ?? false);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        backAction();
        return Future.value(false);
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: NvAppBar(
          bgColor: Colors.transparent,
          backAction: backAction,
        ),
        body: Stack(
          children: [
            const CustomBackground(),
            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 34, 16, 8),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const NvImage(
                          imageUrl: 'ds/icons/neivor-logo-white.svg',
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              copy(
                                'payment.receipt-number',
                                [getInvoiceNumber],
                              ),
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              copy(
                                'payment.date',
                                [getInvoiceDate],
                              ),
                              style: const TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Card(
                      margin: const EdgeInsets.only(top: 24),
                      elevation: 5,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(24, 40, 24, 32),
                        child: Column(
                          children: [
                            NvImage(
                              imageUrl: getStateImage,
                              width: 48,
                              height: 48,
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Text(
                              getStatusName,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 26,
                              ),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            if (getAuthorization != "")
                              Text(
                                copy(
                                  'charges.authorization',
                                  [getAuthorization],
                                ),
                              ),
                            const SizedBox(
                              height: 8,
                            ),
                            if (!fromCardPay) Text(getPaymentMethodName),
                            SizedBox(
                              height: fromCardPay ? 49 : 24,
                            ),
                            if (fromCardPay) ...[
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(UserUtils.currentUser?.currentEnterprise
                                          ?.name ??
                                      ''),
                                  Text(
                                    "${UserUtils.currentServicePoint?.operationZone?.name} - ${UserUtils.currentServicePoint?.name}",
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(copy('referred.owner')),
                                  Text(
                                    "${UserUtils.currentUser?.name}",
                                  ),
                                ],
                              ),
                              const Padding(
                                padding: EdgeInsets.only(top: 24, bottom: 24),
                                child: DashedDivider(
                                  color: AppTheme.black2,
                                ),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(copy('charges.payment-reference')),
                                  Text(
                                    cardInvoice?.invoice?.reference ?? '',
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(copy('common.authorization')),
                                  Text(
                                    cardInvoice?.dpqTransaction ?? '',
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 24,
                              ),
                            ],
                            const DashedDivider(
                              color: AppTheme.black2,
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            ListView.separated(
                              physics: const NeverScrollableScrollPhysics(),
                              separatorBuilder: (context, index) =>
                                  const SizedBox(
                                height: 8,
                              ),
                              shrinkWrap: true,
                              itemCount: getItemCount,
                              itemBuilder: (BuildContext context, int index) {
                                return Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width *
                                          Constants.fiftyPercent,
                                      child: Text(getDescriptionService(index)),
                                    ),
                                    Text(
                                      getItemValue(index),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                if (getTransactionCost != 0) ...[
                                  Text(copy('charges.transaction-cost')),
                                  Text(
                                    Constants.currencyFormatter
                                        .format(getTransactionCost),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            if (fromCardPay) ...[
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(copy('charges.subtotal')),
                                  Text(
                                    Constants.currencyFormatter
                                        .format(cardInvoice?.payedValue),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              // Row(
                              //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              //   children: [
                              //     const Text("Impuestos"),  //! ??
                              //     Text(
                              //       Constants.currencyFormatter
                              //           .format(cardInvoice?.payedValue ?? 0),
                              //     ),
                              //   ],
                              // ),
                            ],
                            const SizedBox(
                              height: 24,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  getStatusName == copy('messages.inprogress')
                                      ? copy('charges.total-to-pay-label')
                                      : copy('charges.total-payed'),
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                Text(
                                  getTotalPayed,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            const DashedDivider(
                              color: AppTheme.black2,
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            if (showThanks)
                              Text(
                                copy('charges.thanks-for-your-payment'),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w300,
                                  fontSize: 18,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 24,
                    ),
                    Row(
                      mainAxisAlignment: isForRecurrent
                          ? MainAxisAlignment.spaceBetween
                          : MainAxisAlignment.center,
                      children: [
                        if (((movement?.idBalance != null) ||
                                (transaction?.idBalance != null) ||
                                cardInvoice?.idBalance != null ||
                                associatedPayIdBalance != null) &&
                            (UserUtils().hasPermissionsTo(215) ||
                                UserUtils().hasPermissionsTo(529)))
                          SizedBox(
                            width: MediaQuery.of(context).size.width *
                                (isForRecurrent &&
                                        UserUtils().hasPermissionsTo(796)
                                    ? 0.45
                                    : 0.9),
                            child: NvButton(
                              variant: "secondary",
                              label: isForRecurrent &&
                                      UserUtils().hasPermissionsTo(796)
                                  ? copy('common.download')
                                  : copy('charges.download-invoice'),
                              action: downloadUrl,
                            ),
                          ),
                        if (isForRecurrent && UserUtils().hasPermissionsTo(796))
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.45,
                            child: NvButton(
                              variant: "primary",
                              label: copy('schedule.schedule-pay'),
                              action: goToSchedule,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
