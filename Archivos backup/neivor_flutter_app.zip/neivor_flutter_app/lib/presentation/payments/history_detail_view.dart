import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_invoice_response.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/history_widgets/detail_payment_card.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

class HistoryPaymentDetail extends StatefulWidget {
  final String? idInvoice;
  final Invoice? invoice;

  const HistoryPaymentDetail({
    Key? key,
    this.idInvoice,
    this.invoice,
  }) : super(key: key);

  @override
  State<HistoryPaymentDetail> createState() => _HistoryPaymentDetailState();
}

class _HistoryPaymentDetailState extends State<HistoryPaymentDetail> {
  List<TransactionList>? listTrans;
  Function copy = AppMessages().getCopy;

  @override
  void initState() {
    callGetTransactionByInvoice(widget.idInvoice ?? '0');
    super.initState();
  }

  callGetTransactionByInvoice(String idInvoice) {
    (() async {
      var response = await getTransactionByInvoice(idInvoice);
      listTrans = response.entity?.transactionList;
      setState(() {});
    })();
  }

  sendEmail() async {
    context.loaderOverlay.show();
    var response = await sendMailTransaction(
      listTrans ?? [],
      widget.invoice?.initialDate ?? '',
      widget.invoice?.dateCreation ?? '',
    );
    context.loaderOverlay.hide();
    if (response.map?.success == true) {
      showAlertDialog("success", response.map?.message ?? "");
    } else {
      showAlertDialog("error", response.map?.message ?? "");
    }
  }

  showAlertDialog(String alertType, String message) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: alertType,
          content: message,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (context) => const MainPayments(isComeFrom: "history"),
          ),
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => const MainPayments(isComeFrom: "history"),
            ),
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.invoice?.descriptionService ?? '',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 26,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  width: MediaQuery.of(context).size.width,
                  height: 200,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                    border: Border.fromBorderSide(
                      BorderSide(color: AppTheme.grayArtic0main, width: 1),
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius:
                              const BorderRadius.all(Radius.circular(5)),
                          color: AppTheme.turquoise0Main.withOpacity(0.2),
                        ),
                        padding: const EdgeInsets.all(5),
                        child: Text(
                          //'Al Día',
                          copy('charges.up-to-date'),
                          style: const TextStyle(
                            color: AppTheme.turquoise4,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                //'Fecha: ',
                                copy('common.date') + ': ',
                              ),
                              Text(
                                widget.invoice?.initialDate ?? '',
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Text(
                                // "N. de Folio: ",
                                copy('charges.receipt-number'),
                              ),
                              Text(
                                widget.invoice?.invoiceNumber.toString() ?? '',
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          if (false) // TODO wait for backend method
                            Padding(
                              padding: const EdgeInsets.all(8),
                              child: NvButton(
                                //"Enviar por correo electrónico",
                                label: copy('charges.send-by-email'),
                                variant: 'secondary',
                                action: () {
                                  sendEmail();
                                },
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                // DETAIL PAYMENT CARD
                DetailPaymentCard(
                  listTrans: listTrans,
                  invoice: widget.invoice,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
