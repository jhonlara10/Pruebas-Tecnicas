import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/month_balance.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/unit_list.dart';

class AccountStatements extends StatefulWidget {
  const AccountStatements({Key? key, required this.balance}) : super(key: key);

  final String balance;
  @override
  State<AccountStatements> createState() => _AccountStatementsState();
}

class _AccountStatementsState extends State<AccountStatements> {
  bool isBalanceVisible = true;

  void changeBalanceVisibility() {
    setState(() {
      isBalanceVisible = !isBalanceVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(children: [
          MonthBalance(
            balance: widget.balance,
            changeBalanceVisibility: changeBalanceVisibility,
            isBalanceVisible: isBalanceVisible,
          ),
          const UnitList(),
        ]),
      ),
    );
  }
}
