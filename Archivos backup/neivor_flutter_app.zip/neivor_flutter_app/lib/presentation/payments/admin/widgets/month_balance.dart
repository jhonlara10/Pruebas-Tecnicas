import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';

import '../../../../theme/app_theme_scope.dart';
import '../../../../widgets/nv_image.dart';
import '../../../../widgets/nv_text.dart';

class MonthBalance extends StatelessWidget {
  const MonthBalance({
    Key? key,
    required this.balance,
    required this.isBalanceVisible,
    required this.changeBalanceVisibility,
  }) : super(key: key);

  final bool isBalanceVisible;
  final Function changeBalanceVisibility;
  final String? balance;
  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return Container(
      margin: const EdgeInsets.only(top: 24.0),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(
              left: 32.0,
              right: 32.0,
              top: 15.0,
              bottom: 15.0,
            ),
            decoration: BoxDecoration(
              color: colors.primary.turquoise.v1,
              borderRadius: const BorderRadius.all(Radius.circular(20.0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                NvText(
                  textHolder: copy('payments.balance-of-the-month'),
                  fontFamily: "Jost",
                  fontWeight: FontWeight.w300,
                  fontSize: 14,
                  color: colors.primary.black.main,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.6,
                      child: NvText(
                        textHolder: isBalanceVisible
                            ? balance
                            : "dummydata".replaceAll(RegExp(r"."), "*"),
                        fontFamily: "Jost",
                        fontWeight: FontWeight.bold,
                        fontSize: 26,
                        color: colors.primary.black.main,
                      ),
                    ),
                    const SizedBox(
                      width: 8.0,
                    ),
                    GestureDetector(
                      onTap: () => changeBalanceVisibility(),
                      child: const NvImage(
                        imageUrl: 'ds/icons/eye.svg',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
