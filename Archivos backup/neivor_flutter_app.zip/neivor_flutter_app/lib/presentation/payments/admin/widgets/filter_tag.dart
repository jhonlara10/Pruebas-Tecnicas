import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class FilterTag extends StatelessWidget {
  const FilterTag({
    Key? key,
    required this.action,
    required this.name,
    this.state = false,
  }) : super(key: key);

  final VoidCallback action;
  final bool state;
  final String name;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return TextButton(
      style: ButtonStyle(
        overlayColor: MaterialStateProperty.all(Colors.transparent),
      ),
      onPressed: () => action(),
      child: Container(
        padding: const EdgeInsets.only(
          top: 8.0,
          bottom: 8.0,
          left: 16.0,
          right: 16.0,
        ),
        decoration: BoxDecoration(
          color: state ? colors.primary.black.main : null,
          border: !state
              ? Border.all(
                  color: colors.primary.black.v3,
                  width: 1.0,
                )
              : null,
          borderRadius: const BorderRadius.all(
            Radius.circular(100.0),
          ),
        ),
        child: NvText(
          textHolder: name,
          fontFamily: "Jost",
          fontWeight: FontWeight.w300,
          fontSize: 16.0,
          color:
              state ? colors.primary.arcticGray.v5 : colors.primary.black.main,
        ),
      ),
    );
  }
}
