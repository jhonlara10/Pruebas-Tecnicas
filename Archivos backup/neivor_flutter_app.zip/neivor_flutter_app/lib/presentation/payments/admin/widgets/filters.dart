import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/filters_units.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/config/nv_text_field.dart';

import '../../../../theme/app_theme_scope.dart';
import '../../../../widgets/nv_text.dart';

class Filters extends StatefulWidget {
  const Filters({
    Key? key,
    required this.filterSearch,
    required this.filterStates,
  }) : super(key: key);

  final Function filterSearch;
  final Function filterStates;

  @override
  State<Filters> createState() => _FiltersState();
}

class _FiltersState extends State<Filters> {
  final Map<String, dynamic> formValues = {'state': ''};
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return Row(
      children: [
        Expanded(
          child: NvTextField(
            action: widget.filterSearch,
            label: "state",
            textHolder: copy('messages.search-placeholder'),
            controller: searchController,
            formValues: formValues,
            icon: const Icon(Icons.search),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10),
          child: SizedBox(
            height: 48,
            child: OutlinedButton.icon(
              // ignore: prefer-extracting-callbacks
              onPressed: () {
                showModalBottomSheet<void>(
                  context: context,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(25.0),
                    ),
                  ),
                  builder: (context) {
                    return FiltersUnits(filterStates: widget.filterStates);
                  },
                );
              },
              icon: const Icon(
                Icons.tune,
                size: 20,
                color: AppTheme.black0Main,
              ),
              label: NvText(
                textHolder: copy('common.filter'),
                fontFamily: "Jost",
                fontWeight: FontWeight.w300,
                fontSize: 16.0,
                color: colors.primary.black.main,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
