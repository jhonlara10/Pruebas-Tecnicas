import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/historic_transaction_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/helpers/string_helper.dart';

class TransactionCard extends StatelessWidget {
  const TransactionCard({
    Key? key,
    this.transaction,
  }) : super(key: key);

  final HistoricTransactionList? transaction;

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    final date = Jiffy(
      transaction?.date,
      'yyyy/MM/dd HH:mm',
    );
    final colors = AppThemeScope.of(context).colors;

    return Container(
      padding: const EdgeInsets.all(16.0),
      margin: const EdgeInsets.only(bottom: 24.0),
      decoration: BoxDecoration(
        border: Border.all(
          color: colors.primary.black.v1,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NvText(
            textHolder:
                transaction?.invoice?.descriptionService?.isNotEmpty == true
                    ? transaction?.invoice?.descriptionService?.capitalize()
                    : copy('payment.not-specified'),
            fontFamily: "Jost",
            fontWeight: FontWeight.w500,
            fontSize: 16.0,
            color: colors.primary.black.main,
          ),
          const SizedBox(
            height: 8.0,
          ),
          NvText(
            textHolder:
                "${transaction?.servicePoint?.operationZone?.name ?? ""} ${" - "} ${transaction?.servicePoint?.name ?? ""}",
            fontFamily: "Jost",
            fontWeight: FontWeight.w300,
            fontSize: 14.0,
            color: colors.primary.black.main,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.5,
                child: NvText(
                  textHolder: transaction?.paymentType?.name.toString(),
                  fontFamily: "Jost",
                  fontWeight: FontWeight.w300,
                  fontSize: 14.0,
                  color: colors.primary.black.main,
                ),
              ),
              NvText(
                textHolder:
                    Constants.currencyFormatter.format(transaction?.payedValue),
                fontFamily: "Jost",
                fontWeight: FontWeight.w500,
                fontSize: 14.0,
                color: colors.primary.turquoise.v4,
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              NvText(
                textHolder: copy('charges.payment-date'),
                fontFamily: "Jost",
                fontWeight: FontWeight.w300,
                fontSize: 14.0,
                color: colors.primary.black.main,
              ),
              NvText(
                textHolder: date.format(
                  'dd/MM/yyyy',
                ),
                fontFamily: "Jost",
                fontWeight: FontWeight.w500,
                fontSize: 14.0,
                color: colors.primary.black.main,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
