import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_tab.dart';

import '../../../../theme/app_theme_scope.dart';

class NavegationTabs extends StatelessWidget {
  const NavegationTabs({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return Container(
      color: colors.primary.arcticGray.main,
      padding: const EdgeInsets.all(4.0),
      child: TabBar(
        tabs: [
          Tab(
            child: NvTab(
              name: copy('payments.account-statements'),
              active: true,
            ),
          ),
          Tab(
            child: NvTab(
              name: copy('collections.movements'),
            ),
          ),
        ],
      ),
    );
  }
}
