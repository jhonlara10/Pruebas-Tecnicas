import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/historic_transaction_response.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/transaction_card.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/empty_view.dart';

class Transactions extends StatefulWidget {
  const Transactions({Key? key}) : super(key: key);

  @override
  State<Transactions> createState() => _TransactionsState();
}

class _TransactionsState extends State<Transactions> {
  List<TransactionCard>? allTransactionCards;
  HistoricTransactionResponse? transacionsResponse;

  @override
  initState() {
    (() async {
      context.loaderOverlay.show();
      await getListHistoricTransactionCards();
      context.loaderOverlay.hide();
    })();
    super.initState();
  }

  getListHistoricTransactionCards() async {
    try {
      transacionsResponse = await getHistoricTransaction();
      if (transacionsResponse?.success == true) {
        allTransactionCards =
            transacionsResponse?.data?.transactionList?.map((item) {
          return TransactionCard(transaction: item);
        }).toList();
      }

      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: allTransactionCards?.isEmpty == true
            ? EmptyView(
                fromTo: 'adminMovements',
              )
            : Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Column(
                  children: [...?allTransactionCards],
                ),
              ),
      ),
    );
  }
}
