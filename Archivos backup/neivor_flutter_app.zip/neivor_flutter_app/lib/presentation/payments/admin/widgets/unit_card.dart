import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_response.dart';
import 'package:neivor_flutter_app/presentation/payments/main_payments.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_tag.dart';

import '../../../../theme/app_theme_scope.dart';
import '../../../../widgets/nv_text.dart';
import '../../../util/constants.dart';

class UnitCard extends StatelessWidget {
  const UnitCard({
    Key? key,
    required this.unit,
  }) : super(key: key);

  final ConciliationResponse unit;

  // ignore: long-method
  Widget getUnitTag(BuildContext context, ConciliationResponse conciliation) {
    final copy = AppMessages().getCopy;
    TagVariant? variant;
    String? text;

    if (conciliation.debt != null) {
      variant = TagVariant.yellow;
      text = copy('home.for-pay');
    }
    if (conciliation.debt == null) {
      variant = TagVariant.harlequinGreen;
      text = copy('payments.up-to-date');
    }
    if (conciliation.servicePoint?.legalCharge != null &&
        conciliation.servicePoint?.legalCharge == 1) {
      variant = TagVariant.black;
      text = copy('payments.legal-collection');
    }

    return NvTag(
      label: text,
      state: variant,
    );
  }

  goToSelectedSP(BuildContext context) {
    BlocProvider.of<PaymentsBloc>(context).add(NewSelectedConciliation(
      selectedConciliation: unit,
    ));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const MainPayments(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return GestureDetector(
      onTap: () => goToSelectedSP(context),
      child: Container(
        padding: const EdgeInsets.fromLTRB(0, 16, 0, 16),
        margin: const EdgeInsets.only(bottom: 24.0),
        decoration: BoxDecoration(
          border: Border.all(
            color: colors.primary.black.v1,
          ),
          borderRadius: const BorderRadius.all(Radius.circular(4)),
        ),
        child: ListTile(
          //mainAxisAlignment: MainAxisAlignment.spaceBetween,
          title: Column(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.76,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width *
                          Constants.thirtyPercent,
                      child: NvText(
                        textHolder:
                            "${unit.servicePoint?.operationZone?.name} - ${unit.servicePoint?.name}",
                        fontFamily: "Jost",
                        fontWeight: FontWeight.w500,
                        fontSize: 16.0,
                        color: colors.primary.black.main,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    getUnitTag(context, unit),
                  ],
                ),
              ),
              const SizedBox(
                height: 4.0,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.76,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    NvText(
                      textHolder: copy('payments.to-turn-off'),
                      fontFamily: "Jost",
                      fontWeight: FontWeight.w500,
                      fontSize: 14.0,
                      color: colors.primary.black.main,
                    ),
                    NvText(
                      textHolder: unit.debt != null
                          ? Constants.currencyFormatter.format(unit.debt)
                          : Constants.currencyFormatter.format(0),
                      fontFamily: "Jost",
                      fontWeight: FontWeight.w300,
                      fontSize: 14.0,
                      color: colors.primary.black.main,
                    ),
                  ],
                ),
              ),
            ],
          ),
          trailing: const NvImage(
            imageUrl: 'ds/icons/arrow.svg',
          ),
        ),
      ),
    );
  }
}
