import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/filter_tag.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class FiltersUnits extends StatefulWidget {
  const FiltersUnits({
    Key? key,
    required this.filterStates,
  }) : super(key: key);

  final Function filterStates;
  @override
  State<FiltersUnits> createState() => _FiltersUnitsState();
}

class _FiltersUnitsState extends State<FiltersUnits> {
  bool isUpToDayActive = false;
  bool isToPayActive = false;
  bool isInArrearsActive = false;
  bool isLegalCollection = false;

  setUpToDayActive() {
    setState(() {
      isUpToDayActive = !isUpToDayActive;
    });
  }

  setToPayActive() {
    setState(() {
      isToPayActive = !isToPayActive;
    });
  }

  setInArrearsActive() {
    setState(() {
      isInArrearsActive = !isInArrearsActive;
    });
  }

  setLegalCollection() {
    setState(() {
      isLegalCollection = !isLegalCollection;
    });
  }

  // ignore: long-method
  action() {
    widget.filterStates(
      upToDay: isUpToDayActive,
      toPay: isToPayActive,
      legalCollection: isLegalCollection,
    );
    if (isUpToDayActive) {
      setUpToDayActive();
    }
    if (isToPayActive) {
      setToPayActive();
    }
    if (isLegalCollection) {
      setLegalCollection();
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return Stack(
      alignment: Alignment.topLeft,
      children: [
        Container(
          color: Colors.white,
          height: 320.0,
          width: double.infinity,
          padding: const EdgeInsets.only(
            top: 24.0,
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16.0,
                ),
                child: Column(children: [
                  NvText(
                    textHolder: copy('common.filter'),
                    fontFamily: "Jost",
                    fontWeight: FontWeight.w600,
                    fontSize: 20.0,
                    color: colors.primary.black.main,
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 34.0),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        NvText(
                          textHolder: copy('common.state'),
                          fontFamily: "Jost",
                          fontWeight: FontWeight.w600,
                          fontSize: 16.0,
                          color: colors.primary.black.main,
                        ),
                        Wrap(
                          spacing: -10.0,
                          runSpacing: -10.0,
                          children: [
                            FilterTag(
                              action: setUpToDayActive,
                              name: copy('payments.up-to-date'),
                              state: isUpToDayActive,
                            ),
                            FilterTag(
                              action: setToPayActive,
                              name: copy('home.for-pay'),
                              state: isToPayActive,
                            ),
                            FilterTag(
                              action: setLegalCollection,
                              name: copy('payments.legal-collection'),
                              state: isLegalCollection,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
              Expanded(
                child: Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Container(
                    margin: const EdgeInsets.only(
                      top: 24,
                    ),
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(
                          color: colors.primary.black.v1,
                          width: 1,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 2, left: 2),
                            child: NvButton(
                              label: copy('common.cancel'),
                              action: () {
                                action();
                              },
                              variant: "secondary",
                            ),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 2, left: 2),
                            child: NvButton(
                              label: copy('common.filter'),
                              action: () {
                                action();
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(16.0),
            child: const NvImage(
              imageUrl: 'ds/icons/icon-close.svg',
            ),
          ),
        ),
      ],
    );
  }
}
