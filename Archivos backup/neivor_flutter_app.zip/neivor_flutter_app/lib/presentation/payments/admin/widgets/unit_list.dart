import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_response.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/filters.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/unit_card.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/empty_view.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';

import '../../../../theme/app_theme_scope.dart';
import '../../../../widgets/nv_text.dart';

class UnitList extends StatefulWidget {
  const UnitList({
    Key? key,
  }) : super(key: key);

  @override
  State<UnitList> createState() => _UnitListState();
}

class _UnitListState extends State<UnitList> {
  List<UnitCard>? allUnitCards;
  List<ConciliationResponse>? unitList;
  List<ConciliationResponse>? unitListToShow;

  @override
  initState() {
    (() async {
      await getListUnitCards();
    })();
    super.initState();
  }

  getListUnitCards() async {
    try {
      context.loaderOverlay.show();
      unitList = await getConciliation();
      setState(() {
        unitListToShow = unitList;
        setUnitCards();
        context.loaderOverlay.hide();
      });
    } catch (e) {
      log(e.toString());
    }
  }

  setUnitCards() {
    allUnitCards = unitListToShow?.map((item) {
      return UnitCard(unit: item);
    }).toList();
  }

  // ignore: long-method
  filterSearch(String? str) {
    List<ConciliationResponse>? newlist = [];
    setState(() {
      if (str != null && str.isNotEmpty) {
        newlist = [
          ...?newlist,
          ...?unitList
              ?.where((element) =>
                  (("${element.servicePoint?.operationZone?.name} - ${element.servicePoint?.name}")
                      .toLowerCase()
                      .contains(str.toLowerCase())))
              .toList(),
        ];
        unitListToShow = newlist;
      } else {
        unitListToShow = unitList;
      }
      setUnitCards();
    });
  }

  // ignore: long-method
  filterStates({
    required bool upToDay,
    required bool legalCollection,
    required bool toPay,
  }) {
    setState(() {
      unitListToShow = unitList;
      List<ConciliationResponse>? newlist;
      if (upToDay) {
        newlist = [
          ...?newlist,
          ...?unitList?.where((element) => element.debt == null).toList(),
        ];
      }
      if (legalCollection) {
        newlist = [
          ...?newlist,
          ...?unitList
              ?.where((element) => (element.servicePoint?.legalCharge != null &&
                  element.servicePoint?.legalCharge == 1))
              .toList(),
        ];
      }
      if (toPay) {
        newlist = [
          ...?newlist,
          ...?unitList?.where((element) => element.debt != null).toList(),
        ];
      }
      if (newlist?.isNotEmpty ?? false) {
        unitListToShow = newlist;
      }
      setUnitCards();
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;

    return Container(
      margin: const EdgeInsets.only(
        top: 34.0,
      ),
      child: unitList?.isEmpty == true
          ? EmptyView(
              fromTo: 'statements',
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                NvText(
                  textHolder: copy('messages.recents'),
                  fontFamily: "Jost",
                  fontWeight: FontWeight.w500,
                  fontSize: 22.0,
                  color: colors.primary.black.main,
                ),
                const SizedBox(
                  height: 24.0,
                ),
                Filters(filterSearch: filterSearch, filterStates: filterStates),
                const SizedBox(
                  height: 24.0,
                ),
                Column(
                  children: [...?allUnitCards],
                ),
              ],
            ),
    );
  }
}
