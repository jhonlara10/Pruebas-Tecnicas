import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/account_statements.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/widgets/transactions.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:tab_indicator_styler/tab_indicator_styler.dart';

import '../../../themes/app_theme.dart';

class MainAdminPayments extends StatefulWidget {
  const MainAdminPayments({Key? key, required this.balance}) : super(key: key);

  final String balance;
  @override
  State<MainAdminPayments> createState() => _MainAdminPaymentsState();
}

class _MainAdminPaymentsState extends State<MainAdminPayments> {
  static const double _indicatorPadding = 5;
  static const double _indicatorborderRadius = 100;
  static const int _tabQuantity = 2;
  final copy = AppMessages().getCopy;

  @override
  void initState() {
    BlocProvider.of<PaymentsBloc>(context).add(const NewSelectedConciliation(
      selectedConciliation: null,
    ));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: 0,
      length: _tabQuantity,
      child: WillPopScope(
        // ignore: prefer-extracting-callbacks
        onWillPop: () {
          Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          );
          return Future.value(false);
        },
        child: Scaffold(
          appBar: NvAppBar(
            backAction: () => Navigator.pushNamedAndRemoveUntil(
              context,
              'home',
              (Route<dynamic> route) => false,
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  copy('onboarding.finance'),
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 26,
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: AppTheme.grayArtic0main,
                    borderRadius: BorderRadius.all(
                      Radius.circular(100),
                    ),
                  ),
                  child: TabBar(
                    onTap: (value) =>
                        FocusManager.instance.primaryFocus?.unfocus(),
                    indicator: RectangularIndicator(
                      color: Colors.white,
                      paintingStyle: PaintingStyle.fill,
                      bottomLeftRadius: _indicatorborderRadius,
                      bottomRightRadius: _indicatorborderRadius,
                      topLeftRadius: _indicatorborderRadius,
                      topRightRadius: _indicatorborderRadius,
                      horizontalPadding: _indicatorPadding,
                      verticalPadding: _indicatorPadding,
                    ),
                    overlayColor: MaterialStateProperty.all(Colors.transparent),
                    labelColor: AppTheme.greenArlequin4,
                    automaticIndicatorColorAdjustment: true,
                    unselectedLabelColor: AppTheme.textPrimary,
                    tabs: [
                      Tab(
                        child: Text(
                          copy('payments.account-statements'),
                          style: const TextStyle(
                            fontSize: 14,
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Tab(
                        child: Text(
                          copy('payments.movements'),
                          style: const TextStyle(
                            fontSize: 14,
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      AccountStatements(balance: widget.balance),
                      const Transactions(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
