import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/empty_view.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

import 'widgets/widgets.dart';

class DebtsView extends StatefulWidget {
  const DebtsView({
    Key? key,
    this.servicePointId,
  }) : super(key: key);
  final int? servicePointId;

  @override
  State<DebtsView> createState() => _DebtsViewState();
}

class _DebtsViewState extends State<DebtsView> {
  static const double _bottomSheetHeight = 80;
  final copy = AppMessages().getCopy;
  DateFormat dateFormatter = DateFormat("dd/MM/yyyy");
  PendingTransactionResponse? pendingResponse;
  bool isDebtVisible = true;
  List<Invoice>? invoices;
  List<Invoice>? currentDebts;
  List<Invoice>? futureDebts;
  bool isLoading = false;
  List<Invoice> selectedDebts = [];
  Map<int, bool> checkboxesActualStates = {};
  Map<int, bool> checkboxesFutureStates = {};
  Map<int, ExpandableController> currentControllers = {};
  Map<int, ExpandableController> futureControllers = {};
  Map<int, TextEditingController> currentTextControllers = {};
  Map<int, TextEditingController> futureTextControllers = {};
  TextEditingController prepaidTextController = TextEditingController();
  Map<int, GlobalKey<FormState>> currentKeys = {};
  GlobalKey<FormState> prepaidKey = GlobalKey<FormState>();
  Map<int, GlobalKey<FormState>> futureKeys = {};
  ExpandableController futureController =
      ExpandableController(initialExpanded: false);
  ExpandableController prepaidController =
      ExpandableController(initialExpanded: false);
  double totalValueSelected = 0;
  Map<String, dynamic> prepaidJson = {
    "idInvoice": null,
    "value": 0,
    "descriptionService": "Pago anticipado",
    "sanctionValueToShow": 0.0,
    "totalValue": 0,
    'valueToPay': 0,
  };

  @override
  void initState() {
    isLoading = true;
    context.loaderOverlay.show();

    /// Initializing the date format for the locale es_CO.
    initializeDateFormatting('es_CO', null);
    (() async {
      await setInitPrepaidJson();
      await callGetDebts();
      context.loaderOverlay.hide();
      isLoading = false;
      buildCheckboxStates();
    })();
    super.initState();
  }

  setInitPrepaidJson() async {
    prepaidJson = {
      "idInvoice": null,
      "value": 0,
      "descriptionService": copy('prepay-button'),
      "sanctionValueToShow": 0.0,
      "totalValue": 0,
      'valueToPay': 0,
    };
  }

  /// It sets the state of the checkboxes to false.
  buildCheckboxStates() {
    setState(() {
      currentDebts?.asMap().forEach((index, element) {
        checkboxesActualStates[index] = false;
      });
      futureDebts?.asMap().forEach((index, element) {
        checkboxesFutureStates[index] = false;
      });
    });
  }

  /// It gets a list of invoices, filters them by date, and then creates a list of controllers for each
  /// list
  // ignore: long-method
  callGetDebts() async {
    invoices = await getInvoices(
      false,
      widget.servicePointId ?? UserUtils.currentServicePoint?.id,
    );
    // ignore: no-empty-block
    setState(() {
      currentDebts = invoices
          ?.where((element) => dateFormatter
              .parse(element.initialDate ?? '')
              .isBefore(DateTime.now()))
          .toList();
      futureDebts = invoices
          ?.where((element) => dateFormatter
              .parse(element.initialDate ?? '')
              .isAfter(DateTime.now()))
          .toList();
      for (var count = 0; count < (currentDebts?.length ?? 0); count++) {
        currentKeys[count] = GlobalKey<FormState>();
        currentTextControllers[count] = TextEditingController();
        currentControllers[count] = ExpandableController();
      }
      for (var count = 0; count < (futureDebts?.length ?? 0); count++) {
        futureKeys[count] = GlobalKey<FormState>();
        futureTextControllers[count] = TextEditingController();
        futureControllers[count] = ExpandableController();
      }
    });
  }

  /// The function is called when the user clicks on the debt button. It changes the visibility of the
  /// debt total.
  void changeDebtVisibility() {
    setState(() {
      isDebtVisible = !isDebtVisible;
    });
  }

  /// It takes a list of invoices, and returns the total debt of all invoices
  ///
  /// Returns:
  ///   A string.
  String getTotalDebt() {
    double total = 0;
    currentDebts?.forEach((element) {
      total = total + (element.debt ?? 0);
    });
    return Constants.currencyFormatter.format(total).toString();
  }

  /// It sets the state of
  /// the widget, and if the value is true, it adds the invoice to the selectedDebts list, and sets the
  /// expanded value of the currentControllers at the index to true. If the value is false, it removes
  /// the invoice from the selectedDebts list, and sets the expanded value of the currentControllers at
  /// the index to false. It then calculates the total selected, and sets the checkboxesActualStates or
  /// checkboxesFutureStates at the index to the opposite of what it was
  ///
  /// Args:
  ///   value: bool,
  ///   invoice (Invoice): Invoice
  ///   index: the index of the item in the list
  ///   isActual: bool
  // ignore: long-method
  changeCheckValue(value, Invoice? invoice, index, isActual) {
    setState(() {
      if (value) {
        if (!selectedDebts.any((element) => element.id == invoice?.id)) {
          selectedDebts
              .add(Invoice.fromJson(invoice?.toJson() ?? {})); // ! shadowing.
          currentControllers[index]?.expanded = true;
        }
      } else {
        selectedDebts.removeWhere((element) => element.id == invoice?.id);
        currentControllers[index]?.expanded = false;
      }
      calculateTotalSelected();
      if (isActual) {
        checkboxesActualStates[index] = value;
      } else {
        checkboxesFutureStates[index] = value;
      }
    });
  }

  /// It checks if there's a pending transaction, if there is, it navigates to the pendingPaymentView,
  /// if not, it navigates to the paymentMethods view
  ///
  /// Args:
  ///   context: BuildContext
  // ignore: long-method
  checkPendingTransaction(contextscope) async {
    context.loaderOverlay.show();
    pendingResponse = await getPendingTransaction(contextscope);
    context.loaderOverlay.hide();
    setState(() {
      if (pendingResponse?.list?.isNotEmpty ?? false) {
        Navigator.pushReplacementNamed(contextscope, "pendingPaymentView");
      } else {
        if (prepaidJson["value"] != 0) {
          selectedDebts.add(Invoice.fromJson(prepaidJson));
        }
        BlocProvider.of<PaymentsBloc>(contextscope).add(NewSelectedDebts(
          selectedDebts: selectedDebts,
        ));
        Navigator.pushReplacementNamed(contextscope, "paymentMethods");
      }
    });
  }

  /// It takes a date in the format "yyyy-MM-dd" and returns a date in the format "d de MMMM de yy"
  ///
  /// Args:
  ///   date (String): The date to be formatted.
  ///
  /// Returns:
  ///   A string with the date in the format "d de MMMM de yy"
  String formatDate(String date) {
    var parsed = dateFormatter.parse(date);
    DateFormat longDateFormatter = DateFormat('dd' ' ' 'MMMM' ' ' 'yyyy');
    return longDateFormatter.format(parsed);
  }

  /// It takes a debt and a value, changes the total value in bottom sheet
  /// if the input is modified
  ///
  /// Args:
  ///   debt (Invoice): Invoice?
  ///   value (String): The value of the debt
  // ignore: long-method
  changePayValue(Invoice? debt, String value) {
    value = value.replaceAll("\$ ", "");
    setState(() {
      int debtIndex =
          selectedDebts.indexWhere((element) => debt?.id == element.id);
      if (value.isNotEmpty) {
        if (debtIndex != -1) {
          selectedDebts[debtIndex].valueToPay =
              double.parse((value).replaceAll(",", "."));
          selectedDebts[debtIndex].value =
              double.parse((value).replaceAll(",", "."));
        }
        if (double.parse((value).replaceAll(",", ".")) == 0) {
          selectedDebts[debtIndex].valueToPay = invoices
              ?.firstWhere(
                (element) => element.id == selectedDebts[debtIndex].id,
              )
              .value;
          selectedDebts[debtIndex].value = invoices
              ?.firstWhere(
                (element) => element.id == selectedDebts[debtIndex].id,
              )
              .value;
        }
      } else {
        selectedDebts[debtIndex].valueToPay = invoices
            ?.firstWhere(
              (element) => element.id == selectedDebts[debtIndex].id,
            )
            .value;
        selectedDebts[debtIndex].value = invoices
            ?.firstWhere(
              (element) => element.id == selectedDebts[debtIndex].id,
            )
            .value;
      }
      calculateTotalSelected();
    });
  }

  /// Calculate the total value of selected items.
  calculateTotalSelected() {
    totalValueSelected = 0;
    for (var element in selectedDebts) {
      totalValueSelected = totalValueSelected + (element.valueToPay ?? 0);
    }
    if (prepaidJson["valueToPay"] > 0) {
      totalValueSelected = totalValueSelected + prepaidJson['valueToPay'];
    }
  }

  /// if the input of prepaid is modify change the value in the json
  ///
  /// Args:
  ///   value (String): The value of the text field
  // ignore: long-method
  prepaidModify(String value) {
    value = value.replaceAll("\$ ", "");
    setState(() {
      if (value.isNotEmpty) {
        prepaidJson["valueToPay"] = double.parse(
          double.parse((value.toString()).replaceAll(",", "."))
              .toStringAsFixed(2),
        );
        prepaidJson["value"] = double.parse(
          double.parse((value).replaceAll(",", ".")).toStringAsFixed(2),
        );
      } else {
        prepaidJson["valueToPay"] = 0;
        prepaidJson["value"] = 0;
      }
      calculateTotalSelected();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: selectedDebts.isNotEmpty || prepaidJson["valueToPay"] > 0
          ? TotalBottom(
              checkPendingTransaction: checkPendingTransaction,
              bottomSheetHeight: _bottomSheetHeight,
              totalValueSelected: totalValueSelected,
              selectedDebts: selectedDebts,
            )
          : null,
      body: SingleChildScrollView(
        padding: selectedDebts.isNotEmpty || prepaidJson["valueToPay"] > 0
            ? const EdgeInsets.only(bottom: 80)
            : null,
        child: (invoices?.isEmpty ?? true) &&
                !isLoading &&
                UserUtils().isAdminUser()
            ? EmptyView(
                fromTo: 'debts',
              )
            : Column(
                children: [
                  if (UserUtils().hasPermissionsTo(787))
                    TotalDebtCard(
                      isDebtVisible: isDebtVisible,
                      changeDebtVisibility: changeDebtVisibility,
                      getTotalDebt: getTotalDebt,
                    ),
                  if (UserUtils().isAdminUser())
                    const SizedBox(
                      height: 24,
                    ),
                  CurrentDebtsList(
                    currentKeys: currentKeys,
                    currentTextControllers: currentTextControllers,
                    currentDebts: currentDebts,
                    currentControllers: currentControllers,
                    checkboxesActualStates: checkboxesActualStates,
                    formatDate: formatDate,
                    changePayValue: changePayValue,
                    changeCheckValue: changeCheckValue,
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  if ((futureDebts?.length ?? 0) != 0 &&
                      !UserUtils().isAdminUser())
                    FutureDebtsList(
                      futureTextControllers: futureTextControllers,
                      futureKeys: futureKeys,
                      futureController: futureController,
                      futureDebts: futureDebts,
                      checkboxesFutureStates: checkboxesFutureStates,
                      changeCheckValue: changeCheckValue,
                      changePayValue: changePayValue,
                      formatDate: formatDate,
                    ),
                  const SizedBox(
                    height: 16,
                  ),
                  if (UserUtils().hasPermissionsTo(790))
                    PrepaidSection(
                      prepaidController: prepaidController,
                      prepaidModify: prepaidModify,
                      prepaidTextController: prepaidTextController,
                      prepaidKey: prepaidKey,
                    ),
                ],
              ),
      ),
    );
  }
}
