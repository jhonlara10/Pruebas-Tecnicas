import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:lottie/lottie.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/payment_methods_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/pse/pse_pay_response.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/pse_web_view.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';

import 'widgets/pse_tile.dart';
import 'widgets/widgets.dart';

class PaymentMethods extends StatefulWidget {
  const PaymentMethods({Key? key}) : super(key: key);

  @override
  State<PaymentMethods> createState() => _PaymentMethodsState();
}

class _PaymentMethodsState extends State<PaymentMethods> {
  static const int _creditCardId1 = 1;
  static const int _creditCardId3 = 3;
  static const int _creditCardId7 = 7;
  static const int _cashId9 = 9;
  static const int _cashId10 = 10;
  static const int _speiId6 = 6;
  static const int _speiId12 = 12;
  static const int _pseId2 = 2;
  static const int _spei = 11;
  final copy = AppMessages().getCopy;
  PsePayResponse? response;
  List<Invoice>? selectedDebts;

  List<UserPaymentMethodResponse>? paymentMethods;
  PaymentMethodsResponse? enterprisePaymentMethod;
  @override
  void initState() {
    context.loaderOverlay.show();
    callGetUserPaymentMethods();
    callGetActivePayMethods();
    selectedDebts = BlocProvider.of<PaymentsBloc>(context).state.selectedDebts;
    super.initState();
  }

  /// Gets the saved payment methods for the current user.
  callGetUserPaymentMethods() async {
    paymentMethods = await getUserPaymentMethods();
    // ignore: no-empty-block
    setState(() {});
  }

  callGetActivePayMethods() async {
    enterprisePaymentMethod = await getActivePaymentMethods();
    context.loaderOverlay.hide();
    // ignore: no-empty-block
    setState(() {});
  }

  getPaymentMethodType(id) {
    switch (id) {
      case _creditCardId1:
      case _creditCardId3:
      case _creditCardId7:
        return copy('payments.credit');
      case _cashId9:
      case _cashId10:
        return copy('payment.cash');
      case _speiId6:
      case _speiId12:
        return copy('common.spei');
      case _pseId2:
        return copy('common.pse');
    }
  }

  bool isMethodActive(idPaymentMethod) {
    return enterprisePaymentMethod?.data
            ?.any((element) => element.id == idPaymentMethod) ??
        false;
  }

  List<Map<String, dynamic>> selectedAsJson() {
    List<Map<String, dynamic>> result = [];
    selectedDebts?.forEach((element) {
      result.add({
        "idInvoice": element.id,
        "value": element.valueToPay,
      });
    });
    return result;
  }

  double getTotalToPay() {
    double total = 0;
    selectedDebts?.forEach((element) {
      total += (element.valueToPay ?? 0);
    });
    return double.parse(total.toStringAsFixed(2));
  }

  // ignore: long-method
  Map<String, dynamic> buildPseJson() {
    return {
      "userInvoicePaymentList": selectedAsJson(),
      "totalToPay": getTotalToPay(),
      "paymentMethodType": {"id": 2},
      "zyosUser": {
        "id": UserUtils.currentUser?.id,
        "email": UserUtils.currentUser?.email,
        "name": UserUtils.currentUser?.name,
      },
      "paymentMethod": {
        "payer": {
          "name": UserUtils.currentUser?.name,
          "lastname": "",
          "documentNumber": UserUtils.currentUser?.documentNumber,
          "documentType": "CC",
          "email": UserUtils.currentUser?.email,
        },
      },
      "enterprise": {"id": UserUtils.currentEnterprise?.id},
      "servicePoint": {
        "id": UserUtils.currentServicePoint?.id,
      },
      "userAgent": GlobalUtils.deviceInfo.model,
    };
  }

  // ignore: long-method
  callPsePay() async {
    showpayingAnimation(true);
    PsePayResponse response = await psePay(buildPseJson());
    showpayingAnimation(false);
    if (response.success ?? false) {
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PseWebView(
            url: response.paymentOperation?.url ?? '',
          ),
        ),
      );
    } else {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Future.delayed(const Duration(seconds: 3), () {
            Navigator.of(context).pop();
          });
          return NvAlert(
            type: "warning",
            content: response.error?.message ?? '',
          );
        },
      );
    }
  }

  // ignore: long-method
  PaymentCommission? getSelectedComission(idPaymentMethod) {
    PaymentMethod? filtered;
    if (enterprisePaymentMethod?.data?.isNotEmpty ?? false) {
      filtered = enterprisePaymentMethod?.data?.firstWhere(
        (element) =>
            idPaymentMethod == element.id &&
            !(element.enterpriseIntegrationPaymentMethodType
                    ?.acceptPayCommission ??
                false),
        orElse: () {
          PaymentMethod emptyObj = PaymentMethod();
          emptyObj.name = "not found";
          return emptyObj;
        },
      );
    }
    return filtered?.name != "not found" ? filtered?.paymentCommission : null;
  }

  // ignore: long-method
  showpayingAnimation(bool show) {
    if (show) {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            alignment: Alignment.center,
            title: Column(
              children: [
                Lottie.asset(
                  'assets/images/paying-animation.zip',
                ),
                const Text(
                  'Tomará un momento, estamos procesando tu pago...',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "payments");
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacementNamed(context, "payments"),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Column(
            children: [
              Text(
                copy('payments.select-payment-method'),
                overflow: TextOverflow.clip,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(
                height: 44,
              ),
              if (((GlobalUtils.countryId == Constants.mxIntIdCode) ||
                      (GlobalUtils.countryId == Constants.mxIntIdCodeTest)) &&
                  UserUtils().hasPermissionsTo(792))
                SpeiCard(
                  isActive: isMethodActive(_spei),
                  showLoader: showpayingAnimation,
                ),
              if (GlobalUtils.countryId == Constants.coIntIdCode)
                PseTile(
                  isActive: isMethodActive(_pseId2),
                  callPsePay: callPsePay,
                ),
              if (UserUtils().hasPermissionsTo(793))
                CardsContainer(
                  isActive: (isMethodActive(_creditCardId7) ||
                      isMethodActive(_creditCardId3) ||
                      isMethodActive(_creditCardId1)),
                  paymentMethods: paymentMethods,
                  paymentCommission: getSelectedComission(
                    (GlobalUtils.countryId == Constants.mxIntIdCode) ||
                            (GlobalUtils.countryId == Constants.mxIntIdCodeTest)
                        ? _creditCardId7
                        : _creditCardId3,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
