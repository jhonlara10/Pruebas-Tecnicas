import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class DisabledPayments extends StatelessWidget {
  const DisabledPayments({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushNamed(context, "home");
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamed(context, "home"),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const NvImage(
                  imageUrl: "/ds/icons/hanging_frame.png",
                ),
                const SizedBox(
                  height: 8,
                ),
                Text(
                  //"Información financiera en configuración",
                  AppMessages().getCopy('payments.hide-payment-section'),
                  style: AppThemeScope.of(context)
                      .typography
                      .h4
                      .medium
                      .copyWith(height: 1.5),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 8,
                ),
                Text(
                  //"Pronto podrás ver tus deudas, movimientos y recibos de pago. Espérala pronto.",
                  AppMessages().getCopy('payments.payment-section-soon'),
                  style:
                      AppThemeScope.of(context).typography.bd1.light.copyWith(),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
