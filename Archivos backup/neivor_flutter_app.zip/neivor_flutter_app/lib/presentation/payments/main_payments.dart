import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/bloc/wall_notifications/wall_notifications_bloc.dart';
import 'package:neivor_flutter_app/domain/models/payment/conciliation/conciliation_response.dart';
import 'package:neivor_flutter_app/presentation/payments/admin/main_admin_payments.dart';
import 'package:neivor_flutter_app/presentation/payments/debts_view.dart';
import 'package:neivor_flutter_app/presentation/payments/history_view.dart';
import 'package:neivor_flutter_app/presentation/payments/movements_view.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_tab_bar.dart';
import 'package:neivor_flutter_app/widgets/nv_tag.dart';

class MainPayments extends StatefulWidget {
  const MainPayments({
    Key? key,
    this.isComeFrom,
  }) : super(key: key);
  final String? isComeFrom;

  @override
  State<MainPayments> createState() => _MainPaymentsState();
}

class _MainPaymentsState extends State<MainPayments> {
  static const int _tabQuantity = 3;
  final copy = AppMessages().getCopy;
  ConciliationResponse? selectedConciliation;
  bool isDebtVisible = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => showBottomModal());
  }

  extractConciliation(BuildContext context) {
    if (UserUtils().isAdminUser()) {
      selectedConciliation =
          BlocProvider.of<PaymentsBloc>(context).state.selectedConciliation;
    }
  }

  // ignore: long-method
  Widget getUnitTag(BuildContext context, ConciliationResponse? conciliation) {
    final copy = AppMessages().getCopy;
    TagVariant? variant;
    String? text;

    if (conciliation?.debt != null) {
      variant = TagVariant.yellow;
      text = copy('home.for-pay');
    }
    if (conciliation?.debt == null) {
      variant = TagVariant.harlequinGreen;
      text = copy('payments.up-to-date');
    }
    if (conciliation?.servicePoint?.legalCharge != null &&
        conciliation?.servicePoint?.legalCharge == 1) {
      variant = TagVariant.black;
      text = copy('payments.legal-collection');
    }

    return NvTag(
      label: text,
      state: variant,
    );
  }

  void changeDebtVisibility() {
    setState(() {
      isDebtVisible = !isDebtVisible;
    });
  }

  int get initialIndex {
    if (widget.isComeFrom == "history") {
      return 2;
    } else if (widget.isComeFrom == "movements") {
      return 1;
    }
    return 0;
  }

  // ignore: long-method
  backRedirect() {
    if (UserUtils().hasPermissionsTo(67) || UserUtils().hasPermissionsTo(130)) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => MainAdminPayments(
            balance: Constants.currencyFormatter
                .format(BlocProvider.of<PaymentsBloc>(context)
                        .state
                        .balance
                        ?.totalValueIncome ??
                    0)
                .toString(),
          ),
        ),
        (Route<dynamic> route) => false,
      );
    } else {
      Navigator.pushNamedAndRemoveUntil(
        context,
        'home',
        (Route<dynamic> route) => false,
      );
    }
  }

  showBottomModal() {
    if (BlocProvider.of<WallNotificationsBloc>(context)
            .state
            .currentLegalCharge ==
        1) {
      showModalBottomSheet(
        enableDrag: false,
        isDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () {
              backRedirect();
              return Future.value(false);
            },
            child: NvBottomSheet(
              bottomSheetHeight: 300,
              iconRoute: "assets/images/warning.png",
              title: copy('charges.judicial-collection-process'),
              subtitle: copy('charges.owner-open-judicial-collection-process'),
              primaryButtonText: copy('common.back'),
              primaryButtonVariant: "nv-bottom-sheet-secondary",
              primaryButtonAction: () =>
                  Navigator.pushReplacementNamed(context, "home"),
            ),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    extractConciliation(context);
    return DefaultTabController(
      initialIndex: initialIndex,
      length: _tabQuantity,
      child: WillPopScope(
        // ignore: prefer-extracting-callbacks
        onWillPop: () {
          backRedirect();
          return Future.value(false);
        },
        child: Scaffold(
          appBar: NvAppBar(
            backAction: () => backRedirect(),
            actions: [
              if (UserUtils().hasPermissionsTo(796)) ...[
                GestureDetector(
                  onTap: () =>
                      Navigator.pushReplacementNamed(context, "wallet"),
                  child: const Padding(
                    padding: EdgeInsets.only(right: 16),
                    child: NvImage(
                      icon: "Payments, Finance/credit-card-favorite",
                    ),
                  ),
                ),
              ],
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (!UserUtils().hasPermissionsTo(788))
                  Text(
                    AppMessages().getCopy("charges.payments"),
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 26,
                    ),
                  ),
                if (UserUtils().hasPermissionsTo(788)) ...[
                  Text(
                    "${selectedConciliation?.servicePoint?.operationZone?.name} - ${selectedConciliation?.servicePoint?.name}",
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 26,
                    ),
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(16)),
                      color: AppThemeScope.of(context)
                          .colors
                          .secondary
                          .cobaltBlue
                          .v4,
                    ),
                    margin: const EdgeInsets.all(0),
                    child: Column(
                      children: [
                        Container(
                          margin: const EdgeInsets.all(0),
                          decoration: const BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(16)),
                            gradient: LinearGradient(
                              colors: [
                                AppTheme.coral0Main,
                                Color(0xFFFF4D78), // ??
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          //"Pagos pendientes",
                                          copy('collections.pending-payments'),
                                          style: AppThemeScope.of(context)
                                              .typography
                                              .bd2
                                              .medium
                                              .copyWith(color: Colors.white),
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              isDebtVisible
                                                  ? Constants.currencyFormatter
                                                      .format(
                                                      selectedConciliation
                                                              ?.debt ??
                                                          0,
                                                    )
                                                  : "dummydata".replaceAll(
                                                      RegExp(r"."),
                                                      "*",
                                                    ),
                                              style: const TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.white,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            const SizedBox(
                                              width: 11,
                                            ),
                                            GestureDetector(
                                              onTap: () =>
                                                  changeDebtVisibility(),
                                              child: const Icon(
                                                Icons.visibility_outlined,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    Container(
                                      decoration: const BoxDecoration(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(4),
                                        ),
                                        color: Colors.white,
                                      ),
                                      child: getUnitTag(
                                        context,
                                        selectedConciliation,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: const [
                              // TODO this data is not available in services.
                              // Text(
                              //   "Saldo a favor",
                              //   style: AppThemeScope.of(context)
                              //       .typography
                              //       .caption
                              //       .xxsMedium
                              //       .copyWith(color: Colors.white),
                              // ),
                              // Text(
                              //   "+\$123,456.00",
                              //   style: AppThemeScope.of(context)
                              //       .typography
                              //       .caption
                              //       .xxsMedium
                              //       .copyWith(color: Colors.white),
                              // ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(
                  height: 40,
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: AppTheme.grayArtic0main,
                    borderRadius: BorderRadius.all(Radius.circular(100)),
                  ),
                  child: NvTabBar(
                    tabs: [
                      Tab(text: copy('collections.debts')),
                      Tab(text: copy('collections.movements')),
                      Tab(text: copy('collections.receipts')),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    physics: const NeverScrollableScrollPhysics(), // Temporal.
                    children: [
                      DebtsView(
                        servicePointId: selectedConciliation?.servicePoint?.id,
                      ),
                      MovementsMain(
                        servicePointId: selectedConciliation?.servicePoint?.id,
                      ),
                      HistoryView(
                        servicePointId: selectedConciliation?.servicePoint?.id,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
