import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/associate_payments/associate_payment_detail_card.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/widgets.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_topbar.dart';

class AssociatePaymentMain extends StatefulWidget {
  const AssociatePaymentMain({Key? key, required this.transactionToAssociate})
      : super(key: key);

  final Transaction transactionToAssociate;

  @override
  State<AssociatePaymentMain> createState() => _AssociatePaymentMainState();
}

class _AssociatePaymentMainState extends State<AssociatePaymentMain> {
  static const double _bottomSheetHeight = 80;
  List<Invoice>? invoices;
  List<Invoice> selectedDebts = [];
  Map<int, ExpandableController> invoiceControllers = {};
  Map<int, bool> checkboxesActualStates = {};
  DateFormat dateFormatter = DateFormat("yyyy/MM/dd");
  double totalValueSelected = 0;
  Function copy = AppMessages().getCopy;
  Map<int, TextEditingController> textControllers = {};
  Map<int, GlobalKey<FormState>> keys = {};
  List<Invoice>? responseInvoices;

  @override
  void initState() {
    callGetInvoices();
    super.initState();
  }

  /// Trae los invoices del servicio
  ///
  callGetInvoices() async {
    context.loaderOverlay.show();
    responseInvoices = await getInvoices(false, null);
    setState(() {
      invoices = responseInvoices;
      context.loaderOverlay.hide();
      for (var count = 0; count < (responseInvoices?.length ?? 0); count++) {
        keys[count] = GlobalKey<FormState>();
        textControllers[count] = TextEditingController();
        invoiceControllers[count] = ExpandableController();
      }
    });
  }

  /// It takes a date in the format "yyyy-MM-dd" and returns a date in the format "d de MMMM de yy"
  ///
  /// Args:
  ///   date (String): The date to be formatted.
  ///
  /// Returns:
  ///   A string with the date in the format "d de MMMM de yy"
  String formatDate(String date) {
    var parsed = dateFormatter.parse(date);
    DateFormat longDateFormatter =
        DateFormat('d' ' - ' 'MMMM' ' - ' 'yy', 'es_CO');
    return longDateFormatter.format(parsed).replaceAll("-", "de");
  }

  /// It takes a debt and a value, changes the total value in bottom sheet
  /// if the input is modified
  ///
  /// Args:
  ///   debt (Invoice): Invoice?
  ///   value (String): The value of the debt
  // ignore: long-method
  changePayValue(Invoice? debt, String value) {
    value = value.replaceAll("\$ ", "");
    setState(() {
      int debtIndex =
          selectedDebts.indexWhere((element) => debt?.id == element.id);
      if (value.isNotEmpty) {
        if (debtIndex != -1) {
          selectedDebts[debtIndex].valueToPay =
              double.parse((value).replaceAll(",", "."));
          selectedDebts[debtIndex].value =
              double.parse((value).replaceAll(",", "."));
        }
        if (double.parse((value).replaceAll(",", ".")) == 0) {
          selectedDebts[debtIndex].valueToPay = invoices
              ?.firstWhere(
                (element) => element.id == selectedDebts[debtIndex].id,
              )
              .value;
          selectedDebts[debtIndex].value = invoices
              ?.firstWhere(
                (element) => element.id == selectedDebts[debtIndex].id,
              )
              .value;
        }
      } else {
        selectedDebts[debtIndex].valueToPay = invoices
            ?.firstWhere(
              (element) => element.id == selectedDebts[debtIndex].id,
            )
            .value;
        selectedDebts[debtIndex].value = invoices
            ?.firstWhere(
              (element) => element.id == selectedDebts[debtIndex].id,
            )
            .value;
      }
      calculateTotalSelected();
    });
  }

  /// Calculate the total value of selected items.
  calculateTotalSelected() {
    totalValueSelected = 0;
    for (var element in selectedDebts) {
      totalValueSelected = totalValueSelected + (element.valueToPay ?? 0);
    }
  }

  /// It sets the state of
  /// the widget, and if the value is true, it adds the invoice to the selectedDebts list, and sets the
  /// expanded value of the currentControllers at the index to true. If the value is false, it removes
  /// the invoice from the selectedDebts list, and sets the expanded value of the currentControllers at
  /// the index to false. It then calculates the total selected, and sets the checkboxesActualStates or
  /// checkboxesFutureStates at the index to the opposite of what it was
  ///
  /// Args:
  ///   value: bool,
  ///   invoice (Invoice): Invoice
  ///   index: the index of the item in the list
  ///   isActual: bool
  // ignore: long-parameter-list
  changeCheckValue(value, Invoice? invoice, index, isActual) {
    setState(() {
      if (value) {
        if (!selectedDebts.any((element) => element.id == invoice?.id)) {
          selectedDebts
              .add(Invoice.fromJson(invoice?.toJson() ?? {})); // ! shadowing.
          invoiceControllers[index]?.expanded = true;
        }
      } else {
        selectedDebts.removeWhere((element) => element.id == invoice?.id);
        invoiceControllers[index]?.expanded = false;
      }
      calculateTotalSelected();
      checkboxesActualStates[index] = value;
    });
  }

  double calculateTotalDiscount() {
    return (widget.transactionToAssociate.positiveBalance?.value ?? 0) -
        totalValueSelected;
  }

  // ignore: long-method
  goToAssociate(context) async {
    var response = await associatePayment(jsonForBodyRequest());
    if (response.success == true) {
      var positiveBalance =
          Constants.currencyFormatter.format(response.data?.value).toString();
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          // ignore: prefer-extracting-callbacks
          Future.delayed(const Duration(seconds: 3), () {
            Navigator.pop(context);
            Navigator.pushNamed(
              context,
              "invoice",
              arguments: {
                "fromAssociation": {
                  "associatedPay": response,
                  "associatedPayIdBalance":
                      widget.transactionToAssociate.idBalance,
                },
              },
            );
          });
          return NvAlert(
            type: "success",
            hasTitle: true,
            titleText: copy('charges.payment-associated-with-success'),
            content:
                copy('charges.positive-balance-message', [positiveBalance]),
          );
        },
      );
    } else {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Future.delayed(const Duration(seconds: 2), () {
            Navigator.of(context).pop();
          });
          return NvAlert(
            type: "error",
            content: copy(
              'charges.an-error-occurred-when-associating-your-payment-try-again',
            ),
          );
        },
      );
    }
  }

  jsonForBodyRequest() {
    var idBalance = widget.transactionToAssociate.idBalance;
    var userChange = UserUtils.currentUser?.id;
    var auxList = [];
    for (var element in selectedDebts) {
      auxList.add({"idInvoice": element.id, "payedValue": element.valueToPay});
    }
    return {
      "id": idBalance,
      "paymentInvoiceValueList": auxList,
      "userChange": userChange,
    };
  }

  showExceedAlert(context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "warning",
          // "El valor excede el monto disponible",.
          content: copy(
            'charges.the-entered-value-exceeds-the-amount-you-have-available-at-this-time',
          ),
        );
      },
    );
  }

  // Iterates over the list "paymentInvoiceValueList" and adds the values of each associated invoice.
  calculateValueAssociated() {
    double sum = 0;
    var list = widget
            .transactionToAssociate.positiveBalance?.paymentInvoiceValueList ??
        [];
    if (list.isNotEmpty) {
      sum = list
              .map((e) => e.payedValue)
              .reduce((value, element) => (value ?? 0) + (element ?? 0)) ??
          0;
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const NvTopBar(),
      bottomSheet: selectedDebts.isNotEmpty
          ? TotalBottom(
              bottomSheetwidth: MediaQuery.of(context).size.width,
              checkPendingTransaction: calculateTotalDiscount() < 0
                  ? showExceedAlert
                  : goToAssociate,
              bottomSheetHeight: _bottomSheetHeight,
              totalValueSelected: totalValueSelected,
              selectedDebts: selectedDebts,
            )
          : null,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 80),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                // 'Asociar pago',
                copy('charges.associate-payment'),
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 26,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              //Associate Payment Detail
              AssociatePaymentDetail(
                count: widget.transactionToAssociate.positiveBalance
                        ?.paymentInvoiceValueList?.length ??
                    0,
                totalPayed: calculateValueAssociated(),
                pendingToAsociate: calculateTotalDiscount(),
                // calculateToDiscount: calculateTotalDiscount,
              ),
              const SizedBox(
                height: 16,
              ),
              CurrentDebtsList(
                currentKeys: keys,
                currentTextControllers: textControllers,
                currentDebts: invoices,
                currentControllers: invoiceControllers,
                checkboxesActualStates: checkboxesActualStates,
                formatDate: formatDate,
                changePayValue: changePayValue,
                changeCheckValue: changeCheckValue,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
