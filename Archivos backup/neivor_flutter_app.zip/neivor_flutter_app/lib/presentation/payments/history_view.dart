import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/empty_view.dart';
import 'package:neivor_flutter_app/presentation/payments/widgets/history_widgets/history_card.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';

class HistoryView extends StatefulWidget {
  const HistoryView({
    Key? key,
    this.servicePointId,
  }) : super(key: key);
  final int? servicePointId;

  @override
  State<HistoryView> createState() => _HistoryViewState();
}

class _HistoryViewState extends State<HistoryView> {
  List<Invoice>? historyInvoiceList;
  List<Invoice> filterList = [];
  bool inSearch = false;
  Function copy = AppMessages().getCopy;
  bool isLoading = false;

  @override
  void initState() {
    callGetHistoryInvoices();
    inSearch = false;
    super.initState();
  }

  callGetHistoryInvoices() async {
    isLoading = true;
    context.loaderOverlay.show();
    var responseInvoices = await getInvoices(
      true,
      widget.servicePointId ?? UserUtils.currentServicePoint?.id,
    );
    historyInvoiceList = responseInvoices;
    isLoading = false;
    context.loaderOverlay.hide();
    setState(() {});
  }

  filterHistoryInvoiceList(String input) {
    setState(() {
      filterList = historyInvoiceList!
          .where((inv) => inv.descriptionService!
              .toLowerCase()
              .contains(input.toLowerCase()))
          .toList();
    });
  }

  cantItemsCard() {
    return filterList.isEmpty && inSearch
        ? filterList.length
        : inSearch
            ? filterList.length
            : historyInvoiceList?.length ?? 0;
  }

  invoiceObjectToCard(int index) {
    return filterList.isEmpty && inSearch
        ? filterList.isNotEmpty
            ? filterList[index]
            : null
        : inSearch
            ? filterList[index]
            : historyInvoiceList![index];
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        body: (historyInvoiceList?.isEmpty ?? true) && !isLoading
            ? EmptyView(
                fromTo: 'history',
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 80),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 16,
                    ),
                    // Search.
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        autofocus: false,
                        // ignore: prefer-extracting-callbacks
                        onFieldSubmitted: (value) {
                          if (value != "") {
                            inSearch = true;
                            filterHistoryInvoiceList(value);
                          } else {
                            setState(() {
                              filterList = [];
                              inSearch = false;
                            });
                          }
                        },
                        decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search),
                          //'Buscar',
                          hintText: copy('user-access.search'),
                        ),
                      ),
                    ),
                    if (filterList.isEmpty && inSearch)
                      Text(
                        //"No se encontraron resultados",
                        copy('common.without-results'),
                        style: const TextStyle(
                          color: Color.fromARGB(255, 235, 18, 18),
                        ),
                      ),
                    const SizedBox(
                      height: 16,
                    ),
                    // Invoice history list.
                    ListView.separated(
                      physics: const NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      separatorBuilder: (context, index) {
                        return const SizedBox(
                          height: 16,
                        );
                      },
                      itemCount: cantItemsCard(),
                      itemBuilder: (BuildContext context, int index) {
                        return CardHistory(
                          invoice: invoiceObjectToCard(index),
                          cookieMessage: copy('charges.paid'),
                        );
                      },
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
