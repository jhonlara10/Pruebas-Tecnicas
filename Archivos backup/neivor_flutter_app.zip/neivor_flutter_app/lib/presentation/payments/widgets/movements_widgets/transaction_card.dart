import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction.dart';
import 'package:neivor_flutter_app/presentation/payments/associate_payment_view.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_tag.dart';

class TransactionCard extends StatelessWidget {
  TransactionCard({
    Key? key,
    required this.transaction,
  }) : super(key: key);

  final Transaction transaction;
  final copy = AppMessages().getCopy;

  // ignore: long-method
  labelNvTag(int state) {
    // estados de transacciones en produccion
    switch (state) {
      case 0:
        if (isToAssociateState(transaction)) {
          // Por asociar
          return copy('charges.to-associate');
        } else if (isApproveState(transaction)) {
          //'Aprobada'
          return copy('charges.passed');
        }
        // Aprobada TC con idBalance y sin idBalance
        return copy('charges.passed');
      case 4:
      case 1:
        //Pendiente SPEI
        return copy('charges.pending-button');
      case 5:
        //Pendiente efectivo
        return copy('charges.pending-button');

      case 2:
        // Rechazada
        return copy('charges.rejected').toLowerCase();
      default:
        return copy('charges.passed');
    }
  }

  // ignore: long-method
  TagVariant tagVariant(int label) {
    // State property in producction.
    switch (label) {
      case 0: // Aprobada - por asociar.
        if (isToAssociateState(transaction)) {
          return TagVariant.blue;
        } else if (isApproveState(transaction)) {
          return TagVariant.harlequinGreen;
        }
        return TagVariant.black;
      case 4: // Pendiente SPEI.
      case 1:
        return TagVariant.yellow;
      case 5: // Pendiente efectivo.
        return TagVariant.yellow;
      case 2: // Rechazada.
        return TagVariant.red;
      default:
        return TagVariant.black;
    }
  }

  // sum the payed value + transaction cost
  double sumTotalValuePayed() {
    double a = transaction.payedValue ?? 0;
    double b = transaction.transactionCost ?? 0;
    return b + a;
  }

  isToAssociateState(t) {
    return (t.state == 0 &&
        t.positiveBalance != null &&
        t.positiveBalance.value != 0);
  }

  isApproveState(t) {
    return (t.state == 0 &&
        (t.positiveBalance == null || (t.positiveBalance.value == 0)));
  }

  // ignore: long-method
  goToMovement(BuildContext context) {
    if (isToAssociateState(transaction)) {
      if (UserUtils().hasPermissionsTo(98)) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                AssociatePaymentMain(transactionToAssociate: transaction),
          ),
        );
      }
    } else {
      Navigator.pushReplacementNamed(
        context,
        "invoice",
        arguments: {
          "fromMovements": {
            "movement": transaction,
          },
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => goToMovement(context),
      child: SizedBox(
        child: Card(
          shape: const RoundedRectangleBorder(
            side: BorderSide(color: AppTheme.grayArtic0main, width: 2),
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0, right: 8),
                        child: Text(
                          GlobalUtils().formatDateUtil(
                            transaction.date ?? '',
                            'yyyy/MM/dd hh:mm:ss',
                            'dd MMM yyyy  -  hh:mm',
                          ),
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      Text(
                        transaction.paymentMethodType?.name?.toUpperCase() ??
                            '',
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        Constants.currencyFormatter
                            .format(sumTotalValuePayed())
                            .toString(),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  NvTag(
                    label: labelNvTag(transaction.state ?? 0),
                    state: tagVariant(transaction.state ?? 0),
                  ),
                ]),
                const SizedBox(
                  width: 8,
                ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [Icon(Icons.chevron_right)],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
