import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';

class ClabeData extends StatelessWidget {
  static const double _clabeHeight = 40;
  const ClabeData({
    Key? key,
    required this.clabeData,
    required this.showCopiedMessage,
  }) : super(key: key);

  final ZyosUserClabe? clabeData;
  final Function showCopiedMessage;

  copyToclipboard(context) {
    Clipboard.setData(ClipboardData(
      text: clabeData?.entity?.referenceNumber ?? '',
    ));
    showCopiedMessage();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(24),
      width: MediaQuery.of(context).size.width,
      color: AppTheme.turquoise2,
      child: Column(
        children: [
          const Text(
            "CLABE única de pago",
            style: TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 22,
            ),
          ),
          const Text(
            'Copia estos datos para pagar por SPEI',
          ),
          const SizedBox(
            height: 16,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Beneficiario"),
              SizedBox(
                width:
                    MediaQuery.of(context).size.width * Constants.fourtyPercent,
                child: Text(
                  UserUtils.currentEnterprise?.name ?? '',
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Razón social"),
              SizedBox(
                width:
                    MediaQuery.of(context).size.width * Constants.fourtyPercent,
                child: Text(
                  UserUtils.currentEnterprise?.name ?? '',
                  textAlign: TextAlign.end,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 16,
          ),
          GestureDetector(
            onTap: () => copyToclipboard(context),
            child: Container(
              alignment: Alignment.center,
              height: _clabeHeight,
              decoration: const BoxDecoration(
                border: Border.fromBorderSide(
                  BorderSide(width: 1, style: BorderStyle.solid),
                ),
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              width: MediaQuery.of(context).size.width -
                  Constants.defaultMarginSum,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(clabeData?.entity?.referenceNumber ?? ''),
                  const SizedBox(
                    width: 50,
                  ),
                  const Icon(Icons.copy),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
