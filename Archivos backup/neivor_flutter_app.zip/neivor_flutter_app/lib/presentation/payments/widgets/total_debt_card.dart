import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/themes/themes.dart';

class TotalDebtCard extends StatelessWidget {
  TotalDebtCard({
    Key? key,
    required this.isDebtVisible,
    required this.changeDebtVisibility,
    required this.getTotalDebt,
  }) : super(key: key);

  final bool isDebtVisible;
  final Function changeDebtVisibility;
  final Function getTotalDebt;
  final copy = AppMessages().getCopy;

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
      margin: const EdgeInsets.only(top: 26, bottom: 26),
      child: Container(
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          gradient: LinearGradient(
            colors: [
              AppTheme.coral0Main,
              Color(0xFFFF4D78), // ??
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              //"Pagos pendientes",
              copy('collections.pending-payments'),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w400,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  isDebtVisible
                      ? getTotalDebt()
                      : "dummydatta".replaceAll(RegExp(r"."), "*"),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(
                  width: 11,
                ),
                GestureDetector(
                  onTap: () => changeDebtVisibility(),
                  child: const Icon(
                    Icons.visibility_outlined,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
