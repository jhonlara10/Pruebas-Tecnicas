import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class AssociatePaymentDetail extends StatefulWidget {
  final int count;
  final double totalPayed;
  final double pendingToAsociate;
  // Function calculateToDiscount;.

  const AssociatePaymentDetail({
    Key? key,
    required this.count,
    required this.totalPayed,
    required this.pendingToAsociate,
    // Required this.calculateToDiscount,.
  }) : super(key: key);

  @override
  State<AssociatePaymentDetail> createState() => _AssociatePaymentDetailState();
}

class _AssociatePaymentDetailState extends State<AssociatePaymentDetail> {
  Function copy = AppMessages().getCopy;
  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    return Container(
      height: 112,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: colors.secondary.persianBlue.main.withOpacity(0.1),
      ),
      child: Padding(
        padding: const EdgeInsets.only(
          left: 16,
          right: 16,
          top: 8,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  //"Pagos asociados",
                  copy('charges.payments-asociated'),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w300,
                  ),
                ),
                Text(
                  //count
                  widget.count.toString(),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  //"Total pagado",
                  copy('charges.total-payed'),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w300,
                  ),
                ),
                Text(
                  // totalPayed
                  Constants.currencyFormatter
                      .format(widget.totalPayed)
                      .toString(),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  //"Pendiente",
                  copy('charges.pending-button'),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  //pendingToAsociate
                  Constants.currencyFormatter.format(
                    widget.pendingToAsociate,
                  ),
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 24,
                    color: widget.pendingToAsociate >= 0
                        ? colors.secondary.indigoBlue.main
                        : colors.primary.coral.main,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
