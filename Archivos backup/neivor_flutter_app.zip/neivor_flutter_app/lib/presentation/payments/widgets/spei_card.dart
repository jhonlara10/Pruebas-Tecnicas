import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/spei/davivienda_payment_response.dart';
import 'package:neivor_flutter_app/presentation/payments/pending_payment_view.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/styles/nv_button/secondary.dart';

class SpeiCard extends StatelessWidget {
  const SpeiCard({
    Key? key,
    required this.showLoader,
    required this.isActive,
  }) : super(key: key);

  final Function showLoader;
  final bool isActive;

  // ignore: long-method
  goToSpeiClabe(context) async {
    List<Map<String, dynamic>> selectedDebtsAsJson = [];
    BlocProvider.of<PaymentsBloc>(context)
        .state
        .selectedDebts
        ?.forEach((element) {
      selectedDebtsAsJson.add({
        "idInvoice": element.id,
        "value": element.valueToPay,
      });
    });
    Map<String, dynamic> request = {
      "enterprise": {
        "id": UserUtils.currentEnterprise?.id,
      },
      "servicePoint": {
        "id": UserUtils.currentServicePoint?.id,
      },
      "zyosUser": {
        "id": UserUtils.currentUser?.id,
      },
      "userInvoicePaymentList": selectedDebtsAsJson,
      "paymentMethodType": {
        "id": 11,
      },
    };
    showLoader(true);
    DaviviendaPaymentResponse response = await addSpeiPayment(request);
    showLoader(false);
    if (response.success ?? false) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const PendingPaymentView(
            isAfterSpei: true,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      enabled: isActive,
      onTap: () => goToSpeiClabe(context),
      contentPadding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      leading: const NvImage(imageUrl: 'payment/method-type/spei.png'),
      isThreeLine: true,
      title: const NvText(
        copy: "payments.spei-transfer",
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: AppTheme.black0Main,
      ),
      subtitle: Row(
        children: [
          Chip(
            backgroundColor: AppTheme.greenArlequin0main
                .withOpacity(Constants.twentyPercent),
            label: NvText(
              copy: "social-areas.free",
              fontSize: 12,
              color: isActive
                  ? AppTheme.greenArlequin4
                  : AppTheme.greenArlequin4.withOpacity(0.1),
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
      trailing: isActive
          ? const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.textPrimary,
            )
          : ElevatedButton(
              onPressed: () {},
              child: const NvText(
                copy: "common.inactive",
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.black0Main,
              ),
              style: getSecondaryButtonStyle(context),
            ),
    );
  }
}
