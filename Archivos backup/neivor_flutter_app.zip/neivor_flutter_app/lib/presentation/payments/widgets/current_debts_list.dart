import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class CurrentDebtsList extends StatelessWidget {
  CurrentDebtsList({
    Key? key,
    required this.currentDebts,
    required this.currentControllers,
    required this.checkboxesActualStates,
    required this.formatDate,
    required this.changePayValue,
    required this.changeCheckValue,
    required this.currentTextControllers,
    required this.currentKeys,
  }) : super(key: key);

  final List<Invoice>? currentDebts;
  final Map<int, ExpandableController> currentControllers;
  final Map<int, bool> checkboxesActualStates;
  final Function formatDate;
  final Function changePayValue;
  final Function changeCheckValue;
  final copy = AppMessages().getCopy;
  final Map<int, TextEditingController> currentTextControllers;
  final Map<int, GlobalKey<FormState>> currentKeys;

  bool isDiscountAplicable(Invoice? invoice) {
    if (invoice?.idDiscountDataLog != null) {
      final DateTime parsedDate =
          DateFormat('yyyy/MM/dd').parse(invoice?.discountDate ?? '');
      return parsedDate.isAfter(DateTime.now().add(const Duration(days: 1))) &&
          (invoice?.discountDataList?.isNotEmpty ?? false);
    }
    return false;
  }

  // ignore: long-method
  String calculateDiscount(Invoice? invoice) {
    return Constants.currencyFormatter
        .format((invoice?.value ?? 0) - (invoice?.discountValue ?? 0));
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      separatorBuilder: (context, index) {
        return const SizedBox(
          height: 16,
        );
      },
      physics: const NeverScrollableScrollPhysics(),
      scrollDirection: Axis.vertical,
      shrinkWrap: true,
      itemCount: currentDebts?.length ?? 0,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            border: Border.fromBorderSide(
              BorderSide(color: AppTheme.black2),
            ),
            borderRadius: BorderRadius.all(Radius.circular(4)),
          ),
          child: ExpandablePanel(
            theme: const ExpandableThemeData(
              headerAlignment: ExpandablePanelHeaderAlignment.center,
              iconPadding: EdgeInsets.only(left: 0),
            ),
            controller: currentControllers[index],
            header: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        if (UserUtils().hasPermissionsTo(789))
                          Checkbox(
                            tristate: false,
                            value: checkboxesActualStates[index] ?? false,
                            onChanged: (value) => changeCheckValue(
                              value,
                              currentDebts?[index],
                              index,
                              true,
                            ),
                            shape: const RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(6)),
                            ),
                            activeColor: AppTheme.turquoise4,
                          ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width *
                              Constants.thirtyPercent,
                          child: Text(
                            currentDebts?[index].descriptionService ?? '',
                            overflow: TextOverflow.clip,
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.3,
                      child: Text(
                        Constants.currencyFormatter.format(
                          currentDebts?[index].valueToPay,
                        ),
                        style: AppThemeScope.of(context).typography.bd2.medium,
                        textAlign: TextAlign.right,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            collapsed: const SizedBox(),
            expanded: Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //TODO: ver formato para multilenguaje actual "3 de junio de 22"
                  Text(formatDate(
                    currentDebts?[index].initialDate ?? '',
                  )),
                  const SizedBox(
                    height: 16,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        //"Tarifa plena",
                        copy('charges.full-rate'),
                      ),
                      Text(
                        Constants.currencyFormatter
                            .format(currentDebts?[index].value),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 8,
                  ),

                  if ((currentDebts?[index].paymentSumValue ?? 0) != 0)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          // "Pago parcial",
                          copy('charges.partial-payment'),
                        ),
                        Text(
                          "- ${Constants.currencyFormatter.format(
                            currentDebts?[index].paymentSumValue,
                          )}",
                        ),
                      ],
                    ),
                  if ((currentDebts?[index].sanctionValueToShow ?? 0) != 0)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          // "Multa",
                          copy('charges.fine'),
                        ),
                        Text(
                          Constants.currencyFormatter.format(
                            currentDebts?[index].sanctionValueToShow,
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(
                    height: 8,
                  ),
                  if (isDiscountAplicable(currentDebts?[index]))
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const NvText(
                          //"Descuento",
                          copy: 'charges.discount',
                          color: AppTheme.black4,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                        Text(
                          calculateDiscount(currentDebts?[index]),
                        ),
                      ],
                    ),
                  const SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        //"Pago total",
                        copy('charges.total-pay'),
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        Constants.currencyFormatter
                            .format(currentDebts?[index].valueToPay),
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  if (UserUtils().hasPermissionsTo(791))
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const NvText(
                          copy: 'payments.pay-payment',
                          fontSize: 14,
                          color: AppTheme.black0Main,
                          fontWeight: FontWeight.w400,
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width *
                              Constants.thirtyPercent,
                          child: TextField(
                            key: currentKeys[index],
                            controller: currentTextControllers[index],
                            decoration: const InputDecoration(
                              prefixIcon: Icon(
                                Icons.attach_money,
                                color: Colors.grey,
                              ),
                            ),
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(
                                RegExp(r'^\d+\.?\d*'),
                              ),
                            ],
                            textAlign: TextAlign.right,
                            keyboardType: TextInputType.number,
                            // ignore: prefer-extracting-callbacks
                            onChanged: (value) {
                              changeCheckValue(
                                true,
                                currentDebts?[index],
                                index,
                                true,
                              );
                              changePayValue(
                                currentDebts?[index],
                                value,
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(
                    height: 8,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
