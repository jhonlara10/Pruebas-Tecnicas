import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class PseTile extends StatelessWidget {
  const PseTile({
    Key? key,
    required this.callPsePay,
    required this.isActive,
  }) : super(key: key);

  final Function callPsePay;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      enabled: isActive,
      onTap: () => callPsePay(),
      contentPadding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      leading: const NvImage(
        imageUrl: 'payment/method-type/logo-pse.png',
        width: 40,
        height: 40,
      ),
      isThreeLine: true,
      title: const Text(
        "PSE",
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.4,
            child: const Text(
              "A través de tus cuentas de ahorro",
              overflow: TextOverflow.clip,
              maxLines: 2,
            ),
          ),
        ],
      ),
      trailing: isActive
          ? const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.textPrimary,
            )
          : ElevatedButton(
              onPressed: () {},
              child: const Text(
                "Inactivo",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
    );
  }
}
