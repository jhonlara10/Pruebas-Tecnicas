import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class EmptyView extends StatefulWidget {
  String? fromTo;

  EmptyView({
    Key? key,
    required this.fromTo,
  }) : super(key: key);

  @override
  State<EmptyView> createState() => _EmptyViewState();
}

class _EmptyViewState extends State<EmptyView> {
  String? image;
  String? title;
  String? subtitle;
  double? width;
  double? height;
  double? scale;
  Function copy = AppMessages().getCopy;
  User? currentProfileUser;
  bool? isAdminRole = false;

  @override
  // ignore: long-method
  void initState() {
    (() async {
      await isAdminRoleLogic();
    })();
    super.initState();
  }

  isAdminRoleLogic() async {
    isAdminRole = await currentProfileUser?.isAdmin();
    setState(() {});
  }

  // ignore: long-method
  buildFromTo(String from) {
    switch (from) {
      case 'debts':
        width = 123;
        scale = 0.7;
        image = 'ds/icons/walking.png';
        title = !(isAdminRole ?? false)
            ? copy('payments.the-resident-is-up-to-date')
            : copy('charges.empty-payment');
        subtitle = '';
        break;
      case 'movements':
        scale = 0.7;
        width = 150;
        image = 'ds/illustrations/meditate.png';
        title = !(isAdminRole ?? false)
            ? copy('payments.the-resident-has-not-yet-made-any-payment')
            : copy('charges.empty-not-payment-yet');
        subtitle = !(isAdminRole ?? false)
            ? copy('payments.remind-him to-pay-for-neivor')
            : copy('charges.empty-movements');
        break;
      case 'history':
        scale = 0.7;
        width = 160;
        image = 'ds/illustrations/buildings.png';
        title = !(isAdminRole ?? false)
            ? copy('payments.he-resident-still-has-no-receipts')
            : copy(
                'payments.you-still-do-not-have-any-receipt-of-your-payments',
              );
        subtitle = '';
        break;
      case 'statements':
        scale = 0.7;
        width = 160;
        image = 'ds/illustrations/buildings.png';
        title = copy('payments.input-your-residents-financial-information');
        subtitle = copy('payments.start-filling-in-the-financial-information');
        break;
      case 'adminMovements':
        scale = 0.7;
        width = 160;
        image = 'ds/illustrations/flying-Money.png';
        title = copy('payments.no-transactions');
        subtitle =
            copy('payments.verify-that-your-payment-methods-are-activated');
        break;
      default:
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    buildFromTo(widget.fromTo ?? '');
    return Column(children: [
      Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                top: 60,
              ),
              child: FadeInImage(
                width: width,
                height: height,
                image: NetworkImage(
                  GlobalUtils().staticCdn(image ?? ''),
                  scale: scale ?? 1,
                ),
                placeholder: const NetworkImage(
                  "https://cdn.neivor.com/cdn/mexico/static/ds/icons/loadingSpinner.gif",
                ),
                imageErrorBuilder: (
                  BuildContext context,
                  Object object,
                  StackTrace? stackTrace,
                ) {
                  return const NvImage(
                    isUserImage: true,
                    imageUrl: '/default/no_avatar.png',
                    width: 200,
                    height: 200,
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                top: 12,
              ),
              child: NvText(
                textHolder: title,
                fontFamily: 'Jost',
                fontWeight: FontWeight.w500,
                fontSize: 22,
                color: colors.text.primary,
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                top: 10,
                left: 30,
                right: 30,
              ),
              child: NvText(
                textHolder: subtitle,
                fontFamily: 'Jost',
                fontWeight: FontWeight.w300,
                fontSize: 16,
                color: colors.text.primary,
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    ]);
  }
}
