import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/presentation/payments/history_detail_view.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import '../../../util/constants.dart';

class CardHistory extends StatelessWidget {
  const CardHistory({
    Key? key,
    required this.invoice,
    required this.cookieMessage,
  }) : super(key: key);

  final Invoice? invoice;
  final String cookieMessage;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => HistoryPaymentDetail(
              idInvoice: invoice?.id.toString(),
              invoice: invoice,
            ),
          ),
        );
      },
      child: Card(
        elevation: 0,
        shape: const RoundedRectangleBorder(
          side: BorderSide(
            color: AppTheme.grayArtic0main,
          ),
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: 300,
            height: 87,
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0, right: 8),
                        child: Text(
                          invoice?.descriptionService ?? '',
                          maxLines: 2,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      Text(
                        Constants.currencyFormatter
                            .format(invoice?.paidValue)
                            .toString(),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(5)),
                        color: AppTheme.turquoise0Main.withOpacity(0.1),
                      ),
                      padding: const EdgeInsets.all(5),
                      width: 60,
                      child: Center(
                        child: Text(
                          cookieMessage,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.greenArlequin4,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
