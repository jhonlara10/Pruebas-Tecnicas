import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/transaction_invoice_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import '../../../../themes/app_theme.dart';

class DetailPaymentCard extends StatelessWidget {
  final Invoice? invoice;
  final List<TransactionList>? listTrans;
  Function copy = AppMessages().getCopy;

  DetailPaymentCard({
    Key? key,
    this.invoice,
    this.listTrans,
  }) : super(key: key);

  // ignore: long-method
  discountOrSanction() {
    if (invoice?.sanctionValueToShow != null &&
        invoice?.sanctionValueToShow != 0.0) {
      var sanction = invoice?.sanctionValueToShow ?? 0;
      // TODO: revisar en escenario porcentaje- actual produccion- valor 1 la multa se aplica en valor, no porcentaje
      var idCriterialSanction =
          invoice?.sanctionDataLog?.first.idCriteriaSanction;
      return Column(
        children: [
          const Divider(
            height: 40,
            thickness: 1,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                //"Multa",
                copy('charges.fine'),
              ),
              Text(
                Constants.currencyFormatter.format(sanction).toString(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                // "Pago despues del",
                copy('charges.payment-after'),
              ),
              const SizedBox(
                width: 10,
              ),
              Text(GlobalUtils().formatDateUtil(
                invoice?.sanctionDate ?? '',
                'yyyy/MM/dd',
                'dd/MM/yyyy',
              )),
            ],
          ),
        ],
      );
    } else if (invoice?.discountDataList?.isNotEmpty ?? false) {
      var criterialDiscount = invoice?.discountDataList?[0].idCriteriaDiscount;
      // idCriterialDiscount = 1 es porcentaje
      var discount = invoice?.discountDataList?[0].discount ?? 0;
      var processDisc = discount;
      if (criterialDiscount == 1) {
        processDisc = invoice!.initialValue! * discount / 100;
      }

      return Column(
        children: [
          const Divider(
            height: 40,
            thickness: 1,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                //Descuento
                criterialDiscount == 1
                    ? '${copy('charges.discount')} ( ${discount.toInt()}% )'
                    : copy('charges.discount'),
              ),
              Text(
                Constants.currencyFormatter.format(processDisc).toString(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                //"Pago antes del",
                copy('charges.payment-before'),
              ),
              const SizedBox(width: 10),
              Text(
                invoice?.discountDate ?? '',
              ),
            ],
          ),
        ],
      );
    } else {
      return const Text('');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: Colors.black12),
      ),
      elevation: 0,
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(Radius.circular(5)),
              color: AppTheme.turquoise0Main.withOpacity(0.2),
            ),
            padding: const EdgeInsets.all(20),
            margin: const EdgeInsets.only(bottom: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  //'tarifa plena'.toUpperCase(),
                  copy('charges.full-rate'),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  Constants.currencyFormatter
                      .format(invoice?.initialValue ?? 0)
                      .toString(),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Column(
                  children: [
                    ListView.separated(
                      separatorBuilder: (context, index) {
                        return const SizedBox(
                          height: 8,
                        );
                      },
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: listTrans?.length ?? 0,
                      itemBuilder: (BuildContext context, int index) {
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const SizedBox(height: 7),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                SizedBox(
                                  width: MediaQuery.of(context).size.width *
                                      Constants.fiftyPercent,
                                  child: Text(
                                    listTrans?[index].descRespuesta ?? '',
                                    overflow: TextOverflow.clip,
                                    maxLines: 2,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                                Text(
                                  Constants.currencyFormatter
                                      .format(listTrans?[index].payedValue ?? 0)
                                      .toString(),
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            // Payment type - cash, bank transaction, etc.
                            Row(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      listTrans?[index].paymentType?.name ?? '',
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0,
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      GlobalUtils().formatDateUtil(
                                        listTrans?[index].date ?? '',
                                        "yyyy/MM/dd HH:mm:ss",
                                        'dd/MM/yyyy',
                                      ),
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w300,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              children: [
                                GestureDetector(
                                  onTap: () => Navigator.pushNamed(
                                    context,
                                    "invoice",
                                    arguments: {
                                      "fromHistory": {
                                        "transaction": listTrans?[index],
                                        "invoice": invoice,
                                      },
                                    },
                                  ),
                                  child: Text(
                                    //'Ver recibo',
                                    copy('charges.see-receipt'),
                                    style: TextStyle(
                                      decoration: TextDecoration.underline,
                                      color: Colors.green.shade700,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                    // Discount, sanctions or interest applied.
                    discountOrSanction(),
                    const Divider(height: 30, thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          //"Total pagado",
                          copy('charges.total-payed'),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                        Text(
                          Constants.currencyFormatter
                              .format(invoice?.paymentSumValue ?? 0)
                              .toString(),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
