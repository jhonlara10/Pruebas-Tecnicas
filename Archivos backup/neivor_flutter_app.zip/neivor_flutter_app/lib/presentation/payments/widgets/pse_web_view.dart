import 'dart:io';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:webview_flutter/webview_flutter.dart';

class PseWebView extends StatefulWidget {
  final String? url;

  const PseWebView({Key? key, this.url}) : super(key: key);

  @override
  PseWebViewState createState() => PseWebViewState();
}

class PseWebViewState extends State<PseWebView> {
  @override
  void initState() {
    super.initState();
    // Enable virtual display.
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }

  callPaymentResponse(String orderId) async {
    context.loaderOverlay.show();
    var invoiceData = await getInvoiceResponseInfo(orderId);
    context.loaderOverlay.hide();
    // ignore: use_build_context_synchronously
    Navigator.pushReplacementNamed(
      context,
      "invoice",
      arguments: {
        "fromCardPay": {
          "invoice": invoiceData,
        },
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WebView(
      initialUrl: "https://${widget.url}",
      javascriptMode: JavascriptMode.unrestricted,
      gestureNavigationEnabled: true,
      // ignore: prefer-extracting-callbacks
      onPageFinished: (String url) {
        if (url.contains("resultadoPago")) {
          Uri resultPayment = Uri.parse(url);
          var orderNumber = resultPayment.queryParameters['order'];
          callPaymentResponse(orderNumber ?? "");
        }
      },
    );
  }
}
