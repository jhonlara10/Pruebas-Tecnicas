import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class PrepaidSection extends StatelessWidget {
  PrepaidSection({
    Key? key,
    required this.prepaidController,
    required this.prepaidModify,
    required this.prepaidTextController,
    required this.prepaidKey,
  }) : super(key: key);

  final ExpandableController prepaidController;
  final Function prepaidModify;
  final copy = AppMessages().getCopy;
  final TextEditingController prepaidTextController;
  final GlobalKey<FormState> prepaidKey;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: const Border.fromBorderSide(
          BorderSide(color: AppTheme.black2),
        ),
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: AppTheme.turquoise0Main.withOpacity(Constants.twentyPercent),
      ),
      child: ExpandablePanel(
        controller: prepaidController,
        theme: const ExpandableThemeData(
          headerAlignment: ExpandablePanelHeaderAlignment.center,
        ),
        header: Container(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              const NvImage(imageUrl: "ds/icons/card-heart.svg"),
              const SizedBox(width: 16),
              Text(
                //"Pago anticipado",
                copy('prepay-button'),
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
        collapsed: const SizedBox(),
        expanded: Container(
          padding: const EdgeInsets.all(16),
          color: Colors.white,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Text(
                    "*",
                    style: TextStyle(
                      color: AppTheme.rosePonche0Main,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    copy('charges.mount'),
                    //"Monto",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 8,
              ),
              TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(
                    Icons.attach_money,
                    color: Colors.grey,
                  ),
                ),
                key: prepaidKey,
                controller: prepaidTextController,
                textAlign: TextAlign.right,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                    RegExp(r'^\d+\.?\d*'),
                  ),
                ],
                onChanged: (value) => prepaidModify(value),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
