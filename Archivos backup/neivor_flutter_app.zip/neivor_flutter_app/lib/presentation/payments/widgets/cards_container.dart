import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/payment_methods_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/presentation/payments/add_new_card.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/styles/nv_button/secondary.dart';

class CardsContainer extends StatelessWidget {
  static const double _cardLogoWidth = 35;
  static const double _cardLogoHeight = 24;
  const CardsContainer({
    Key? key,
    required this.paymentMethods,
    this.paymentCommission,
    required this.isActive,
  }) : super(key: key);
  final PaymentCommission? paymentCommission;
  final bool isActive;

  final List<UserPaymentMethodResponse>? paymentMethods;

  // ignore: long-method
  getCardLogo(String string) {
    String newString = string.replaceAllMapped(RegExp(r"[0-9]*\** *"), (_) {
      return '';
    });
    switch (newString.toUpperCase()) {
      case 'MASTERCARD':
      case 'MASTER':
        return "payment/cc-brand/logo-mastercard.png";
      case 'VISA':
        return "payment/cc-brand/logo-visa.png";
      case 'DISCOVER':
        return "payment/cc-brand/logo-discover.png";
      case 'DINERS':
      case 'DINERSCLUB':
        return "payment/cc-brand/logo-diners.png";
      default:
        {
          "payment/cc-brand/credit-card.png";
        }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(top: 16),
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const NvImage(imageUrl: "/ds/icons/card.svg"),
                const SizedBox(
                  width: 19,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    NvText(
                      copy: "payments-scheduler.credit-debit",
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: isActive ? Colors.black : Colors.grey,
                    ),
                    NvText(
                      copy: 'payments.accept-all-cards',
                      fontSize: 14,
                      fontWeight: FontWeight.w300,
                      color: isActive ? Colors.black : Colors.grey,
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(
              height: 32,
            ),
            ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: paymentMethods?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  onTap: () => Navigator.pushNamed(
                    context,
                    "confirmPay",
                    arguments: {
                      "registeredCard": paymentMethods?[index],
                      "commision": paymentCommission,
                    },
                  ),
                  enabled: isActive,
                  isThreeLine: true,
                  subtitle: Text(
                    paymentMethods?[index].payer?.name ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  contentPadding: const EdgeInsets.all(0),
                  leading: NvImage(
                    width: _cardLogoWidth,
                    height: _cardLogoHeight,
                    imageUrl: getCardLogo(
                      paymentMethods?[index].name ?? '',
                    ),
                  ),
                  title: Text(
                    paymentMethods?[index].name ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  trailing: isActive
                      ? const Icon(
                          Icons.chevron_right_rounded,
                          color: AppTheme.textPrimary,
                        )
                      : null,
                );
              },
            ),
            ListTile(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddNewCard(
                    commision: paymentCommission,
                  ),
                ),
              ),
              enabled: isActive,
              contentPadding: const EdgeInsets.all(0),
              title: const NvText(
                copy: 'payments.add-new-card',
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: AppTheme.textPrimary,
              ),
              trailing: isActive
                  ? const Icon(
                      Icons.chevron_right_rounded,
                      color: AppTheme.textPrimary,
                    )
                  : ElevatedButton(
                      onPressed: () {},
                      child: const NvText(
                        copy: "common.inactive",
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.black0Main,
                      ),
                      style: getSecondaryButtonStyle(context),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
