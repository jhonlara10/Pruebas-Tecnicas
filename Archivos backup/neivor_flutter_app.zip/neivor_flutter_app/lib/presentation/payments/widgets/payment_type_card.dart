import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/delete_transaction_response.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class PaymentTypeCard extends StatelessWidget {
  const PaymentTypeCard({
    Key? key,
    required this.pendingTransactionId,
    required this.showBottomSheet,
  }) : super(key: key);

  final int? pendingTransactionId;
  final Function showBottomSheet;

  /// If the user is on the payment methods page, and they click the "edit" button, the app will delete
  /// the pending transaction, and then navigate to the payment methods page
  ///
  /// Args:
  ///   context: The context of the current screen.
  goToEditPayment(context) async {
    DeletePendingTransactionResponse? deleteResponse =
        await deletePendingTransaction(pendingTransactionId);
    if (deleteResponse.success ?? false) {
      Navigator.pushReplacementNamed(context, 'paymentMethods');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Método de pago"),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: GestureDetector(
                    onTap: () => showBottomSheet(),
                    child: const NvText(
                      //"Editar",
                      copy: 'common.edit',
                      color: AppTheme.turquoise4,
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      textDecoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.fromLTRB(4, 0, 4, 0),
                      decoration: const BoxDecoration(
                        border: Border.fromBorderSide(
                          BorderSide(
                            color: AppTheme.black2,
                            width: 1,
                            style: BorderStyle.solid,
                          ),
                        ),
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: const NvImage(
                        imageUrl: 'payment/method-type/spei.png',
                        height: 24,
                      ),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    const Text("SPEI"),
                  ],
                ),
                Chip(
                  backgroundColor: AppTheme.greenArlequin0main
                      .withOpacity(Constants.twentyPercent),
                  label: const Text(
                    "Gratis",
                    style: TextStyle(
                      color: AppTheme.greenArlequin4,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
