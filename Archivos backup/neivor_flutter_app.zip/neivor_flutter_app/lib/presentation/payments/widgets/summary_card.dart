import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';

class SummaryCard extends StatelessWidget {
  const SummaryCard({
    Key? key,
    required this.pendingTransactionData,
    required this.showBottomSheet,
  }) : super(key: key);

  final PendingTransactionResponse? pendingTransactionData;
  final Function showBottomSheet;

  /// return the sum of all transaction values
  /// the values
  ///
  /// Returns:
  ///   A string.
  getTotalValue() {
    double totalValue = 0;
    pendingTransactionData?.list?.first.paymentInvoiceValueList
        ?.forEach((element) {
      totalValue = totalValue + (element.value ?? 0);
    });
    return Constants.currencyFormatter.format(totalValue);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Resumen de pago"),
                GestureDetector(
                  onTap: () => showBottomSheet(),
                  child: const Text(
                    "Editar",
                    style: TextStyle(
                      color: AppTheme.turquoise4,
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 16,
            ),
            Column(
              children: [
                ListView.separated(
                  separatorBuilder: (context, index) {
                    return const SizedBox(
                      height: 8,
                    );
                  },
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: pendingTransactionData
                          ?.list?.first.paymentInvoiceValueList?.length ??
                      0,
                  itemBuilder: (BuildContext context, int index) {
                    List<PaymentInvoiceValueList>? pendingList =
                        pendingTransactionData
                            ?.list?.first.paymentInvoiceValueList;
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width *
                              Constants.fiftyPercent,
                          child: Text(
                            pendingList?[index].descriptionService ?? '',
                            overflow: TextOverflow.clip,
                          ),
                        ),
                        Text(Constants.currencyFormatter
                            .format(pendingList?[index].value)),
                      ],
                    );
                  },
                ),
                const SizedBox(
                  height: 16,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Total a pagar"),
                    Text(getTotalValue()),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
