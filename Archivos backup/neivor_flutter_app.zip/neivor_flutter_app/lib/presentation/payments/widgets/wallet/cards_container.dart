import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/presentation/payments/my_cards.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class CardsContainer extends StatelessWidget {
  const CardsContainer({
    Key? key,
    required this.paymentMethods,
    required this.getCardLogo,
  }) : super(key: key);

  final List<UserPaymentMethodResponse>? paymentMethods;
  final Function getCardLogo;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(top: 16),
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: paymentMethods?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  onTap: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MyCards(
                        paymentMethod: paymentMethods?[index],
                      ),
                    ),
                  ),
                  isThreeLine: true,
                  subtitle: Text(
                    "${paymentMethods?[index].payer?.name ?? ''} ${paymentMethods?[index].payer?.lastname ?? ''}",
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  contentPadding: const EdgeInsets.all(0),
                  leading: NvImage(
                    width: 35,
                    height: 24,
                    imageUrl: getCardLogo(
                      paymentMethods?[index].name ?? '',
                    ),
                  ),
                  title: Text(
                    paymentMethods?[index].name ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  trailing: const Icon(
                    Icons.chevron_right_rounded,
                    color: AppTheme.textPrimary,
                  ),
                );
              },
            ),
            ListTile(
              onTap: () =>
                  Navigator.pushReplacementNamed(context, "cardSuscription"),
              contentPadding: const EdgeInsets.all(0),
              title: const NvText(
                copy: 'payments.add-new-card',
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: AppTheme.textPrimary,
              ),
              trailing: const Icon(
                Icons.chevron_right_rounded,
                color: AppTheme.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
