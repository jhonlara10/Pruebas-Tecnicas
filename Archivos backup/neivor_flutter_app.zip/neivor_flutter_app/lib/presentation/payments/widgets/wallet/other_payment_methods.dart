import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class OtherPaymentMethods extends StatelessWidget {
  const OtherPaymentMethods({
    Key? key,
    required this.clabeData,
    this.copy,
  }) : super(key: key);

  final ZyosUserClabe? clabeData;
  final copy;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ListTile(
              dense: true,
              isThreeLine: true,
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    clabeData?.entity?.referenceNumber ?? '',
                    style: AppThemeScope.of(context)
                        .typography
                        .st1
                        .light
                        .copyWith(fontSize: 12),
                  ),
                  Chip(
                    backgroundColor: AppTheme.greenArlequin0main
                        .withOpacity(Constants.twentyPercent),
                    label: const NvText(
                      copy: "social-areas.free",
                      fontSize: 12,
                      color: AppTheme.greenArlequin4,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
              contentPadding: const EdgeInsets.all(0),
              leading: const NvImage(
                width: 35,
                imageUrl: 'payment/method-type/spei.png',
              ),
              title: Text(
                copy("schedule.transfer-spei"),
                style: AppThemeScope.of(context).typography.bd1.medium,
              ),
            ),
            ListTile(
              dense: true,
              isThreeLine: true,
              subtitle: Text(
                copy("schedule.payment-networks"),
                style: AppThemeScope.of(context)
                    .typography
                    .st1
                    .light
                    .copyWith(fontSize: 12),
              ),
              contentPadding: const EdgeInsets.all(0),
              leading: NvImage(
                width: 35,
                imageUrl: "/ds/icons/cash-banknote-hand.png",
                color: AppThemeScope.of(context)
                    .colors
                    .secondary
                    .harlequinGreen
                    .main,
              ),
              title: Text(
                copy("schedule.cash"),
                style: AppThemeScope.of(context).typography.bd1.medium,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
