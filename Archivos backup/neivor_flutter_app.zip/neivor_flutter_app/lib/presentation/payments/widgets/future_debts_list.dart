import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class FutureDebtsList extends StatelessWidget {
  static const double _checkboxSize = 16;
  FutureDebtsList({
    Key? key,
    required this.futureController,
    required this.futureDebts,
    required this.checkboxesFutureStates,
    required this.formatDate,
    required this.changePayValue,
    required this.changeCheckValue,
    required this.futureTextControllers,
    required this.futureKeys,
  }) : super(key: key);

  final ExpandableController futureController;
  final List<Invoice>? futureDebts;
  final Map<int, bool> checkboxesFutureStates;
  final Function formatDate;
  final Function changePayValue;
  final Function changeCheckValue;
  final Map<int, TextEditingController> futureTextControllers;
  final Map<int, GlobalKey<FormState>> futureKeys;
  final copy = AppMessages().getCopy;

  bool isDiscountAplicable(Invoice? invoice) {
    if (invoice?.idDiscountDataLog != null) {
      final DateTime parsedDate =
          DateFormat('yyyy/MM/dd').parse(invoice?.discountDate ?? '');
      return parsedDate.isAfter(DateTime.now().add(const Duration(days: 1))) &&
          (invoice?.discountDataList?.isNotEmpty ?? false);
    }
    return false;
  }

  // ignore: long-method
  String calculateDiscount(Invoice? invoice) {
    return Constants.currencyFormatter
        .format((invoice?.value ?? 0) - (invoice?.discountValue ?? 0));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: const Border.fromBorderSide(
          BorderSide(color: AppTheme.black2),
        ),
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: AppTheme.turquoise0Main.withOpacity(Constants.twentyPercent),
      ),
      child: ExpandablePanel(
        controller: futureController,
        theme: const ExpandableThemeData(
          headerAlignment: ExpandablePanelHeaderAlignment.center,
        ),
        header: Container(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: const [
              NvImage(imageUrl: "ds/icons/phone-card.svg"),
              SizedBox(
                width: 16,
              ),
              NvText(
                //"Pagar cuotas adelantadas",
                copy: 'payments.pay-advanced-bills',
                fontWeight: FontWeight.w500,
                fontSize: 16,
                color: AppTheme.textPrimary,
              ),
            ],
          ),
        ),
        collapsed: const SizedBox(),
        expanded: Container(
          padding: const EdgeInsets.all(16),
          color: Colors.white,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: ListView.separated(
                  physics: const NeverScrollableScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemCount: futureDebts?.length ?? 0,
                  separatorBuilder: (context, index) {
                    return const Divider(
                      thickness: 1,
                    );
                  },
                  itemBuilder: (context, index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 16,
                        ),
                        Row(
                          children: [
                            if (UserUtils().hasPermissionsTo(789))
                              SizedBox(
                                width: _checkboxSize,
                                height: _checkboxSize,
                                child: Checkbox(
                                  tristate: false,
                                  value: checkboxesFutureStates[index] ?? false,
                                  onChanged: (value) => changeCheckValue(
                                    value,
                                    futureDebts?[index],
                                    index,
                                    false,
                                  ),
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(6),
                                    ),
                                  ),
                                  activeColor: AppTheme.turquoise4,
                                ),
                              ),
                            const SizedBox(
                              width: 8,
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width *
                                  Constants.seventyPercent,
                              child: Text(
                                futureDebts?[index].descriptionService ?? '',
                                overflow: TextOverflow.clip,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        Text(formatDate(
                          futureDebts?[index].initialDate ?? '',
                        )),
                        const SizedBox(
                          height: 16,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const NvText(
                              copy: "charges.full-rate",
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: AppTheme.textPrimary,
                            ),
                            Text(
                              Constants.currencyFormatter.format(
                                futureDebts?[index].value ?? '',
                              ),
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        if ((futureDebts?[index].sanctionValueToShow ?? 0) != 0)
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                // "Multa",
                                copy('charges.fine'),
                              ),
                              Text(
                                Constants.currencyFormatter.format(
                                  futureDebts?[index].sanctionValueToShow,
                                ),
                              ),
                            ],
                          ),
                        const SizedBox(
                          height: 8,
                        ),
                        if (isDiscountAplicable(futureDebts?[index]))
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const NvText(
                                //"Descuento",
                                copy: 'charges.discount',
                                color: AppTheme.black4,
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                              ),
                              Text(
                                "- ${calculateDiscount(futureDebts?[index])}",
                              ),
                            ],
                          ),
                        const SizedBox(
                          height: 8,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const NvText(
                              copy: "charges.total-pay",
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: AppTheme.textPrimary,
                            ),
                            Text(
                              Constants.currencyFormatter.format(
                                futureDebts?[index].valueToPay ?? '',
                              ),
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        if (UserUtils().hasPermissionsTo(791))
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const NvText(
                                copy: 'payments.pay-payment',
                                fontSize: 14,
                                color: AppTheme.black0Main,
                                fontWeight: FontWeight.w400,
                              ),
                              SizedBox(
                                width: MediaQuery.of(context).size.width *
                                    Constants.thirtyPercent,
                                child: TextField(
                                  decoration: const InputDecoration(
                                    prefixIcon: Icon(
                                      Icons.attach_money,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  key: futureKeys[index],
                                  controller: futureTextControllers[index],
                                  textAlign: TextAlign.right,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.allow(
                                      RegExp(r'^\d+\.?\d*'),
                                    ),
                                  ],
                                  // ignore: prefer-extracting-callbacks
                                  onChanged: (value) {
                                    changeCheckValue(
                                      true,
                                      futureDebts?[index],
                                      index,
                                      false,
                                    );
                                    changePayValue(
                                      futureDebts?[index],
                                      value,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
