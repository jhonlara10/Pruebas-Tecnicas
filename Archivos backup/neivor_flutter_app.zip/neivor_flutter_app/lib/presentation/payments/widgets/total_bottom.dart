import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/payment/invoices/invoice.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';

class TotalBottom extends StatelessWidget {
  TotalBottom({
    Key? key,
    required double bottomSheetHeight,
    required this.totalValueSelected,
    required this.selectedDebts,
    required this.checkPendingTransaction,
    this.bottomSheetwidth,
  })  : _bottomSheetHeight = bottomSheetHeight,
        super(key: key);

  final double _bottomSheetHeight;
  final double totalValueSelected;
  final List<Invoice> selectedDebts;
  final Function checkPendingTransaction;
  final double? bottomSheetwidth;
  final copy = AppMessages().getCopy;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(16),
      width: bottomSheetwidth ??
          MediaQuery.of(context).size.width - Constants.defaultMarginSum,
      height: _bottomSheetHeight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                //"Subtotal",
                copy('charges.subtotal'),
              ),
              Text(Constants.currencyFormatter.format(totalValueSelected)),
            ],
          ),
          ElevatedButton(
            onPressed: () => checkPendingTransaction(context),
            child: Text(
              // "Pagar${selectedDebts.isEmpty ? '' : " ${selectedDebts.length} cuota"}${((selectedDebts.length > 1) ? "s" : '')}",
              selectedDebts.isEmpty
                  ? copy('charges.pay')
                  : copy(
                        'collections.pay-x-fees',
                        ['${selectedDebts.length}'],
                      ) +
                      (selectedDebts.length > 1 ? 's' : ''),
            ),
          ),
        ],
      ),
    );
  }
}
