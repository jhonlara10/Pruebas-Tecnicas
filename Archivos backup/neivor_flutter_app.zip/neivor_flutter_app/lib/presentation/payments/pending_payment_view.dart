import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/payments/payments_bloc.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/delete_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/pending_transaction_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:url_launcher/url_launcher.dart';

import 'widgets/clabe_data.dart';
import 'widgets/payment_type_card.dart';
import 'widgets/summary_card.dart';
import 'widgets/user_card.dart';

class PendingPaymentView extends StatefulWidget {
  final bool? isAfterSpei;
  const PendingPaymentView({Key? key, this.isAfterSpei}) : super(key: key);

  @override
  State<PendingPaymentView> createState() => _PendingPaymentViewState();
}

class _PendingPaymentViewState extends State<PendingPaymentView> {
  static const double _messageSize = 80;
  static const double _colorIndicatorSize = 8;
  Function copy = AppMessages().getCopy;
  ZyosUserClabe? clabeData;
  PendingTransactionResponse? pendingTransactionData;
  @override
  void initState() {
    callGetClabe();

    /// Checking if the widget isAfterSpei is true or false. If it is true, it will call the function
    /// callGetPendingTransaction. If it is false, it will set the pendingTransactionData to the state
    /// of the PaymentsBloc.
    if (widget.isAfterSpei ?? false) {
      callGetPendingTransaction();
    } else {
      pendingTransactionData =
          BlocProvider.of<PaymentsBloc>(context).state.pendingTransactionData;
    }
    super.initState();
  }

  /// It calls a function that the clabe data, and then sets the state of the widget.
  callGetClabe() async {
    context.loaderOverlay.show();
    clabeData = await getZyosUserClabe();
    context.loaderOverlay.hide();
    // ignore: no-empty-block
    setState(() {});
  }

  /// check if the user has pending transaction and sets the
  /// state of the widget
  callGetPendingTransaction() async {
    pendingTransactionData = await getPendingTransaction(context);
    // ignore: no-empty-block
    setState(() {});
  }

  /// It deletes the pending transaction and then returns to the payments page.
  goCancelPendingPayment() async {
    context.loaderOverlay.show();
    DeletePendingTransactionResponse? deleteResponse =
        await deletePendingTransaction(pendingTransactionData?.list?.first.id);
    context.loaderOverlay.hide();
    if (deleteResponse.success ?? false) {
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, 'payments');
    }
  }

  // ignore: long-method
  showBottomSheet() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return NvBottomSheet(
          bottomSheetHeight: 300,
          iconRoute: "assets/images/money-hand.png",
          title: copy('payments.confirm-change-payment-method'),
          subtitle: copy('payments.cancel-transaccion-spei'),
          primaryButtonText: copy('common.confirm'),
          secondaryButtonText: copy('profile.back'),
          primaryButtonVariant: "nv-bottom-sheet-primary",
          secondaryButtonVariant: "nv-bottom-sheet-secondary",
          primaryButtonAction: goCancelPendingPayment,
          secondaryButtonAction: () => Navigator.pop(context),
        );
      },
    );
  }

  // ignore: long-method
  showCopiedMessage() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return NvBottomSheet(
          bottomSheetHeight:
              MediaQuery.of(context).size.height * Constants.thirtyPercent,
          iconRoute: "assets/images/money-hand.png",
          title: copy('payments.spei-key-copied'),
          subtitle: copy('payments.enter-your-bank-app'),
          primaryButtonText: copy('profile.back'),
          primaryButtonVariant: "nv-bottom-sheet-secondary",
          primaryButtonAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            "home",
            (route) => false,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "home");
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacementNamed(context, "home"),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 21, 16, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!(widget.isAfterSpei ?? false)) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(
                      Icons.warning_amber_rounded,
                      size: 60,
                      color: Colors.amber,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width -
                          Constants.defaultMarginSum,
                      child: Text(
                        AppMessages().getCopy(
                          'componentes.have-spei-active-transaction',
                        ),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          overflow: TextOverflow.clip,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width -
                      Constants.defaultMarginSum,
                  child: Text(
                    AppMessages().getCopy('components.spei-reminder'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w300,
                      overflow: TextOverflow.clip,
                    ),
                  ),
                ),
              ],
              if (widget.isAfterSpei ?? false)
                Text(
                  copy('payments.payment-information'),
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 26,
                  ),
                ),
              ClabeData(
                clabeData: clabeData,
                showCopiedMessage: showCopiedMessage,
              ),
              const SizedBox(
                height: 16,
              ),
              PaymentTypeCard(
                showBottomSheet: showBottomSheet,
                pendingTransactionId: pendingTransactionData?.list?.first.id,
              ),
              SummaryCard(
                pendingTransactionData: pendingTransactionData,
                showBottomSheet: showBottomSheet,
              ),
              const UserCard(),
              if (widget.isAfterSpei ?? false) ...[
                const SizedBox(
                  height: 8,
                ),
                RichText(
                  text: TextSpan(
                    style: const TextStyle(
                      height: 2,
                      fontSize: 14,
                      color: AppTheme.textPrimary,
                    ),
                    children: [
                      TextSpan(
                        text: copy('payments.continue-terms-and-conditios'),
                        style: const TextStyle(
                          decoration: TextDecoration.underline,
                          fontWeight: FontWeight.w500,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () async {
                            // ignore: deprecated_member_use
                            if (await canLaunch(Constants.tAndCUrl)) {
                              // ignore: deprecated_member_use
                              await launch(
                                Constants.tAndCUrl,
                                forceSafariVC: false,
                              );
                            }
                          },
                      ),
                      TextSpan(
                        text: ' ${copy('payments.and-authorize-the')} ',
                        style: const TextStyle(
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      TextSpan(
                        text: copy('payments.processing-of-personal-data'),
                        style: const TextStyle(
                          decoration: TextDecoration.underline,
                          fontWeight: FontWeight.w500,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () async {
                            // ignore: deprecated_member_use
                            if (await canLaunch(Constants.personalDataUrl)) {
                              // ignore: deprecated_member_use
                              await launch(Constants.personalDataUrl);
                            }
                          },
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    color: AppTheme.blueIndigo0Main
                        .withOpacity(Constants.twentyPercent),
                  ),
                  height: _messageSize,
                  child: Row(
                    children: [
                      Container(
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(4),
                            topLeft: Radius.circular(4),
                          ),
                          color: AppTheme.blueIndigo0Main,
                        ),
                        width: _colorIndicatorSize,
                      ),
                      Container(
                        margin: const EdgeInsets.only(left: 16),
                        width: MediaQuery.of(context).size.width *
                            Constants.seventyPercent,
                        child: Text(
                          copy('payments.payment-spei-show-in-app'),
                          overflow: TextOverflow.clip,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(
                height: 16,
              ),
              NvButton(
                variant: "secondary",
                label: copy('payments.cancel-active-transacction'),
                action: showBottomSheet,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
