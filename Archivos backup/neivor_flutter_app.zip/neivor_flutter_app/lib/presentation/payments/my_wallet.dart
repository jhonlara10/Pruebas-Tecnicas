import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/payment/payment_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/payment/methods/user_payment_method_response.dart';
import 'package:neivor_flutter_app/domain/models/payment/transactions/zyos_user_clabe.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'widgets/wallet/wallet.dart';

class MyWallet extends StatefulWidget {
  const MyWallet({Key? key}) : super(key: key);

  @override
  State<MyWallet> createState() => _MyWalletState();
}

class _MyWalletState extends State<MyWallet> {
  List<UserPaymentMethodResponse>? paymentMethods;
  ZyosUserClabe? clabeData;
  final copy = AppMessages().getCopy;

  @override
  void initState() {
    callGetUserPaymentMethods();
    callGetClabe();
    super.initState();
  }

  callGetClabe() async {
    context.loaderOverlay.show();
    clabeData = await getZyosUserClabe();
    context.loaderOverlay.hide();
    // ignore: no-empty-block
    setState(() {});
  }

  /// Gets the saved payment methods for the current user.
  callGetUserPaymentMethods() async {
    paymentMethods = await getUserPaymentMethods();
    // ignore: no-empty-block
    setState(() {});
  }

  // ignore: long-method
  getCardLogo(String string) {
    String newString = string.replaceAllMapped(RegExp(r"[0-9]*\** *"), (_) {
      return '';
    });
    switch (newString.toUpperCase()) {
      case 'MASTERCARD':
      case 'MASTER':
        return "payment/cc-brand/logo-mastercard.png";
      case 'VISA':
        return "payment/cc-brand/logo-visa.png";
      case 'DISCOVER':
        return "payment/cc-brand/logo-discover.png";
      case 'DINERS':
      case 'DINERSCLUB':
        return "payment/cc-brand/logo-diners.png";
      default:
        {
          "payment/cc-brand/credit-card.png";
        }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "payments");
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushReplacementNamed(context, "payments"),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                copy("schedule.my-wallet"),
                style: AppThemeScope.of(context).typography.h2.semibold,
              ),
              const SizedBox(
                height: 40,
              ),
              Text(
                copy("schedule.cc-and-dc"),
                style: AppThemeScope.of(context).typography.bd1.medium,
              ),
              CardsContainer(
                paymentMethods: paymentMethods,
                getCardLogo: getCardLogo,
              ),
              const SizedBox(
                height: 16,
              ),
              Text(
                copy("schedule.other-pm"),
                style: AppThemeScope.of(context).typography.bd1.medium,
              ),
              const SizedBox(
                height: 16,
              ),
              OtherPaymentMethods(clabeData: clabeData, copy: copy),
            ],
          ),
        ),
      ),
    );
  }
}
