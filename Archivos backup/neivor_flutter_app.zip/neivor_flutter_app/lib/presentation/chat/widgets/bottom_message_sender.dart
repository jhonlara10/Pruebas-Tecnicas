import 'dart:io';

import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

class BottomMessageSender extends StatelessWidget {
  const BottomMessageSender({
    Key? key,
    required this.changeEmojiVisibility,
    required this.isEmojiSelectionActive,
    required this.controller,
    required this.sendMessage,
    this.isGroupMember,
    this.isGroup,
    required this.callJoinGroup,
  }) : super(key: key);

  final Function changeEmojiVisibility;
  final bool isEmojiSelectionActive;
  final TextEditingController controller;
  final Function sendMessage;
  final bool? isGroupMember;
  final bool? isGroup; // Not delete.
  static const double _iconRotationAngle = 5.5;
  static const double _iconSize = 40;
  static const double _emojiSize = 40;
  static const int _emojiColumns = 8;
  final Function callJoinGroup;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Divider(
            height: 1,
            thickness: 1,
          ),
          const SizedBox(
            height: 16,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, bottom: 16),
            child: Row(
              children: [
                if (isGroup == false ||
                    (isGroupMember != null && (isGroupMember ?? false))) ...[
                  SizedBox(
                    width: MediaQuery.of(context).size.width *
                        Constants.eightyPercent,
                    child: TextFormField(
                      minLines: 1,
                      maxLines: 3,
                      controller: controller,
                      // ignore: prefer-extracting-callbacks
                      onTap: () {
                        if (MediaQuery.of(context).viewInsets.bottom == 0 &&
                            isEmojiSelectionActive) {
                          changeEmojiVisibility();
                        }
                      },
                      decoration: InputDecoration(
                        hintText: "...",
                        border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(100)),
                        ),
                        prefixIcon: GestureDetector(
                          onTap: () {
                            changeEmojiVisibility();
                          },
                          child: const Icon(
                            Icons.sentiment_satisfied_alt_outlined,
                            color: AppTheme.black2,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 8,
                  ),
                  Transform.rotate(
                    angle: _iconRotationAngle,
                    child: Container(
                      width: _iconSize,
                      height: _iconSize,
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(100)),
                        color: AppTheme.turquoise4,
                      ),
                      child: IconButton(
                        onPressed: () {
                          sendMessage();
                        },
                        icon: const Icon(
                          Icons.send,
                          color: AppTheme.grayArtic0main,
                        ),
                      ),
                    ),
                  ),
                ] else
                  SizedBox(
                    width: MediaQuery.of(context).size.width - 32,
                    child: NvButton(
                      label: "Unirme",
                      action: () => callJoinGroup(),
                    ),
                  ),
              ],
            ),
          ),
          if (isEmojiSelectionActive)
            SizedBox(
              height:
                  MediaQuery.of(context).size.height * Constants.thirtyPercent,
              child: EmojiPicker(
                onEmojiSelected: (category, emoji) {
                  controller.text = controller.text + emoji.emoji;
                },
                config: Config(
                  columns: _emojiColumns,
                  //ignore: no-magic-number
                  emojiSizeMax: _emojiSize * (Platform.isIOS ? 1.3 : 1.0),
                  verticalSpacing: 5,
                  horizontalSpacing: 0,
                  gridPadding: EdgeInsets.zero,
                  initCategory: Category.RECENT,
                  bgColor: AppTheme.grayArtic0main,
                  indicatorColor: AppTheme.coral0Main,
                  iconColor: AppTheme.coral0Main,
                  iconColorSelected: AppTheme.coral0Main,
                  //ignore: no-equal-arguments
                  progressIndicatorColor: AppTheme.coral0Main,
                  backspaceColor: AppTheme.coral0Main,
                  //ignore: no-equal-arguments
                  skinToneDialogBgColor: AppTheme.grayArtic0main,
                  skinToneIndicatorColor: AppTheme.black3,
                  enableSkinTones: true,
                  showRecentsTab: true,
                  tabIndicatorAnimDuration: kTabScrollDuration,
                  categoryIcons: const CategoryIcons(),
                  buttonMode: Platform.isAndroid
                      ? ButtonMode.MATERIAL
                      : ButtonMode.CUPERTINO,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
