import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/messages/messages_bloc.dart';
import 'package:neivor_flutter_app/data/repository/chat_messages/chat_msgs_repository_impl.dart';
import 'package:neivor_flutter_app/data/repository/tickets/tickets_repository_impl.dart';
import 'package:neivor_flutter_app/domain/groups/groups_response.dart';
import 'package:neivor_flutter_app/domain/groups/join_group_response.dart';
import 'package:neivor_flutter_app/domain/models/chat_messages/get_chat_msgs_response.dart';
import 'package:neivor_flutter_app/domain/models/general/general.dart';
import 'package:neivor_flutter_app/domain/models/tickets/tickets.dart';
import 'package:neivor_flutter_app/presentation/tickets/Widget/Widget.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:skeletons/skeletons.dart';

class Chat extends StatefulWidget {
  final GetChatMsgsResponse? chatConversation;
  final NeighborsResponse? selectedNeighbor;
  final bool? fromNeighborList;
  final bool? isGroupMember;
  final Data? selectedGroup;

  const Chat({
    Key? key,
    this.chatConversation,
    this.selectedNeighbor,
    this.fromNeighborList,
    this.selectedGroup,
    this.isGroupMember,
  }) : super(key: key);

  @override
  State<Chat> createState() => _Chat();
}

class _Chat extends State<Chat> {
  ScrollController listController = ScrollController();
  TicketsRequestResponse? selectedTicket;
  List<NeighborsResponse>? neighborsList;
  List<TicketGetMsgResponse>? conversation;
  bool isEmojiSelectionActive = false;
  final TextEditingController textEditingController = TextEditingController();
  Map<String, dynamic> messageJson = {};
  Map<String, dynamic> emailJson = {};
  final ImagePicker _picker = ImagePicker();
  XFile? image;
  String? imgAsBase64;
  bool isLoading = true;
  bool? fromNeighborList;
  bool enableMessageSend = true;
  Timer? messageTimer;
  bool? isGroupMember;
  final copy = AppMessages().getCopy;

  @override
  // ignore: long-method
  void initState() {
    isGroupMember = widget.isGroupMember;
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        if (ModalRoute.of(context)?.settings.arguments != null) {
          setTicketConversation();
        } else {
          setNonTicketConversation();
        }
      });
      fromNeighborList = widget.fromNeighborList ?? false;
    });
  }

  /// call the conversation and if it's
  /// not null, scrolls to the bottom of the list
  void setNonTicketConversation() {
    (() async {
      await callGetConversation(null);
      if (conversation != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (listController.hasClients) {
            scrollToLast();
          }
        });
      }
    })();
  }

  /// extract the arguments with ticket data
  /// get's the conversation of that ticket
  /// and scrolls to the bottom of the conversation
  ///finally set the jsons needed to send message and send email alert
  void setTicketConversation() {
    selectedTicket =
        ModalRoute.of(context)?.settings.arguments as TicketsRequestResponse;
    neighborsList = BlocProvider.of<MessagesBloc>(context).state.neighborsList;
    (() async {
      await callGetConversation(null);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (listController.hasClients) {
          scrollToLast();
        }
      });
      setMessageJsonDefault();
      setEmailJsonDefault();
    })();
  }

  /// Setting the default values to message call.
  // ignore: long-method
  setMessageJsonDefault() {
    messageJson = {
      "idConversation":
          selectedTicket?.idConversation ?? conversation?.first.idConversation,
      "newMessage":
          (selectedTicket == null && conversation == null) ? true : false,
      "messageBody": "",
      "userCreation": UserUtils.currentUser?.id,
      "idZyosUserCreator": UserUtils.currentUser?.id,
      "recipients": (selectedTicket == null && conversation == null)
          ? [widget.selectedNeighbor?.id]
          : null,
      "idEnterprise": UserUtils.currentEnterprise?.id,
      "pqr": selectedTicket == null ? false : true,
    };
  }

  /// Setting the default values to email call.
  // ignore: long-method
  setEmailJsonDefault() {
    emailJson = {
      'adminUser': UserUtils().isAdminUser(),
      'dateCreation': selectedTicket?.dateCreation,
      'daysBetweenDeadLine': selectedTicket?.daysBetweenDeadLine,
      'deadLineLong': selectedTicket?.deadLineLong,
      'description': selectedTicket?.description,
      'hourCreation': selectedTicket?.hourCreation,
      'id': selectedTicket?.id,
      'idComplaintDemandType': selectedTicket?.idComplaintDemandType,
      'idConversation': selectedTicket?.idConversation,
      'idEnterprise': selectedTicket?.idEnterprise,
      'idResponsible': selectedTicket?.idResponsible,
      'idServicePoint': selectedTicket?.idServicePoint,
      'idStateComplaintDemand': selectedTicket?.idStateComplaintDemand,
      'idZyosUser': selectedTicket?.idZyosUser,
      'messageUnread': false,
      'nameComentary': UserUtils.currentUser?.name,
      'nameResponsible': selectedTicket?.nameResponsible,
      'nameServicePoint': selectedTicket?.nameServicePoint,
      'nameUser': selectedTicket?.nameUser,
      'numberCD': selectedTicket?.numberCD,
      'state': selectedTicket?.state,
      'title': selectedTicket?.title,
      'updateResponsible': false,
    };
  }

  ///close emoji selection panel, then close keyboard, then saves message body in the json
  ///and sendt the message, then get the conversation with the new message, clears the
  ///message input and then scrolls to last message
  // ignore: long-method
  callSendMessage() {
    if (enableMessageSend) {
      enableMessageSend = false;
      fromNeighborList = false;
      isEmojiSelectionActive = false;
      FocusManager.instance.primaryFocus?.unfocus();
      setMessageJsonDefault();
      if (textEditingController.text.isNotEmpty) {
        messageJson['messageBody'] = textEditingController.text;
        (() async {
          SendTicketMessageResponse response =
              await sendTicketMessage(messageJson);
          if (conversation == null) {
            await callGetConversation(response.idConversation);
          } else {
            await callGetConversation(conversation?.first.idConversation);
          }
          setState(() {
            textEditingController.text = '';
          });
        })();
        Future.delayed(const Duration(seconds: 1), () {
          scrollToLast();
        });
        messageTimer = Timer(const Duration(seconds: 3), () {
          enableMessageSend = true;
        });
      }
    }
  }

  /// It takes the image path, reads the bytes, encodes the bytes to base64, and returns the base64
  /// encoded string
  ///
  /// Returns:
  ///   A Future<String>;
  imgToBase64() async {
    final Uint8List bytes;
    if (image != null) {
      bytes = await File(image?.path ?? '').readAsBytes();
      String base64Encoded = base64Encode(bytes);
      String prefix =
          "data:image/${image?.path.substring((image?.path.length ?? 0) - 3) ?? "jpeg"};base64,";
      return prefix + base64Encoded;
    }
  }

  /// It takes a string as a parameter, if the string is equal to gallery, it will open the gallery, if
  /// not, it will open the camera. takes a picture and upload to conversation
  ///
  /// Args:
  ///   source (String): String
  ///
  /// Returns:
  ///   The image is being returned as a base64 string.
  pickImage(String source) async {
    try {
      image = source == 'gallery'
          ? await _picker.pickImage(source: ImageSource.gallery)
          : await _picker.pickImage(source: ImageSource.camera);
      if (image != null) {
        await convertAndUploadPhoto();
      }
    } catch (e) {
      log(e.toString());
    }
  }

  /// 1. Convert image to base64
  /// 2. Add base64 to messageJson
  /// 3. Send messageJson to server
  /// 4. Get conversation from server
  /// 5. Set image to null
  /// 6. Scroll to last message
  // ignore: long-method
  convertAndUploadPhoto() async {
    fromNeighborList = false;
    imgAsBase64 = await imgToBase64();
    setMessageJsonDefault();
    messageJson['image'] = imgAsBase64;
    (() async {
      context.loaderOverlay.show();
      SendTicketMessageResponse response = await sendTicketMessage(messageJson);
      context.loaderOverlay.hide();
      if (conversation == null) {
        await callGetConversation(response.idConversation);
      } else {
        await callGetConversation(conversation?.first.idConversation);
      }
      setState(() {
        image == null;
      });
    })();
    Future.delayed(const Duration(seconds: 1), () {
      scrollToLast();
    });
  }

  /// The function takes a JSON object as a parameter, converts it to a string, and then sends it to the
  /// native side of the app
  callSendEmail() async {
    await sendEmail(emailJson);
  }

  /// get the conversation in base of his type (Ticket, already existent, or new conversation)
  /// if it's a new conversation sets the json to create a new one
  /// Args:
  ///   idConversation (int): The id of the conversation that is being loaded.
  // ignore: long-method
  callGetConversation(int? idConversation) async {
    if (selectedTicket != null) {
      conversation = await getTicketMessage(
        (selectedTicket?.idConversation),
        UserUtils.currentEnterprise?.id,
        UserUtils.currentUser?.id,
      );
    } else if (widget.chatConversation != null) {
      conversation = await getTicketMessage(
        widget.chatConversation?.idConversation,
        UserUtils.currentEnterprise?.id,
        UserUtils.currentUser?.id,
      );
    } else if (widget.selectedGroup != null) {
      conversation = await getTicketMessage(
        widget.selectedGroup?.id,
        UserUtils.currentEnterprise?.id,
        UserUtils.currentUser?.id,
      );
    } else {
      if (idConversation != null) {
        conversation = await getTicketMessage(
          idConversation,
          UserUtils.currentEnterprise?.id,
          UserUtils.currentUser?.id,
        );
      }
      setMessageJsonDefault();
    }
    // ignore: no-empty-block
    setState(() {});
    isLoading = false;
  }

  /// If the id is the current user's id, return the current user. Otherwise, return the neighbor with
  /// the matching id
  ///
  /// Args:
  ///   id (int): The id of the user you want to search for.
  ///
  /// Returns:
  ///   A Future<List<Neighbor>>
  searchNeighborById(int id) {
    if (id == UserUtils.currentUser?.id) {
      return UserUtils.currentUser;
    } else {
      return neighborsList?.firstWhere((element) => element.id == (id));
    }
  }

  /// change the visibility of emoji panel
  /// and if the emoji panel is open closes the keyboard
  changeEmojiVisibility() {
    setState(() {
      isEmojiSelectionActive = !isEmojiSelectionActive;
    });
    if (isEmojiSelectionActive) FocusManager.instance.primaryFocus?.unfocus();
  }

  /// Scroll to the las message.
  scrollToLast() {
    try {
      listController.jumpTo(listController.position.maxScrollExtent);
    } catch (e) {
      log(e.toString());
    }
  }

  goBack() {
    if (messageTimer != null) {
      messageTimer?.cancel();
    }
    if (fromNeighborList ?? false) {
      Navigator.pop(context);
    } else {
      if (selectedTicket == null) {
        Navigator.pushReplacementNamed(context, "messages");
      } else {
        Navigator.pushReplacementNamed(context, "tickets");
      }
    }
  }

  String get title {
    if (selectedTicket != null) {
      return  "${AppMessages().getCopy('messages.ticket')} ${selectedTicket?.numberCD}";
    } else if (widget.chatConversation != null) {
      return widget.chatConversation?.nameConversation ?? '';
    } else if (widget.selectedNeighbor != null) {
      return widget.selectedNeighbor?.name ?? '';
    } else if (widget.selectedGroup != null) {
      return widget.selectedGroup?.name ?? '';
    }
    return "";
  }

  callJoinGroup() async {
    Map<String, dynamic> request = {
      "idZyosUser": UserUtils.currentUser?.id,
      "idConversation": widget.selectedGroup?.id,
      "userCreation": UserUtils.currentUser?.id,
    };
    JoinGroupResponse joinResponse = await joinGroup(request);
    if (joinResponse.success ?? false) {
      isGroupMember = true;
      setState(() {});
    }
  }

  // ignore: long-method
  modalLeaveGroup() {
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        showModalBottomSheet(
          enableDrag: false,
          isDismissible: false,
          context: context,
          builder: (BuildContext context) {
            return NvBottomSheet(
              bottomSheetHeight: 300,
              iconRoute: "assets/images/warning.png",
              title: copy('groups.leave-group-confirm'),
              primaryButtonText: copy('common.confirm'),
              primaryButtonVariant: "nv-bottom-sheet-primary",
              secondaryButtonVariant: "nv-bottom-sheet-secondary",
              secondaryButtonText: copy("common.cancel"),
              secondaryButtonAction: () => Navigator.pop(context),
              primaryButtonAction: () => callLeaveGroup(),
              subtitle: '',
            );
          },
        );
      });
    });
  }

  callLeaveGroup() async {
    JoinGroupResponse leaveResponse = await leaveGroup(
      UserUtils.currentUser?.id ?? 0,
      widget.chatConversation?.idConversation ?? widget.selectedGroup?.id ?? 0,
    );
    if (leaveResponse.success ?? false) {
      goBack();
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        goBack();
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => goBack(),
          actions: [
            TicketMessageActions(
              pickImage: pickImage,
              isGroupMember: (isGroupMember ?? false) ||
                  (widget.chatConversation?.group ?? false),
            ),
            if ((isGroupMember ?? false) ||
                (widget.chatConversation?.group ?? false))
              PopupMenuButton(
                onSelected: (value) => Navigator.pop(context),
                itemBuilder: (context) => [
                  PopupMenuItem(
                    onTap: () => modalLeaveGroup(),
                    child: Text(
                      copy("groups.leave-group"),
                    ),
                  ),
                ],
              ),
          ],
          title: title,
          subtitle: selectedTicket?.nameServicePoint,
        ),
        body: Column(
          verticalDirection: VerticalDirection.down,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isLoading)
              Expanded(
                child: SkeletonListView(
                  itemBuilder: (p0, p1) {
                    return ConversationMessage(
                      conversation: TicketGetMsgResponse(
                        messageBody:
                            "Lorem Ipsum is simply dummy text of the printing ", // Dummy data to get a sized skeletton.
                        idZyosUserCreator:
                            p1.isEven ? UserUtils.currentUser?.id ?? 0 : 0,
                      ),
                    );
                  },
                ),
              ),
            if (conversation != null)
              Expanded(
                child: ListView.builder(
                  controller: listController,
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 85),
                  itemCount: conversation?.length,
                  itemBuilder: (BuildContext context, int index) {
                    return ConversationMessage(
                      conversation: conversation?[index],
                    );
                  },
                ),
              ),
            if (conversation == null)
              Center(
                child: SizedBox(
                  width: MediaQuery.of(context).size.width *
                      Constants.fiftyPercent,
                  child: const NvText(
                    //"Los mensajes que envíes a continuación le llegarán de inmediato a los participantes de la lista",
                    copy: 'messages.new-chat-message',
                    textAlign: TextAlign.center,
                    fontSize: 12,
                    color: AppTheme.black3,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
          ],
        ),
        bottomSheet: (selectedTicket == null &&
                    UserUtils().hasPermissionsTo(91)) ||
                (selectedTicket != null && UserUtils().hasPermissionsTo(584))
            ? BottomMessageSender(
                callJoinGroup: callJoinGroup,
                isGroup: widget.selectedGroup != null,
                sendMessage: callSendMessage,
                controller: textEditingController,
                changeEmojiVisibility: changeEmojiVisibility,
                isEmojiSelectionActive: isEmojiSelectionActive,
                isGroupMember: isGroupMember,
              )
            : null,
      ),
    );
  }
}
