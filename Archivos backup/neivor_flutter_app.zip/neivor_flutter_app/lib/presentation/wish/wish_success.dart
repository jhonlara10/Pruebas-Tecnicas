import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

void main() {
  runApp(const WishSuccess());
}

class WishSuccess extends StatefulWidget {
  const WishSuccess({
    Key? key,
  }) : super(key: key);

  @override
  State<WishSuccess> createState() => _WishStateSuccess();
}

class _WishStateSuccess extends State<WishSuccess> {
  @override
  void initState() {
    super.initState();
  }

  backHome() {
    Navigator.of(context)
        .pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        body: Column(children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 150),
                child: Image.asset(
                  'assets/images/relationship.png',
                  height: 200,
                  width: 200,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: NvText(
                  textHolder:
                      AppMessages().getCopy('feedback.what-a-great-idea'),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: NvText(
                  textHolder: AppMessages().getCopy('feedback.thanks-for-that'),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: NvText(
                  textHolder: AppMessages().getCopy(
                    'feedback.our-challenge-now-is-to-make-it-possible',
                  ),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 18,
                  color: Colors.black,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: NvText(
                  textHolder:
                      AppMessages().getCopy('feedback.we-are-in-contact'),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 18,
                  color: Colors.black,
                ),
              ),
            ],
          ),
          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: NvButton(
                  label: AppMessages().getCopy("common.back-to-home"),
                  action: backHome,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
