import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/wish/wish_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/wish/wish_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

void main() {
  runApp(const Wish());
}

class Wish extends StatefulWidget {
  const Wish({
    Key? key,
  }) : super(key: key);

  @override
  State<Wish> createState() => _WishState();
}

class _WishState extends State<Wish> {
  var headerPlaceholder = "";
  var questionPlaceholder = "";
  var sendButtonPlaceholder = "";
  var textAreaPlaceholder = "";

  @override
  void initState() {
    getCopies();
    super.initState();
  }

  getCopies() async {
    headerPlaceholder = await AppMessages().getMessage('feedback.want-neivor');
    questionPlaceholder =
        await AppMessages().getMessage('feedback.what-you-want');
    textAreaPlaceholder =
        await AppMessages().getMessage('feedback.i-would-like');
    sendButtonPlaceholder = await AppMessages().getMessage('feedback.send');
    // ignore: no-empty-block
    setState(() {});
  }

  final textEditingController = TextEditingController();

  // ignore: long-method
  makeWish() async {
    var currentUser = await User().getCurrentUser();
    textEditingController.text;
    var wishRequest = WishRequest(
      feedbackCommentary: textEditingController.text,
      idEnterprise: UserUtils.currentEnterprise?.id,
      idZyosUser: currentUser.id,
      userCreation: currentUser.id,
    );
    context.loaderOverlay.show();
    var wishResponse = await WishRepository().makeWish(wishRequest);
    context.loaderOverlay.hide();
    if (wishResponse.sucessRequestFeedback == true) {
      if (!mounted) return;
      Navigator.pushNamed(context, 'wishSuccess');
    } else {
      showError(wishResponse.message ?? "");
    }
  }

  // ignore: long-method
  showError(String? message) {
    Widget okButton = TextButton(
      child: Text(AppMessages().getCopy('common.accept')), //"Aceptar"
      onPressed: () {
        Navigator.pop(context, false);
      },
    );

    // Set up the AlertDialog.
    AlertDialog alert = AlertDialog(
      title: const Text("Error"),
      content: Text(message ?? ""),
      actions: [
        okButton,
      ],
    );

    // Show the dialog.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(children: [
          Align(
            alignment: Alignment.topLeft,
            child: Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 20,
                        bottom: 10,
                        top: 30,
                      ),
                      child: NvText(
                        textHolder: headerPlaceholder,
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                        color: Colors.black,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 20,
                        bottom: 10,
                        right: 20,
                        top: 10,
                      ),
                      child: NvText(
                        textHolder: questionPlaceholder,
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.normal,
                        fontSize: 12,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                Image.asset('assets/images/bird.png', height: 110, width: 65),
              ],
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 20, bottom: 20, right: 20),
              child: TextField(
                keyboardType: TextInputType.emailAddress,
                maxLines: 8,
                controller: textEditingController,
                decoration: InputDecoration(hintText: textAreaPlaceholder),
              ),
            ),
          ),
          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: NvButton(
                  label: sendButtonPlaceholder,
                  action: makeWish,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
