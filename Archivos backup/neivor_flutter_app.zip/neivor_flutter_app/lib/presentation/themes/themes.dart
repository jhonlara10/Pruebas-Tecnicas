import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/theme/data/app_theme_data.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';

class Themes extends StatelessWidget {
  const Themes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;

    return Scaffold(
      appBar: NvAppBar(
        title: 'Themes',
        backAction: () => Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              'Consectetur cupidatat aute incididunt incididunt elit ut ipsum laborum reprehenderit. Eiusmod exercitation aute excepteur quis culpa dolor nostrud fugiat reprehenderit sit. Amet adipisicing incididunt incididunt adipisicing esse exercitation veniam nulla esse amet ut. Irure nulla ex reprehenderit minim. Pariatur anim nulla incididunt sunt dolore tempor aliqua.',
              style: typo.bd1.italicMedium,
            ),
            const SizedBox(
              height: 32,
            ),
            NvButton(
              label: 'Light',
              action: () {
                AppTheme.of(context).setTheme(AppThemeData.light());
              },
            ),
            const SizedBox(
              height: 8,
            ),
            NvButton(
              label: 'Dark',
              action: () {
                AppTheme.of(context).setTheme(AppThemeData.dark());
              },
            ),
          ],
        ),
      ),
    );
  }
}
