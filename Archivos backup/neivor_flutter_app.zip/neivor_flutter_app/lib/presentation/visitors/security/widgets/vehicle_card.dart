import 'package:flutter/material.dart';

import '../../../../theme/app_theme_scope.dart';
import '../../../../widgets/nv_image.dart';
import '../../../../widgets/nv_text.dart';

class VehicleCard extends StatelessWidget {
  const VehicleCard({
    Key? key,
    required this.borderColor,
    required this.mainColor,
    required this.isSelected,
    required this.image,
    required this.textField,
    this.action,
  }) : super(key: key);

  final Color borderColor;
  final Color mainColor;
  final bool isSelected;
  final String image;
  final String textField;
  final Function? action;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    const double textSm = 14.0;

    return GestureDetector(
      onTap: () {
        //ignore: avoid-non-null-assertion
        if (action != null) action!();
      },
      child: Container(
        height: 96.0,
        width: 104.0,
        padding: const EdgeInsets.only(
          top: 16.0,
        ),
        decoration: BoxDecoration(
          color: mainColor,
          borderRadius: const BorderRadius.all(
            Radius.circular(4),
          ),
          border: isSelected
              ? Border.all(
                  color: borderColor,
                  width: 1.0,
                )
              : null,
        ),
        child: Column(
          children: [
            NvImage(
              width: 40.0,
              imageUrl: image,
            ),
            const SizedBox(
              height: 8.0,
            ),
            NvText(
              textHolder: textField,
              fontFamily: 'Jost',
              fontWeight: FontWeight.w500,
              fontSize: textSm,
              color: colors.text.primary,
            ),
          ],
        ),
      ),
    );
  }
}
