import 'dart:io';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_data.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/widgets/vehicle_card.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/config/nv_text_field.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitPlatePhoto extends StatefulWidget {
  final String visitorName;
  final ServicePointObject? servicePointObject;
  final Map<String, dynamic> data;
  final String path;

  const VisitPlatePhoto({
    Key? key,
    required this.visitorName,
    this.servicePointObject,
    required this.data,
    required this.path,
  }) : super(key: key);

  @override
  State<VisitPlatePhoto> createState() => _VisitPlatePhotoState();
}

class _VisitPlatePhotoState extends State<VisitPlatePhoto> {
  goToConfirmation() {
    widget.data['isVehicleSelected'] = true;
    widget.data['idVehicleType'] = widget.data['idVehicleType'] ?? 1;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitData(
          visitorName: widget.visitorName,
          servicePointObject: widget.servicePointObject,
          data: widget.data,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    TextEditingController plateNumberController = TextEditingController();
    plateNumberController.text = widget.data['licensePlate'];
    plateNumberController.selection = TextSelection.fromPosition(
      TextPosition(offset: plateNumberController.text.length),
    );

    final copy = AppMessages().getCopy;
    final colors = AppThemeScope.of(context).colors;

    const double textMd = 16.0;
    const double textSm = 14.0;
    const double textLg = 26.0;

    selectCar() {
      widget.data['isCarSelected'] = true;
      widget.data['isBikeSelected'] = false;
      widget.data['isMotorcycleSelected'] = false;
      widget.data['idVehicleType'] = 1;
      setState(() {});
    }

    selectBike() {
      widget.data['isBikeSelected'] = true;
      widget.data['isCarSelected'] = false;
      widget.data['isMotorcycleSelected'] = false;
      widget.data['idVehicleType'] = 3;
      setState(() {});
    }

    selectMotircycle() {
      widget.data['isMotorcycleSelected'] = true;
      widget.data['isCarSelected'] = false;
      widget.data['isBikeSelected'] = false;
      widget.data['idVehicleType'] = 2;
      setState(() {});
    }

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            margin: const EdgeInsets.only(
              bottom: 16.0,
              top: 37.0,
              left: 16.0,
              right: 16.0,
            ),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NvText(
                textHolder: copy('visitors.fill-the-corresponding-data'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.w600,
                fontSize: textLg,
                color: colors.text.primary,
              ),
              Image.file(
                File(widget.path),
                height: 161,
                width: double.infinity,
              ),
              Container(
                margin: const EdgeInsets.only(top: 24, bottom: 16),
                child: (Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                        text: '* ',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: colors.primary.coral.main,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            text: copy('common.vehicle'),
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.text.primary,
                              fontFamily: 'Jost',
                              fontSize: textMd,
                            ),
                          ),
                        ],
                      ),
                    ),
                    NvText(
                      textHolder: copy('visitors.vehicle-type'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w300,
                      fontSize: textSm,
                      color: colors.text.secondary,
                    ),
                  ],
                )),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  VehicleCard(
                    mainColor: colors.secondary.yellow.v1,
                    borderColor: colors.secondary.yellow.main,
                    isSelected: widget.data["isBikeSelected"],
                    image: 'ds/icons/bike-bicycle-2.svg',
                    textField: copy('visitors.bike'), //'Bici',
                    action: selectBike,
                  ),
                  VehicleCard(
                    mainColor: colors.primary.turquoise.v1,
                    borderColor: colors.primary.turquoise.main,
                    isSelected: widget.data["isCarSelected"],
                    image: 'ds/icons/car.svg',
                    textField: copy('profile.car'), //'Auto',
                    action: selectCar,
                  ),
                  VehicleCard(
                    mainColor: colors.secondary.lavanda.v1,
                    borderColor: colors.secondary.lavanda.main,
                    isSelected: widget.data["isMotorcycleSelected"],
                    image: 'ds/icons/motorcycle.svg',
                    // textField: copy('page.visit.laberMotorcycle'), //'Moto',
                    textField: 'Moto',
                    action: selectMotircycle,
                  ),
                ],
              ),
              if (!widget.data["isBikeSelected"])
                Container(
                  margin: const EdgeInsets.only(bottom: 8.0, top: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          NvText(
                            textHolder: copy('visitors.registration-number'),
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.w500,
                            fontSize: textMd,
                            color: colors.text.primary,
                          ),
                          const SizedBox(
                            width: 4.0,
                          ),
                          NvText(
                            textHolder: copy('common.optional'),
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.w300,
                            fontSize: textMd,
                            color: colors.text.secondary,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8.0,
                      ),
                      NvTextField(
                        textHolder: 'Ej: AB 123 CD',
                        label: "plateNumber",
                        formValues: widget.data,
                        controller: plateNumberController,
                        maxLength:
                            GlobalUtils.countryId == Constants.coIntIdCode
                                ? Constants.plateColombiaLenght
                                : Constants.plateMexicoLenght,
                        action: (value) {
                          setState(() {
                            widget.data['licensePlate'] = value.toString();
                          });
                        },
                      ),
                    ],
                  ),
                ),
            ]),
          ),
          Container(
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  width: 1.0,
                  color: colors.primary.black.v1,
                ),
              ),
            ),
            padding: const EdgeInsets.only(bottom: 16.0),
            child: BottomButton(
              disabled: widget.data["isBikeSelected"]
                  ? false
                  : widget.data['licensePlate'] == '',
              buttonText: copy('visitors.next'),
              action: goToConfirmation,
            ),
          ),
        ]),
      ),
    );
  }
}
