import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_add_manual.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_confirm_data.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/widgets/vehicle_card.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/config/nv_text_field.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';

class VisitorsData extends StatefulWidget {
  final Contact? contact;
  final bool? isFavorite;

  const VisitorsData({
    Key? key,
    required this.contact,
    required this.isFavorite,
  }) : super(key: key);

  @override
  State<VisitorsData> createState() => _VisitorsData();
}

class _VisitorsData extends State<VisitorsData> {
  Function copy = AppMessages().getCopy;
  Map<String, dynamic> formValues = {};
  TextEditingController dateinput = TextEditingController();
  TextEditingController fromDateInput = TextEditingController();
  TextEditingController toDateInput = TextEditingController();
  var defaultSelectionValue = 1;
  var selectedValue = "1";
  var isAdvancedOptionsCliced = false;
  var isManyDaysVisit = false;
  bool isCompanionSwitched = false;
  bool isVehicleSwitched = false;
  DateTime? initDateSelected = DateTime.now();
  TextStyle advancedOptionsStyle = const TextStyle(
    color: AppTheme.greenArlequin4,
    fontWeight: FontWeight.w400,
    fontSize: 12,
  );

  TextStyle labelStyle = const TextStyle(
    color: AppTheme.black4,
    fontWeight: FontWeight.bold,
    fontSize: 12,
  );

  final visitCategories = Constants().visitCategory;

  @override
  // ignore: long-method
  void initState() {
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      dateinput.text = "";
      // ignore: no-empty-block
      setState(() {});
      formValues = {
        'idServicePoint': UserUtils.currentServicePoint?.id,
        'nameEnterprise': UserUtils.currentUser?.currentEnterprise?.name,
        'idEnterprise': UserUtils.currentEnterprise?.id,
        'userName': UserUtils.currentUser?.name,
        'email': UserUtils.currentUser?.email,
        'idZyosUser': UserUtils.currentUser?.id,
        'userCreation': UserUtils.currentUser?.id,
        'visitor': {
          'name': widget.contact?.displayName ?? "",
          'mobilePhone': widget.contact?.phones.first.number,
          'favorite': widget.isFavorite == true ? "S" : "N",
          'idDocumentType': null,
          'documentNumber': null,
        },
        'eventName': "",
        'idVisitPeriod': defaultSelectionValue,
        'idVisitCategory': defaultSelectionValue,
        'visitDateAsString': "",
        'initDateAsString': "",
        'lastDateAsString': "",
        "visitorDocument": "",
        "vehicle": "",
        "plate": "",
        "accompanist": "",
        "isMotorcycleSelected": false,
        "isCarSelected": false,
        "isBikeSelected": true,
      };
    });
  }

  selectMotorcycle() {
    setState(() {
      formValues["isMotorcycleSelected"] = true;
      formValues["isCarSelected"] = false;
      formValues["isBikeSelected"] = false;
    });
  }

  selectCar() {
    setState(() {
      formValues["isCarSelected"] = true;
      formValues["isMotorcycleSelected"] = false;
      formValues["isBikeSelected"] = false;
    });
  }

  selectBike() {
    setState(() {
      formValues["isBikeSelected"] = true;
      formValues["isCarSelected"] = false;
      formValues["isMotorcycleSelected"] = false;
    });
  }

  // ignore: long-method
  goToConfirmation() {
    if (!isManyDaysVisit) {
      formValues['initDateAsString'] = "";
      formValues['lastDateAsString'] = "";
      formValues['idVisitPeriod'] = Constants.singleDayVisit;
    } else {
      formValues['visitDateAsString'] = "";
      formValues['idVisitPeriod'] = Constants.manyDaysVisit;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => widget.contact != null
            ? VisitorsConfirmData(
                request: CreateVisitRequest.fromJson(formValues),
                isFavorite: "S",
              )
            : VisitorsAddManual(
                request: CreateVisitRequest.fromJson(formValues),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    const double textSm = 14.0;
    const double textMd = 16.0;
    const double textLg = 26.0;

    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'visitorNameAndSp',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'visitorNameAndSp',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(children: [
          Container(
            margin: const EdgeInsets.only(top: 37.0),
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                NvText(
                  //"Datos de la visita",
                  textHolder: copy('visitors.visit-data'),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.w600,
                  fontSize: textLg,
                  color: Colors.black,
                  textAlign: TextAlign.center,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    NvText(
                      //"Visita de varios días",
                      textHolder: copy('visitors.range-day-visits'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w500,
                      fontSize: textMd,
                      color: Colors.black,
                    ),
                    Switch(
                      value: isManyDaysVisit,
                      activeColor: colors.primary.turquoise.v4,
                      onChanged: (value) {
                        setState(() {
                          isManyDaysVisit = value;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(
                  height: 36.0,
                ),
                if (isManyDaysVisit)
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              text: '* ',
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.primary.coral.main,
                              ),
                              children: <TextSpan>[
                                TextSpan(
                                  text: 'Desde',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: colors.primary.black.main,
                                    fontFamily: 'Jost',
                                    fontSize: textMd,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 8.0,
                          ),
                          TextField(
                            maxLines: 1,
                            controller: toDateInput,
                            decoration: const InputDecoration(
                              hintText: 'dd/mm/yyyy',
                              hintStyle: TextStyle(fontSize: 16.0),
                              contentPadding: EdgeInsets.only(
                                left: 16.0,
                                right: 16.0,
                                top: 10.0,
                                bottom: 10.0,
                              ),
                            ),
                            style: TextStyle(
                              fontWeight: FontWeight.w300,
                              color: colors.primary.black.main,
                              fontFamily: 'Jost',
                              fontSize: textMd,
                            ),
                            readOnly:
                                true, // Set it true, so that user will not able to edit text.
                            // ignore: prefer-extracting-callbacks
                            onTap: () async {
                              DateTime? pickedDate = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime.now()
                                    .subtract(const Duration(days: 0)),
                                lastDate: DateTime(2101),
                              );
                              initDateSelected = pickedDate;
                              if (pickedDate != null) {
                                String formattedDate =
                                    DateFormat('dd/MM/yyyy').format(pickedDate);

                                formValues['initDateAsString'] =
                                    DateFormat('yyyy-MM-dd').format(pickedDate);
                                setState(() {
                                  toDateInput.text =
                                      formattedDate; // Set output date to TextField value.
                                });
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      width: 16.0,
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              text: '* ',
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.primary.coral.main,
                              ),
                              children: <TextSpan>[
                                TextSpan(
                                  text: 'Hasta',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: colors.primary.black.main,
                                    fontFamily: 'Jost',
                                    fontSize: textMd,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 8.0,
                          ),
                          TextField(
                            maxLines: 1,
                            controller: fromDateInput,
                            decoration: const InputDecoration(
                              hintText: 'dd/mm/yyyy',
                              hintStyle: TextStyle(fontSize: 16.0),
                              contentPadding: EdgeInsets.only(
                                left: 16.0,
                                right: 16.0,
                                top: 10.0,
                                bottom: 10.0,
                              ),
                            ),

                            style: TextStyle(
                              fontWeight: FontWeight.w300,
                              color: colors.primary.black.main,
                              fontFamily: 'Jost',
                              fontSize: textMd,
                            ),
                            readOnly:
                                true, // Set it true, so that user will not able to edit text.
                            // ignore: prefer-extracting-callbacks
                            onTap: () async {
                              DateTime? pickedDate = await showDatePicker(
                                context: context,
                                initialDate: initDateSelected!
                                    .add(const Duration(days: 1)),
                                firstDate: initDateSelected!
                                    .add(const Duration(days: 1)),
                                lastDate: DateTime(2101),
                              );

                              if (pickedDate != null) {
                                String formattedDate =
                                    DateFormat('dd/MM/yyyy').format(pickedDate);

                                formValues['lastDateAsString'] =
                                    DateFormat('yyyy-MM-dd').format(pickedDate);

                                setState(() {
                                  fromDateInput.text =
                                      formattedDate; // Set output date to TextField value.
                                });
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  ]),
                if (!isManyDaysVisit)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8.0),
                    child: RichText(
                      text: TextSpan(
                        text: '* ',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: colors.primary.coral.main,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            //'Día de la visita',
                            text: copy('visitors.visit-day'),
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.primary.black.main,
                              fontFamily: 'Jost',
                              fontSize: textMd,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (!isManyDaysVisit)
                  TextField(
                    maxLines: 1,
                    controller: dateinput,
                    decoration: const InputDecoration(
                      hintText: 'dd/mm/yyyy',
                      hintStyle: TextStyle(fontSize: 16.0),
                      contentPadding: EdgeInsets.only(
                        left: 16.0,
                        right: 16.0,
                        top: 10.0,
                        bottom: 10.0,
                      ),
                    ),
                    style: TextStyle(
                      fontWeight: FontWeight.w300,
                      color: colors.primary.black.main,
                      fontFamily: 'Jost',
                      fontSize: textMd,
                    ),
                    readOnly:
                        true, // Set it true, so that user will not able to edit text.
                    // ignore: prefer-extracting-callbacks
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate:
                            DateTime.now().subtract(const Duration(days: 0)),
                        lastDate: DateTime(2101),
                      );

                      if (pickedDate != null) {
                        String formattedDate =
                            DateFormat('dd/MM/yyyy').format(pickedDate);
                        formValues['visitDateAsString'] =
                            DateFormat('yyyy-MM-dd').format(pickedDate);
                        setState(() {
                          dateinput.text =
                              formattedDate; // Set output date to TextField value.
                        });
                      }
                    },
                  ),
                const SizedBox(
                  height: 24.0,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                        text: '* ',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: colors.primary.coral.main,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            //'Tipo de visita',
                            text: copy('visitors.visit-type'),
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.primary.black.main,
                              fontFamily: 'Jost',
                              fontSize: textMd,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8.0,
                    ),
                    DropdownButtonHideUnderline(
                      child: DropdownButtonFormField(
                        items: visitCategories,
                        icon: const Icon(Icons.arrow_drop_down),
                        isExpanded: true,
                        value: selectedValue,
                        style: TextStyle(
                          color: colors.primary.black.main,
                          fontSize: 16,
                          fontWeight: FontWeight.w300,
                          fontFamily: "Jost",
                        ),
                        onChanged: (String? value) {
                          formValues['idVisitCategory'] =
                              int.parse(value ?? "0");
                        },
                        decoration: InputDecoration(
                          isDense: true,
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: colors.primary.black.v1,
                            ),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(6)),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: colors.primary.black.v1,
                            ),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(6)),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 8.5,
                            horizontal: 10.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 24.0,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                            text: '* ',
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.primary.coral.main,
                            ),
                            children: <TextSpan>[
                              TextSpan(
                                //'Vehículo',
                                text: copy('visitors.visit-vehicle'),
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: colors.primary.black.main,
                                  fontFamily: 'Jost',
                                  fontSize: textMd,
                                ),
                              ),
                            ],
                          ),
                        ),
                        NvText(
                          //"Tipo de vehículo",
                          textHolder: copy('visitors.visit-vehicle-type'),
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w500,
                          fontSize: textSm,
                          color: colors.text.primary,
                        ),
                      ],
                    ),
                    Switch(
                      value: isVehicleSwitched,
                      activeColor: colors.primary.turquoise.v4,
                      onChanged: (value) {
                        setState(() {
                          isVehicleSwitched = value;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(
                  height: 16.0,
                ),
                if (isVehicleSwitched)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      VehicleCard(
                        mainColor: colors.secondary.yellow.v1,
                        borderColor: colors.secondary.yellow.main,
                        isSelected: formValues["isBikeSelected"],
                        action: selectBike,
                        image: 'ds/icons/bike-bicycle-2.svg',
                        textField: copy('visitors.bike'), //'Bici',
                      ),
                      VehicleCard(
                        mainColor: colors.primary.turquoise.v1,
                        borderColor: colors.primary.turquoise.main,
                        isSelected: formValues["isCarSelected"],
                        action: selectCar,
                        image: 'ds/icons/car.svg',
                        textField: copy('profile.car'), //'Auto',
                      ),
                      VehicleCard(
                        mainColor: colors.secondary.lavanda.v1,
                        borderColor: colors.secondary.lavanda.main,
                        isSelected: formValues["isMotorcycleSelected"],
                        action: selectMotorcycle,
                        image: 'ds/icons/motorcycle.svg',
                        textField: copy('page.visit.laberMotorcycle'),
                        //'Moto',
                      ),
                    ],
                  ),
                const SizedBox(
                  height: 16.0,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    NvText(
                      //"Acompañantes",
                      textHolder: copy('visitors.visit-companions'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w500,
                      fontSize: textMd,
                      color: colors.text.primary,
                    ),
                    Switch(
                      value: isCompanionSwitched,
                      activeColor: colors.primary.turquoise.v4,
                      onChanged: (value) {
                        setState(() {
                          isCompanionSwitched = value;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(
                  height: 4.0,
                ),
                if (isCompanionSwitched)
                  NvTextField(
                    textHolder: '0',
                    textType: 'number',
                    label: "accompanist",
                    formValues: formValues,
                    controller: TextEditingController(
                      text: formValues['accompanist'],
                    ),
                    action: () {},
                  ),
              ],
            ),
          ),
          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Container(
                margin: const EdgeInsets.only(
                  top: 24,
                ),
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                      color: colors.primary.black.v1,
                      width: 1,
                    ),
                  ),
                ),
                child: NvButton(
                  //"Siguiente",
                  label: copy('visitors.next'),
                  action: () {
                    goToConfirmation;
                  },
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
