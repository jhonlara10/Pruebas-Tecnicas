import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_take_id_photo.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/config/nv_text_field.dart';

import '../../../theme/app_theme_scope.dart';
import '../../../widgets/nv_appbar.dart';
import '../../../widgets/nv_text.dart';

class EditVisitData extends StatefulWidget {
  final String visitorName;
  final ServicePointObject? servicePointObject;

  const EditVisitData({
    Key? key,
    required this.data,
    required this.visitorName,
    this.servicePointObject,
  }) : super(key: key);

  final Map<String, dynamic> data;

  @override
  State<EditVisitData> createState() => _EditVisitDataState();
}

class _EditVisitDataState extends State<EditVisitData> {
  final copy = AppMessages().getCopy;
  bool isVehicleSwitched = false;
  bool isCompanionSwitched = false;
  String visitorPhone = "";
  // ignore: prefer-correct-identifier-length
  List<DropdownMenuItem<String>> documentDropdownTypeList = [];
  // ignore: prefer-correct-identifier-length
  List<DropdownMenuItem<String>> visitCategoryDropdownTypeList =
      Constants().visitCategory;
  var defaultSelectionValue = 1;
  Map<String, dynamic> formValues = {};
  var isManyDaysVisit = false;
  DateTime? initDateSelected = DateTime.now();
  TextEditingController dateinput = TextEditingController();
  TextEditingController fromDateInput = TextEditingController();
  TextEditingController toDateInput = TextEditingController();
  TextEditingController companionInput = TextEditingController();

  @override
  // ignore: long-method
  initState() {
    (() async {
      formValues = {
        "nameEnterprise": UserUtils.currentEnterprise?.name,
        "idEnterprise": UserUtils.currentEnterprise?.id,
        "userName": UserUtils.currentUser?.name,
        "email": UserUtils.currentUser?.email,
        "idZyosUser": UserUtils.currentUser?.id,
        "userCreation": UserUtils.currentUser?.id,
        "idServicePoint": widget.servicePointObject?.id,
        "idVisitPeriod": defaultSelectionValue,
        "idVisitCategory": 0,
        "idVisitType": 0,
        "visitDateAsString": "",
        "initDateAsString": "",
        "lastDateAsString": "",
        "companions": "",
        "isVehicleSelected": false,
        "isMotorcycleSelected": false,
        "isCarSelected": true,
        "isBikeSelected": false,
        "visitor": {
          "name": widget.visitorName,
          "mobilePhone": null,
          "favorite": "",
          "documentNumber": null,
          "idDocumentType": null,
        },
        "idVehicleType": null,
        "licensePlate": "",
        "base64IdPhoto": "",
        "idPhotoPath": "",
        "base64PlatePhoto": "",
        "platePhotoPath": "",
      };
    })();
    super.initState();
  }

  setCompanions(val) {
    setState(() {
      formValues['companions'] = val;
    });
  }

  backToData() {
    Navigator.pop(context);
  }

  // ignore: long-method
  goToDocumentPhoto() {
    if (!isManyDaysVisit) {
      formValues['initDateAsString'] = "";
      formValues['lastDateAsString'] = "";
      formValues['idVisitPeriod'] = Constants.singleDayVisit;
    } else {
      formValues['visitDateAsString'] = "";
      formValues['idVisitPeriod'] = Constants.manyDaysVisit;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitTakeIdPhoto(
          data: formValues,
          visitorName: widget.visitorName,
          servicePointObject: widget.servicePointObject,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    const double textMd = 16.0;
    const double textLg = 26.0;

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO review this.
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(
                top: 20.0,
                left: 16.0,
                right: 16.0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  NvText(
                    textHolder: copy('visitors.visit-data'),
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.w600,
                    fontSize: textLg,
                    color: colors.text.primary,
                  ),
                  const SizedBox(
                    height: 16.0,
                  ),
                  NvText(
                    textHolder: widget.visitorName,
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.w600,
                    fontSize: textMd,
                    color: colors.text.primary,
                  ),
                  const SizedBox(
                    height: 12.0,
                  ),
                  Row(children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 10,
                      ),
                      child: NvText(
                        textHolder: copy('visitors.range-day-visits'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w500,
                        fontSize: textMd,
                        color: colors.text.primary,
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 10, left: 15),
                        child: CupertinoSwitch(
                          value: isManyDaysVisit,
                          activeColor: colors.primary.turquoise.v4,
                          onChanged: (bool value) {
                            setState(() {
                              isManyDaysVisit = value;
                            });
                          },
                        ),
                      ),
                    ),
                  ]),
                  if (isManyDaysVisit)
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                            top: 8.0,
                            bottom: 10.0,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  bottom: 10,
                                  right: 10,
                                ),
                                child: RichText(
                                  text: TextSpan(
                                    text: '*  ',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: colors.primary.coral.main,
                                    ),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: copy('visitors.from'),
                                        style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          color: colors.text.primary,
                                          fontFamily: 'Jost',
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              TextField(
                                maxLines: 1,
                                controller: toDateInput,
                                decoration: const InputDecoration(
                                  hintText: 'dd/mm/yyyy',
                                  hintStyle: TextStyle(
                                    fontFamily: 'Jost',
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w300,
                                  ),
                                ),
                                readOnly:
                                    true, // Set it true, so that user will not able to edit text.
                                // ignore: prefer-extracting-callbacks
                                onTap: () async {
                                  DateTime? pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime.now()
                                        .subtract(const Duration(days: 0)),
                                    lastDate: DateTime(2101),
                                  );
                                  initDateSelected = pickedDate;
                                  if (pickedDate != null) {
                                    String formattedDate =
                                        DateFormat('dd/MM/yyyy')
                                            .format(pickedDate);

                                    formValues['initDateAsString'] =
                                        DateFormat('yyyy-MM-dd')
                                            .format(pickedDate);
                                    setState(() {
                                      toDateInput.text =
                                          formattedDate; // Set output date to TextField value.
                                    });
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                            top: 8.0,
                            bottom: 10.0,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  bottom: 10,
                                  left: 10,
                                ),
                                child: RichText(
                                  text: TextSpan(
                                    text: '*  ',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: colors.primary.coral.main,
                                    ),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: copy('visitors.to'),
                                        style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          color: colors.text.primary,
                                          fontFamily: 'Jost',
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              TextField(
                                maxLines: 1,
                                controller: fromDateInput,
                                decoration: const InputDecoration(
                                  hintText: 'dd/mm/yyyy',
                                  hintStyle: TextStyle(
                                    fontFamily: 'Jost',
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w300,
                                  ),
                                ),
                                readOnly:
                                    true, // Set it true, so that user will not able to edit text.
                                // ignore: prefer-extracting-callbacks
                                onTap: () async {
                                  DateTime? pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: initDateSelected!
                                        .add(const Duration(days: 1)),
                                    firstDate: initDateSelected!
                                        .add(const Duration(days: 1)),
                                    lastDate: DateTime(2101),
                                  );

                                  if (pickedDate != null) {
                                    String formattedDate =
                                        DateFormat('dd/MM/yyyy')
                                            .format(pickedDate);

                                    formValues['lastDateAsString'] =
                                        DateFormat('yyyy-MM-dd')
                                            .format(pickedDate);

                                    setState(() {
                                      fromDateInput.text =
                                          formattedDate; // Set output date to TextField value.
                                    });
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ]),
                  if (!isManyDaysVisit)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: const EdgeInsets.only(
                          top: 8.0,
                          bottom: 10.0,
                        ),
                        child: RichText(
                          text: TextSpan(
                            text: '*  ',
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.primary.coral.main,
                            ),
                            children: <TextSpan>[
                              TextSpan(
                                text: copy('visitors.visit-day'),
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: colors.text.primary,
                                  fontFamily: 'Jost',
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (!isManyDaysVisit)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: const EdgeInsets.only(
                          bottom: 8,
                        ),
                        child: TextField(
                          maxLines: 1,
                          controller: dateinput,
                          decoration: const InputDecoration(
                            hintText: 'dd/mm/yyyy',
                            hintStyle: TextStyle(
                              fontFamily: 'Jost',
                              fontSize: 16.0,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                          readOnly:
                              true, // Set it true, so that user will not able to edit text.
                          // ignore: prefer-extracting-callbacks
                          onTap: () async {
                            DateTime? pickedDate = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime.now()
                                  .subtract(const Duration(days: 0)),
                              lastDate: DateTime(2101),
                            );

                            if (pickedDate != null) {
                              String formattedDate =
                                  DateFormat('dd/MM/yyyy').format(pickedDate);
                              formValues['visitDateAsString'] =
                                  DateFormat('yyyy-MM-dd').format(pickedDate);
                              setState(() {
                                dateinput.text =
                                    formattedDate; // Set output date to TextField value.
                              });
                            }
                          },
                        ),
                      ),
                    ),
                  const SizedBox(
                    height: 16.0,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RichText(
                        text: TextSpan(
                          text: '*  ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: colors.primary.coral.main,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: copy('visitors.visit-type'),
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.text.primary,
                                fontFamily: 'Jost',
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 8.0,
                      ),
                      DropdownButtonFormField(
                        // ignore: prefer-extracting-callbacks
                        validator: (value) {
                          if (value == null) {
                            return copy('visitors.validator-required');
                            // 'Obligatorio';
                          }
                          return null;
                        },
                        isDense: true,
                        decoration: InputDecoration(
                          hintText: copy('common.select-option'),
                          hintStyle: const TextStyle(
                            fontFamily: 'Jost',
                            fontSize: 16.0,
                            fontWeight: FontWeight.w300,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 8,
                            horizontal: 5,
                          ),
                        ),
                        menuMaxHeight: MediaQuery.of(context).size.height *
                            Constants.thirtyPercent,
                        isExpanded: true,
                        items: visitCategoryDropdownTypeList,
                        onChanged: (value) {
                          formValues['idVisitType'] =
                              int.parse(value.toString());
                          formValues['idVisitCategory'] =
                              int.parse(value.toString());
                          setState(() {});
                        },
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 16.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      NvText(
                        textHolder: copy('visitors.visit-companions'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w500,
                        fontSize: textMd,
                        color: colors.text.primary,
                      ),
                      CupertinoSwitch(
                        value: isCompanionSwitched,
                        onChanged: (value) {
                          setState(() {
                            isCompanionSwitched = value;
                          });
                        },
                        activeColor: colors.primary.turquoise.v4,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 4.0,
                  ),
                  if (isCompanionSwitched)
                    NvTextField(
                      textHolder: '0',
                      textType: 'number',
                      label: "companions",
                      formValues: formValues,
                      controller: companionInput,
                      action: setCompanions,
                    ),
                ],
              ),
            ),
            const SizedBox(
              height: 16,
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: BottomButton(
          //"Siguiente",
          buttonText: copy('visitors.next'),
          action: goToDocumentPhoto,
          disabled: !isManyDaysVisit
              ? (dateinput.text.isEmpty || formValues['idVisitType'] == 0)
              : (fromDateInput.text.isEmpty || toDateInput.text.isEmpty) ||
                  formValues['idVisitType'] == 0,
        ),
      ),
    );
  }
}
