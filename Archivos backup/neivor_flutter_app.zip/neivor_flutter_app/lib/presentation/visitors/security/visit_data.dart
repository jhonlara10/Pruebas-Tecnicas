import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/entry_visit_action_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/insert_document_photo_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/insert_plate_photo_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/edit_visit_data.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visitor_created_success.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../theme/app_theme_scope.dart';
import '../../../widgets/nv_appbar.dart';
import '../../../widgets/nv_button.dart';
import '../../../widgets/nv_text.dart';
import 'widgets/vehicle_card.dart';

class VisitData extends StatefulWidget {
  final String visitorName;
  final ServicePointObject? servicePointObject;
  final Map<String, dynamic> data;

  const VisitData({
    Key? key,
    required this.data,
    required this.visitorName,
    required this.servicePointObject,
  }) : super(key: key);

  @override
  State<VisitData> createState() => _VisitDataState();
}

class _VisitDataState extends State<VisitData> {
  Function copy = AppMessages().getCopy;
  bool isMotorcycleSelected = false;
  bool isCarSelected = false;
  bool isBikeSelected = true;
  bool isManyDaysToVisit = false;
  String visitorPhone = "3112612298";
  String visitorDocument = "ZA000254";
  DateTime visitDay = DateTime.now();
  DateTime initVisitDay = DateTime.now();
  DateTime lastVisitDay = DateTime.now();
  Map<String, dynamic> formValues = {};
  List<dynamic> documentTypeList = [];
  String documentType = '';
  final visitCategoryDropdownList = Constants().visitCategory;
  Widget typeOfVisit = const Text('');

  @override
  initState() {
    (() async {
      await setData();
    })();
    getDocumentTypes();
    getCategoryValue();
    super.initState();
  }

  insertPlatePhoto() async {
    try {
      widget.data['plateImage'] = widget.data['base64PlatePhoto'];
      if (widget.data['visitor']['idDocumentType'] != null) {
        widget.data['visitor']['idDocumentType'] =
            widget.data['visitor']['idDocumentType'].toString();
      }
      widget.data['id'] = widget.data['idZyosUser'];
      var insertPlatePhotoRequest =
          InsertPlatePhotoRequest.fromJson(widget.data);
      // ignore: prefer-correct-identifier-length
      await VisitorsRepository().insertPlatePhoto(insertPlatePhotoRequest);
    } catch (e) {}
  }

  insertDocumentPhoto() async {
    try {
      widget.data['id'] = widget.data['idVisitor'];
      widget.data['userChange'] = widget.data['idZyosUser'];
      widget.data['image'] = widget.data['base64IdPhoto'];
      var insertDocumentPhotoRequest =
          InsertDocumentPhotoRequest.fromJson(widget.data);
      await VisitorsRepository()
          .insertDocumentPhoto(insertDocumentPhotoRequest);
    } catch (e) {}
  }

  // ignore: long-method
  createVisit() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    var isQrFlow = sharedPreferences.getBool("isQrFlow");
    context.loaderOverlay.show();
    if (isQrFlow == false) {
      var createVisitRequest = CreateVisitRequest.fromJson(widget.data);
      var response = await VisitorsRepository().createVisit(createVisitRequest);
      var arrayIds = response.textQr?.split(",");
      var idVisitor = arrayIds?[1];
      widget.data['idVisitor'] = int.parse(idVisitor ?? "0");
    }

    if (widget.data['visitor']['idDocumentType'] != null) {
      widget.data['visitor']['idDocumentType'] =
          widget.data['visitor']['idDocumentType'].toString();
    }
    if (widget.data['base64IdPhoto'] != null &&
        widget.data['base64IdPhoto'] != "") {
      await insertDocumentPhoto();
    }
    if (widget.data['base64PlatePhoto'] != null &&
        widget.data['base64PlatePhoto'] != "") {
      await insertPlatePhoto();
    }

    var entryVisitActionRequest = EntryVisitActionRequest(
      id: widget.data['idVisitor'],
      name: widget.data['visitor']['name'],
      userChange: UserUtils.currentUser?.id,
      entryDateAsString:
          GlobalUtils().getParsedTodayDate("yyyy/MM/dd hh:mm:ss"),
    );

    await VisitorsRepository().markVisitAsEntry(entryVisitActionRequest);

    context.loaderOverlay.hide();
    // ignore: use_build_context_synchronously
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitorCreatedSuccess(
          visitorName: widget.visitorName,
        ),
      ),
    );
  }

  /// Show default error on native [AlertDialog] alert
  ///
  /// Param:
  /// [String] message to show on [AlertDialog]
  ///
  // ignore: long-method
  showError(String? message) {
    Widget okButton = TextButton(
      child: Text(AppMessages().getCopy('common.accept')), //"Aceptar"
      onPressed: () {
        Navigator.pop(context, false);
      },
    );

    // Set up the AlertDialog.
    AlertDialog alert = AlertDialog(
      title: const Text("Error"),
      content: Text(message ?? ""),
      actions: [
        okButton,
      ],
    );

    // Show the dialog.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  getDocumentTypes() {
    if (formValues["visitor"]['idDocumentType'] != null &&
        formValues["visitor"]['idDocumentType'] != '') {
      documentTypeList =
          jsonDecode(AppUrls().getProperty('core.list.documentType'));
      var result = documentTypeList.where(
        (element) =>
            element['id'].toString() ==
            formValues["visitor"]['idDocumentType'].toString(),
      );
      documentType = result.first['name'] ?? '';
      setState(() {});
    }
  }

  //gets type of visit from constants dynamic value - multilanguage
  getCategoryValue() {
    var idVisitCategory = formValues['idVisitType'];
    for (var element in visitCategoryDropdownList) {
      element.value == idVisitCategory.toString()
          ? typeOfVisit = element.child
          : null;
    }
    setState(() {});
  }

  setData() {
    formValues = widget.data;

    if (formValues['visitDateAsString'] != '') {
      visitDay = Jiffy(formValues['visitDateAsString'], 'yyyy-MM-dd').dateTime;
      isManyDaysToVisit = false;
    }

    if ((formValues['initDateAsString'] != '' &&
            formValues['initDateAsString'] != null) &&
        (formValues['lastDateAsString'] != '' &&
            formValues['lastDateAsString'] != null)) {
      initVisitDay =
          Jiffy(formValues['initDateAsString'], 'yyyy-MM-dd').dateTime;
      lastVisitDay =
          Jiffy(formValues['lastDateAsString'], 'yyyy-MM-dd').dateTime;
      isManyDaysToVisit = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    const double textSm = 14.0;
    const double textMd = 16.0;
    const double textLg = 26.0;

    redirectEditVisitData() {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => EditVisitData(
            data: formValues,
            visitorName: widget.visitorName,
            servicePointObject: widget.servicePointObject,
          ),
        ),
      );
    }

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO review this.
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Column(
            children: [
              Container(
                margin: const EdgeInsets.only(
                  top: 37.0,
                  left: 16.0,
                  right: 16.0,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    NvText(
                      // "Datos de la visita",
                      textHolder: copy('visitors.visit-data'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w600,
                      fontSize: textLg,
                      color: colors.text.primary,
                    ),
                    const SizedBox(
                      height: 16.0,
                    ),
                    Row(
                      children: [
                        if (formValues['idPhotoPath'] != '' &&
                            formValues['idPhotoPath'] != null)
                          Image.file(
                            File(formValues['idPhotoPath']),
                            height: 60,
                            width: 60,
                          ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            NvText(
                              textHolder: widget.visitorName,
                              fontFamily: 'Jost',
                              fontWeight: FontWeight.w500,
                              fontSize: textMd,
                              color: colors.text.primary,
                            ),
                            if (formValues["visitor"]['documentNumber'] != '' &&
                                formValues["visitor"]['documentNumber'] != null)
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  NvText(
                                    textHolder: documentType,
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                    color: colors.text.secondary,
                                  ),
                                  NvText(
                                    textHolder: formValues["visitor"]
                                        ['documentNumber'],
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w300,
                                    fontSize: textSm,
                                    color: colors.text.primary,
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 16.0,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: colors.primary.black.v1,
                          width: 1.0,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(8.0),
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  NvText(
                                    textHolder: copy('visitors.event'),
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w500,
                                    fontSize: textMd,
                                    color: colors.text.primary,
                                  ),
                                  GestureDetector(
                                    // ignore: prefer-extracting-callbacks
                                    onTap: () {
                                      redirectEditVisitData();
                                    },
                                    child: NvText(
                                      textHolder: copy('common.edit'),
                                      fontFamily: 'Jost',
                                      fontWeight: FontWeight.w500,
                                      fontSize: textMd,
                                      color: colors.primary.turquoise.v4,
                                      textDecoration: TextDecoration.underline,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 16.0,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  NvText(
                                    //"Día de la visita",
                                    textHolder: copy('visitors.visit-day'),
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w300,
                                    fontSize: textSm,
                                    color: colors.text.primary,
                                  ),
                                  NvText(
                                    textHolder: isManyDaysToVisit
                                        ? '${DateFormat('yyyy/MM/dd').format(initVisitDay)} al ${DateFormat('yyyy/MM/dd').format(lastVisitDay)}'
                                        : DateFormat('yyyy/MM/dd')
                                            .format(visitDay),
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w500,
                                    fontSize: textSm,
                                    color: colors.text.primary,
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8.0,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  NvText(
                                    //"Unidad",
                                    textHolder: copy('user-access.unity-label'),
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w300,
                                    fontSize: textSm,
                                    color: colors.text.primary,
                                  ),
                                  NvText(
                                    textHolder:
                                        "${widget.servicePointObject?.operationZone?.name ?? ""} - ${widget.servicePointObject?.name ?? ""}",
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w500,
                                    fontSize: textSm,
                                    color: colors.text.primary,
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8.0,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  NvText(
                                    //"Tipo de visita",
                                    textHolder: copy('visitors.visit-type'),
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w300,
                                    fontSize: textSm,
                                    color: colors.text.primary,
                                  ),
                                  typeOfVisit,
                                ],
                              ),
                            ]),
                          ),
                          if (formValues['isVehicleSelected'] != null &&
                              formValues['isVehicleSelected'] == true)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 16,
                                    right: 16,
                                    top: 24,
                                    bottom: 16,
                                  ),
                                  child: NvText(
                                    textHolder: copy('vicitors.vehicle-type'),
                                    fontFamily: 'Jost',
                                    fontWeight: FontWeight.w500,
                                    fontSize: textMd,
                                    color: colors.text.primary,
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    VehicleCard(
                                      mainColor: colors.secondary.yellow.v1,
                                      borderColor: colors.secondary.yellow.main,
                                      isSelected: formValues["isBikeSelected"],
                                      image: 'ds/icons/bike-bicycle-2.svg',
                                      textField:
                                          copy('visitors.bike'), //'Bici',
                                    ),
                                    VehicleCard(
                                      mainColor: colors.primary.turquoise.v1,
                                      borderColor:
                                          colors.primary.turquoise.main,
                                      isSelected: formValues["isCarSelected"],
                                      image: 'ds/icons/car.svg',
                                      textField: copy('profile.car'), //'Auto',
                                    ),
                                    VehicleCard(
                                      mainColor: colors.secondary.lavanda.v1,
                                      borderColor:
                                          colors.secondary.lavanda.main,
                                      isSelected:
                                          formValues["isMotorcycleSelected"],
                                      image: 'ds/icons/motorcycle.svg',
                                      // textField: copy(
                                      //   'page.visit.laberMotorcycle',
                                      // ),,
                                      textField: 'Moto',
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                if (formValues["isCarSelected"] ||
                                    formValues["isMotorcycleSelected"])
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      NvText(
                                        textHolder: copy(
                                          'visitors.visit-vehicle-plate',
                                        ),
                                        fontFamily: 'Jost',
                                        fontWeight: FontWeight.w300,
                                        fontSize: textSm,
                                        color: colors.text.primary,
                                      ),
                                      NvText(
                                        textHolder:
                                            formValues["licensePlate"] != ''
                                                ? formValues["licensePlate"]
                                                : copy('common.unspecified'),
                                        fontFamily: 'Jost',
                                        fontWeight: FontWeight.w500,
                                        fontSize: textSm,
                                        color: colors.text.primary,
                                      ),
                                    ],
                                  ),
                                const SizedBox(
                                  height: 8.0,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    NvText(
                                      // Acompañantes
                                      textHolder:
                                          copy('visitors.visit-companions'),
                                      fontFamily: 'Jost',
                                      fontWeight: FontWeight.w300,
                                      fontSize: textSm,
                                      color: colors.text.primary,
                                    ),
                                    NvText(
                                      textHolder: formValues["companions"] != ''
                                          ? formValues["companions"]
                                          : '0',
                                      fontFamily: 'Jost',
                                      fontWeight: FontWeight.w500,
                                      fontSize: textSm,
                                      color: colors.text.primary,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ]),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(15),
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: colors.primary.black.v1,
              width: 1,
            ),
          ),
        ),
        child: NvButton(
          //"Listo",
          label: copy('common.ready'),
          // ignore: prefer-extracting-callbacks
          action: createVisit,
        ),
      ),
    );
  }
}
