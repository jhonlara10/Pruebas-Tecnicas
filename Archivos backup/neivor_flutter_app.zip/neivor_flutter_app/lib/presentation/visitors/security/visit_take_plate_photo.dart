import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_data.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_take_picture.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitTakePlatePhoto extends StatefulWidget {
  final String visitorName;
  final ServicePointObject? servicePointObject;
  final Map<String, dynamic> data;

  const VisitTakePlatePhoto({
    Key? key,
    required this.visitorName,
    this.servicePointObject,
    required this.data,
  }) : super(key: key);

  @override
  State<VisitTakePlatePhoto> createState() => _VisitTakePlatePhoto();
}

class _VisitTakePlatePhoto extends State<VisitTakePlatePhoto> {
  Function copy = AppMessages().getCopy;

  openCamera() async {
    var cameraList = await availableCameras();
    // ignore: use_build_context_synchronously
    // widget.data.isVehicleSelected = true;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => NvTakePicture(
          camera: cameraList.first,
          from: "photo-plate",
          servicePointObject: widget.servicePointObject,
          data: widget.data,
          visitorName: widget.visitorName,
        ),
      ),
    );
  }

  goRoResumeView() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitData(
          visitorName: widget.visitorName,
          servicePointObject: widget.servicePointObject,
          data: widget.data,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO Review this.
      ),
      body: Column(children: [
        Row(children: [
          Padding(
            padding: const EdgeInsets.only(top: 30, left: 30),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.9,
              child: NvText(
                //"Toma la foto de la matrícula",
                textHolder: copy('visitors.take-photo-license-plate'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.w600,
                fontSize: 26,
                color: colors.text.primary,
                textAlign: TextAlign.start,
              ),
            ),
          ),
        ]),
        Center(
          child: Padding(
            padding: const EdgeInsets.only(top: 70),
            child: Image.asset(
              'assets/images/plate.png',
              height: 300,
              width: 300,
            ),
          ),
        ),
        const Spacer(),
        Align(
          alignment: FractionalOffset.bottomCenter,
          child: Container(
            padding: const EdgeInsets.only(
              top: 20.0,
              left: 16.0,
              right: 16.0,
              bottom: 16.0,
            ),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: colors.primary.black.v1,
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2, left: 2),
                    child: NvButton(
                      //"Omitir",
                      label: copy('common.skip'),
                      action: () {
                        goRoResumeView();
                      },
                      variant: "secondary",
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2, left: 2),
                    child: NvButton(
                      //"Tomar foto",
                      label: copy('visitors.take-photo'),
                      action: () {
                        openCamera();
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}
