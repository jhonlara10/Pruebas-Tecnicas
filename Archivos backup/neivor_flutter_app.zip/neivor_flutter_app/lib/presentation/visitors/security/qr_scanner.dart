import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_scan_page.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';

class QRScanner extends StatefulWidget {
  const QRScanner({
    Key? key,
  }) : super(key: key);

  @override
  State<QRScanner> createState() => _QRScanner();
}

class _QRScanner extends State<QRScanner> {
  Function copy = AppMessages().getCopy;
  openQRScanner() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitScanPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'visitorsSecurity',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'visitorsSecurity',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(children: [
          Row(children: [
            Padding(
              padding: const EdgeInsets.only(top: 30, left: 30),
              child: NvText(
                textHolder: copy('visitors.scan-qr'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.bold,
                fontSize: 25,
                color: Colors.black,
                textAlign: TextAlign.center,
              ),
            ),
          ]),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 120),
                child: Image.asset(
                  'assets/images/qr_header.png',
                  height: 200,
                  width: 200,
                ),
              ),
            ],
          ),
          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: NvButton(
                  label: copy('visitors.next'),
                  //"Siguiente",
                  action: openQRScanner,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
