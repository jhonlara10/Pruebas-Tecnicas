import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/validate_qr_request.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_take_id_photo.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

class VisitScanPage extends StatefulWidget {
  @override
  _VisitScanPageState createState() => _VisitScanPageState();
}

class _VisitScanPageState extends State<VisitScanPage> {
  String qrCodeResult = "Not Yet Scanned";
  Map<String, dynamic> formValues = {};
  var defaultSelectionValue = 1;

  validateQrCode(String qrCode) {}

  @override
  // ignore: long-method
  void initState() {
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      // ignore: no-empty-block
      setState(() {});
      formValues = {
        'idServicePoint': -1,
        'nameEnterprise': -1,
        'idVisitType': -1,
        'idEnterprise': UserUtils.currentEnterprise?.id,
        'userName': "",
        'email': "",
        'idZyosUser': UserUtils.currentUser?.id,
        'userCreation': UserUtils.currentUser?.id,
        'visitor': {
          'name': "",
          'mobilePhone': null,
          'documentNumber': null,
          'idDocumentType': null,
          'favorite': "",
          'idVisitor': -1,
        },
        'eventName': "",
        'nameOperationZone': "",
        'idVisitPeriod': defaultSelectionValue,
        'idVisitCategory': defaultSelectionValue,
        'visitDateAsString': "",
        'initDateAsString': "",
        'lastDateAsString': "",
        "visitorDocument": "",
        "vehicle": "",
        "plate": "",
        "companions": "",
        "isMotorcycleSelected": false,
        "isCarSelected": false,
        "isBikeSelected": true,
      };
    });
  }

  // ignore: long-method
  validateQrData(String data) async {
    context.loaderOverlay.show();
    var validateQrResponse = await VisitorsRepository().validateQrCode(
      ValidateQrRequest(
        idEnterprise: UserUtils.currentEnterprise?.id?.toInt(),
        textQr: data,
      ),
    );
    context.loaderOverlay.hide();
    if (validateQrResponse.sucessScanQR == true) {
      formValues['idServicePoint'] = validateQrResponse.idServicePoint;
      formValues['nameEnterprise'] = validateQrResponse.enterpriseName;
      formValues['userName'] = validateQrResponse.userName;
      formValues['email'] = validateQrResponse.email;
      formValues['idVisitType'] = validateQrResponse.idVisitCategory;
      formValues['idVisitPeriod'] =
          validateQrResponse.idVisitPeriod ?? defaultSelectionValue;
      formValues['idVisitCategory'] =
          validateQrResponse.idVisitCategory ?? defaultSelectionValue;
      formValues['visitDateAsString'] = GlobalUtils().parseDoubleDate(
        validateQrResponse.visitDate?.toDouble() ?? 0.0,
      );
      formValues['initDateAsString'] = GlobalUtils().parseDoubleDate(
        validateQrResponse.initDate?.toDouble() ?? 0.0,
      );
      validateQrResponse.initDateAsString;
      formValues['lastDateAsString'] = GlobalUtils().parseDoubleDate(
        validateQrResponse.lastDate?.toDouble() ?? 0.0,
      );
      formValues['visitor']['name'] = validateQrResponse.visitor?.name ?? "";
      formValues['visitor']['mobilePhone'] =
          validateQrResponse.visitor?.mobilephone;
      formValues['visitor']['favorite'] =
          validateQrResponse.visitor?.favorite ?? "N";
      formValues['visitor']['idVisitor'] = validateQrResponse.visitor?.id;
      var servicePointObject = ServicePointObject(
        name: validateQrResponse.nameServicePoint,
        operationZone: OperationZone(
          name: validateQrResponse.nameOperationZone,
        ),
        id: validateQrResponse.id,
      );
      // ignore: use_build_context_synchronously
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => VisitTakeIdPhoto(
            data: formValues,
            visitorName: validateQrResponse.visitor?.name ?? "",
            servicePointObject: servicePointObject,
          ),
        ),
      );
    } else {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Timer(const Duration(seconds: 3), () {
            Navigator.of(context).pop();
          });
          return NvAlert(
            type: "error",
            content: validateQrResponse.message ?? "",
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var scanArea = (MediaQuery.of(context).size.width < 400 ||
            MediaQuery.of(context).size.height < 400)
        ? 150.0
        : 300.0;
    // To ensure the Scanner view is properly sizes after rotation
    // we need to listen for Flutter SizeChanged notification and update controller
    return QRView(
      key: GlobalKey(debugLabel: 'QR'),
      onQRViewCreated: _onQRViewCreated,
      overlay: QrScannerOverlayShape(
        borderColor: Colors.red,
        borderRadius: 10,
        borderLength: 30,
        borderWidth: 10,
        cutOutSize: scanArea,
      ),
      onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
    );
  }

  Barcode? result;
  QRViewController? controller;

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.resumeCamera();
    controller.scannedDataStream.listen((scanData) {
      HapticFeedback.vibrate();
      if (mounted) {
        setState(() {
          if (result == null) {
            result = scanData;
            validateQrData(result?.code ?? "");
          }
        });
      }
    });
    this.controller!.pauseCamera();
    this.controller!.resumeCamera();
  }

  @override
  void setState(fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  // In order to get hot reload to work we need to pause the camera if the platform
  // is android, or resume the camera if the platform is iOS.
  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller!.pauseCamera();
    }
    controller!.resumeCamera();
  }

  void _onPermissionSet(BuildContext context, QRViewController ctrl, bool p) {
    if (!p) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('no Permission')),
      );
    }
  }

  @override
  void dispose() {
    controller?.stopCamera();
    controller?.dispose();
    super.dispose();
  }
}
