import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/domain/models/settings/setting.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/visit_take_plate_photo.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitIdPhoto extends StatefulWidget {
  final String visitorName;
  final ServicePointObject? servicePointObject;
  final Map<String, dynamic> data;
  final String path;

  const VisitIdPhoto({
    Key? key,
    required this.visitorName,
    this.servicePointObject,
    required this.data,
    required this.path,
  }) : super(key: key);

  @override
  State<VisitIdPhoto> createState() => _VisitIdPhotoState();
}

class _VisitIdPhotoState extends State<VisitIdPhoto> {
  // ignore: prefer-correct-identifier-length
  List<DropdownMenuItem<String>> documentDropdownTypesList = [];
  final documentNumberTextController = TextEditingController();
  final documentTypeController = TextEditingController();

  goToPlatePhoto() {
    if (documentNumberTextController.text.isNotEmpty) {
      widget.data["visitor"]["documentNumber"] =
          documentNumberTextController.text;
    } else {
      widget.data["visitor"]["documentNumber"] = null;
    }
    if (documentTypeController.text.isNotEmpty) {
      widget.data["visitor"]['idDocumentType'] = documentTypeController.text;
    } else {
      widget.data["visitor"]['idDocumentType'] = null;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitTakePlatePhoto(
          visitorName: widget.visitorName,
          servicePointObject: widget.servicePointObject,
          data: widget.data,
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    getDocumentTypes();
  }

  getDocumentTypes() {
    var documentTypeList =
        jsonDecode(AppUrls().getProperty('core.list.documentType'));
    documentTypeList.forEach((element) {
      var settingObj = Setting.fromJson(element);
      documentDropdownTypesList.add(DropdownMenuItem(
        value: settingObj.id.toString(),
        child: Text(settingObj.name ?? ''),
      ));
    });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    final colors = AppThemeScope.of(context).colors;

    const double textMd = 16.0;
    const double textLg = 26.0;

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            margin: const EdgeInsets.only(
              bottom: 16.0,
              top: 37.0,
              left: 16.0,
              right: 16.0,
            ),
            child: Column(children: [
              NvText(
                textHolder: copy('visitors.fill-the-corresponding-data'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.w600,
                fontSize: textLg,
                color: colors.text.primary,
              ),
              Image.file(
                File(widget.path),
                height: 161,
                width: double.infinity,
              ),
              Container(
                margin: const EdgeInsets.only(top: 26.0, bottom: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    NvText(
                      textHolder: copy('common.document-type-required'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w500,
                      fontSize: textMd,
                      color: colors.text.primary,
                    ),
                    const SizedBox(
                      height: 8.0,
                    ),
                    DropdownButtonFormField(
                      // ignore: prefer-extracting-callbacks
                      validator: (value) {
                        if (value == null) {
                          return copy('visitors.validator-required');
                          // 'Obligatorio';
                        }
                        return null;
                      },

                      isDense: true,
                      decoration: InputDecoration(
                        hintText: copy('common.select-option'),
                        hintStyle: TextStyle(
                          color: colors.text.placeholders,
                          fontWeight: FontWeight.w300,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 5,
                        ),
                      ),
                      menuMaxHeight: MediaQuery.of(context).size.height *
                          Constants.thirtyPercent,
                      isExpanded: true,
                      items: documentDropdownTypesList,
                      onChanged: (value) {
                        documentTypeController.text = value.toString();
                        setState(() {});
                      },
                    ),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(bottom: 8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    NvText(
                      textHolder: copy('common.document-number'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w500,
                      fontSize: textMd,
                      color: colors.text.primary,
                    ),
                    const SizedBox(
                      height: 8.0,
                    ),
                    TextField(
                      keyboardType: TextInputType.name,
                      maxLines: 1,
                      controller: documentNumberTextController,
                      decoration: InputDecoration(
                        hintText: '0123456789',
                        hintStyle: TextStyle(
                          color: colors.text.placeholders,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      onChanged: (value) {
                        setState(() {});
                      },
                    ),
                  ],
                ),
              ),
            ]),
          ),
          Container(
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  width: 1.0,
                  color: colors.primary.black.v1,
                ),
              ),
            ),
            padding: const EdgeInsets.only(bottom: 16.0),
            child: BottomButton(
              buttonText: copy('visitors.next'),
              disabled: documentNumberTextController.text.isEmpty ||
                  documentTypeController.text.isEmpty,
              action: goToPlatePhoto,
            ),
          ),
        ]),
      ),
    );
  }
}
