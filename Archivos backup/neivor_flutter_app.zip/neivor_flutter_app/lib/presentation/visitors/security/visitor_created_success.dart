import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';

import '../../../theme/app_theme_scope.dart';
import '../../../widgets/nv_appbar.dart';
import '../../../widgets/nv_button.dart';
import '../../../widgets/nv_image.dart';
import '../../../widgets/nv_text.dart';

class VisitorCreatedSuccess extends StatelessWidget {
  final String visitorName;

  const VisitorCreatedSuccess({Key? key, required this.visitorName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    const double textMd = 16.0;
    const double textLg = 26.0;

    backToHome() {
      Navigator.of(context)
          .pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
    }

    return Scaffold(
      appBar: NvAppBar(
        backAction: () {
          backToHome();
        },
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            margin: const EdgeInsets.only(
              top: 37,
              left: 16,
              right: 16.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                NvText(
                  // "Nuevo visitante",
                  textHolder: AppMessages().getCopy('visitors.new-visit'),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.w600,
                  fontSize: textLg,
                  color: colors.text.primary,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 66.0,
                      ),
                      const NvImage(
                        imageUrl: 'ds/icons/walking.png',
                      ),
                      const SizedBox(
                        height: 16.0,
                      ),
                      NvText(
                        textHolder: AppMessages()
                            .getCopy('visitors.welcome', [visitorName]),
                        //"¡Bienvenido, $visitorName!",
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w600,
                        fontSize: 22,
                        color: colors.text.primary,
                      ),
                      const SizedBox(
                        height: 8.0,
                      ),
                      NvText(
                        // "Ya puedes ingresar al condominio.",
                        textHolder: AppMessages()
                            .getCopy('page.visit.label.visit.income.tower'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w300,
                        fontSize: textMd,
                        color: colors.text.primary,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Container(
                margin: const EdgeInsets.only(
                  top: 24,
                ),
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(
                      color: colors.primary.black.v1,
                      width: 1,
                    ),
                  ),
                ),
                child: NvButton(
                  //"Listo",
                  label: AppMessages().getCopy('common.ready'),
                  action: () {
                    backToHome();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
