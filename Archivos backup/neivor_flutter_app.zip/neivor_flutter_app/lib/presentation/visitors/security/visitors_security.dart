import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

class VisitorsSecurity extends StatefulWidget {
  const VisitorsSecurity({
    Key? key,
  }) : super(key: key);

  @override
  State<VisitorsSecurity> createState() => _Visitors();
}

class _Visitors extends State<VisitorsSecurity> {
  Function copy = AppMessages().getCopy;
  @override
  void initState() {
    super.initState();
  }

  goToQrScanner() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setBool("isQrFlow", true);
    // ignore: use_build_context_synchronously
    Navigator.pushNamed(context, 'visitorsScanner');
  }

  goToManualRegistration() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setBool("isQrFlow", false);
    // ignore: use_build_context_synchronously
    Navigator.pushNamed(context, 'visitorNameAndSp');
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(children: [
          Row(children: [
            Padding(
              padding: const EdgeInsets.only(top: 30, left: 30),
              child: SizedBox(
                width: MediaQuery.of(context).size.width * 0.9,
                child: NvText(
                  textHolder: copy('visitors.how-register-visit'),
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.w600,
                  fontSize: 26,
                  color: colors.text.primary,
                ),
              ),
            ),
          ]),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 90),
                child: Image.asset(
                  'assets/images/key.png',
                  height: 143,
                  width: 150,
                ),
              ),
            ],
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 10, right: 16, left: 16),
                    child: Container(
                      decoration: const BoxDecoration(
                        border: Border.fromBorderSide(
                          BorderSide(color: AppTheme.grayBorder),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(8)),
                      ),
                      child: ListTile(
                        leading: Image.asset('assets/images/with_qr.png'),
                        title: Text(
                          // ignore: format-comment
                          //"Con código QR",
                          copy('visitors.with-qr-code'),
                        ),
                        trailing: Image.asset("assets/images/chevron.png"),
                        onTap: goToQrScanner,
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      top: 8,
                      right: 16,
                      left: 16,
                      bottom: 16,
                    ),
                    child: Container(
                      decoration: const BoxDecoration(
                        border: Border.fromBorderSide(
                          BorderSide(color: AppTheme.grayBorder),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(8)),
                      ),
                      child: ListTile(
                        leading: Image.asset('assets/images/wo_qr.png'),
                        title: Text(
                          //"Sin código QR",
                          copy('visitors.without-qr-code'),
                        ),
                        trailing: Image.asset("assets/images/chevron.png"),
                        onTap: goToManualRegistration,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
