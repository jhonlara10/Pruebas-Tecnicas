import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/row_service_point.dart';
import 'package:neivor_flutter_app/presentation/visitors/security/edit_visit_data.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitorNameAndSp extends StatefulWidget {
  const VisitorNameAndSp({
    Key? key,
  }) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  VisitorNameAndSpState createState() => VisitorNameAndSpState();
}

class VisitorNameAndSpState extends State<VisitorNameAndSp> {
  Function copy = AppMessages().getCopy;
  TextEditingController nameTextEditingController = TextEditingController();
  TextEditingController servicePointEditingController = TextEditingController();
  List<ServicePointObject>? filterList;
  ServicePointObject? selectedServicePoint = null;
  var inSearch = false;
  var packagesRepository = PackageRepository();

  // ignore: long-method
  goToConfirmation() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => EditVisitData(
          // ignore: prefer_const_literals_to_create_immutables
          data: {},
          visitorName: nameTextEditingController.text,
          servicePointObject: selectedServicePoint,
        ),
      ),
    );
  }

  servicePointClicked(ServicePointObject servicePointObj) {
    selectedServicePoint = servicePointObj;
    setState(() {
      servicePointEditingController.text =
          "${servicePointObj.operationZone?.name ?? ""} - ${servicePointObj.name ?? ""}";
      filterList = [];
    });
  }

  // ignore: long-method
  findServicePointByName(String name) async {
    context.loaderOverlay.show();
    filterList = await PackageRepository().getServicePointListByName(name);
    setState(() {});
    context.loaderOverlay.hide();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'visitorsSecurity',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'visitorsSecurity',
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Row(children: [
                Padding(
                  padding: const EdgeInsets.only(top: 30, left: 15),
                  child: NvText(
                    //"Datos de la visita",
                    textHolder: copy('visitors.visit-data'),
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.w600,
                    fontSize: 25,
                    color: colors.text.primary,
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 15, top: 20, bottom: 8),
                    child: RichText(
                      text: TextSpan(
                        text: '*  ',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: colors.primary.coral.main,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            text: copy("user-access.fullname"),
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.text.primary,
                              fontFamily: 'Jost',
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 15, bottom: 30, right: 15),
                    child: TextField(
                      keyboardType: TextInputType.name,
                      maxLines: 1,
                      controller: nameTextEditingController,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.only(
                          left: 16,
                          top: 12,
                          bottom: 12,
                        ),
                        hintText: 'Ej: juan lizcano',
                        hintStyle: TextStyle(
                          color: colors.text.placeholders,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: RichText(
                      text: TextSpan(
                        text: '*  ',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: colors.primary.coral.main,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            text: copy('packages.search-apartment'),
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: colors.text.primary,
                              fontFamily: 'Jost',
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(top: 10, left: 15, right: 15),
                    child: TextFormField(
                      autofocus: false,
                      controller: servicePointEditingController,
                      // ignore: prefer-extracting-callbacks
                      onFieldSubmitted: (value) {
                        if (value != "") {
                          inSearch = true;
                          findServicePointByName(value);
                        } else {
                          setState(() {
                            filterList = [];
                            inSearch = false;
                          });
                        }
                      },
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: 'Ej. Torre1 -101',
                        hintStyle: TextStyle(
                          color: colors.text.secondary,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(),
                      itemCount: filterList?.length ?? 0,
                      itemBuilder: (context, index) {
                        return RowServicePoint(
                          servicePointClicked: servicePointClicked,
                          servicePointObj: filterList![index],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        bottomNavigationBar: SizedBox(
          //width: MediaQuery.of(context).size.width,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: BottomButton(
              //"Siguiente",
              buttonText: copy('visitors.next'),
              action: goToConfirmation,
              disabled: selectedServicePoint == null ||
                  nameTextEditingController.text.isEmpty,
            ),
          ),
        ),
      ),
    );
  }
}
