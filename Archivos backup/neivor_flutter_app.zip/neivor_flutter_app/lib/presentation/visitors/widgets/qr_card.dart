import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class QRCard extends StatelessWidget {
  final CreateVisitResponse? response;
  final String? userVisit;
  final String? visitDate;
  final int? idVisitPeriod;
  final String? servicePointInfo;
  final String? phone;
  final String? initDate;
  final String? lastDate;

  const QRCard({
    Key? key,
    this.idVisitPeriod,
    this.response,
    this.userVisit,
    this.visitDate,
    this.servicePointInfo,
    this.phone,
    this.initDate,
    this.lastDate,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Card(
          elevation: 10.0,
          child: Column(children: [
            Container(
              width: double.infinity,
              height: 90,
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [
                  AppTheme.coral0Main,
                  AppTheme.colar1Main,
                ]),
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(10),
                  topLeft: Radius.circular(10),
                ),
              ),
              child: Column(children: [
                Align(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: SizedBox(
                      child: Container(
                        height: 10,
                        width: 85,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  child: Image.asset(
                    "assets/images/qr_card_header.png",
                    width: 100,
                    height: 50,
                  ),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 8),
              child: Text(
                userVisit ?? "",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'Jost',
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            QrImage(
              data: response?.textQr ?? "",
              gapless: false,
              version: QrVersions.auto,
              backgroundColor: Colors.white,
              size: 180,
            ),
            if (idVisitPeriod == 2)
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(right: 5),
                          child: Icon(Icons.date_range,
                              color: AppTheme.black0Main),
                        ),
                        Text(
                          "Inicia: ${initDate ?? ""}",
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontFamily: 'Jost'),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(right: 5),
                          child: Icon(Icons.date_range,
                              color: AppTheme.black0Main),
                        ),
                        Text(
                          "Finaliza: ${lastDate ?? ""}",
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontFamily: 'Jost'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            if (idVisitPeriod == 1 || idVisitPeriod == null)
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(right: 5),
                      child: Icon(Icons.date_range, color: AppTheme.black0Main),
                    ),
                    Text(
                      visitDate ?? "",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontFamily: 'Jost'),
                    ),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.only(top: 7),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(right: 5),
                    child: Icon(Icons.phone_iphone, color: AppTheme.black0Main),
                  ),
                  Text(
                    phone ?? "",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontFamily: 'Jost'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 7, bottom: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(right: 5),
                    child: Icon(Icons.apartment, color: AppTheme.black0Main),
                  ),
                  Text(
                    servicePointInfo ?? "",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontFamily: 'Jost'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Text(
                //"¿Quieres saber más sobre Neivor?",
                AppMessages().getCopy('visitors.qr-know-more'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontFamily: 'Jost'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 5, bottom: 10),
              child: GestureDetector(
                onTap: () {
                  // ignore: deprecated_member_use
                  launch(Constants.neivorWebPage);
                },
                child: const Text(
                  Constants.neivorWebPageWithouCertificate,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppTheme.coral0Main,
                    fontFamily: 'Jost',
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
