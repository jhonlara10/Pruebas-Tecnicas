import 'package:favorite_button/favorite_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';
import 'package:flutter_svg/svg.dart';
import 'package:neivor_flutter_app/themes/themes.dart';

class RowContact extends StatefulWidget {
  final Contact contact;
  final Function markContactAsSelected;
  final Function markAsFavorite;

  const RowContact({
    Key? key,
    required this.contact,
    required this.markContactAsSelected,
    required this.markAsFavorite,
  }) : super(key: key);

  @override
  State<RowContact> createState() => _RowContactState();
}

class _RowContactState extends State<RowContact> {
  /// Handle state color of CheckBox.
  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return AppTheme.turquoiseGreen;
    }
    return AppTheme.turquoiseGreen;
  }

  /// Flag to check or not the row checkbox of ListTile.
  var isChecked = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      // ignore: prefer-extracting-callbacks
      onTap: () {
        setState(() {
          isChecked = true;
        });
        widget.markContactAsSelected(widget.contact);
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          elevation: 5,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: Wrap(
                spacing: 4,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: StarButton(
                      valueChanged: (_isStarred) {
                        widget.markAsFavorite(_isStarred, widget.contact);
                      },
                      iconSize: 45,
                      iconColor: AppTheme.warningColor,
                    ),
                  ),
                  SvgPicture.asset(
                    "assets/images/avatar.svg",
                    height: 40,
                    width: 40,
                  ),
                ],
              ),
              title: Padding(
                padding: const EdgeInsets.only(top: 8.0, left: 2.0, right: 2.0),
                child: Text(
                  widget.contact.displayName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 2, left: 2, right: 2),
                child: Text(
                  widget.contact.phones.first.number,
                  maxLines: 1,
                  style: const TextStyle(
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.normal,
                    color: Colors.grey,
                  ),
                ),
              ),
              trailing: Checkbox(
                checkColor: Colors.white,
                fillColor: MaterialStateProperty.resolveWith(getColor),
                value: isChecked,
                // ignore: prefer-extracting-callbacks
                onChanged: (bool? value) {
                  setState(() {
                    if (value == true) {
                      widget.markContactAsSelected(widget.contact);
                    }
                    //ignore: avoid-non-null-assertion
                    isChecked = value!;
                  });
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
