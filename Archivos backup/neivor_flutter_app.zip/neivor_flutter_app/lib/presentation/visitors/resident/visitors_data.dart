import 'package:accordion/accordion.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/contact.dart';
import 'package:intl/intl.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/domain/models/visitors/favorite.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_add_manual.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_confirm_data.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';

class VisitorsData extends StatefulWidget {
  final Contact? contact;
  final bool? isFavorite;

  const VisitorsData({
    Key? key,
    required this.contact,
    required this.isFavorite,
  }) : super(key: key);

  @override
  State<VisitorsData> createState() => _VisitorsData();
}

class _VisitorsData extends State<VisitorsData> {
  Function copy = AppMessages().getCopy;
  Map<String, dynamic> formValues = {};
  TextEditingController dateinput = TextEditingController();
  TextEditingController fromDateInput = TextEditingController();
  TextEditingController toDateInput = TextEditingController();
  List<Favorite> favoritesList = [];
  var defaultSelectionValue = 1;
  var selectedValue = "1";
  var isAdvancedOptionsCliced = false;
  var isManyDaysVisit = false;
  DateTime? initDateSelected = DateTime.now();

  TextStyle advancedOptionsStyle = const TextStyle(
    color: AppTheme.greenArlequin4,
    fontWeight: FontWeight.w500,
    fontFamily: 'Jost',
    fontSize: 16,
  );
  final visitCategories = Constants().visitCategory;

  @override
  // ignore: long-method
  void initState() {
    getFavoriteContactList();
    super.initState();
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      dateinput.text = "";
      setState(() {});
      formValues = {
        'idServicePoint': UserUtils.currentServicePoint?.id,
        'nameEnterprise': UserUtils.currentEnterprise?.name,
        'idEnterprise': UserUtils.currentEnterprise?.id,
        'userName': UserUtils.currentUser?.name,
        'email': UserUtils.currentUser?.email,
        'idZyosUser': UserUtils.currentUser?.id,
        'userCreation': UserUtils.currentUser?.id,
        'visitor': {
          'name': widget.contact?.displayName ?? "",
          'mobilePhone': widget.contact?.phones.first.number,
          'favorite': widget.isFavorite == true ? "S" : "N",
        },
        'eventName': "",
        'idVisitPeriod': defaultSelectionValue,
        'idVisitCategory': defaultSelectionValue,
        'idVisitType': defaultSelectionValue,
        'visitDateAsString': "",
        'initDateAsString': "",
        'lastDateAsString': "",
      };
    });
  }

  // ignore: long-method
  String isFavoriteInApiList() {
    var isFavorite = '';
    for (var element in favoritesList) {
      // ignore: unrelated_type_equality_checks
      if (element.name == widget.contact?.displayName) {
        isFavorite = 'S';
        break;
      } else {
        isFavorite = 'N';
      }
    }
    return isFavorite;
  }

  getFavoriteContactList() async {
    favoritesList = await VisitorsRepository().obtainFavorites();
  }

  // ignore: long-method
  goToConfirmation() {
    if (!isManyDaysVisit) {
      formValues['initDateAsString'] = "";
      formValues['lastDateAsString'] = "";
      formValues['idVisitPeriod'] = Constants.singleDayVisit;
    } else {
      formValues['visitDateAsString'] = "";
      formValues['idVisitPeriod'] = Constants.manyDaysVisit;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => widget.contact != null
            ? VisitorsConfirmData(
                request: CreateVisitRequest.fromJson(formValues),
                isFavorite: isFavoriteInApiList(),
              )
            : VisitorsAddManual(
                request: CreateVisitRequest.fromJson(formValues),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO review this.
      ),
      body: Column(children: [
        Row(children: [
          Padding(
            padding: const EdgeInsets.only(top: 15, left: 15),
            child: NvText(
              //"Datos de la visita",
              textHolder: copy('visitors.visit-data'),
              fontFamily: 'Jost',
              fontWeight: FontWeight.w600,
              fontSize: 26,
              color: colors.text.primary,
              textAlign: TextAlign.center,
            ),
          ),
        ]),
        Row(children: [
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 15),
            child: NvText(
              //"Visita de varios días",
              textHolder: copy('visitors.range-day-visits'),
              fontFamily: 'Jost',
              fontWeight: FontWeight.w500,
              fontSize: 16,
              color: colors.text.primary,
            ),
          ),
          const Spacer(),
          Align(
            alignment: Alignment.topRight,
            child: Padding(
              padding: const EdgeInsets.only(top: 10, left: 15),
              child: Switch(
                activeColor: colors.primary.arcticGray.v1,
                activeTrackColor: colors.primary.turquoise.v4,
                value: isManyDaysVisit,
                onChanged: (bool value) {
                  setState(() {
                    isManyDaysVisit = value;
                  });
                },
              ),
            ),
          ),
        ]),
        if (isManyDaysVisit)
          Row(mainAxisSize: MainAxisSize.min, children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: RichText(
                        text: TextSpan(
                          text: '*  ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: colors.primary.coral.main,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: copy('visitors.from'),
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.text.primary,
                                fontFamily: 'Jost',
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    TextField(
                      maxLines: 1,
                      controller: toDateInput,
                      decoration: InputDecoration(
                        hintText: 'yyyy/mm/dd',
                        hintStyle: TextStyle(
                          color: colors.text.placeholders,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      readOnly:
                          true, // Set it true, so that user will not able to edit text.
                      // ignore: prefer-extracting-callbacks
                      onTap: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate:
                              DateTime.now().subtract(const Duration(days: 0)),
                          lastDate: DateTime(2101),
                        );
                        initDateSelected = pickedDate;
                        if (pickedDate != null) {
                          String formattedDate =
                              DateFormat('yyyy/MM/dd').format(pickedDate);

                          formValues['initDateAsString'] =
                              DateFormat('yyyy-MM-dd').format(pickedDate);
                          setState(() {
                            toDateInput.text =
                                formattedDate; // Set output date to TextField value.
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 15.0,
                  right: 15.0,
                  top: 8.0,
                  bottom: 10.0,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: RichText(
                        text: TextSpan(
                          text: '*  ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: colors.primary.coral.main,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: copy('visitors.to'),
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.text.primary,
                                fontFamily: 'Jost',
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    TextField(
                      maxLines: 1,
                      controller: fromDateInput,
                      decoration: InputDecoration(
                        hintText: 'yyyy/mm/dd',
                        hintStyle: TextStyle(
                          color: colors.text.placeholders,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      readOnly:
                          true, // Set it true, so that user will not able to edit text.
                      // ignore: prefer-extracting-callbacks
                      onTap: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate:
                              initDateSelected!.add(const Duration(days: 1)),
                          firstDate:
                              initDateSelected!.add(const Duration(days: 1)),
                          lastDate: DateTime(2101),
                        );

                        if (pickedDate != null) {
                          String formattedDate =
                              DateFormat('yyyy/MM/dd').format(pickedDate);

                          formValues['lastDateAsString'] =
                              DateFormat('yyyy-MM-dd').format(pickedDate);

                          setState(() {
                            fromDateInput.text =
                                formattedDate; // Set output date to TextField value.
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ]),
        if (!isManyDaysVisit)
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(
                left: 15,
                bottom: 10,
                right: 20,
                top: 16,
              ),
              child: RichText(
                text: TextSpan(
                  text: '*  ',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: colors.primary.coral.main,
                  ),
                  children: <TextSpan>[
                    TextSpan(
                      text: copy('visitors.visit-day'),
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: colors.text.primary,
                        fontFamily: 'Jost',
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        if (!isManyDaysVisit)
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 15, bottom: 5, right: 15),
              child: TextField(
                maxLines: 1,
                controller: dateinput,
                decoration: InputDecoration(
                  hintText: 'yyyy/mm/dd',
                  hintStyle: TextStyle(
                    color: colors.text.placeholders,
                    fontWeight: FontWeight.w300,
                  ),
                ),
                readOnly:
                    true, // Set it true, so that user will not able to edit text.
                // ignore: prefer-extracting-callbacks
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now().subtract(const Duration(days: 0)),
                    lastDate: DateTime(2101),
                  );

                  if (pickedDate != null) {
                    String formattedDate =
                        DateFormat('yyyy/MM/dd').format(pickedDate);
                    formValues['visitDateAsString'] =
                        DateFormat('yyyy-MM-dd').format(pickedDate);
                    setState(() {
                      dateinput.text =
                          formattedDate; // Set output date to TextField value.
                    });
                  }
                },
              ),
            ),
          ),
        Padding(
          padding:
              const EdgeInsets.only(top: 2, bottom: 10, left: 16, right: 16),
          child: Accordion(
            openAndCloseAnimation: false,
            disableScrolling: true,
            paddingListHorizontal: 0,
            headerPadding: const EdgeInsets.only(bottom: 10),
            children: [
              AccordionSection(
                contentVerticalPadding: 0,
                contentHorizontalPadding: 0,
                rightIcon: const Icon(
                  Icons.keyboard_arrow_down_outlined,
                  color: AppTheme.greenArlequin4,
                ),
                flipRightIconIfOpen: true,
                isOpen: false,
                headerBackgroundColor: Colors.transparent,
                contentBorderColor: Colors.transparent,
                header: Text(
                  //'Opciones avanzadas',
                  copy('visitors.advanced-options'),
                  style: advancedOptionsStyle,
                ),
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 2, bottom: 10),
                      child: Text(
                        //"Tipo de visita",
                        copy('visitors.visit-type'),
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: colors.text.primary,
                          fontFamily: 'Jost',
                          fontSize: 16,
                        ),
                      ),
                    ),
                    DropdownButtonFormField(
                      // ignore: prefer-extracting-callbacks
                      validator: (value) {
                        if (value == null) {
                          //'Obligatorio';
                          return copy('visitors.validator-required');
                        }
                        return null;
                      },
                      isDense: true,
                      decoration: InputDecoration(
                        hintText: copy('common.select-option'),
                        //'Selecciona una opción',
                        hintStyle: TextStyle(
                          color: colors.text.placeholders,
                          fontWeight: FontWeight.w300,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 8,
                          horizontal: 5,
                        ),
                      ),
                      menuMaxHeight: MediaQuery.of(context).size.height *
                          Constants.thirtyPercent,
                      isExpanded: true,
                      items: visitCategories,
                      onChanged: (value) {
                        formValues['idVisitType'] = int.parse(value.toString());
                        formValues['idVisitCategory'] =
                            int.parse(value.toString());
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Align(
            alignment: FractionalOffset.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: BottomButton(
                buttonText: copy('visitors.next'),
                action: goToConfirmation,
                disabled: !isManyDaysVisit
                    ? (dateinput.text.isEmpty)
                    : (fromDateInput.text.isEmpty || toDateInput.text.isEmpty),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
