import 'package:country_code_picker/country_code_picker.dart';
import 'package:favorite_button/favorite_button.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_confirm_data.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/bottom_button.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitorsAddManual extends StatefulWidget {
  final CreateVisitRequest? request;

  const VisitorsAddManual({
    Key? key,
    required this.request,
  }) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _VisitorsAddManual createState() => _VisitorsAddManual();
}

class _VisitorsAddManual extends State<VisitorsAddManual> {
  Function copy = AppMessages().getCopy;
  String? countryCode;
  TextEditingController phoneTextEditingController = TextEditingController();
  TextEditingController nameTextEditingController = TextEditingController();

  goToConfirmation() {
    widget.request?.visitor?.name = nameTextEditingController.text;
    widget.request?.visitor?.mobilePhone =
        (countryCode ?? "") + phoneTextEditingController.text;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitorsConfirmData(
          request: widget.request,
          isFavorite: widget.request?.visitor?.favorite,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO review this.
      ),
      body: CustomScrollView(
        slivers: [
          SliverFillRemaining(
            hasScrollBody: false,
            child: Column(
              children: [
                Row(children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 30, left: 15),
                    child: NvText(
                      //"Registrar visitante",
                      textHolder: copy('visitors.title-register-visit'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w600,
                      fontSize: 26,
                      color: colors.text.primary,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ]),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 15, top: 20, bottom: 15),
                      child: RichText(
                        text: TextSpan(
                          text: '* ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: colors.primary.coral.main,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: copy("user-access.fullname"),
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.text.primary,
                                fontFamily: 'Jost',
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 15,
                        bottom: 15,
                        right: 20,
                      ),
                      child: TextField(
                        keyboardType: TextInputType.name,
                        maxLines: 1,
                        controller: nameTextEditingController,
                        decoration: InputDecoration(
                          hintText: 'Ej: juan lizcano',
                          hintStyle: TextStyle(
                            color: colors.text.placeholders,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {});
                        },
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 15, top: 5, bottom: 5),
                      child: RichText(
                        text: TextSpan(
                          text: '* ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: colors.primary.coral.main,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: copy("profile.cellphone"),
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: colors.text.primary,
                                fontFamily: 'Jost',
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        CountryCodePicker(
                          onInit: (value) {
                            countryCode = value?.dialCode;
                          },
                          onChanged: (value) {
                            countryCode = value.dialCode;
                          },
                          countryFilter: const [
                            'CO',
                            'MX',
                            'US',
                            'EC',
                            'BO',
                          ],
                          initialSelection: 'CO',
                          showCountryOnly: false,
                          showOnlyCountryWhenClosed: false,
                          alignLeft: false,
                          showDropDownButton: true,
                          enabled: true,
                          hideSearch: true,
                          dialogSize: Size(
                            (MediaQuery.of(context).size.width *
                                Constants.eightyPercent),
                            //ignore: no-equal-arguments
                            (MediaQuery.of(context).size.width *
                                Constants.eightyPercent),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: TextField(
                              keyboardType: TextInputType.number,
                              maxLines: 1,
                              maxLength: 10,
                              controller: phoneTextEditingController,
                              decoration: InputDecoration(
                                hintText: '1234567890',
                                hintStyle: TextStyle(
                                  color: colors.text.placeholders,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                              onChanged: (value) {
                                setState(() {});
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: StarButton(
                            iconSize: 40,
                            iconColor: AppTheme.warningColor,
                            valueChanged: (isStarred) {
                              widget.request?.visitor?.favorite =
                                  isStarred ? "S" : "N";
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 5,
                            right: 12,
                          ),
                          child: NvText(
                            // "Agregar a favoritos",
                            textHolder: copy('visitors.add-to-favorite'),
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            color: colors.text.primary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Expanded(
                  child: Align(
                    alignment: FractionalOffset.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: BottomButton(
                        buttonText: copy('visitors.next'),
                        disabled: nameTextEditingController.text.isEmpty ||
                            phoneTextEditingController.text.length != 10,
                        action: goToConfirmation,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
