import 'package:favorite_button/favorite_button.dart';
import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_qr.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';

class VisitorsConfirmData extends StatefulWidget {
  final CreateVisitRequest? request;
  final String? isFavorite;

  const VisitorsConfirmData({
    Key? key,
    required this.request,
    required this.isFavorite,
  }) : super(key: key);

  @override
  State<VisitorsConfirmData> createState() => _VisitorsConfirmData();
}

class _VisitorsConfirmData extends State<VisitorsConfirmData> {
  final singleDayVisit = 1;
  final multipleDayVisit = 2;
  bool? markAsFavorite;
  Function copy = AppMessages().getCopy;
  final visitCategoryDropdownList = Constants().visitCategory;
  Widget typeOfVisit = const Text('');

  @override
  void initState() {
    getCategoryValue();
    setState(() {});
    super.initState();
  }

  // ignore: long-method
  createVisit() async {
    context.loaderOverlay.show();
    var createVisitRequest = widget.request;
    if (markAsFavorite != null) {
      createVisitRequest?.visitor?.favorite =
          markAsFavorite == true ? "S" : "N";
    }
    var createVisitResponse =
        await VisitorsRepository().createVisit(createVisitRequest);
    context.loaderOverlay.hide();
    if (createVisitResponse.sucessRequestVisit == true) {
      // ignore: use_build_context_synchronously
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => VisitorsQr(
            response: createVisitResponse,
            userVisit: widget.request?.visitor?.name,
            visitDate: widget.request?.idVisitPeriod == multipleDayVisit
                ? "${GlobalUtils().getCorrectDate(
                    widget.request?.initDateAsString,
                  )} - ${GlobalUtils().getCorrectDate(
                    widget.request?.lastDateAsString,
                  )}"
                : GlobalUtils().getCorrectDate(
                    widget.request?.visitDateAsString,
                  ),
            servicePointInfo:
                "${UserUtils.currentServicePoint?.operationZone?.name ?? ""} - ${UserUtils.currentServicePoint?.name ?? ""}",
            phone: widget.request?.visitor?.mobilePhone,
          ),
        ),
      );
    } else {
      showError(createVisitResponse.message);
    }
  }

  /// Show default error on native [AlertDialog] alert
  ///
  /// Param:
  /// [String] message to show on [AlertDialog]
  ///
  // ignore: long-method
  showError(String? message) {
    Widget okButton = TextButton(
      child: Text(AppMessages().getCopy('common.accept')), //"Aceptar"
      onPressed: () {
        Navigator.pop(context, false);
      },
    );

    // Set up the AlertDialog.
    AlertDialog alert = AlertDialog(
      title: const Text("Error"),
      content: Text(message ?? ""),
      actions: [
        okButton,
      ],
    );

    // Show the dialog.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  //gets category of visitorType
  getCategoryValue() {
    var idVisitCategory = widget.request?.idVisitCategory;
    for (var element in visitCategoryDropdownList) {
      element.value == idVisitCategory.toString()
          ? typeOfVisit = element.child
          : null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO review this.
      ),
      body: Column(children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 30, left: 15),
              child: NvText(
                //"Datos de la visita",
                textHolder: copy('visitors.visit-data'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.w600,
                fontSize: 26,
                color: colors.text.primary,
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.only(
                top: 12,
                left: 16,
                right: 16,
              ),
              child: NvText(
                //"Revisa que los datos de tus visitas y del evento esten correctos.",
                copy: 'visitors.check-data-visitors',
                fontFamily: 'Jost',
                fontWeight: FontWeight.w400,
                fontSize: 14,
                color: colors.text.secondary,
                textAlign: TextAlign.start,
              ),
            ),
          ],
        ),
        Container(
          margin: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border.all(
              color: colors.primary.black.v1,
              width: 1.0,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(6.0)),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.only(top: 10, left: 15, right: 15),
                    child: NvText(
                      //"Evento",
                      textHolder: copy('visitors.event'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: colors.text.primary,
                    ),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding:
                            const EdgeInsets.only(top: 10, left: 15, right: 15),
                        child: NvText(
                          //"Editar",
                          textHolder: copy('page.core.labelEdit'),
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: AppTheme.turquoiseLink,
                          textDecoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              if (widget.request?.idVisitPeriod == singleDayVisit)
                Row(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 10, left: 15, right: 15),
                      child: NvText(
                        //"Día de la visita",
                        textHolder: copy('visitors.visit-day'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                        color: colors.text.secondary,
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding:
                            const EdgeInsets.only(top: 10, left: 15, right: 15),
                        child: NvText(
                          textHolder: GlobalUtils().getCorrectDate(
                            widget.request?.visitDateAsString,
                          ),
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: colors.text.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              if (widget.request?.idVisitPeriod == multipleDayVisit)
                Row(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 10, left: 15, right: 15),
                      child: NvText(
                        //"Fecha inicio",
                        textHolder: copy('page.poll.labelStartDate'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                        color: colors.text.secondary,
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding:
                            const EdgeInsets.only(top: 10, left: 15, right: 15),
                        child: NvText(
                          textHolder: GlobalUtils().getCorrectDate(
                            widget.request?.initDateAsString,
                          ),
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: colors.text.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              if (widget.request?.idVisitPeriod == multipleDayVisit)
                Row(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 10, left: 15, right: 15),
                      child: NvText(
                        //"Fecha fin",
                        textHolder: copy('page.poll.labelEndDate'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                        color: colors.text.secondary,
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding:
                            const EdgeInsets.only(top: 10, left: 15, right: 15),
                        child: NvText(
                          textHolder: GlobalUtils().getCorrectDate(
                            widget.request?.lastDateAsString,
                          ),
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: colors.text.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 10,
                      left: 15,
                      right: 15,
                      bottom: 15,
                    ),
                    child: NvText(
                      //"Tipo de visita",
                      textHolder: copy('visitors.visit-type'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.normal,
                      fontSize: 14,
                      color: colors.text.secondary,
                    ),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        top: 10,
                        left: 15,
                        right: 15,
                        bottom: 15,
                      ),
                      child: typeOfVisit,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Container(
          margin: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border.all(
              color: colors.primary.black.v1,
              width: 1.0,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(6.0)),
          ),
          child: Column(
            children: [
              Row(children: [
                Padding(
                  padding: const EdgeInsets.only(top: 10, left: 15, right: 15),
                  child: NvText(
                    //"Visitantes",
                    textHolder: copy('home.visitor'),
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    color: colors.text.primary,
                  ),
                ),
              ]),
              ListTile(
                leading: NvText(
                  textHolder: widget.request?.visitor?.name,
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.normal,
                  fontSize: 14,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  color: colors.text.secondary,
                ),
                trailing: Padding(
                  padding: const EdgeInsets.only(
                    bottom: 10,
                  ),
                  child: StarButton(
                    isStarred: widget.isFavorite == 'S',
                    iconSize: 45,
                    iconColor: AppTheme.warningColor,
                    // ignore: no_leading_underscores_for_local_identifiers
                    valueChanged: (_isStarred) {
                      setState(() {
                        markAsFavorite = _isStarred;
                      });
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Align(
            alignment: FractionalOffset.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: NvButton(
                label: copy('common.ready'),
                action: createVisit,
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
