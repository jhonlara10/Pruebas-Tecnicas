import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/visitors/list_visits_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_contact_list.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_data.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visits_historic.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';
import 'package:permission_handler/permission_handler.dart';

class Visitors extends StatefulWidget {
  const Visitors({
    Key? key,
    this.tabIndex,
  }) : super(key: key);

  final int? tabIndex;

  @override
  State<Visitors> createState() => _Visitors();
}

class _Visitors extends State<Visitors> {
  List<Contact>? contacts;
  Function copy = AppMessages().getCopy;
  bool viewLoader = true;

  @override
  void initState() {
    getVisits();
    super.initState();
  }

  setViewLoader() {
    setState(() {
      viewLoader = !viewLoader;
    });
  }

  getVisits() async {
    context.loaderOverlay.show();
    final ListVisitsResponse listVisits =
        await VisitorsRepository().listVisits();
    var visitsList = listVisits.data?.length ?? 0;
    setViewLoader();
    if (visitsList > 0) {
      // ignore: use_build_context_synchronously
      Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => VisitsHistoric(
            visits: listVisits,
            tabIndex: widget.tabIndex,
          ),
        ),
      );
    }
    context.loaderOverlay.hide();
  }

  /// Obtaining contact list from [FlutterContacts] plugin.
  // ignore: long-method
  getContacts() async {
    if (!mounted) return;
    context.loaderOverlay.show();
    // Requesting contacts permissions.
    if (await FlutterContacts.requestPermission()) {
      contacts = await FlutterContacts.getContacts(withProperties: true);
      context.loaderOverlay.hide();
      // ignore: use_build_context_synchronously
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => VisitorsContactList(
            contacts: contacts
                ?.where((element) => element.phones.isNotEmpty)
                .toList(),
          ),
        ),
      );
      // ignore: no-empty-block
    } else {
      context.loaderOverlay.hide();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const VisitorsData(
            contact: null,
            isFavorite: false,
          ),
        ),
      );
    }
  }

  cancelSynqContacts() {
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => const VisitorsData(
          contact: null,
          isFavorite: false,
        ),
      ),
    );
  }

  /// Show bottom sheet modal when user synq their contacts in Neivor.
  // ignore: long-method
  showSynqContactsBottomSheet() async {
    var isPermissionGranted = await Permission.contacts.isGranted;
    if (!isPermissionGranted) {
      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return NvBottomSheet(
            bottomSheetHeight: 300,
            iconRoute: "assets/images/synq.png",
            title: copy('visitors.sync-your-contacts'),
            subtitle: copy('visitors.allow-access-contacts'),
            primaryButtonText: copy('visitors.sync-up'),
            secondaryButtonText: copy('common.cancel'),
            primaryButtonVariant: "nv-bottom-sheet-primary",
            secondaryButtonVariant: "nv-bottom-sheet-secondary",
            primaryButtonAction: getContacts,
            secondaryButtonAction: cancelSynqContacts,
          );
        },
      );
    } else {
      getContacts();
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          "home",
          (route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            "home",
            (route) => false,
          ),
        ),
        body: Container(
          child: !viewLoader
              ? Column(children: [
                  Row(children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 30, left: 30),
                      child: NvText(
                        textHolder: copy('home.visitor'),
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                        color: Colors.black,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ]),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 120),
                        child: Image.asset(
                          'assets/images/empty_state_visitors.png',
                          height: 200,
                          width: 200,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: SizedBox(
                          width: 200,
                          child: NvText(
                            textHolder:
                                copy('visitors.main-no-active-visitors'),
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.normal,
                            fontSize: 20,
                            color: Colors.black,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Expanded(
                    child: Align(
                      alignment: FractionalOffset.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: NvButton(
                          label: copy('visitors.title-register-visit'),
                          action: showSynqContactsBottomSheet,
                        ),
                      ),
                    ),
                  ),
                ])
              : null,
        ),
      ),
    );
  }
}
