import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_data.dart';
import 'package:neivor_flutter_app/presentation/visitors/widgets/row_contact.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitorsContactList extends StatefulWidget {
  final List<Contact>? contacts;

  const VisitorsContactList({
    Key? key,
    required this.contacts,
  }) : super(key: key);

  @override
  State<VisitorsContactList> createState() => _VisitorsContactList();
}

class _VisitorsContactList extends State<VisitorsContactList> {
  final textEditingController = TextEditingController();
  List<Contact>? contactList = List<Contact>.empty(growable: true);
  Contact? contactSelected;
  bool isFavorite = false;
  Function copy = AppMessages().getCopy;

  @override
  void initState() {
    contactList?.addAll(widget.contacts!);
    super.initState();
  }

  goToContactSelection() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitorsData(
          contact: contactSelected,
          isFavorite: isFavorite,
        ),
      ),
    );
  }

  goToAddManualContact() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => const VisitorsData(
          contact: null,
          isFavorite: false,
        ),
      ),
    );
  }

  markAsFavorite(bool isStarred, Contact contact) {
    isFavorite = isStarred;
    contactSelected = contact;
    goToContactSelection();
  }

  markContactAsSelected(Contact contact) {
    contactSelected = contact;
    goToContactSelection();
  }

  /// Filtering result list by value introduced in searchbox.
  ///
  /// Param:
  /// [String] value, text input by user.
  ///
  /// Return:
  /// Refreshed state with filtered contact list.
  ///
  filterSearchResults(String value) {
    setState(() {
      var filteredList = widget.contacts
          ?.where((element) =>
              element.displayName.toLowerCase().contains(value.toLowerCase()))
          .toList();
      contactList?.clear();
      contactList = filteredList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NvAppBar(
        backAction: () => Navigator.pop(context), // TODO review this.
      ),
      body: Column(children: [
        Row(children: [
          Padding(
            padding: const EdgeInsets.only(top: 30, left: 20),
            child: NvText(
              //"Mis Contactos",
              textHolder: copy('visitors.my-contacts'),
              fontFamily: 'Jost',
              fontWeight: FontWeight.bold,
              fontSize: 25,
              color: Colors.black,
              textAlign: TextAlign.center,
            ),
          ),
        ]),
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
              child: TextField(
                onChanged: (value) => {filterSearchResults(value)},
                keyboardType: TextInputType.text,
                maxLines: 1,
                controller: textEditingController,
                decoration: InputDecoration(
                  // 'Buscar en tus contactos',
                  hintText: copy('visitors.search-my-contacts'),
                  prefixIcon: const Icon(Icons.search),
                ),
              ),
            ),
          ],
        ),
        Expanded(
          flex: 5,
          child: Padding(
            padding: const EdgeInsets.only(
              top: 10,
              left: 10,
              right: 10,
              bottom: 10,
            ),
            child: ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: contactList?.length ?? 0,
              itemBuilder: (context, index) {
                return RowContact(
                  contact: contactList![index],
                  markContactAsSelected: markContactAsSelected,
                  markAsFavorite: markAsFavorite,
                );
              },
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: ListTile(
            title: Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2, left: 2),
                    child: NvButton(
                      //"Nuevo Contacto",
                      label: copy('visitors.new-contact'),
                      action: goToAddManualContact,
                      textColor: Colors.black,
                      variant: "nv-bottom-sheet-secondary",
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2, left: 2),
                    child: NvButton(
                      //"Siguiente",
                      label: copy('visitors.next'),
                      action: goToContactSelection,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}
