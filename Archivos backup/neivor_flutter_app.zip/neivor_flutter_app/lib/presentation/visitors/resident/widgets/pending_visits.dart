import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/visitors/list_visits_response.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/widgets/visit_card.dart';

class PendingVisits extends StatefulWidget {
  const PendingVisits({
    Key? key,
    this.visits,
    this.tabIndex,
    required this.getQR,
  }) : super(key: key);

  final List<Visit>? visits;
  final Function getQR;
  final int? tabIndex;

  @override
  State<PendingVisits> createState() => _PendingVisitsState();
}

class _PendingVisitsState extends State<PendingVisits> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: widget.visits?.length ?? 0,
      itemBuilder: (context, index) => Container(
        padding: const EdgeInsets.only(left: 16, right: 16),
        child: Column(
          children: [
            VisitCard(
              visit: widget.visits![index],
              getQR: widget.getQR,
              tabIndex: widget.tabIndex,
            ),
          ],
        ),
      ),
    );
  }
}
