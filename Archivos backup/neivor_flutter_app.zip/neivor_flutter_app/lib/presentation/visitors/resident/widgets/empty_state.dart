import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({
    Key? key,
    this.title,
    this.subtitle,
  }) : super(key: key);

  final String? title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    return Column(
      children: [
        Image.asset(
          'assets/images/empty_state_visitors.png',
          height: 200,
          width: 200,
        ),
        NvText(
          textHolder: title,
          fontFamily: 'Jost',
          fontWeight: FontWeight.w500,
          fontSize: 22,
          color: colors.primary.black.main,
          textAlign: TextAlign.center,
        ),
        NvText(
          textHolder: subtitle,
          fontFamily: 'Jost',
          fontWeight: FontWeight.w300,
          fontSize: 16,
          color: colors.primary.black.main,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
