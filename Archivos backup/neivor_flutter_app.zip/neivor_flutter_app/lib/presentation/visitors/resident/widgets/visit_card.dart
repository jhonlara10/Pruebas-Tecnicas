import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/domain/models/visitors/list_visits_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/visit_data_qr.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class VisitCard extends StatelessWidget {
  const VisitCard({
    Key? key,
    this.tabIndex,
    required this.visit,
    required this.getQR,
  }) : super(key: key);

  final Visit visit;
  final int? tabIndex;
  final Function getQR;

  @override
  Widget build(BuildContext context) {
    const multipleDayVisit = 2;
    final copy = AppMessages().getCopy;
    final colors = AppThemeScope.of(context).colors;
    final String firstLetterName = visit.visitor?.name?[0].toUpperCase() ?? '';
    Jiffy? initDate = visit.initDate != null
        ? Jiffy.unixFromMillisecondsSinceEpoch(visit.initDate!)
        : null;
    Jiffy? lastDate = visit.lastDate != null
        ? Jiffy.unixFromMillisecondsSinceEpoch(visit.lastDate!)
        : null;
    Jiffy? visitDate = visit.visitDate != null
        ? Jiffy.unixFromMillisecondsSinceEpoch(visit.visitDate!)
        : null;
    Map<String, dynamic> visityDinamic = {
      "textQr": visit.generatedQR,
    };
    final Map<String, dynamic> visitDataToQr = {
      "response": visityDinamic,
      "userVisit": visit.visitor?.name,
      "idVisitPeriod": visit.idVisitPeriod,
      "visitDate": "${visitDate?.format(
        copy('common.full-date-format')
            .replaceAll('Do', 'do')
            .replaceAll('dddd', 'EEEE')
            .replaceAll('D', 'd')
            .replaceAll('YYYY', 'yyyy'),
      )}",
      "initDate": initDate?.format(
        copy('common.full-date-format')
            .replaceAll('Do', 'do')
            .replaceAll('dddd', 'EEEE')
            .replaceAll('D', 'd')
            .replaceAll('YYYY', 'yyyy'),
      ),
      "lastDate": lastDate?.format(
        copy('common.full-date-format')
            .replaceAll('Do', 'do')
            .replaceAll('dddd', 'EEEE')
            .replaceAll('D', 'd')
            .replaceAll('YYYY', 'yyyy'),
      ),
      "servicePointInfo":
          "${UserUtils.currentServicePoint?.operationZone?.name ?? ""} - ${UserUtils.currentServicePoint?.name ?? ""}",
      "phone": visit.visitor?.mobilePhone,
      "visitId": visit.visitor?.id,
    };
    VisitDataQr visitDataQr = VisitDataQr.fromJson(visitDataToQr);

    return GestureDetector(
      onTap: () {
        getQR(
          visitDataQr,
          tabIndex,
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          border:
              Border.fromBorderSide(BorderSide(color: colors.primary.black.v2)),
          borderRadius: const BorderRadius.all(Radius.circular(10.0)),
        ),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(
            children: [
              Container(
                height: 40,
                width: 40,
                margin: const EdgeInsets.only(right: 12),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: colors.primary.coral.main,
                  borderRadius: const BorderRadius.all(
                    Radius.circular(40),
                  ),
                ),
                child: NvText(
                  textHolder: firstLetterName,
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  color: colors.primary.arcticGray.v5,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  NvText(
                    textHolder: visit.visitor?.name,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    color: colors.text.primary,
                  ),
                  if (visit.idVisitPeriod == 2)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        NvText(
                          textHolder: "Inicia: ${initDate?.format(
                            copy('common.full-date-format')
                                .replaceAll('Do', 'do')
                                .replaceAll('dddd', 'EEEE')
                                .replaceAll('D', 'd')
                                .replaceAll('YYYY', 'yyyy'),
                          )}",
                          fontWeight: FontWeight.w300,
                          fontSize: 12,
                          color: colors.text.primary,
                        ),
                        NvText(
                          textHolder: "Finaliza: ${lastDate?.format(
                            copy('common.full-date-format')
                                .replaceAll('Do', 'do')
                                .replaceAll('dddd', 'EEEE')
                                .replaceAll('D', 'd')
                                .replaceAll('YYYY', 'yyyy'),
                          )}",
                          fontWeight: FontWeight.w300,
                          fontSize: 12,
                          color: colors.text.primary,
                        ),
                      ],
                    ),
                  if (visit.idVisitPeriod == 1)
                    NvText(
                      textHolder: "Fecha: ${visitDate?.format(
                        copy('common.full-date-format')
                            .replaceAll('Do', 'do')
                            .replaceAll('dddd', 'EEEE')
                            .replaceAll('D', 'd')
                            .replaceAll('YYYY', 'yyyy'),
                      )}",
                      fontWeight: FontWeight.w300,
                      fontSize: 12,
                      color: colors.text.primary,
                    ),
                  Container(
                    margin: const EdgeInsets.only(top: 4),
                    padding: const EdgeInsets.only(
                      left: 8,
                      right: 8,
                      top: 4,
                      bottom: 4,
                    ),
                    decoration: BoxDecoration(
                      color: visit.pending == false
                          ? colors.primary.turquoise.v2
                          : colors.secondary.yellow.v2,
                      borderRadius: const BorderRadius.all(
                        Radius.circular(4),
                      ),
                    ),
                    child: NvText(
                      textHolder:
                          visit.pending == false ? "Activo " : "Pendiente",
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                      color: visit.pending == false
                          ? colors.primary.turquoise.v4
                          : colors.secondary.yellow.v4,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const NvImage(
            imageUrl: 'ds/icons/arrow.svg',
          ),
        ]),
      ),
    );
  }
}
