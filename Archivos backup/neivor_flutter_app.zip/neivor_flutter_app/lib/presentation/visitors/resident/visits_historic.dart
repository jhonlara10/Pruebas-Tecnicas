import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/list_visits_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/visit_data_qr.dart';
import 'package:neivor_flutter_app/presentation/amenities/widgets/header.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_contact_list.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_data.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors_qr.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/widgets/avaliable_visits.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/widgets/empty_state.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/widgets/pending_visits.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_sliver_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_tab_bar.dart';
import 'package:permission_handler/permission_handler.dart';

class VisitsHistoric extends StatefulWidget {
  const VisitsHistoric({
    Key? key,
    this.visits,
    this.tabIndex,
  }) : super(key: key);

  final ListVisitsResponse? visits;
  final int? tabIndex;

  @override
  State<VisitsHistoric> createState() => _VisitsHistoricState();
}

class _VisitsHistoricState extends State<VisitsHistoric> {
  static const _tabsNumber = 2;
  final multipleDayVisit = 2;
  final copy = AppMessages().getCopy;
  ServicePointObject? _currentServicePoint;
  ListVisitsResponse? listVisitsResponse;
  List<Visit>? pendingVisits = [];
  List<Visit>? avaliableVisits = [];
  int visitsLenght = 0;
  List<Contact>? contacts;

  @override
  void initState() {
    getVisits();
    super.initState();
  }

  getVisits() async {
    if (widget.visits == null) {
      context.loaderOverlay.show();
      listVisitsResponse = await VisitorsRepository().listVisits();
      context.loaderOverlay.hide();
    }

    if (widget.visits != null) {
      listVisitsResponse = widget.visits;
      visitsLenght = widget.visits?.data?.length ?? 0;
      pendingVisits = widget.visits?.data
          ?.where((element) => element.pending == true)
          .toList();
      avaliableVisits = widget.visits?.data
          ?.where((element) => element.pending == false)
          .toList();
    }
  }

  // ignore: long-method
  getQR(
    VisitDataQr visit,
    int? tabIndex,
  ) async {
    // ignore: use_build_context_synchronously
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => VisitorsQr(
          response: visit.response,
          userVisit: visit.userVisit,
          visitDate: visit.visitDate,
          initDate: visit.initDate,
          lastDate: visit.lastDate,
          servicePointInfo: visit.servicePointInfo,
          phone: visit.phone,
          visitId: visit.visitId,
          idVisitPeriod: visit.idVisitPeriod,
          tabIndex: tabIndex,
        ),
      ),
    );
  }

  /// Obtaining contact list from [FlutterContacts] plugin.
  // ignore: long-method
  getContacts() async {
    if (!mounted) return;
    context.loaderOverlay.show();
    // Requesting contacts permissions.
    if (await FlutterContacts.requestPermission()) {
      contacts = await FlutterContacts.getContacts(withProperties: true);
      context.loaderOverlay.hide();
      // ignore: use_build_context_synchronously
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => VisitorsContactList(
            contacts: contacts
                ?.where((element) => element.phones.isNotEmpty)
                .toList(),
          ),
        ),
      );
      // ignore: no-empty-block
    } else {
      context.loaderOverlay.hide();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const VisitorsData(
            contact: null,
            isFavorite: false,
          ),
        ),
      );
    }
  }

  cancelSynqContacts() {
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => const VisitorsData(
          contact: null,
          isFavorite: false,
        ),
      ),
    );
  }

  /// Show bottom sheet modal when user synq their contacts in Neivor.
  // ignore: long-method
  showSynqContactsBottomSheet() async {
    var isPermissionGranted = await Permission.contacts.isGranted;
    if (!isPermissionGranted) {
      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return NvBottomSheet(
            bottomSheetHeight: 300,
            iconRoute: "assets/images/synq.png",
            title: copy('visitors.sync-your-contacts'),
            subtitle: copy('visitors.allow-access-contacts'),
            primaryButtonText: copy('visitors.sync-up'),
            secondaryButtonText: copy('common.cancel'),
            primaryButtonVariant: "nv-bottom-sheet-primary",
            secondaryButtonVariant: "nv-bottom-sheet-secondary",
            primaryButtonAction: getContacts,
            secondaryButtonAction: cancelSynqContacts,
          );
        },
      );
    } else {
      getContacts();
    }
  }

  @override
  Widget build(BuildContext context) {
    final typo = AppThemeScope.of(context).typography;

    return WillPopScope(
      onWillPop: () {
        Navigator.pushReplacementNamed(context, "home");
        return Future.value(false);
      },
      child: Scaffold(
        body: SafeArea(
          child: DefaultTabController(
            length: _tabsNumber,
            initialIndex: widget.tabIndex ?? 0,
            child: NestedScrollView(
              scrollDirection: Axis.vertical,
              floatHeaderSlivers: true,
              // ignore: prefer-extracting-callbacks
              headerSliverBuilder:
                  (BuildContext context, bool innerBoxIsScrolled) {
                return [
                  NvSliverAppbar(
                    flexibleSpace: Header(
                      onGoBack: _currentServicePoint != null
                          ? () {
                              _currentServicePoint = null;
                              setState(() {});
                            }
                          : null,
                      title: Text(
                        copy('home.visitor'),
                        style: typo.h2.semibold,
                      ),
                      children: [
                        const SizedBox(height: 24),
                        NvTabBar(
                          tabs: [
                            Tab(text: copy('social-areas.available')),
                            Tab(text: copy('social-areas.pending-bookings')),
                          ],
                        ),
                      ],
                    ),
                  ),
                ];
              },
              body: TabBarView(
                children: [
                  avaliableVisits?.length == 0
                      ? const EmptyState(
                          title: '¡Aún no tienes vistantes activos!',
                          subtitle:
                              'Le invitamos a registrar una nueva visita.',
                        )
                      : AvaliableVisits(
                          visits: avaliableVisits,
                          getQR: getQR,
                          tabIndex: 0,
                        ),
                  pendingVisits?.length == 0
                      ? const EmptyState(
                          title: '¡No tienes visitas pendientes!',
                          subtitle:
                              'Le invitamos a registrar una nueva visita.',
                        )
                      : PendingVisits(
                          visits: pendingVisits,
                          getQR: getQR,
                          tabIndex: 1,
                        ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.all(16),
          child: NvButton(
            label: copy('visitors.title-register-visit'),
            action: showSynqContactsBottomSheet,
          ),
        ),
      ),
    );
  }
}
