import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/visitors/visitors_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/visitors/create_visit_response.dart';
import 'package:neivor_flutter_app/domain/models/visitors/delete_visit_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/visitors/resident/visitors.dart';
import 'package:neivor_flutter_app/presentation/visitors/widgets/qr_card.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_bottom_sheet.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_extend/share_extend.dart';

class VisitorsQr extends StatefulWidget {
  final CreateVisitResponse? response;
  final String? userVisit;
  final String? visitDate;
  final int? idVisitPeriod;
  final String? servicePointInfo;
  final String? phone;
  final int? visitId;
  final int? tabIndex;
  final String? initDate;
  final String? lastDate;

  const VisitorsQr({
    Key? key,
    required this.response,
    this.idVisitPeriod,
    this.userVisit,
    this.visitDate,
    this.servicePointInfo,
    this.phone,
    this.visitId,
    this.tabIndex,
    this.initDate,
    this.lastDate,
  }) : super(key: key);

  @override
  State<VisitorsQr> createState() => _VisitorsQr();
}

class _VisitorsQr extends State<VisitorsQr> {
  Function copy = AppMessages().getCopy;
  ScreenshotController screenshotController = ScreenshotController();

  backToVisitors() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => Visitors(
          tabIndex: widget.tabIndex,
        ),
      ),
    );
  }

  takeScreenshotandShare() async {
    // ignore: prefer-async-await
    screenshotController.capture().then((capturedImage) async {
      if (Platform.isAndroid) {
        if (await Permission.storage.request().isGranted) {
          String filePath = await GlobalUtils().storeAndroidFile(capturedImage);
          ShareExtend.share(filePath, "file");
        }
      } else {
        await GlobalUtils().shareiOSFile(capturedImage);
      }
      // ignore: no-empty-block
    }).catchError((onError) {});
  }

  downloadFile() async {
    // ignore: prefer-async-await
    screenshotController.capture().then((capturedImage) async {
      if (Platform.isAndroid) {
        if (await Permission.storage.request().isGranted) {
          await GlobalUtils().storeAndroidFile(capturedImage);
          showSuccessDialog();
        }
      } else {
        await GlobalUtils().shareiOSFile(capturedImage);
      }
      // ignore: no-empty-block
    }).catchError((onError) {});
  }

  /// Shows a success dialog with 3 sec autoclose.
  showSuccessDialog() {
    // ignore: prefer-async-await
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "success",
          content: copy('visitors.card-downloaded-successfully'),
        );
      },
    );
  }

  /// Shows a success dialog with 3 sec autoclose.
  showErroDialog(String? error) {
    // ignore: prefer-async-await
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: "error",
          content: error ?? '',
        );
      },
    );
  }

  deleteVisit() async {
    context.loaderOverlay.show();
    DeleteVisitResponse? responseDeleteVisit =
        await VisitorsRepository().deleteVisit(widget.visitId);
    context.loaderOverlay.hide();
    if (responseDeleteVisit.success == true) {
      modalDeleteVisit();
    } else {
      showErroDialog(responseDeleteVisit.info?.message);
    }
  }

  // ignore: long-method
  modalConfirmDeleteVisit() {
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        showModalBottomSheet(
          enableDrag: false,
          isDismissible: false,
          context: context,
          builder: (BuildContext context) {
            return NvBottomSheet(
              bottomSheetHeight: 300,
              iconRoute: "assets/images/warning.png",
              title:
                  "¿Está seguro que desea Eliminar a ${widget.userVisit} de su lista de visitantes?",
              primaryButtonText: copy('schedule.delete'),
              primaryButtonVariant: "nv-bottom-sheet-primary",
              secondaryButtonVariant: "nv-bottom-sheet-secondary",
              secondaryButtonText: copy("common.cancel"),
              secondaryButtonAction: () => Navigator.pop(context),
              primaryButtonAction: () => deleteVisit(),
              subtitle: '',
            );
          },
        );
      });
    });
  }

  // ignore: long-method
  modalDeleteVisit() {
    // ignore: prefer-extracting-callbacks
    Future.delayed(Duration.zero, () {
      setState(() {
        showModalBottomSheet(
          enableDrag: false,
          isDismissible: false,
          context: context,
          builder: (BuildContext context) {
            return NvBottomSheet(
              bottomSheetHeight: 300,
              iconRoute: "assets/images/check-success.png",
              title: "¡Eliminado!",
              subtitle:
                  "El acceso de ${widget.userVisit} ha sido eliminado con exito",
              primaryButtonText: "Regresar",
              primaryButtonVariant: "nv-bottom-sheet-secondary",
              primaryButtonAction: () => backToVisitors(),
            );
          },
        );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    return Scaffold(
      appBar: NvAppBar(
        title: copy('page.app.labelDetailAppTitle'),
        backAction: () => backToVisitors(),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Screenshot(
                controller: screenshotController,
                child: QRCard(
                  response: widget.response,
                  visitDate: widget.visitDate,
                  userVisit: widget.userVisit,
                  servicePointInfo: widget.servicePointInfo,
                  phone: widget.phone,
                  idVisitPeriod: widget.idVisitPeriod,
                  initDate: widget.initDate,
                  lastDate: widget.lastDate,
                ),
              ),
            ],
          ),
        ),
        const Spacer(),
        if (widget.tabIndex != null)
          GestureDetector(
            onTap: modalConfirmDeleteVisit,
            child: NvText(
              textHolder: "¿Deseas eliminar el acceso?",
              fontFamily: 'Jost',
              fontWeight: FontWeight.w500,
              fontSize: 16,
              color: colors.primary.turquoise.v4,
              textAlign: TextAlign.center,
            ),
          ),
        const Spacer(),
        Align(
          alignment: FractionalOffset.bottomCenter,
          child: Container(
            padding: const EdgeInsets.only(
              top: 20.0,
              left: 16.0,
              right: 16.0,
              bottom: 16.0,
            ),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: colors.primary.black.v1,
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2, left: 2),
                    child: NvButton(
                      label: copy('visitors.more-options'),
                      action: () {
                        takeScreenshotandShare();
                      },
                      variant: "secondary",
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2, left: 2),
                    child: NvButton(
                      label: "Whatsapp",
                      action: () {
                        takeScreenshotandShare();
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}
