import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:neivor_flutter_app/domain/models/settings/messages_request.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/data/repository/messages/messages_repository_impl.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const Splash());
}

class Splash extends StatefulWidget {
  const Splash({
    Key? key,
  }) : super(key: key);

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  // Defines selected language provided by user, obtained by platform locale value.
  String defaultLocale = '';

  final repository = MessagesRepository();

  @override
  void initState() {
    initLanguage();
    getCopies();
    initPermissions();
    if (GlobalUtils.deviceInfo == null) {
      GlobalUtils().getDeviceInfo();
    }

    super.initState();
  }

  initPermissions() async {
    var sharePreferences = await SharedPreferences.getInstance();
    var isLogged = sharePreferences.getBool("isLogged");
    if ((sharePreferences.getString("permissions") == [] ||
            sharePreferences.getString("permissions") == null) &&
        (isLogged != null && isLogged)) {
      await UserUtils().getPermissions();
    }
  }

  initLanguage() async {
    var sharePreferences = await SharedPreferences.getInstance();
    if (sharePreferences.getString("selectedLang") == [] ||
        sharePreferences.getString("selectedLang") == null) {
      defaultLocale = Platform.localeName.split("_").first == Constants.esCode
          ? Constants.spanishLanguage
          : Constants.englishLanguage;
    } else {
      defaultLocale = sharePreferences.getString("selectedLang") ?? '';
    }
    Jiffy.locale(defaultLocale == Constants.spanishLanguage ? 'es' : 'en');
  }

  // ignore: long-method
  getCopies() async {
    var sharePreferences = await SharedPreferences.getInstance();
    var isLogged = sharePreferences.getBool("isLogged");
    try {
      sharePreferences.setString("selectedLang", defaultLocale);
      await GlobalUtils().synqCurrentLanguage();
      await repository.getMessages(MessagesRequest(
        defaultLocale,
        Constants.appSource,
        Constants.mxIdCode,
        true,
      ));
      await Future.delayed(
        const Duration(seconds: Constants.delaySplashDuration),
        // ignore: prefer-extracting-callbacks
        () {
          Navigator.pushReplacementNamed(
            context,
            isLogged != null && isLogged ? 'home' : 'geolocation',
          );
        },
      );
    } catch (e) {
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Image.asset(
        'assets/images/splash.png',
        fit: BoxFit.cover,
        height: double.infinity,
        width: double.infinity,
        alignment: Alignment.center,
      ),
    );
  }
}
