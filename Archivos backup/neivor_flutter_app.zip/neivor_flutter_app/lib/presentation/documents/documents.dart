import 'dart:io';
import 'dart:isolate';
import 'dart:ui';

import 'package:android_path_provider/android_path_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/documents/documents_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/documents/document_list.dart';
import 'package:neivor_flutter_app/presentation/documents/widgets/document_card.dart';
import 'package:neivor_flutter_app/presentation/documents/widgets/folder_card.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:skeletons/skeletons.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../widgets/widgets.dart';

class Documents extends StatefulWidget {
  const Documents({
    Key? key,
  }) : super(key: key);

  @override
  State<Documents> createState() => _DocumentsState();
}

class _DocumentsState extends State<Documents> {
  final copy = AppMessages().getCopy;

  /// A variable that is assigned the value of the list of documents in the current path.
  List<String>? currentPath;

  /// A variable that is assigned the value of the list of documents in the current path.
  DocumentList? docList;

  /// A variable that is assigned the value of the path to the downloads folder on the device.
  String? downloadsPath;

  /// Creating a port to receive data from the isolate.
  final ReceivePort _port = ReceivePort();
  bool isLoading = true;
  @override
  void initState() {
    loadBaseDoclist();

    /// Registering a port to receive data from the isolate.
    IsolateNameServer.registerPortWithName(
      _port.sendPort,
      'downloader_send_port',
    );

    /// Listening for data from the isolate.
    _port.listen((dynamic data) {
      // ignore: unused_local_variable
      String id = data[0];
      // ignore: unused_local_variable
      DownloadTaskStatus status = data[1];
      // ignore: unused_local_variable
      int progress = data[2];
    });

    /// Registering a callback to receive data from the isolate.
    FlutterDownloader.registerCallback(downloadCallback);
    super.initState();
  }

  /// It gets the download path, gets the documents in the download path, sets the current path to an
  /// empty list, and then sets the state
  // ignore: long-method
  loadBaseDoclist() async {
    try {
      context.loaderOverlay.show();
      isLoading = true;
      getDownloadPath();
      docList = await getDocuments(null);
      currentPath = [];
      // ignore: no-empty-block
      setState(() {});
      isLoading = false;
      context.loaderOverlay.hide();
    } catch (e) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              //"Error",
              copy('page.core.labelError'),
            ),
            content: Text(
              //"No se pudo obtener carpeta de destino",
              copy('documents.folder-error'),
            ),
          );
        },
      );
    }
  }

  /// It gets the path of the downloads folder.
  ///
  /// Returns:
  ///   The path to the downloads folder.
  void getDownloadPath() async {
    if (Platform.isAndroid) {
      try {
        downloadsPath = await AndroidPathProvider.downloadsPath;
      } catch (e) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text(copy('page.core.labelError')),
              content: Text(copy('documents.folder-error')),
            );
          },
        );
      }
    }
  }

  /// It takes a path, adds it to the current path, then goes to that path and sets the state
  ///
  /// Args:
  ///   path (String): The path to load.
  loadPath(String path) async {
    context.loaderOverlay.show();
    if (path.isNotEmpty) {
      currentPath?.add(path);
    }
    docList = await getDocuments(
      "${currentPath?.join("/").replaceAll(" ", "%20") ?? ''}/",
    );
    // ignore: no-empty-block
    setState(() {});
    context.loaderOverlay.hide();
  }

  /// If the currentPath is not null, then join the path with a " > " separator, otherwise return
  /// "Documentos"
  ///
  /// Returns:
  ///   The currentPath is being returned.
  String pathToString() {
    return currentPath?.join(" > ") ??
        copy('documents.documents'); //'Documentos';
  }

  /// It downloads the file from the url, shows a notification, opens the file from the notification,
  /// saves the file in the external storage path, and gives the file a name
  ///
  /// Args:
  ///   doc (Document): The document object that contains the url, name and type of the file.
  void downloadFiles(Document doc) async {
    if (Platform.isAndroid) {
      if (await Permission.storage.request().isGranted) {
        await FlutterDownloader.enqueue(
          url: doc.encodeUrl ?? "",
          showNotification: true,
          openFileFromNotification: true,
          savedDir: downloadsPath ?? "",
          fileName:
              ("${doc.name?.replaceAll(RegExp(r"[^A-Za-z0-9]"), "")}${DateTime.now().millisecondsSinceEpoch}.${doc.type}"),
        );
      }
    } else {
      // ignore: deprecated_member_use
      launch(doc.encodeUrl ?? "");
    }
  }

  @override

  /// The function is called when the app is closed. It removes the port name mapping from the isolate
  /// name server
  void dispose() {
    IsolateNameServer.removePortNameMapping('downloader_send_port');
    super.dispose();
  }

  @pragma('vm:entry-point')

  /// It looks up the send port by name, and sends the download progress to the main isolate
  ///
  /// Args:
  ///   id (String): The id of the download task.
  ///   status (DownloadTaskStatus): The status of the download task.
  ///   progress (int): The progress of the download, from 0 to 100.
  static void downloadCallback(
    String id,
    DownloadTaskStatus status,
    int progress,
  ) {
    final SendPort? send =
        IsolateNameServer.lookupPortByName('downloader_send_port');
    send?.send([id, status, progress]);
  }

  manageBack() {
    if (currentPath?.isNotEmpty ?? false) {
      backPath();
    } else {
      Navigator.pushReplacementNamed(context, "home");
    }
  }

  backPath() async {
    context.loaderOverlay.show();
    currentPath?.removeLast();
    docList = await getDocuments(
      "${currentPath?.join("/").replaceAll(" ", "%20") ?? ''}/",
    );
    setState(() {});
    context.loaderOverlay.hide();
  }

  goToSpecific(int index) async {
    index += 1;
    if ((currentPath?.isNotEmpty ?? false)) {
      setState(() {
        currentPath = currentPath?.sublist(0, index);
        loadPath("");
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NvAppBar(
        title: copy('documents.documents'), //'Documentos',
        backAction: manageBack,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            Row(
              children: [
                ElevatedButton(
                  onPressed: () =>
                      Navigator.pushReplacementNamed(context, "home"),
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all(const CircleBorder(
                      side: BorderSide(color: AppTheme.black1),
                    )),
                    backgroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  child: const NvImage(
                    imageUrl: 'ds/icons/tiny-house.svg',
                  ),
                ),
                TextButton(
                  style: ButtonStyle(
                    padding: MaterialStateProperty.all(EdgeInsets.zero),
                  ),
                  onPressed: () => loadBaseDoclist(),
                  child: Text(
                    //'Documentos > ',
                    '${copy('documents.documents')} >',
                    style: const TextStyle(
                      color: Color(0xFF8A8A8A),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width *
                      Constants.fiftyPercent,
                  height: 40,
                  child: ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: (currentPath?.isEmpty ?? true)
                        ? 1
                        : currentPath?.length ?? 1,
                    itemBuilder: (BuildContext context, int index) {
                      return TextButton(
                        style: ButtonStyle(
                          padding: MaterialStateProperty.all(EdgeInsets.zero),
                        ),
                        onPressed: () => (currentPath?.isNotEmpty ?? false)
                            ? goToSpecific(index)
                            : null,
                        child: Text(
                          (currentPath?.isNotEmpty ?? false)
                              ? (currentPath?[index] ?? '') +
                                  (currentPath?[index] !=
                                          (currentPath?.last ?? "")
                                      ? " > "
                                      : "")
                              : '',
                          style: const TextStyle(color: Color(0xFF8A8A8A)),
                          textAlign: TextAlign.center,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 26),
              child: Skeleton(
                isLoading: isLoading,
                skeleton: SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: SkeletonListView(
                    item: FolderCard(
                      docList: DocumentList(),
                      index: 0,
                      loadPath: loadPath,
                    ),
                  ),
                ),
                child: ListView.builder(
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  itemCount: docList?.getList?.length ?? 0,
                  itemBuilder: (BuildContext context, int index) {
                    return docList?.getList?[index].type == 'folder'
                        ? FolderCard(
                            docList: docList ?? DocumentList(),
                            index: index,
                            loadPath: loadPath,
                          )
                        : DocumentCard(
                            docList: docList ?? DocumentList(),
                            index: index,
                            downloadFiles: downloadFiles,
                          );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
