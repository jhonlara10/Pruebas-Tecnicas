import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/documents/document_list.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

import '../../../themes/themes.dart';

class FolderCard extends StatelessWidget {
  final DocumentList? docList;
  final int? index;
  final Function loadPath;
  static const double _defaultElevation = 10;

  const FolderCard({
    Key? key,
    this.docList,
    this.index,
    required this.loadPath,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    return GestureDetector(
      onTap: () {
        loadPath(docList?.getList?[index ?? 0].name ?? '');
      },
      child: Card(
        margin: const EdgeInsets.fromLTRB(25, 0, 25, 24),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        elevation: _defaultElevation,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(25, 5, 22, 5),
          child: Row(
            children: [
              const NvImage(
                imageUrl: 'ds/icons/folder-button-corrected.svg',
                width: 38,
              ),
              Container(
                margin: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      docList?.getList?[index ?? 0].name ?? '',
                      style: AppTheme.lightTheme.textTheme.headline4,
                    ),
                    Text(
                      //Modificada:
                      "${copy('documents.modified-with-a')} ${docList?.getList?[index ?? 0].lastUpdate ?? ''}",
                      style: const TextStyle(
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w400,
                        fontSize: 10,
                        color: AppTheme.black3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
