import 'dart:math';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/documents/document_list.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class DocumentCard extends StatelessWidget {
  final DocumentList? docList;
  final int? index;

  /// A function that is passed as a parameter to the DocumentCard widget.
  final Function downloadFiles;
  static const int _byteSize = 1024;
  static const double _iconSize = 35;

  const DocumentCard({
    Key? key,
    this.docList,
    this.index,
    required this.downloadFiles,
  }) : super(key: key);

  /// It returns a string based on the value of the variable 'type' which is a property of the object
  /// 'docList'. return
  ///
  /// Returns:
  ///   A string.
  // ignore: long-method
  String getIcon() {
    switch (docList?.getList?[index ?? 0].type?.toUpperCase()) {
      case 'XLS':
      case 'XLSX':
        {
          return 'ds/icons/excel.svg';
        }
      case 'PDF':
        {
          return 'ds/icons/pdf-icon.svg';
        }
      case 'GIF':
      case 'JPG':
      case 'JPE':
      case 'PNG':
        {
          return 'ds/icons/file-default.svg';
        }
      case 'DOC':
      case 'DOCX':
        {
          return 'ds/icons/word-icon.svg';
        }
      case 'PPT':
      case 'PPTX':
        {
          return 'ds/icons/pptx-powerpoint.svg';
        }

      default:
        {
          return 'ds/icons/file-default.svg';
        }
    }
  }

  /// It takes a number of bytes and returns a string with the number of bytes and the appropriate suffix
  ///
  /// Args:
  ///   bytes (int): The number of bytes to format.
  ///
  /// Returns:
  ///   a string.
  static String formatBytes(int bytes) {
    if (bytes <= 0) return " | 0 B";
    const suffixes = ["B", "KB", "MB", "GB"];
    var size = (log(bytes) / log(_byteSize)).floor();
    // ignore: prefer_interpolation_to_compose_strings
    return (" | " + (bytes / pow(_byteSize, size)).round().toString()) +
        ' ' +
        suffixes[size];
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.fromLTRB(25, 0, 25, 24),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        side: BorderSide(color: AppTheme.black2),
      ),
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(25, 5, 22, 5),
        child: Row(
          children: [
            NvImage(
              imageUrl: getIcon(),
              width: _iconSize,
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${docList?.getList?[index ?? 0].name ?? ''}.${docList?.getList?[index ?? 0].type}",
                      style: AppTheme.lightTheme.textTheme.headline4,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    Text(
                      "Modificada: ${docList?.getList?[index ?? 0].lastUpdate ?? ''} ${formatBytes(docList?.getList?[index ?? 0].size ?? 0)}",
                      style: const TextStyle(
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w400,
                        fontSize: 10,
                        color: AppTheme.black3,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (UserUtils().hasPermissionsTo(820))
              ElevatedButton(
                onPressed: () => downloadFiles(docList?.getList?[index ?? 0]),
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.white),
                ),
                child: const NvImage(
                  imageUrl: 'ds/icons/download-icon.svg',
                  width: 20,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
