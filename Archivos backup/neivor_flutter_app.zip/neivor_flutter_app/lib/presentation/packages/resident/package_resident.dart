import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_data_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:neivor_flutter_app/widgets/widgets.dart';

class PackageResident extends StatefulWidget {
  const PackageResident({
    Key? key,
  }) : super(key: key);

  @override
  State<PackageResident> createState() => _PackageResidentState();
}

class _PackageResidentState extends State<PackageResident> {
  final copy = AppMessages().getCopy;
  List<PackageDataObject>? listPackages;
  bool isLoading = true;
  //permission: "Ver paquetes que registraron"
  bool canSeePackagesRegistered = UserUtils().hasPermissionsTo(870);

  @override
  void initState() {
    findPackageDataBySP();
    super.initState();
  }

  /// Search Packages by service point
  // ignore: long-method
  findPackageDataBySP() async {
    context.loaderOverlay.show();
    int? sp = UserUtils.currentServicePoint?.id;
    var packageDataRes =
        await PackageRepository().getPackageListByServicePoint(sp.toString());
    listPackages = packageDataRes?.data?.list;
    isLoading = false;
    setState(() {});
    context.loaderOverlay.hide();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
          elevation: 0,
        ),
        body: canSeePackagesRegistered
            ? SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                scrollDirection: Axis.vertical,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(bottom: 24, top: 24),
                      child: NvText(
                        //"Recoge tus paquetes",
                        copy: 'packages.pick-up',
                        color: AppTheme.black0Main,
                        fontWeight: FontWeight.w600,
                        fontSize: 24,
                      ),
                    ),
                    isLoading == false &&
                            (context == null || listPackages?.length == 0)
                        ? emptyPackages()
                        : ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            itemCount: listPackages?.length ?? 0,
                            itemBuilder: (BuildContext context, int index) {
                              return Card(
                                margin: const EdgeInsets.only(bottom: 16),
                                elevation: 1,
                                shape: const RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8)),
                                  side: BorderSide(color: AppTheme.black2),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: 80,
                                        child: Column(
                                          children: [
                                            NvImage(
                                              imageUrl: listPackages?[index]
                                                          .idPackType ==
                                                      1
                                                  ? "ds/icons/package-circle.svg"
                                                  : 'ds/icons/package.mai-circle.svg',
                                              width: 54,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                              bottom: 2,
                                            ),
                                            child: NvText(
                                              copy: listPackages?[index]
                                                  .packTypeName,
                                              color: AppTheme.black0Main,
                                              fontWeight: FontWeight.w500,
                                              fontSize: 16,
                                            ),
                                          ),
                                          Text(
                                            listPackages?[index].idPackType == 1
                                                ? '${copy('packages.recived-package')} ${copy('${listPackages?[index].packTypeName}').toLowerCase()}'
                                                : '${copy('packages.recived-one')} ${copy('${listPackages?[index].packTypeName}').toLowerCase()}',
                                            //"Recibiste 1 nuevo ${copy('${listPackages?[index].packTypeName}').toLowerCase()}",
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w300,
                                              color: AppTheme.black0Main,
                                              fontSize: 16,
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              const NvText(
                                                //"Pidelo con el código:",
                                                copy: 'packages.pick-up-code',
                                                fontWeight: FontWeight.w300,
                                                color: AppTheme.black0Main,
                                                fontSize: 16,
                                              ),
                                              Text(
                                                listPackages?[index]
                                                        .id
                                                        .toString() ??
                                                    '',
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.w400,
                                                  color: AppTheme.black0Main,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ],
                                          ),
                                          NvText(
                                            textHolder: GlobalUtils().parseDate(
                                              listPackages?[index].dateCreation,
                                              'dd MMMM yyyy',
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                            fontWeight: FontWeight.w400,
                                            fontSize: 16,
                                            color: AppTheme.black3,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ],
                ),
              )
            : emptyPackages(),
      ),
    );
  }

  /// build the empty view when no have packages to show
  ///
  emptyPackages() {
    return Center(
      heightFactor: 1.5,
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: 300,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const NvImage(
              imageUrl: 'ds/icons/package-box-label.svg',
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18.0),
              child: SizedBox(
                width: MediaQuery.of(context).size.width * 0.7,
                child: NvText(
                  //'Aquí te avisaremos cuando tengas paquetes por retirar',
                  copy: canSeePackagesRegistered
                      ? 'packages.pick-up-notice'
                      : 'common.not-permission',
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  color: AppTheme.black3,
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
