import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/packages/packages_detail.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/row_service_point.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import '../../../themes/app_theme.dart';
import '../../../widgets/nv_button.dart';

class MainPackages extends StatefulWidget {
  const MainPackages({Key? key}) : super(key: key);

  @override
  State<MainPackages> createState() => _MainPackagesState();
}

class _MainPackagesState extends State<MainPackages> {
  List<ServicePointObject>? filterList;
  var inSearch = false;
  final copy = AppMessages().getCopy;
  //Permissions: registrar paquete - registrar servicios públicos - registrar correspondencia
  final canRegisterPackage = UserUtils().hasPermissionsTo(680);
  final canRegisterService = UserUtils().hasPermissionsTo(682);
  final canRegisterCorrespondence = UserUtils().hasPermissionsTo(681);

  @override
  void initState() {
    filterList = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: ListView(
          padding: const EdgeInsets.only(top: 16),
          children: [
            Text(
              copy('packages.packages'),
              style: const TextStyle(
                letterSpacing: .7,
                fontFamily: 'Jost',
                fontWeight: FontWeight.w600,
                fontSize: 26,
                color: AppTheme.black0Main,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              copy('packages.search-apartment'),
              style: const TextStyle(
                fontFamily: 'Jost',
                fontWeight: FontWeight.w500,
                fontSize: 16,
                color: AppTheme.black0Main,
              ),
            ),
            TextFormField(
              autofocus: false,
              onFieldSubmitted: (value) {
                if (value != "") {
                  inSearch = true;
                  findServicePointByName(value);
                } else {
                  setState(() {
                    filterList = [];
                    inSearch = false;
                  });
                }
              },
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
              ),
            ),
            ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: filterList?.length ?? 0,
              itemBuilder: (context, index) {
                return RowServicePoint(
                  servicePointClicked: servicePointClicked,
                  servicePointObj: filterList![index],
                );
              },
            ),
            if (inSearch && filterList!.isEmpty)
              const NvText(
                //"No se encontraron resultados, intenta con otro nombre",
                copy: 'packages.without-sp-results',
                textAlign: TextAlign.center,
                fontFamily: 'Jost',
                fontWeight: FontWeight.w400,
                fontSize: 16,
                color: Color(0xFF8A8A8A),
              ),
            const SizedBox(height: 20),
            if (!inSearch)
              const NvImage(
                imageUrl: 'ds/illustrations/neivor-package.svg',
                shadow: false,
                width: 160,
                height: 160,
              ),
            const SizedBox(height: 20),
            if (!inSearch)
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      copy('packages.register-or-find-packages'),
                      style: const TextStyle(
                        letterSpacing: .5,
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        color: AppTheme.black0Main,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 70),
            if (!inSearch &&
                (canRegisterCorrespondence ||
                    canRegisterPackage ||
                    canRegisterService))
              NvButton(
                action: () {
                  goToRegisterPackage();
                },
                label: copy('packages.register-packages'),
                variant: 'primary',
              ),
          ],
        ),
      ),
    );
  }

  findServicePointByName(String name) async {
    context.loaderOverlay.show();
    filterList = await PackageRepository().getServicePointListByName(name);
    setState(() {});
    context.loaderOverlay.hide();
  }

  servicePointClicked(ServicePointObject spo) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) =>
            PackageDetail(servicePointObject: spo),
      ),
    );
  }

  goToRegisterPackage() {
    Navigator.pushNamed(context, 'packagesRegister');
  }
}
