import 'dart:async';
import 'dart:core';
import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/drop_down_package_item.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/sp_card.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import '../../../domain/models/packages/package_data_response.dart';
import '../../../widgets/nv_appbar.dart';

class PackageDetail extends StatefulWidget {
  final ServicePointObject servicePointObject;

  const PackageDetail({Key? key, required this.servicePointObject})
      : super(key: key);

  @override
  State<PackageDetail> createState() => _PackageDetailState();
}

class _PackageDetailState extends State<PackageDetail> {
  PackageDataResponse? packageDataRes;
  List<PackageDataObject>? listPackages;
  String? variantButton = 'nv-bottom-disabled';
  final deliveredState = 2;
  final packagesRepository = PackageRepository();
  final copy = AppMessages().getCopy;

  /// Search Packages by service point and it set the button style.
  // ignore: long-method
  findPackageDataBySP(String sp) async {
    packageDataRes = await PackageRepository().getPackageListByServicePoint(sp);
    listPackages = packageDataRes?.data?.list;
    if (listPackages != null) {
      listPackages!.isNotEmpty ? variantButton = 'primary' : '';
    } else {
      // If the response of service fail, it´ll show this message.
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          Timer(const Duration(seconds: 3), () {
            Navigator.of(context).pop();
            Navigator.of(context).pop();
          });
          return const NvAlert(
            type: 'warning',
            content:
                'No se pudo obtener informacion del la unidad, contacte con atencion al cliente',
          );
        },
      );
    }
    setState(() {});
  }

  // ignore: long-method
  deliverPackages() async {
    context.loaderOverlay.show();
    List<PackageDataObject>? listPackagesToDeliver = [];
    listPackages?.forEach((element) {
      listPackagesToDeliver.add(PackageDataObject(
        userChange: UserUtils.currentUser?.id,
        idPackState: deliveredState,
        idPackType: element.idPackType,
        idServicePoint: element.idServicePoint,
        idDistributor: element.idDistributor,
        comment: element.comment,
        id: element.id,
      ));
    });
    var response =
        await packagesRepository.deliverPackages(listPackagesToDeliver);
    if (response.success == true) {
      showAlert(
        "success",
        AppMessages().getCopy("packages.packages-delivered"),
      );
    } else {
      showAlert("error", AppMessages().getCopy("common.common-error"));
    }
    await findPackageDataBySP(widget.servicePointObject.id.toString());
    context.loaderOverlay.hide();
  }

  void showAlert(String type, String message) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 2), () {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
          Navigator.pushReplacementNamed(context, "packages");
        });
        return NvAlert(
          type: type,
          content: message,
        );
      },
    );
  }

  // Buit a part of view.
  // ignore: long-method
  emptyList() {
    return Column(
      children: [
        const SizedBox(
          height: 50,
        ),
        const NvImage(
          imageUrl: 'ds/illustrations/neivor-package.svg',
          width: 160,
          height: 160,
        ),
        const SizedBox(
          height: 16,
        ),
        Text(
          copy('packages.no-registered-packages'),
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Color(0xFFFFAB1B),
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    (() async {
      context.loaderOverlay.show();
      await findPackageDataBySP(widget.servicePointObject.id.toString());
      setState(() {
        context.loaderOverlay.hide();
      });
    })();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'packages',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'packages',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Stack(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            width: MediaQuery.of(context).size.width,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Row(children: [
                    NvText(
                      textHolder: copy('packages.packages-found'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.bold,
                      fontSize: 25,
                      color: const Color.fromARGB(255, 0, 0, 0),
                      textAlign: TextAlign.center,
                    ),
                  ]),
                  const SizedBox(
                    height: 16,
                  ),
                  ServicePointCard(
                    spName:
                        '${widget.servicePointObject.operationZone?.name} - ${widget.servicePointObject.name}',
                    cantPackages: packageDataRes?.data?.totalRow,
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  // Package list.
                  if (listPackages == null || (listPackages?.isEmpty ?? true))
                    emptyList(),
                  if (listPackages != null)
                    DropDownPackageDetail(
                      dataListPackages: listPackages,
                    ),
                  const SizedBox(
                    height: 100,
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Container(
                decoration: const BoxDecoration(color: Colors.white),
                padding: const EdgeInsets.all(10),
                child: NvButton(
                  action: packageDataRes?.data?.totalRow == 0
                      ? null
                      : deliverPackages,
                  label: copy(
                    'packages.deliver-packages',
                    ['${packageDataRes?.data?.totalRow}'],
                  ),
                  variant: 'primary',
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
