import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/packages/main_packages.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';

class Packages extends StatelessWidget {
  const Packages({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
        ),
        body: const MainPackages(),
      ),
    );
  }
}
