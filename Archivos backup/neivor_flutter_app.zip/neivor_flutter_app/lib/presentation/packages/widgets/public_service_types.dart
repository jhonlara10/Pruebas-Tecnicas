// ignore: file_names
import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_distributors_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

import '../../../data/repository/packages/packages_repository_impl.dart';
import '../../../theme/app_theme_scope.dart';

class PublicServiceTypes extends StatefulWidget {
  const PublicServiceTypes({
    Key? key,
    required this.selectIdDistributor,
  }) : super(key: key);

  final Function selectIdDistributor;

  @override
  State<PublicServiceTypes> createState() => _PublicServiceTypesState();
}

class _PublicServiceTypesState extends State<PublicServiceTypes> {
  PackagesDistributorsResponse? distributorsList;
  bool isLoading = true;
  String? selectedValue;

  @override
  void initState() {
    listDistributors();
    super.initState();
  }

  listDistributors() async {
    try {
      distributorsList = await PackageRepository().getPackagesDistributors(2);
      isLoading = false;
      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  findDistributor(String? name) =>
      distributorsList?.data?.firstWhere((dist) => dist.name == name);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;
    const String placeholder = 'Select';
    const double buttonHeight = 48;

    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        buttonHeight: buttonHeight,
        buttonPadding: const EdgeInsets.only(left: 16, right: 16),
        buttonDecoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          border: Border.all(color: colors.primary.black.v2, width: 1),
        ),
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          placeholder,
          style: typo.bd1.light.copyWith(color: colors.text.placeholders),
        ),
        items: distributorsList?.data
            ?.map((value) => DropdownMenuItem(
                  value: value.name,
                  child: Row(
                    children: [
                      NvImage(imageUrl: value.image),
                      const SizedBox(width: 8),
                      Text(
                        AppMessages().getCopy(value.name),
                        style: typo.bd1.light,
                      ),
                    ],
                  ),
                ))
            .toList(),
        icon: const Icon(Icons.keyboard_arrow_down),
        // ignore: prefer-extracting-callbacks
        onChanged: (value) {
          var distributor = findDistributor(value as String);
          widget.selectIdDistributor(distributor.id);
          setState(() {
            selectedValue = value;
          });
        },
      ),
    );
  }
}
