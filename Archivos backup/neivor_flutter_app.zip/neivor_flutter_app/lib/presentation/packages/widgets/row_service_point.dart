import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';

class RowServicePoint extends StatefulWidget {
  final ServicePointObject servicePointObj;
  final Function servicePointClicked;

  const RowServicePoint({
    Key? key,
    required this.servicePointObj,
    required this.servicePointClicked,
  }) : super(key: key);

  @override
  State<RowServicePoint> createState() => _RowServicePointState();
}

class _RowServicePointState extends State<RowServicePoint> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        widget.servicePointClicked(widget.servicePointObj);
      },
      child: ListTile(
        title: Text(
          '${widget.servicePointObj.operationZone?.name} - ${widget.servicePointObj.name}',
        ),
        leading: const Icon(Icons.house_outlined),
        trailing: const Icon(Icons.keyboard_arrow_right_outlined),
      ),
    );
  }
}
