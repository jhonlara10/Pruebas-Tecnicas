import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_distributors_response.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

import '../../util/app_messages.dart';

class Distributors extends StatefulWidget {
  const Distributors({
    Key? key,
    required this.selectIdDistributor,
  }) : super(key: key);

  final Function selectIdDistributor;

  @override
  State<Distributors> createState() => _DistributorsState();
}

class _DistributorsState extends State<Distributors> {
  PackagesDistributorsResponse? distributorsList;
  bool isLoading = true;
  String? selectedValue;

  @override
  void initState() {
    // Obtain a list of distributors according to the id of the type of package.
    listDistributors();
    super.initState();
  }

  listDistributors() async {
    try {
      distributorsList = await PackageRepository().getPackagesDistributors(1);
      isLoading = false;
      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  findDistributor(String? name) =>
      distributorsList?.data?.firstWhere((dist) => dist.name == name);

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;
    final String? placeholder = AppMessages().getCopy('packages.supplier');
    const double buttonHeight = 48;

    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        buttonHeight: buttonHeight,
        buttonPadding: const EdgeInsets.only(left: 16, right: 16),
        buttonDecoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(4)),
          border: Border.all(color: colors.primary.black.v2, width: 1),
        ),
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          placeholder ?? '',
          style: typo.bd1.light.copyWith(color: colors.text.placeholders),
        ),
        items: distributorsList?.data
            ?.map((value) => DropdownMenuItem(
                  value: value.name,
                  child: Row(
                    children: [
                      NvImage(
                        imageUrl: value.image?.replaceAll(".svg", '.png'),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        AppMessages().getCopy(value.name),
                        style: typo.bd1.light,
                      ),
                    ],
                  ),
                ))
            .toList(),
        icon: const Icon(Icons.keyboard_arrow_down),
        // ignore: prefer-extracting-callbacks
        onChanged: (value) {
          var distributor = findDistributor(value as String);
          widget.selectIdDistributor(distributor.id);
          setState(() {
            selectedValue = value;
          });
        },
      ),
    );
  }
}
