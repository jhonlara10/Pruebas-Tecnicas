// Class Item for stores ExpansionPanel data information.
import 'package:flutter/material.dart';

class Item {
  Item({
    required this.expandedValue,
    required this.headerValue,
    this.isExpanded = false,
    required this.id,
    required this.dateCreation,
    required this.totalRow,
    required this.idPackType,
    required this.idServicePoint,
    required this.idDistributor,
    required this.comment,
    required this.packTypeName,
  });

  Widget expandedValue;
  Widget headerValue;
  bool isExpanded;
  int? id;
  int? totalRow;
  int? idPackType;
  int? idServicePoint;
  int? idDistributor;
  double? dateCreation;
  String? comment;
  String? packTypeName;
  String? imageDistributor;
}
