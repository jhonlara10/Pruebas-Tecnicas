import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_types_response.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../themes/app_theme.dart';

class PackageTypeCard extends StatefulWidget {
  PackageTypeCard({
    Key? key,
    required this.isCorresponSelected,
    required this.isPackageSelected,
    required this.isUtilitiesSelected,
    required this.selectPackage,
    required this.selectUtilities,
    required this.selectCorrespon,
  }) : super(key: key);

  bool isPackageSelected;
  bool isUtilitiesSelected;
  bool isCorresponSelected;
  final Function selectPackage;
  final Function selectUtilities;
  final Function selectCorrespon;

  @override
  State<PackageTypeCard> createState() => _PackageTypeCardState();
}

class _PackageTypeCardState extends State<PackageTypeCard> {
  PackagesTypesResponse? packageTypes;
  bool? isLoading = true;
  bool canRegisterPackage = UserUtils().hasPermissionsTo(680);
  bool canRegisterService = UserUtils().hasPermissionsTo(682);
  bool canRegisterCorrespondence = UserUtils().hasPermissionsTo(681);

  @override
  void initState() {
    listPackagesTypes();
    super.initState();
  }

  listPackagesTypes() async {
    try {
      packageTypes = await PackageRepository().getPackageTypes();
      isLoading = false;
      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        if (canRegisterPackage)
          GestureDetector(
            onTap: () {
              widget.selectPackage(packageTypes?.data?.first.id);
            },
            child: Container(
              height: 102,
              padding: const EdgeInsets.only(top: 14.0),
              width: (MediaQuery.of(context).size.width / 3) - 16,
              decoration: BoxDecoration(
                border: widget.isPackageSelected
                    ? Border.fromBorderSide(
                        BorderSide(color: colors.button.turquoise.main),
                      )
                    : null,
                borderRadius: const BorderRadius.all(
                  Radius.circular(8),
                ),
                color: AppTheme.turquoise0Main.withOpacity(0.1),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: packageTypes?.data?.first.image,
                      color: colors.button.turquoise.main,
                      width: 40,
                      height: 40,
                    ),
                  ),
                  Text(
                    AppMessages().getCopy(packageTypes?.data?.first.name),
                    style: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w600,
                      color: colors.button.turquoise.main,
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (canRegisterService)
          GestureDetector(
            onTap: () {
              widget.selectUtilities(packageTypes?.data?[1].id);
            },
            child: Container(
              height: 102,
              padding: const EdgeInsets.only(top: 14.0),
              width: (MediaQuery.of(context).size.width / 3) - 16,
              decoration: BoxDecoration(
                border: widget.isUtilitiesSelected
                    ? Border.fromBorderSide(
                        BorderSide(color: colors.button.turquoise.main),
                      )
                    : null,
                borderRadius: const BorderRadius.all(
                  Radius.circular(8),
                ),
                color: AppTheme.turquoise0Main.withOpacity(0.1),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: packageTypes?.data?[1].image,
                      color: colors.button.turquoise.main,
                      width: 40,
                      height: 40,
                    ),
                  ),
                  Text(
                    AppMessages().getCopy(packageTypes?.data?[1].name),
                    style: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w600,
                      color: colors.button.turquoise.main,
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (canRegisterCorrespondence)
          GestureDetector(
            onTap: () {
              widget.selectCorrespon(packageTypes?.data?[2].id);
            },
            child: Container(
              height: 102,
              padding: const EdgeInsets.only(top: 14.0),
              width: (MediaQuery.of(context).size.width / 3) - 16,
              decoration: BoxDecoration(
                border: widget.isCorresponSelected
                    ? Border.fromBorderSide(
                        BorderSide(color: colors.button.turquoise.main),
                      )
                    : null,
                borderRadius: const BorderRadius.all(
                  Radius.circular(8),
                ),
                color: AppTheme.turquoise0Main.withOpacity(0.1),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: NvImage(
                      imageUrl: packageTypes?.data?[2].image,
                      color: colors.button.turquoise.main,
                      width: 40,
                      height: 40,
                    ),
                  ),
                  Text(
                    AppMessages().getCopy(packageTypes?.data?[2].name),
                    style: TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w600,
                      color: colors.button.turquoise.main,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
