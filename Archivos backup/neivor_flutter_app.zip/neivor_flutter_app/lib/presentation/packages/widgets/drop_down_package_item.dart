import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/domain/models/packages/package_data_response.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/drop_down_item.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/global_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

class DropDownPackageDetail extends StatefulWidget {
  final List<PackageDataObject>? dataListPackages;

  const DropDownPackageDetail({
    Key? key,
    required this.dataListPackages,
  }) : super(key: key);

  @override
  State<DropDownPackageDetail> createState() => _DropDownPackageDetailState();
}

class _DropDownPackageDetailState extends State<DropDownPackageDetail> {
  var _dataList;
  final copy = AppMessages().getCopy;

  @override
  void initState() {
    context.loaderOverlay.show();
    _dataList = packageDataToListItemTransform(
      widget.dataListPackages?.length ?? 0,
      widget.dataListPackages ?? [],
    );
    setState(() {});
    super.initState();
    context.loaderOverlay.hide();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        child: _buildPanel(),
      ),
    );
  }

  Widget _buildPanel() {
    return ExpansionPanelList(
      expansionCallback: (int index, bool isExpanded) {
        setState(() {
          _dataList[index].isExpanded = !isExpanded;
        });
      },
      children: _dataList?.map<ExpansionPanel>((Item item) {
        return ExpansionPanel(
          headerBuilder: (BuildContext context, bool isExpanded) {
            return ListTile(
              title: item.headerValue,
            );
          },
          body: ListTile(
            title: item.expandedValue,
            onTap: () {
              setState(() {
                _dataList
                    .removeWhere((Item currentItem) => item == currentItem);
              });
            },
          ),
          isExpanded: item.isExpanded,
        );
      }).toList(),
    );
  }

  // Transforms the list of PackageDataObject into a list of items
  // to be used for the widget_buildPanel
  // ignore: long-method
  List<Item>? packageDataToListItemTransform(
    int numberOfItems,
    List<PackageDataObject> listObj,
  ) {
    List<Item> itemListGenerate = [];
    const mailType = 3;
    for (var i = 0; i < numberOfItems; i++) {
      itemListGenerate.add(Item(
        headerValue: Row(
          children: [
            NvImage(
              imageUrl: listObj[i].idPackType != mailType
                  ? listObj[i].imageDistributor?.replaceAll('.svg', '.png')
                  : 'ds/icons/mail-option.svg',
            ),
            const SizedBox(
              width: 8,
            ),
            Expanded(
              //width: 100,
              child: Text(
                AppMessages().getCopy(listObj[i].packTypeName),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(
              width: 8,
            ),
            const Icon(Icons.calendar_month_outlined),
            const SizedBox(
              width: 8,
            ),
            Text(
              GlobalUtils().parseDate(listObj[i].dateCreation, "dd/MM/yyyy"),
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        expandedValue: ListTile(
          title: Column(
            children: [
              Row(
                children: [
                  const NvImage(
                    imageUrl: 'ds/icons/code-icon.svg',
                    width: 16,
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Text(
                    //'Código: ${listObj[i].id}',
                    '${copy('packages.code')}: ${listObj[i].id}',
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const NvImage(
                        imageUrl: 'ds/icons/dialog-chat.svg',
                        width: 16,
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Text(
                        copy('packages.comment'),
                        //'Comentario: ',
                        style: const TextStyle(
                          letterSpacing: 0.7,
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          color: AppTheme.black0Main,
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(
                      listObj[i].comment ?? '',
                      style: const TextStyle(
                        letterSpacing: 0.7,
                        fontFamily: 'Jost',
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        color: AppTheme.black0Main,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        id: listObj[i].id,
        dateCreation: listObj[i].dateCreation,
        totalRow: listObj[i].totalRow,
        idPackType: listObj[i].idPackType,
        idServicePoint: listObj[i].idServicePoint,
        idDistributor: listObj[i].idDistributor,
        comment: listObj[i].comment,
        packTypeName: listObj[i].packTypeName,
        isExpanded: i == 0 ? true : false,
      ));
    }

    return itemListGenerate;
  }
}
