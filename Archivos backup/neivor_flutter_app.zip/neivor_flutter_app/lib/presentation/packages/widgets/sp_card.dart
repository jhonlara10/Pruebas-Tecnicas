import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class ServicePointCard extends StatelessWidget {
  ServicePointCard({
    Key? key,
    required this.spName,
    required this.cantPackages,
  }) : super(key: key);

  final String? spName;
  final int? cantPackages;
  final copy = AppMessages().getCopy;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    return Container(
      height: 93,
      decoration: BoxDecoration(
        color: colors.opacityBackgrounds.indigoBlueOpacity,
        borderRadius: const BorderRadius.all(Radius.circular(8)),
      ),
      child: Padding(
        padding: const EdgeInsets.only(
          left: 16,
          right: 2,
          top: 0,
          bottom: 8,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              children: [
                Text(
                  '${copy('packages.apartment')}: ',
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    letterSpacing: .7,
                    fontSize: 20,
                    height: 1.75,
                  ),
                ),
                Expanded(
                  child: Text(
                    '$spName',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w300,
                      fontSize: 22,
                      height: 1.75,
                    ),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                // "Paquetes por entregar: ",
                Text(
                  '${copy('packages.packages-to-be-delivered')}: ',
                  style: const TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                    height: 1.75,
                  ),
                ),
                Text(
                  '$cantPackages',
                  style: const TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 16,
                    height: 1.75,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
