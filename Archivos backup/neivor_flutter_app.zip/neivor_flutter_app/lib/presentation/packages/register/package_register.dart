import 'dart:async';

import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/packages/packages_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/packages/service_point_list_response.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/distributors.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/package_type_card.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/public_service_types.dart';
import 'package:neivor_flutter_app/presentation/packages/widgets/row_service_point.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

import '../../../domain/models/login/user.dart';
import '../../util/app_messages.dart';

class PackageRegister extends StatefulWidget {
  const PackageRegister({Key? key}) : super(key: key);

  @override
  State<PackageRegister> createState() => _PackageRegisterState();
}

class _PackageRegisterState extends State<PackageRegister> {
  Map<String, dynamic> formValues = {};
  User? currentProfileUser;
  bool isPackageSelected = false;
  bool isUtilitiesSelected = false;
  bool isCorresponSelected = false;
  List<ServicePointObject>? filterList = [];
  var inSearch = false;
  final textEditingController = TextEditingController();
  //Permissions: registrar paquete-registrar servicios públicos-registrar correspondencia
  bool canRegisterPackage = UserUtils().hasPermissionsTo(680);
  bool canRegisterService = UserUtils().hasPermissionsTo(682);
  bool canRegisterCorrespondence = UserUtils().hasPermissionsTo(681);

  @override
  void initState() {
    _wichFormShowFirst();
    super.initState();
    (() async {
      await getProfileCurrentUser();
      formValues = {
        "comment": "",
        "idDistributor": 0,
        "idEnterprise": currentProfileUser?.currentEnterprise?.id,
        "idPackState": 1,
        "idPackType": 1,
        "idServicePoint": 0,
        "userCreation": currentProfileUser?.id,
      };
    })();
  }

  void _wichFormShowFirst() {
    canRegisterPackage
        ? selectPackage(1)
        : canRegisterService
            ? selectUtilities(2)
            : selectCorrespon(3);
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final typo = AppThemeScope.of(context).typography;

    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'packages',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'packages',
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding:
                    const EdgeInsets.only(top: 24.0, left: 16.0, right: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppMessages().getCopy('packages.registration-info'),
                      style: typo.h2.semibold,
                      textAlign: TextAlign.start,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: const EdgeInsets.symmetric(vertical: 24.0),
                          child: Text(
                            AppMessages().getCopy('packages.package-type'),
                            style: typo.bd1.medium,
                            textAlign: TextAlign.start,
                          ),
                        ),
                        PackageTypeCard(
                          isPackageSelected: isPackageSelected,
                          isUtilitiesSelected: isUtilitiesSelected,
                          isCorresponSelected: isCorresponSelected,
                          selectPackage: selectPackage,
                          selectUtilities: selectUtilities,
                          selectCorrespon: selectCorrespon,
                        ),
                      ],
                    ),
                    if (isPackageSelected || isCorresponSelected)
                      Container(
                        margin: const EdgeInsets.only(top: 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${AppMessages().getCopy('packages.search-apartment')} *',
                              style: typo.bd1.medium,
                            ),
                            TextFormField(
                              autofocus: false,
                              onFieldSubmitted: (value) {
                                if (value != "") {
                                  inSearch = true;
                                  findServicePointByName(value);
                                } else {
                                  setState(() {
                                    filterList = [];
                                    inSearch = false;
                                  });
                                }
                              },
                              controller: textEditingController,
                              decoration: const InputDecoration(
                                prefixIcon: Icon(Icons.search),
                              ),
                            ),
                            ListView.builder(
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              physics: const BouncingScrollPhysics(),
                              itemCount: filterList?.length ?? 0,
                              itemBuilder: (context, index) {
                                return RowServicePoint(
                                  servicePointClicked: servicePointClicked,
                                  servicePointObj: filterList![index],
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    if (isPackageSelected)
                      Container(
                        margin: const EdgeInsets.only(top: 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${AppMessages().getCopy('packages.supplier')} *',
                              style: typo.bd1.medium,
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            Distributors(
                              selectIdDistributor: selectIdDistributor,
                            ),
                          ],
                        ),
                      ),
                    if (isPackageSelected || isCorresponSelected)
                      Container(
                        margin: const EdgeInsets.only(
                          top: 16.0,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              AppMessages().getCopy('packages.comments'),
                              style: typo.bd1.medium,
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            TextField(
                              keyboardType: TextInputType.multiline,
                              textInputAction: TextInputAction.newline,
                              minLines: 2,
                              maxLines: 5,
                              decoration: InputDecoration(
                                hintStyle: const TextStyle(
                                  fontStyle: FontStyle.normal,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16.0,
                                  vertical: 8.0,
                                ),
                                hintText: AppMessages()
                                    .getCopy('packages.comment-ex'),
                              ),
                              onChanged: (value) {
                                setComment(value);
                              },
                            ),
                          ],
                        ),
                      ),
                    if (isUtilitiesSelected)
                      Container(
                        margin: const EdgeInsets.only(top: 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${AppMessages().getCopy('packages.public-service-type')} *',
                              style: typo.bd1.medium,
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            PublicServiceTypes(
                              selectIdDistributor: selectIdDistributor,
                            ),
                            const SizedBox(
                              height: 16.0,
                            ),
                            Container(
                              decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                              ),
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                    left: BorderSide(
                                      color: colors.secondary.indigoBlue.main,
                                      width: 8,
                                    ),
                                  ),
                                  color: colors.secondary.indigoBlue.v1,
                                ),
                                width: MediaQuery.of(context).size.width,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 16.0,
                                  horizontal: 16.0,
                                ),
                                child: Text(
                                  AppMessages().getCopy(
                                    'packages.plublic-services-massive-notification',
                                  ),
                                  overflow: TextOverflow.clip,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Container(
          margin: const EdgeInsets.only(top: 24.0),
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border(
              top: BorderSide(
                width: 1,
                color: colors.primary.black.v2,
                style: BorderStyle.solid,
              ),
            ),
          ),
          child: NvButton(
            label: AppMessages().getCopy('packages.register'),
            action: () {
              validationPackType(formValues) ? createPackage() : showAlert();
            },
          ),
        ),
      ),
    );
  }

  /// Get the current user data to the profile.
  ///
  /// Return:
  /// A object with the profile data.
  ///
  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    // ignore: no-empty-block
    setState(() {});
  }

  /// Set comment.
  ///
  /// Return:
  /// Change value to the comment.
  ///
  setComment(String? text) {
    setState(() {
      formValues['comment'] = text;
    });
  }

  /// Set idDistributor.
  ///
  /// Return:
  /// Change value to the idDistributor for the distributor selected.
  ///
  selectIdDistributor(int? id) {
    setState(() {
      formValues['idDistributor'] = id;
    });
  }

  /// Set the flag state true to the isPackageSelected.
  ///
  /// Return:
  /// Change state to the flags to type package selected.
  ///
  selectPackage(int? id) {
    setState(() {
      isPackageSelected = true;
      isUtilitiesSelected = false;
      isCorresponSelected = false;
      formValues['idPackType'] = id;
      formValues['idPackState'] = id;
    });
  }

  /// Set the flag state true to the isUtilitiesSelected.
  ///
  /// Return:
  /// Change state to the flags to type package selected.
  ///
  selectUtilities(int? id) {
    setState(() {
      isUtilitiesSelected = true;
      isPackageSelected = false;
      isCorresponSelected = false;
      formValues['idPackType'] = id;
      formValues['idPackState'] = id;
    });
  }

  /// Set the flag state true to the isCorresponSelected.
  ///
  /// Return:
  /// Change state to the flags to type package selected.
  ///
  selectCorrespon(int? id) {
    setState(() {
      isCorresponSelected = true;
      isUtilitiesSelected = false;
      isPackageSelected = false;
      formValues['idPackType'] = id;
      formValues['idPackType'] = id;
    });
  }

  /// Set the flag state true to the isCorresponSelected.
  ///
  /// Return:
  /// Change state to the flags to type package selected.
  ///
  createPackage() async {
    context.loaderOverlay.show();
    var response = await PackageRepository().createPackage(formValues);
    context.loaderOverlay.hide();
    if (response.success == true) {
      alertDialog(
        'success',
        //response.info?.message ?? '',
        AppMessages().getCopy('packages.success-registration'),
      );
    } else {
      alertDialog(
        'sucess',
        'error',
      );
    }
  }

  /// Show alert dialog with the response to create pack
  ///
  /// Return:
  /// Modal alert.
  ///
  alertDialog(String type, String message) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
          Navigator.pushReplacementNamed(context, "packages");
        });
        return NvAlert(
          type: type,
          content: message,
        );
      },
    );
  }

  findServicePointByName(String name) async {
    context.loaderOverlay.show();
    var newServicePointList =
        await PackageRepository().getServicePointListByName(name);
    setState(() {
      filterList = newServicePointList;
      context.loaderOverlay.hide();
    });
  }

  servicePointClicked(ServicePointObject servicePointObject) {
    formValues["idServicePoint"] = servicePointObject.id;
    textEditingController.text =
        '${servicePointObject.operationZone?.name} - ${servicePointObject.name}';
    setState(() {
      filterList = [];
    });
  }

  /// validates the information required for each type of package
  ///
  /// Args:
  ///    [formValues] an object with all properties needed for the service
  ///
  /// Returns:
  ///     [boolean] true if the object pass the validation
  ///
  bool validationPackType(formValues) {
    switch (formValues['idPackType']) {
      case 1:
        return formValues['idServicePoint'] != 0 &&
                formValues['idDistributor'] != 0
            ? true
            : false;

      case 2:
        return formValues['idDistributor'] > 2 &&
                formValues['idDistributor'] != 7
            ? true
            : false;

      default:
        //idDistributor "1" valor quemado para que el servicio responda success, idPackType 3 no ocupa seleccionar idDistributor.
        formValues['idDistributor'] = 1;
        return formValues['idServicePoint'] != 0 ? true : false;
    }
  }

  showAlert() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: 'warning',
          //'Los campos con * son obligatorios',
          content: AppMessages().getCopy('packages.required-fields'),
        );
      },
    );
  }
}
