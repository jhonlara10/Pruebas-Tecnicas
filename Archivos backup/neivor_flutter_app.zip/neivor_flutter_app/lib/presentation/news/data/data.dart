Map<String, dynamic> formValuesInitial = {
  'name': '',
  'description': '',
  'idNoticeType': 0,
  'idNoticePublicationType': 3,
  'idMailOption': 1,
  'enterpriseName': 'BETA SPEI',
  'idEnterprise': 962,
  'userSessionFirstName': 'Roman 1',
  'state': 1,
  'image': '',
  'userCreation': 985412,
  'videoUri': '',
};
