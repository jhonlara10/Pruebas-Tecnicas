import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/news/news_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/news/delete_new_request.dart';
import 'package:neivor_flutter_app/domain/models/news/list_news_response.dart';
import 'package:neivor_flutter_app/presentation/news/widgets/news_appbar.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';

import '../../../widgets/nv_alert.dart';
import '../../../widgets/nv_video_player.dart';
import '../../util/app_messages.dart';

class ShowNew extends StatefulWidget {
  final ListNewsResponse? newSelected;

  const ShowNew({Key? key, this.newSelected}) : super(key: key);

  @override
  _ShowNewState createState() => _ShowNewState();
}

class _ShowNewState extends State<ShowNew> {
  User? currentProfileUser;
  User? currentUser;
  String? creationDate;
  String? newType;
  int? idNoticePublicationType;
  String? videoURL;
  String image =
      'https://images.pexels.com/photos/317356/pexels-photo-317356.jpeg?cs=srgb&dl=pexels-lukas-317356.jpg&fm=jpg';
  bool isAdminRole = false;

  /// State initializer.
  @override
  void initState() {
    (() async {
      await getProfileCurrentUser();
      isAdminRole = await UserUtils().isAdminUser();
      sendGetNews();
    })();
    super.initState();
  }

  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    setState(() {});
  }

  sendGetNews() async {
    try {
      getDate(widget.newSelected?.dateCreation ?? 0);
      getNewType(widget.newSelected?.idNoticeType ?? 0);
      idNoticePublicationType = widget.newSelected?.idNoticePublicationType;
      videoURL = widget.newSelected?.videoUri;
      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  // ignore: long-method
  sendDeleteNew() async {
    try {
      // ignore: prefer_null_aware_operators
      var arrayOfStrings = widget.newSelected?.image != null
          ? widget.newSelected?.image?.split("/")
          : null;

      DeleteNewRequest data = DeleteNewRequest(
        fileNameToDelete: arrayOfStrings?.last,
        id: widget.newSelected?.id,
        idEnterprise: UserUtils.currentEnterprise?.id,
        userChange: UserUtils.currentUser?.id,
      );
      context.loaderOverlay.show();
      var deleteNewResponse = await deleteNew(data);
      context.loaderOverlay.hide();
      if (deleteNewResponse.successRequestNotice == true) {
        await showDialog(
          barrierDismissible: false,
          context: context,
          builder: (BuildContext context) {
            Future.delayed(const Duration(seconds: 3), () {
              Navigator.of(context).pop(true);
            });
            return const NvAlert(
              content: 'Eliminado exitoso\n Se ha eliminado la noticia',
              type: "success",
            );
          },
        );
        if (!mounted) return;
        Navigator.pushReplacementNamed(context, "home");
      } else {
        await showDialog(
          barrierDismissible: false,
          context: context,
          builder: (BuildContext context) {
            Future.delayed(const Duration(seconds: 3), () {
              Navigator.of(context).pop(true);
            });
            return NvAlert(
              content: AppMessages().getCopy('common.common-error'),
              type: "success",
            );
          },
        );
      }
    } catch (e) {
      log(e.toString());
    }
  }

  getDate(double? date) {
    int dateToInt = date?.toInt() ?? 0;
    creationDate =
        DateTime.fromMillisecondsSinceEpoch(dateToInt * 1000).toString();
  }

  // ignore: long-method
  getNewType(int? stateId) {
    switch (stateId) {
      case 1:
        newType = AppMessages().getCopy('news.public-service-cut');
        break;
      case 2:
        newType = AppMessages().getCopy('common.message');
        break;
      case 3:
        newType = AppMessages().getCopy('news.repair');
        break;
      case 4:
        newType = AppMessages().getCopy('news.information');
        break;
      case 5:
        newType = AppMessages().getCopy('news.generic');
        break;
      case 6:
        newType = AppMessages().getCopy('news.advertising');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NewsAppBar(
          isAdminRole: isAdminRole,
          title: AppMessages().getCopy('news.news'),
          sendDeleteNew: sendDeleteNew,
          newSelected: widget.newSelected,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                alignment: Alignment.topRight,
                children: [
                  if (idNoticePublicationType != 6)
                    NvImage(
                      imageUrl: widget.newSelected?.image,
                      isStatic: true,
                      width: double.infinity,
                      height: 260,
                    ),
                  if (idNoticePublicationType == 6)
                    NvVideoPlayer(
                      videoUrl: videoURL ?? '',
                    ),
                  Card(
                    color: AppTheme.iconSuccess,
                    margin: const EdgeInsets.only(top: 8.0, right: 8.0),
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                    ),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        vertical: 2.0,
                        horizontal: 8.0,
                      ),
                      child: Text(
                        newType ?? '',
                        style: const TextStyle(
                          color: AppTheme.grayArtic5,
                          fontSize: 12.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                margin:
                    const EdgeInsets.only(left: 12.0, right: 12.0, top: 16.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          widget.newSelected?.zyosUser?.name ?? '',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppTheme.black3,
                            fontSize: 14.0,
                          ),
                        ),
                        Text(
                          creationDate?.split(" ").first ?? '',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppTheme.black3,
                            fontSize: 14.0,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 8.0),
                      alignment: Alignment.topLeft,
                      child: Text(
                        widget.newSelected?.name ?? '',
                        textAlign: TextAlign.left,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.black5,
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                    Html(
                      data: widget.newSelected?.description ?? '',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
