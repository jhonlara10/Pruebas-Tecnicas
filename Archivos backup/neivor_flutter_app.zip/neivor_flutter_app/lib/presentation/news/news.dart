// ignore_for_file: use_build_context_synchronously

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/news/news_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/user.dart';
import 'package:neivor_flutter_app/domain/models/news/create_new_response.dart';
import 'package:neivor_flutter_app/domain/models/news/news.dart';
import 'package:neivor_flutter_app/presentation/news/data/data.dart';
import 'package:neivor_flutter_app/presentation/news/widgets/button.dart';
import 'package:neivor_flutter_app/presentation/news/widgets/drop_down.dart';
import 'package:neivor_flutter_app/presentation/news/widgets/input_group.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import '../../domain/models/news/list_news_response.dart';
import '../../widgets/widgets.dart';
import 'dart:io';

import '../util/app_messages.dart';

class News extends StatefulWidget {
  const News({Key? key}) : super(key: key);

  @override
  State<News> createState() => _NewsState();
}

class _NewsState extends State<News> {
  /// A variable that is assigned the value of the title to the notice.
  ListNewsResponse? args;
  User? currentProfileUser;
  String? newTitle;
  CreateNewResponse? createNewResponse;
  String? newBody;
  String? newCategory;
  String? newType;
  String? newVideo;
  String? newSend;
  XFile? image;
  final ImagePicker _picker = ImagePicker();
  String? imgAsBase64;
  NewData? newData;
  Map<String, dynamic> formValues = formValuesInitial;
  bool isSendEmail = false;
  bool isAddFileSwitched = false;
  bool isAddImageSelected = false;
  bool isAddVideoSelected = false;
  GlobalKey<FormState> newFormKey = GlobalKey<FormState>();
  final List<DropdownMenuItem<int>> categoryOptions = [
    DropdownMenuItem(
      value: 0,
      child: Text(AppMessages().getCopy('news.select-one')),
    ),
    DropdownMenuItem(
      value: 1,
      child: Text(AppMessages().getCopy('news.public-service-cut')),
    ),
    DropdownMenuItem(
      value: 2,
      child: Text(AppMessages().getCopy('common.message')),
    ),
    DropdownMenuItem(
      value: 3,
      child: Text(AppMessages().getCopy('news.repair')),
    ),
    DropdownMenuItem(
      value: 4,
      child: Text(AppMessages().getCopy('news.information')),
    ),
    DropdownMenuItem(
      value: 5,
      child: Text(AppMessages().getCopy('news.generic')),
    ),
    DropdownMenuItem(
      value: 6,
      child: Text(AppMessages().getCopy('news.advertising')),
    ),
  ];

  final copy = AppMessages().getCopy;

  /// State initializer.
  @override
  void initState() {
    (() async {
      await getProfileCurrentUser();
      initFormValues();
    })();
    super.initState();
  }

  /// Get the current user data to the profile.
  ///
  /// Return:
  /// A object with the profile data.
  ///
  getProfileCurrentUser() async {
    currentProfileUser = await User().getCurrentUser();
    // ignore: no-empty-block
    setState(() {});
  }

  /// Initializer form values.
  ///
  /// Return:
  /// A object with the initial values to formValues with profile data.
  ///
  // ignore: long-method
  initFormValues() {
    setState(() {
      formValues = {
        'name': '',
        'description': '',
        'idNoticeType': 0,
        'idNoticePublicationType': Constants.idtTextPublicationType,
        'idMailOption': 1,
        'enterpriseName': UserUtils.currentEnterprise?.name,
        'idEnterprise': UserUtils.currentEnterprise?.id,
        'userSessionFirstName': UserUtils.currentUser?.name,
        'state': 1,
        'image': '',
        'userCreation': UserUtils.currentUser?.id,
        'videoUri': '',
      };
      image = null;
    });
  }

  /// It takes the image path, reads the bytes, and encodes them into base64
  ///
  /// Return:
  /// Set the image variable with value bytes.
  ///
  imgToBase64() async {
    final Uint8List bytes;
    if (image != null) {
      //ignore: avoid-non-null-assertion
      bytes = await File(image!.path).readAsBytes();
      String base64Encoded = base64Encode(bytes);
      String prefix =
          //ignore: avoid-non-null-assertion
          "data:image/${image!.path.substring(image!.path.length - 3)};base64,";

      return prefix + base64Encoded;
    }
  }

  /// Picks an image from gallery
  ///
  /// Return:
  /// Set the image variable with the file from gallery.
  ///
  pickImage() async {
    image = await _picker.pickImage(source: ImageSource.gallery);
    // ignore: no-empty-block
    setState(() {});
  }

  /// Delete image selected
  ///
  /// Return:
  /// The image state set to null
  ///
  deleteImage() {
    setState(() {
      image = null;
    });
  }

  /// Change value to isAddImageSelected
  ///
  /// Return:
  /// The isAddImageSelected != state
  ///
  selectAddImageOption() {
    setState(() {
      isAddVideoSelected = false;
      isAddImageSelected = !isAddImageSelected;
      formValues['idNoticePublicationType'] = isAddImageSelected
          ? Constants.idImagePublicationType
          : Constants.idtTextPublicationType;
    });
  }

  /// Change value to isAddImageSelected
  ///
  /// Return:
  /// The isAddImageSelected != state
  ///
  selectAddVideoOption() {
    setState(() {
      isAddImageSelected = false;
      isAddVideoSelected = !isAddVideoSelected;
      formValues['idNoticePublicationType'] = isAddVideoSelected
          ? Constants.idVideoPublicationType
          : Constants.idtTextPublicationType;
    });
  }

  /// Validate the response to the create new.
  ///
  /// Return:
  /// A modals with validatios if the response is not true or redirecto to the new view.
  ///
  // ignore: long-method
  validateCreateNew() async {
    try {
      context.loaderOverlay.show();

      /// Send requesto to create new.
      createNewResponse = await createNew(formValues);
      context.loaderOverlay.hide();

      /// Validate response to request.
      if (createNewResponse?.successRequestNotice == true) {
        initFormValues();
        await showAlertDialog(
          copy('news.your-news-has-been-sucessfully-created'),
          'success',
          AppTheme.iconSuccess,
          Icons.done,
        );
        Navigator.pushReplacementNamed(context, "home");
      } else {
        showAlertDialog(
          createNewResponse?.message,
          'error',
          AppTheme.iconError,
          Icons.close_rounded,
        );
      }
    } catch (e) {
      showAlertDialog(
        copy('common.common-error'),
        'error',
        AppTheme.iconError,
        Icons.close_rounded,
      );
    }
  }

  /// Validate the image field and description field and send request to create new notice.
  ///
  /// Return:
  /// A modals with validatios or excute validateCreateNew method.
  ///
  // ignore: long-method
  createNewNotice() async {
    /// Validate if the image exist.
    if (formValues['idNoticePublicationType'] == 1 && image == null) {
      showAlertDialog(
        copy(
          'news.you-must-upload-an-image-for-the-selected-news-type',
        ),
        'error',
        AppTheme.iconError,
        Icons.close_rounded,
      );
    } else if (formValues['description'] == '') {
      showAlertDialog(
        copy('news.you-must-enter-a-description-for-the-news'),
        'error',
        AppTheme.iconError,
        Icons.close_rounded,
      );
    } else {
      /// Set image value in formValues.
      formValues['image'] = await imgToBase64();
      validateCreateNew();
    }
  }

  /// Show alert for validations and errors.
  ///
  /// Params:
  /// [String] message, description to the body alert.
  /// [String] type, option to styles to the icon.
  ///
  /// Return:
  /// A modal for errors and validations.
  ///
  // ignore: long-method
  showAlertDialog(
    String? message,
    String? type,
    Color alertIconColor,
    IconData iconData,
  ) async {
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        Future.delayed(const Duration(seconds: 3), () {
          Navigator.of(context).pop(true);
        });
        return AlertDialog(
          content: SingleChildScrollView(
            child: ListBody(
              children: [
                Icon(
                  iconData,
                  size: 60.0,
                  color: alertIconColor,
                ),
                Text(
                  message ?? '',
                  style: const TextStyle(color: AppTheme.black5),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Update form values with dropdown.
  ///
  /// Params:
  /// [String] value, key to the formValues.
  /// [int] value, option selected to the dropdown.
  ///
  /// Return:
  /// Refreshed state with formValues list.
  ///
  updateFormValues(String? key, int? value) {
    setState(() {
      formValues[(key ?? '')] = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return colors.primary.turquoise.v4;
    }

    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'home',
            (Route<dynamic> route) => false,
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin:
                    const EdgeInsets.only(top: 16.0, left: 12.0, right: 12.0),
                child: SingleChildScrollView(
                  child: Form(
                    key: newFormKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        NvText(
                          textHolder: copy('new.pots-new'),
                          fontFamily: 'Jost',
                          fontWeight: FontWeight.w600,
                          fontSize: 26,
                          color: colors.text.primary,
                        ),
                        const SizedBox(height: 26.0),
                        Dropdown(
                          labelName: 'idNoticeType',
                          formValues: formValues,
                          title: copy('news.category'),
                          options: categoryOptions,
                          setFunction: updateFormValues,
                          isRequired: true,
                        ),
                        InputGroup(
                          labelName: 'name',
                          title: copy('news.title'),
                          customHintText: copy('news.title-placeholder'),
                          formValues: formValues,
                          controller:
                              TextEditingController(text: formValues['name']),
                        ),
                        InputGroup(
                          labelName: 'description',
                          title: copy('news.news-label'),
                          customHintText: copy('news.description-hint-text'),
                          formValues: formValues,
                          controller: TextEditingController(
                            text: formValues['description'],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                NvText(
                                  textHolder: copy('news.add-photo-or-video'),
                                  fontFamily: 'Jost',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16.0,
                                  color: colors.text.primary,
                                ),
                                NvText(
                                  textHolder: copy('news.select-file'),
                                  fontFamily: 'Jost',
                                  fontWeight: FontWeight.w300,
                                  fontSize: 14.0,
                                  color: colors.text.primary,
                                ),
                              ],
                            ),
                            Switch(
                              activeColor: AppTheme.turquoise4,
                              value: isAddFileSwitched,
                              onChanged: (value) => setState(() {
                                isAddFileSwitched = value;
                              }),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 12.0,
                        ),
                        if (isAddFileSwitched)
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                onTap: selectAddImageOption,
                                child: Container(
                                  width:
                                      MediaQuery.of(context).size.height * 0.22,
                                  height: 96,
                                  decoration: isAddImageSelected
                                      ? BoxDecoration(
                                          color: colors.primary.turquoise.v1,
                                          border: Border.all(
                                            color: colors.primary.turquoise.v4,
                                          ),
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(4),
                                          ),
                                        )
                                      : BoxDecoration(
                                          color: colors.primary.arcticGray.v5,
                                        ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      NvImage(
                                        width: 40.0,
                                        imageUrl: 'ds/icons/images-photos.svg',
                                        color: isAddImageSelected
                                            ? colors.primary.turquoise.v4
                                            : colors.text.primary,
                                      ),
                                      const SizedBox(
                                        height: 8.0,
                                      ),
                                      NvText(
                                        textHolder: copy('news.photo'),
                                        fontFamily: 'Jost',
                                        fontWeight: isAddImageSelected
                                            ? FontWeight.w500
                                            : FontWeight.w300,
                                        fontSize: 12.0,
                                        color: isAddImageSelected
                                            ? colors.primary.turquoise.v4
                                            : colors.text.primary,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: selectAddVideoOption,
                                child: Container(
                                  height: 96,
                                  width:
                                      MediaQuery.of(context).size.height * 0.22,
                                  decoration: isAddVideoSelected
                                      ? BoxDecoration(
                                          color: colors.primary.turquoise.v1,
                                          border: Border.all(
                                            color: colors.primary.turquoise.v4,
                                          ),
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(4),
                                          ),
                                        )
                                      : BoxDecoration(
                                          color: colors.primary.arcticGray.v5,
                                        ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      NvImage(
                                        width: 40.0,
                                        imageUrl: 'ds/icons/movie.svg',
                                        color: isAddVideoSelected
                                            ? colors.primary.turquoise.v4
                                            : colors.text.primary,
                                      ),
                                      const SizedBox(
                                        height: 8.0,
                                      ),
                                      NvText(
                                        textHolder: copy('news.video'),
                                        fontFamily: 'Jost',
                                        fontWeight: isAddVideoSelected
                                            ? FontWeight.w500
                                            : FontWeight.w300,
                                        fontSize: 12.0,
                                        color: isAddVideoSelected
                                            ? colors.primary.turquoise.v4
                                            : colors.text.primary,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        const SizedBox(
                          height: 16.0,
                        ),
                        if (image != null &&
                            formValues['idNoticePublicationType'] ==
                                Constants.idImagePublicationType)
                          Container(
                            margin: const EdgeInsets.only(bottom: 8.0),
                            padding: const EdgeInsets.all(6.0),
                            decoration: const BoxDecoration(
                              border: Border.fromBorderSide(
                                BorderSide(color: AppTheme.black1, width: 1.0),
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(6.0)),
                            ),
                            child: Image.file(
                              //ignore: avoid-non-null-assertion
                              File(image!.path),
                              fit: BoxFit.cover,
                            ),
                          ),
                        if (isAddImageSelected)
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                onTap: pickImage,
                                child: Container(
                                  width: image != null
                                      ? MediaQuery.of(context).size.width * 0.7
                                      : MediaQuery.of(context).size.width *
                                          0.93,
                                  height: 40.0,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: colors.primary.turquoise.v3,
                                    ),
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(4.0),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const NvImage(
                                        width: 24,
                                        imageUrl:
                                            'ds/icons/add-images-photos.svg',
                                      ),
                                      const SizedBox(
                                        width: 16.0,
                                      ),
                                      NvText(
                                        textHolder: image != null
                                            ? copy('news.replace-photo')
                                            : copy('news.add-photo'),
                                        fontFamily: 'Jost',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 12,
                                        color: colors.primary.turquoise.v4,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              if (image != null)
                                GestureDetector(
                                  onTap: deleteImage,
                                  child: Container(
                                    height: 40.0,
                                    width: 56.0,
                                    padding: const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: colors.primary.arcticGray.v4,
                                      ),
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(4.0),
                                      ),
                                    ),
                                    child: const NvImage(
                                      imageUrl: '/ds/icons/trash.svg',
                                      width: 24,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        if (isAddVideoSelected)
                          InputGroup(
                            labelName: 'videoUri',
                            title: 'URL',
                            customHintText: 'URL',
                            formValues: formValues,
                            controller: TextEditingController(
                              text: formValues['videoUri'],
                            ),
                          ),
                        const SizedBox(
                          height: 12.0,
                        ),
                        Row(
                          children: [
                            NvText(
                              textHolder: copy('news.notify-by-email'),
                              fontFamily: 'Jost',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              color: colors.text.primary,
                            ),
                            Checkbox(
                              checkColor: Colors.white,
                              fillColor:
                                  MaterialStateProperty.resolveWith(getColor),
                              value: isSendEmail,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(4.0),
                                ),
                              ),
                              // ignore: prefer-extracting-callbacks
                              onChanged: (bool? value) {
                                setState(() {
                                  isSendEmail = value!;
                                  formValues['idMailOption'] = value ? 2 : 1;
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 8.0,
              ),
              Button(
                title: copy('news.to-post'),
                formKey: newFormKey,
                action: createNewNotice,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
