import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

class Button extends StatelessWidget {
  const Button({
    Key? key,
    required this.formKey,
    required this.action,
    required this.title,
  }) : super(key: key);

  final GlobalKey<FormState> formKey;
  final VoidCallback action;
  final String title;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return Container(
      margin: const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 16),
      padding: const EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: colors.primary.arcticGray.main, width: 1.0),
        ),
      ),
      child: Column(
        children: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              minimumSize: const Size.fromHeight(48),
            ),
            onPressed: () {
              // Respond to button press.
              //ignore: avoid-non-null-assertion
              if (formKey.currentState!.validate()) {
                // If the form is valid, display a snackbar. In the real world,
                // you'd often call a server or save the information in a database.
                action();
              }
            },
            child: NvText(
              textHolder: title,
              fontFamily: 'Jost',
              fontWeight: FontWeight.w500,
              fontSize: 16,
              color: colors.primary.arcticGray.v1,
            ),
          ),
        ],
      ),
    );
  }
}
