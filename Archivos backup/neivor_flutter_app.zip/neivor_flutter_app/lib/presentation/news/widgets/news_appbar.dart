import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/themes.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_image.dart';
import '../../../domain/models/news/list_news_response.dart';
import '../../../widgets/nv_text.dart';

class NewsAppBar extends StatelessWidget with PreferredSizeWidget {
  const NewsAppBar({
    Key? key,
    this.title,
    this.elevation,
    this.actions,
    this.newSelected,
    required this.sendDeleteNew,
    required this.isAdminRole,
  }) : super(key: key);

  final String? title;
  final double? elevation;
  final List<Widget>? actions;
  final Function sendDeleteNew;
  final ListNewsResponse? newSelected;
  final bool isAdminRole;

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;

    return AppBar(
      title: Text(
        AppMessages().getCopy('page.app.labelDetailAppTitle'),
      ),
      leading: GestureDetector(
        onTap: () => Navigator.pushNamedAndRemoveUntil(
          context,
          'home',
          (Route<dynamic> route) => false,
        ),
        child: Transform.translate(
          offset: const Offset(10, 0),
          child: const CircleAvatar(
            backgroundColor: AppTheme.grayBackIcon,
            radius: 75,
            child: Icon(
              Icons.keyboard_backspace,
              color: AppTheme.black0Main,
            ),
          ),
        ),
      ),
      actions: [
        if (UserUtils().hasPermissionsTo(20) ||
            UserUtils().hasPermissionsTo(18))
          PopupMenuButton(
            // ignore: prefer-extracting-callbacks
            itemBuilder: (context) {
              return [
                if (UserUtils().hasPermissionsTo(18))
                  PopupMenuItem<int>(
                    value: 0,
                    child: Text(
                      AppMessages().getCopy('common.edit'),
                      style: TextStyle(
                        fontFamily: "Jost",
                        color: colors.primary.black.main,
                      ),
                    ),
                  ),
                if (UserUtils().hasPermissionsTo(20))
                  PopupMenuItem<int>(
                    value: 1,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: colors.primary.arcticGray.v5,
                        padding: const EdgeInsets.all(0),
                        minimumSize: const Size(20, 20),
                      ),
                      child: Text(
                        'Eliminar',
                        style: TextStyle(
                          fontFamily: "Jost",
                          color: colors.primary.black.main,
                          fontWeight: FontWeight.w400,
                          fontSize: 16,
                        ),
                      ),
                      // ignore: prefer-extracting-callbacks
                      onPressed: () {
                        showModalBottomSheet<void>(
                          context: context,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(25.0),
                            ),
                          ),
                          builder: (BuildContext context) {
                            return Container(
                              decoration: BoxDecoration(
                                color: colors.primary.arcticGray.v5,
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(25),
                                  topRight: Radius.circular(25),
                                ),
                              ),
                              height: 320.0,
                              width: double.infinity,
                              padding: const EdgeInsets.only(
                                top: 24.0,
                                left: 16.0,
                                right: 16.0,
                              ),
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const NvImage(
                                      imageUrl: '/ds/icons/trash.svg',
                                    ),
                                    NvText(
                                      textHolder:
                                          '¿Deseas eliminar esta noticia?',
                                      fontFamily: 'Jost',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: colors.primary.black.main,
                                    ),
                                    const SizedBox(
                                      height: 8.0,
                                    ),
                                    NvText(
                                      textHolder:
                                          'Si eliminas esta noticia ya no se visualizará en el',
                                      fontFamily: 'Jost',
                                      fontWeight: FontWeight.normal,
                                      fontSize: 16,
                                      color: colors.primary.black.main,
                                    ),
                                    NvText(
                                      textHolder: 'home de la app',
                                      fontFamily: 'Jost',
                                      fontWeight: FontWeight.normal,
                                      fontSize: 16,
                                      color: colors.primary.black.main,
                                    ),
                                    const SizedBox(
                                      height: 24.0,
                                    ),
                                    NvButton(
                                      label: 'Eliminar',
                                      action: () {
                                        sendDeleteNew();
                                        Navigator.pop(context);
                                      },
                                    ),
                                    const SizedBox(
                                      height: 8.0,
                                    ),
                                    NvButton(
                                      //"Cancelar",
                                      label: AppMessages()
                                          .getCopy('common.cancel'),
                                      action: () => Navigator.pop(context),
                                      variant: 'secondary',
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
              ];
            },
            // ignore: prefer-extracting-callbacks
            onSelected: (value) {
              if (value == 0) {
                Navigator.pushReplacementNamed(
                  context,
                  "editNew",
                  arguments: newSelected,
                );
              } else {
                sendDeleteNew();
              }
            },
          ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
