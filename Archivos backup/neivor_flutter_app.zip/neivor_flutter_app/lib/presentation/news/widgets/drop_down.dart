import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';

class Dropdown extends StatelessWidget {
  final String? title;
  final List<DropdownMenuItem<int>>? options;
  final String labelName;
  final Map<String, dynamic> formValues;
  final Function setFunction;
  final bool? disabled;
  final bool isRequired;

  const Dropdown({
    Key? key,
    this.title,
    this.options,
    this.disabled,
    this.isRequired = false,
    required this.labelName,
    required this.formValues,
    required this.setFunction,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int? dropdownValue = formValues[labelName] ?? 0;

    final copy = AppMessages().getCopy;
    final colors = AppThemeScope.of(context).colors;

    const double textMd = 16.0;

    return Container(
      margin: const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RichText(
            text: TextSpan(
              text: isRequired ? '* ' : '',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: colors.primary.coral.main,
              ),
              children: <TextSpan>[
                TextSpan(
                  text: title ?? "",
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: colors.text.primary,
                    fontFamily: 'Jost',
                    fontSize: textMd,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          DropdownButtonHideUnderline(
            child: DropdownButtonFormField(
              icon: const Icon(Icons.arrow_drop_down),
              isExpanded: true,
              value: dropdownValue,
              style: TextStyle(
                color: colors.text.primary,
                fontSize: 16,
              ),
              onChanged: disabled == true
                  ? null
                  : (int? newVal) {
                      dropdownValue = newVal;
                      setFunction(labelName, newVal);
                    },
              items: options,
              validator: (value) => dropdownValue == 0
                  ? copy('common.default-text-validation')
                  : null,
              decoration: InputDecoration(
                isDense: true,
                enabledBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(width: 1, color: colors.primary.black.v1),
                  borderRadius: const BorderRadius.all(Radius.circular(6)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(width: 1, color: colors.primary.black.v1),
                  borderRadius: const BorderRadius.all(Radius.circular(6)),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 8.5, horizontal: 10.0),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
