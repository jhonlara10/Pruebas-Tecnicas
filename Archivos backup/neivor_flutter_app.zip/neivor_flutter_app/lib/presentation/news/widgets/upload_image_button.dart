import 'package:flutter/material.dart';

class UploadImagedButton extends StatelessWidget {
  final Function imagePicker;

  const UploadImagedButton({
    Key? key,
    required this.imagePicker,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (() {
        imagePicker();
      }),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16.0),
        child: Row(
          children: const [
            Icon(
              Icons.camera_alt,
            ),
            Text(
              "Cargar imagen",
              style: TextStyle(fontSize: 16.0),
            ),
          ],
        ),
      ),
    );
  }
}
