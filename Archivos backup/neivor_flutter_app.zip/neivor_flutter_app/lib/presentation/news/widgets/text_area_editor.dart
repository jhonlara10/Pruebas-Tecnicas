import 'package:flutter/material.dart';

import '../../../themes/app_theme.dart';

class TextAreaEditor extends StatelessWidget {
  final TextEditingController controller;
  final String? labelName;
  final Map<String, dynamic> formValues;
  final String? title;

  const TextAreaEditor({
    Key? key,
    required this.controller,
    required this.labelName,
    required this.formValues,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title ?? '',
            style: const TextStyle(
              fontSize: 16,
              color: AppTheme.black0Main,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 8.0),
            height: 170.0,
            child: TextFormField(
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Este campo es requerido';
                }
                return null;
              },
              style: const TextStyle(color: AppTheme.black0Main),
              controller: controller,
              onChanged: (value) {
                formValues[labelName?.toLowerCase() ?? ''] = value;
              },
              decoration: const InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 180.0, horizontal: 16),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 1, color: AppTheme.black3),
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(width: 1, color: AppTheme.coral0Main),
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
