import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import '../../../themes/app_theme.dart';
import '../../util/app_messages.dart';

class InputGroup extends StatefulWidget {
  final Map<String, dynamic> formValues;
  final TextEditingController controller;
  final String? labelName;
  final String? title;
  final String? customHintText;
  const InputGroup({
    Key? key,
    required this.formValues,
    required this.controller,
    required this.labelName,
    required this.title,
    required this.customHintText,
  }) : super(key: key);

  @override
  State<InputGroup> createState() => _InputGroupState();
}

class _InputGroupState extends State<InputGroup> {
  /// State initializer.
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    final copy = AppMessages().getCopy;
    widget.controller.selection = TextSelection.fromPosition(
      TextPosition(offset: widget.controller.text.length),
    );

    const double textMd = 16.0;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RichText(
            text: TextSpan(
              text: '* ',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: colors.primary.coral.main,
              ),
              children: <TextSpan>[
                TextSpan(
                  text: widget.title ?? '',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: colors.text.primary,
                    fontFamily: 'Jost',
                    fontSize: textMd,
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 8.0),
            // Height: 40,.
            child: TextFormField(
              controller: widget.controller,
              onChanged: (value) {
                widget.formValues[widget.labelName ?? ''] = value;
              },
              style: TextStyle(
                fontSize: 16,
                color: colors.text.primary,
              ),
              maxLines: widget.labelName == 'description' ? 4 : null,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return copy('common.default-text-validation');
                }
                return null;
              },
              decoration: InputDecoration(
                hintText: widget.customHintText ?? '',
                hintStyle: TextStyle(
                  color: colors.text.placeholders,
                  fontFamily: 'Jost',
                  fontWeight: FontWeight.w300,
                ),
                isDense: true,
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 8.5, horizontal: 10),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    width: 1,
                    color: colors.primary.black.v1,
                  ),
                  borderRadius: const BorderRadius.all(Radius.circular(6)),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    width: 1,
                    color: colors.primary.coral.main,
                  ),
                  borderRadius: const BorderRadius.all(Radius.circular(6)),
                ),
                // focusedErrorBorder: OutlineInputBorder(
                //   borderSide:
                //       const BorderSide(width: 1, color: AppTheme.coral0Main),
                //   borderRadius: BorderRadius.circular(6),
                // ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(width: 1, color: AppTheme.coral0Main),
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
