import 'package:flutter/material.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';

import '../../../themes/app_theme.dart';

class InlineGroupInput extends StatefulWidget {
  final TextEditingController controller;
  final String? labelName;
  final String? title;
  final Map<String, dynamic> formValues;

  const InlineGroupInput({
    Key? key,
    required this.controller,
    required this.formValues,
    required this.labelName,
    required this.title,
  }) : super(key: key);

  @override
  State<InlineGroupInput> createState() => _InlineGroupInputState();
}

class _InlineGroupInputState extends State<InlineGroupInput> {
  @override
  Widget build(BuildContext context) {
    // ignore: todo
    // TODO: implement build
    return Container(
      margin: const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 16),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Flexible(
          child: Text(
            widget.title ?? '',
            style: const TextStyle(
              fontSize: 16,
              color: AppTheme.black0Main,
            ),
          ),
        ),
        Flexible(
          child: TextFormField(
            style: const TextStyle(
              fontSize: 16.0,
              color: AppTheme.black0Main,
            ),
            controller: widget.controller,
            onChanged: (value) {
              widget.formValues[widget.labelName ?? ''] = value;
            },
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Este campo es requerido';
              } else if (!RegExp(Constants.youtubeAndVimeoRegexExpression)
                  .hasMatch(value)) {
                return "El link no es valido";
              }
              return null;
            },
            decoration: const InputDecoration(
              isDense: true,
              contentPadding:
                  EdgeInsets.symmetric(vertical: 8.5, horizontal: 10),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 1, color: AppTheme.black3),
                borderRadius: BorderRadius.all(Radius.circular(6)),
              ),
              errorBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 1, color: AppTheme.coral0Main),
                borderRadius: BorderRadius.all(Radius.circular(6)),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 1, color: AppTheme.coral0Main),
                borderRadius: BorderRadius.all(Radius.circular(6)),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
