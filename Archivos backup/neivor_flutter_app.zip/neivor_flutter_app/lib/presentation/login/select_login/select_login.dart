import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/login/login_repository_impl.dart';
import 'package:neivor_flutter_app/presentation/login/login.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/app_urls.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/themes/app_theme.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'dart:async';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:neivor_flutter_app/domain/models/login/google_sign_in_request.dart';
import 'package:neivor_flutter_app/domain/models/login/login_response.dart';
import 'package:neivor_flutter_app/widgets/nv_alert.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SelectLogin extends StatefulWidget {
  const SelectLogin({Key? key}) : super(key: key);

  @override
  State<SelectLogin> createState() => _SelectLoginState();
}

class _SelectLoginState extends State<SelectLogin> {
  final loginRepository = LoginRepositoryImpl();
  String strengthenBonds = "";
  // ignore: prefer-correct-identifier-length
  bool isIOSGoogleButtonEnabled = true;
  int pressed = 0;
  bool secretSetting = false;

  @override
  void initState() {
    AppUrls().getPreferences();
    getCopies();
    super.initState();
  }

  getCopies() async {
    strengthenBonds = await AppMessages().getMessage('welcome.strengthenBonds');
    isIOSGoogleButtonEnabled =
        AppUrls().getProperty("api.ios.showGoogleSocialButton") == "true"
            ? true
            : false;
    setState(() {});
  }

  GoogleSignInRequest prepareGoogleLoginRequest(
    GoogleSignInAuthentication? googleSignInAuthentication,
    GoogleSignInAccount? googleSignInAccount,
    String token,
  ) {
    return GoogleSignInRequest(
      loginAuthType: 'google',
      apiToken: googleSignInAuthentication?.accessToken,
      photo: googleSignInAccount?.photoUrl,
      firebaseToken: token,
      email: googleSignInAccount?.email,
      appVersion: 2,
    );
  }

  // ignore: long-method
  handleGoogleSignIn() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    try {
      await googleSignIn.disconnect();
      // ignore: empty_catches
    } catch (error) {}
    try {
      var googleSignInAccount = await googleSignIn.signIn();
      // ignore: prefer-correct-identifier-length
      GoogleSignInAuthentication? googleSignInAuthentication =
          await googleSignInAccount?.authentication;
      if (googleSignInAuthentication != null) {
        context.loaderOverlay.show();
        var token = await FirebaseMessaging.instance.getToken();
        var loginResponse =
            await loginRepository.makeGoogleLogin(prepareGoogleLoginRequest(
          googleSignInAuthentication,
          googleSignInAccount,
          token ?? "",
        ));
        processLoginResponse(loginResponse);
        context.loaderOverlay.hide();
      }
    } catch (error) {
      throw Exception("Error making google Sign in");
    }
  }

  processLoginResponse(LoginResponse loginResponse) async {
    if (loginResponse.successLogin == false) {
      alertDialog('error', loginResponse.message ?? "");
    } else {
      var sharePreferences = await SharedPreferences.getInstance();
      sharePreferences.setBool("isLogged", true);
      await UserUtils().getPermissions();
      // ignore: use_build_context_synchronously
      Navigator.of(context)
          .pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
    }
  }

  alertDialog(String type, String message) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: type,
          content: message,
        );
      },
    );
  }

  redirectLogin() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => Login(
        secretSetting: secretSetting,
      ),
    ));
  }

  secretSettingChecker() {
    pressed += 1;
    Timer(const Duration(seconds: 4), () {
      pressed = 0;
    });
    if (pressed == 5) {
      secretSetting = true;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("n3!V0r"),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final copy = AppMessages().getCopy;
    final colors = AppThemeScope.of(context).colors;
    const double fontSizeMd = 22;
    const double textSizeSm = 14;
    const double fontSizeNormal = 16;

    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'geolocation',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset(
                "assets/images/header_nav_bar.png",
                width: double.infinity,
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: () => secretSettingChecker(),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Image.asset(
                          "assets/images/login_header.png",
                          width: 280,
                          height: 280,
                        ),
                      ),
                    ),
                    NvText(
                      //"¡Fortalece los vínculos!",
                      textHolder: copy('welcome.strengthenBonds'),
                      fontFamily: 'Jost',
                      fontWeight: FontWeight.bold,
                      fontSize: fontSizeMd,
                      color: colors.text.primary,
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.63,
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              children: <TextSpan>[
                                TextSpan(
                                  //'Comparte e intercambia',
                                  text:
                                      '${copy("welcome.strengthenBonds-msg1")} ',
                                  style: const TextStyle(
                                    color: AppTheme.coral0Main,
                                    fontSize: fontSizeNormal,
                                    fontFamily: 'Jost',
                                  ),
                                ),
                                TextSpan(
                                  //' los mejores\n servicios de tus vecinos!',
                                  text: copy('welcome.strengthenBonds-msg2'),
                                  style: const TextStyle(
                                    color: AppTheme.black0Main,
                                    fontSize: fontSizeNormal,
                                    fontFamily: 'Jost',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    NvButton(
                      //"Continuar con tu email",
                      label: copy('user-access.continue-with-email'),
                      variant: 'secondary',
                      action: redirectLogin,
                    ),
                    const SizedBox(
                      height: 29,
                    ),
                    if (Platform.isAndroid ||
                        (Platform.isIOS && isIOSGoogleButtonEnabled)) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: 1,
                            width: 50.0,
                            color: Colors.grey,
                            margin: const EdgeInsets.only(right: 8.0),
                          ),
                          NvText(
                            //'O continuar con',
                            copy: 'user-access.continue-with',
                            fontFamily: 'Jost',
                            fontWeight: FontWeight.bold,
                            fontSize: textSizeSm,
                            color: colors.text.primary,
                          ),
                          Container(
                            height: 1,
                            width: 50.0,
                            color: Colors.grey,
                            margin: const EdgeInsets.only(left: 8.0),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          GestureDetector(
                            onTap: handleGoogleSignIn,
                            child: Image.asset(
                              "assets/images/google.png",
                              width: 30,
                              height: 30,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
