import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/login/login_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/login_request.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/crypto_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Password extends StatefulWidget {
  final String email;

  const Password({
    Key? key,
    required this.email,
  }) : super(key: key);

  @override
  State<Password> createState() => _PasswordState();
}

class _PasswordState extends State<Password> {
  bool _isObscure = true;
  final textEditingController = TextEditingController();
  final loginRepository = LoginRepositoryImpl();

  /// Making login request doing the following steps:
  ///
  /// 1. Appearing loading overlay on whole screen.
  /// 2. Preparing [LoginRequest] to be send to API repository.
  /// 3. Hiding loading overlay
  /// 4. Validating response according successLogin bool param.
  /// 5. Storing session value.
  /// 6. Showing error if applies.
  ///
  // ignore: long-method
  makeLogin() async {
    context.loaderOverlay.show();
    var token = await FirebaseMessaging.instance.getToken();
    var loginResponse = await loginRepository.makeLogin(LoginRequest(
      loginAuthType: Constants.formAccess,
      userLogin: widget.email,
      password: CryptoUtils().encrypt(textEditingController.text),
      firebaseToken: token,
      validationCode: "",
    ));
    context.loaderOverlay.hide();
    if (loginResponse.successLogin == false) {
      showLoginError(loginResponse.message);
    } else {
      var sharePreferences = await SharedPreferences.getInstance();
      sharePreferences.setBool("isLogged", true);
      await UserUtils().getPermissions();
      // if (!mounted) return;
      Navigator.of(context)
          .pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
    }
  }

  /// Show default error on native [AlertDialog] alert
  ///
  /// Param:
  /// [String] message to show on [AlertDialog]
  ///
  // ignore: long-method
  showLoginError(String? message) {
    Widget okButton = TextButton(
      child: Text(AppMessages().getCopy('common.accept')), //"Aceptar"
      onPressed: () {
        Navigator.pop(context, false);
      },
    );

    // Set up the AlertDialog.
    AlertDialog alert = AlertDialog(
      title: Text(
        //"Error",
        AppMessages().getCopy('page.core.labelError'),
      ),
      content: Text(message ?? ""),
      actions: [
        okButton,
      ],
    );

    // Show the dialog.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'login',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          //'Ingresar',
          title: AppMessages().getCopy('user-access.login-title'),
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'login',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(
                left: 20,
                bottom: 10,
                right: 20,
                top: 30,
              ),
              child: NvText(
                //"Contraseña",
                textHolder: AppMessages().getCopy('user-access.password-label'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.normal,
                fontSize: 12,
                color: Colors.black,
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 20, bottom: 20, right: 20),
              child: TextField(
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.deny(
                    " ",
                  ),
                ],
                keyboardType: TextInputType.emailAddress,
                maxLines: 1,
                obscureText: _isObscure,
                controller: textEditingController,
                decoration: InputDecoration(
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isObscure ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _isObscure = !_isObscure;
                      });
                    },
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              child: Align(
                alignment: FractionalOffset.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.all(5),
                  child: NvText(
                    //"Olvidé mi contraseña",
                    textHolder:
                        AppMessages().getCopy('user-access.forgot-password'),
                    fontFamily: 'Jost',
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: NvButton(
              //'Ingresar',
              label: AppMessages().getCopy('user-access.login-title'),
              action: makeLogin,
            ),
          ),
        ]),
      ),
    );
  }
}
