import 'dart:async';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/bloc/login/login_bloc.dart';
import 'package:neivor_flutter_app/data/repository/login/login_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/first_mail_request.dart';
import 'package:neivor_flutter_app/presentation/login/confirm_code/confirm_code.dart';
import 'package:neivor_flutter_app/presentation/login/password.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:neivor_flutter_app/widgets/nv_text.dart';

import '../../widgets/nv_alert.dart';

class Login extends StatefulWidget {
  const Login({
    Key? key,
    this.secretSetting,
  }) : super(key: key);
  final bool? secretSetting;

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final textEditingController = TextEditingController();
  int pressed = 0;
  GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();

  // ignore: long-method
  goToPasswordView() async {
    try {
      if (loginFormKey.currentState?.validate() ?? false) {
        var loginRepository = LoginRepositoryImpl();
        context.loaderOverlay.show();
        var firstMailResponse =
            await loginRepository.makeFirstMail(FirstMailRequest(
          email: textEditingController.text,
          digitsCode: true,
          validationCodeLogin: !(widget.secretSetting ?? false),
        ));
        // ignore: use_build_context_synchronously
        BlocProvider.of<LoginBloc>(context).add(NewFirstLogin(
          firstLogin: firstMailResponse.zyosLogin?.firstLogin ?? false,
        ));
        context.loaderOverlay.hide();
        if (firstMailResponse.zyosLogin == null) {
          noUserAliasAlert(
            "warning",
            // "No se ha econtrado un alias de usuario");
            AppMessages().getCopy('user-access.alias-no-found'),
          );
        } else {
          // ignore: use_build_context_synchronously
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => kDebugMode ||
                      textEditingController.text == "apps@neivor.com" ||
                      (widget.secretSetting ?? false)
                  ? Password(
                      email: textEditingController.text,
                    )
                  : ConfirmCode(
                      email: textEditingController.text,
                    ),
            ),
          );
        }
      }
    } catch (error) {
      context.loaderOverlay.hide();
      noUserAliasAlert(
        "error",
        //"Es necesario informar el usuario para poder continuar",
        AppMessages().getCopy('user-access.user-required'),
      );
    }
  }

  /// It shows a dialog with a warning message for 2 seconds and then it disappears.
  void noUserAliasAlert(String alertType, String message) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(seconds: 3), () {
          Navigator.of(context).pop();
        });
        return NvAlert(
          type: alertType,
          content: message,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: prefer-extracting-callbacks
      onWillPop: () {
        Navigator.pushNamedAndRemoveUntil(
          context,
          'selectLogin',
          (Route<dynamic> route) => false,
        );
        return Future.value(false);
      },
      child: Scaffold(
        appBar: NvAppBar(
          title: AppMessages().getCopy('user-access.login-title'), //'Ingresar',
          backAction: () => Navigator.pushNamedAndRemoveUntil(
            context,
            'selectLogin',
            (Route<dynamic> route) => false,
          ),
        ),
        body: Column(children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(
                left: 20,
                bottom: 20,
                right: 20,
                top: 30,
              ),
              child: NvText(
                //"Escribe tu correo electrónico para empezar",
                textHolder:
                    AppMessages().getCopy('user-access.write-e-mail-to-start'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: Colors.black,
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(
                left: 20,
                bottom: 10,
                right: 20,
                top: 10,
              ),
              child: NvText(
                //Correo electrónico",
                textHolder: AppMessages().getCopy('user-access.email-label'),
                fontFamily: 'Jost',
                fontWeight: FontWeight.normal,
                fontSize: 12,
                color: Colors.black,
              ),
            ),
          ),
          Form(
            key: loginFormKey,
            child: Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 20, bottom: 20, right: 20),
                child: TextFormField(
                  // ignore: prefer-extracting-callbacks
                  validator: (value) {
                    if (!EmailValidator.validate(value ?? '') ||
                        (value?.isEmpty ?? true)) {
                      return 'Email no valido';
                    }
                    return null;
                  },
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.deny(
                      " ",
                    ),
                  ],
                  keyboardType: TextInputType.emailAddress,
                  maxLines: 1,
                  controller: textEditingController,
                  decoration:
                      const InputDecoration(hintText: 'Ej: usuario@email.com'),
                ),
              ),
            ),
          ),
          Expanded(
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: NvButton(
                  //'Continuar',
                  label: AppMessages().getCopy('user-access.action-next'),
                  action: goToPasswordView,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
