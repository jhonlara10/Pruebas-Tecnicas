import 'dart:async';
import 'dart:developer';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:neivor_flutter_app/data/repository/login/login_repository_impl.dart';
import 'package:neivor_flutter_app/domain/models/login/first_mail_request.dart';
import 'package:neivor_flutter_app/domain/models/login/login_request.dart';
import 'package:neivor_flutter_app/presentation/login/confirm_code/widgets/digit_box.dart';
import 'package:neivor_flutter_app/presentation/util/app_messages.dart';
import 'package:neivor_flutter_app/presentation/util/constants.dart';
import 'package:neivor_flutter_app/presentation/util/crypto_utils.dart';
import 'package:neivor_flutter_app/presentation/util/user_utils.dart';
import 'package:neivor_flutter_app/theme/app_theme_scope.dart';
import 'package:neivor_flutter_app/widgets/nv_appbar.dart';
import 'package:neivor_flutter_app/widgets/nv_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../widgets/nv_text.dart';

const int tick = 1;

class ConfirmCode extends StatefulWidget {
  final String? email;

  const ConfirmCode({
    Key? key,
    required this.email,
  }) : super(key: key);

  @override
  State<ConfirmCode> createState() => _ConfirmCodeState();
}

class _ConfirmCodeState extends State<ConfirmCode> {
  String? codeNumber;
  Map<String, dynamic>? pinNumbers;
  bool isResendAgain = false;
  bool timeUpFlag = false;
  int timeCounter = 20;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    setDefaultPinNumbersValues();
    timerUpdate();
  }

  setDefaultPinNumbersValues() {
    pinNumbers = {
      'pin1': '',
      'pin2': '',
      'pin3': '',
      'pin4': '',
    };
  }

  /// Validate the code and redirecto to Home View
  ///
  /// Param:
  /// [String] code to validate with the service API
  ///
  // ignore: long-method
  makeLogin(String? code) async {
    try {
      var loginRepository = LoginRepositoryImpl();
      context.loaderOverlay.show();
      var token = await FirebaseMessaging.instance.getToken();
      var loginResponse = await loginRepository.makeLogin(LoginRequest(
        loginAuthType: Constants.validationCode,
        userLogin: widget.email,
        firebaseToken: token,
        validationCode: CryptoUtils().rsaEncrypt(code ?? ""),
      ));
      context.loaderOverlay.hide();
      if (loginResponse.successLogin == false) {
        showLoginError(loginResponse.message);
      } else {
        var sharePreferences = await SharedPreferences.getInstance();
        sharePreferences.setBool("isLogged", true);
        await UserUtils().getPermissions();
        timer?.cancel();
        if (!mounted) return;
        Navigator.of(context)
            .pushNamedAndRemoveUntil('home', (Route<dynamic> route) => false);
      }
    } catch (e) {
      log(e.toString());
    }
  }

  /// Show default error on native [AlertDialog] alert
  ///
  /// Param:
  /// [String] message to show on [AlertDialog]
  ///
  // ignore: long-method
  showLoginError(String? message) {
    Widget okButton = TextButton(
      child: Text(AppMessages().getCopy('common.accept')), //"Aceptar"
      onPressed: () {
        Navigator.pop(context, false);
      },
    );

    // Set up the AlertDialog.
    AlertDialog alert = AlertDialog(
      title: const Text("Error"),
      content: Text(message ?? ""),
      actions: [
        okButton,
      ],
    );

    // Show the dialog.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  /// Redirect to Select Login Screen
  ///
  /// Param:
  /// None
  ///
  // ignore: long-method
  goToSelectLogin() {
    Navigator.of(context).pushNamedAndRemoveUntil(
      'selectLogin',
      (Route<dynamic> route) => false,
    );
  }

  getNumberCode(String num, String key) {
    setState(() {
      pinNumbers?[key] = num;
    });
    if (pinNumbers?['pin1'] != '' &&
        pinNumbers?['pin2'] != '' &&
        pinNumbers?['pin3'] != '' &&
        pinNumbers?['pin4'] != '') {
      var codeToSend = pinNumbers?['pin1'] +
          pinNumbers?['pin2'] +
          pinNumbers?['pin3'] +
          pinNumbers?['pin4'];
      makeLogin(codeToSend);
    }
  }

  timerUpdate() {
    // ignore: prefer-extracting-callbacks
    timer = Timer(const Duration(seconds: tick), () async {
      setState(() {
        timeCounter--;
      });
      if (timeCounter != 0) {
        timerUpdate();
      } else {
        timeUpFlag = true;
      }
    });
  }

  // ignore: long-method
  resendConfirmCode() async {
    var loginRepository = LoginRepositoryImpl();
    context.loaderOverlay.show();
    // Var firstMailResponse =.
    await loginRepository.makeFirstMail(FirstMailRequest(
      email: widget.email,
      digitsCode: true,
      validationCodeLogin: true,
    ));
    context.loaderOverlay.hide();
    setState(() {
      timeUpFlag = false;
      timeCounter = 20;
      timerUpdate();
    });
  }

  goback() {
    timer?.cancel();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final colors = AppThemeScope.of(context).colors;
    const double fontSizeLg = 26;
    const double fontSizeNormal = 16;

    return Scaffold(
      appBar: NvAppBar(
        backAction: goback,
      ),
      body: Container(
        margin: const EdgeInsets.only(
          top: 30.0,
          left: 16.0,
          right: 16.0,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          NvText(
            //"Verifica tu cuenta",
            copy: 'user-access.veryfy-account',
            fontFamily: 'Jost',
            fontWeight: FontWeight.bold,
            fontSize: fontSizeLg,
            color: colors.text.primary,
          ),
          const SizedBox(
            height: 16.0,
          ),
          NvText(
            //"Te hemos enviado un código a tu email:",
            copy:
                'user-access.password-recovery.enter-the-access-code-to-set-the-password',
            fontFamily: 'Jost',
            fontWeight: FontWeight.w400,
            fontSize: fontSizeNormal,
            color: colors.text.primary,
          ),
          NvText(
            textHolder: widget.email,
            fontFamily: 'Jost',
            fontWeight: FontWeight.bold,
            fontSize: fontSizeNormal,
            color: colors.text.primary,
          ),
          const SizedBox(
            height: 40.0,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                DigitBox(
                  stringKey: 'pin1',
                  first: true,
                  last: false,
                  getNumberCode: getNumberCode,
                ),
                DigitBox(
                  first: false,
                  last: false,
                  stringKey: 'pin2',
                  getNumberCode: getNumberCode,
                ),
                DigitBox(
                  stringKey: 'pin3',
                  first: false,
                  last: false,
                  getNumberCode: getNumberCode,
                ),
                DigitBox(
                  stringKey: 'pin4',
                  first: false,
                  last: true,
                  getNumberCode: getNumberCode,
                ),
              ],
            ),
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 15),
                    child: NvButton(
                      label: timeUpFlag
                          //"Reenviar código"
                          ? AppMessages().getCopy('user-access.resend-code')
                          : "${timeCounter}s ${AppMessages().getCopy('user-access.password-recovery.resend-code')}",
                      variant: timeUpFlag ? 'primary' : 'secondary',
                      action: timeUpFlag ? resendConfirmCode : null,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
