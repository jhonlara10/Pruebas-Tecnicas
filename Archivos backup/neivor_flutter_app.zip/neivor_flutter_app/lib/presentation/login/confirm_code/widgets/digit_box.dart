import 'package:flutter/material.dart';

class DigitBox extends StatefulWidget {
  final bool first;
  final bool last;
  final Function getNumberCode;
  final String stringKey;

  const DigitBox({
    Key? key,
    required this.first,
    required this.last,
    required this.getNumberCode,
    required this.stringKey,
  }) : super(key: key);

  @override
  State<DigitBox> createState() => _DigitBox();
}

class _DigitBox extends State<DigitBox> {
  setChangeListener(String value) {
    if (value.isNotEmpty && !widget.last) {
      FocusScope.of(context).nextFocus();
    }
    // ignore: prefer_is_empty
    if (value.isEmpty && !widget.first) {
      FocusScope.of(context).previousFocus();
    }
    widget.getNumberCode(value, widget.stringKey);
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 85,
      child: AspectRatio(
        aspectRatio: .7,
        child: TextField(
          autofocus: true,
          showCursor: false,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
          keyboardType: TextInputType.number,
          maxLength: 1,
          onChanged: (text) {
            setChangeListener(text);
          },
          decoration: const InputDecoration(
            counter: Offstage(),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                width: 1,
                color: Colors.black12,
              ),
              borderRadius: BorderRadius.all(Radius.circular(4)),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                width: 1,
                color: Colors.black,
              ),
              borderRadius: BorderRadius.all(Radius.circular(4)),
            ),
          ),
        ),
      ),
    );
  }
}
